////////////////////////////////////////////////////////////////////////////
//
//  FILE:         readme.txt
//  DATE:         9-Nov-01
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

The DevTools project is an open-source (BSD-licensed) set of development
tools, including a set of shared gmake-style utility makefiles, the TLM
version-control wrapper, and various other little utility C++ programs and
Perl and Python scripts.

The license under which this code is released occurs at the top of most of
the source files in DevTools, as well as in the file license.txt.

Working with the DevTools project
=================================

Startup
-------

NOTE: some of this document (and many other DevTools files, in fact) is
most relevant to internal users of DevTools, so external users should
ignore stuff about things like drive mappings and try to extrapolate
alternative means of getting themselves appropriately configured.

I am going to assume that the installation is to the local directory
c:\devtools, though it's not neccessary. 

The amount of disk space you need is pretty minimal.  You should make sure
to leave some space free (at least 30MB) on your source drive and on the
drive with your temp directory.

Note that removing all built files with a "pmake cleanall" and doing fresh
builds is recommended periodically (maybe even every night).  Less often
(and with the aid of tlm xcheck/xbackup [-f]), you may want to check in all
your files, copy anything else important elsewhere, rm -rf c:\devtools, and
reinstall.

Attach to the wa-netapp01 server.  There is no one convention for what
drives go where.  I use the following mappings.

        F:      \\wa-netapp01\res\sys
        G:      \\wa-netapp01\res\mrec\tools
        H:      \\wa-netapp01\res\home\users\<userid>
        J:      \\wa-netapp01\mreccode
        K:      \\wa-netapp01\res\sys
        L:      \\wa-netapp01\res\home
        N:      \\wa-netapp01\eng\eng1\eng_one
        S:      \\wa-netapp01\res\mrec\release
        V:      \\wa-netapp01\dev1

Some people prefer to attach F: and G: to dragres; engineers typically have
drageng on F: and G:, etc., etc.  If you already have a setup you like,
pick an unused letter for \\wa-netapp01\mreccode.  If you don't, we
recommend you copy somebody else's setup as a starting point.  Mapping
drives in NT from the explorer or from a batch file is fairly
straightforward.

You will want to put g:\bin or n:\bin on your path, and g:\ntbin or
n:\ntbin before that.  This is where most of the useful programs are kept. 
You may want to copy some frequently-used programs to a local drive to
improve speed, but be careful; somebody might fix a bug and put a better
version on the network.  You may want to copy other things so you can
continue work when the network falls over.  And it's possible that you will
need to copy something to make sure you get a version that's compatible
with everything else.  There are no known cases of this at the moment. 
Also, you should make sure you have the current premium M installed locally
somewhere on your path before the old network version, and a good m.cfg to
go with it.

You will need to install TLIB, MSDev 6 with SP5, and Python 2.1 before you
can install and build DevTools.

Once you've installed these apps, you should make sure some relevant
version control/build environment variables are set to reasonable values. 
Here are some examples:

        BIN_DIR=c:\ntbin\
        DTCOMPPRE=inm
        DTCOMPSUF=x
        home=c:\mhome
        include=D:\msdev\vc98\INCLUDE;D:\msdev\vc98\ATL\INCLUDE;
            D:\msdev\vc98\MFC\INCLUDE
        lib=D:\msdev\vc98\LIB;D:\msdev\vc98\MFC\LIB
        M_CHECKOUT=tlm edit
        MSDevDir=D:\msdev\Common\MSDev98
        MSVCDir=D:\msdev\vc98
        PYTHON_DIR=d:\python\
        TEMP=c:\temp
        TLIBID=JohnD
        TLM_TLIBBS_PATH=d:\tlib553f\tlib32c
        TMP=c:\temp
        TOOLBIN=c:\ntbin
        VSCommonDir=D:\msdev\Common

Now you're ready to actually install the source.

Run tlm install without any arguments.  

    c:\> tlm install

Then run it again with actual arguments, as indicated by its first
output.

    [example] 
    c:\> tlm install j:\devtools c:\devtools

Building the Project
--------------------

You can now build the project.

The project currently has one source directory, tools.  We currently only
build using the Microsoft Visual C++ compiler under Windows NT.

A little more advice on standard environment settings: you should either
set DTCOMPPRE=inm and DTCOMPSUF=x, or set ARCHITECTURE=Intel,
OPERATING_SYSTEM=Win32, COMPILER=MS, so your default result of "pmake" will
be the inmx build, and you'll be able to override this with commands like
"pmake DTCOMPSUF=s" or "pmake BUILD=s" (respectively), or with commands
like "pmake DTCOMPDIR=inms" (which will always work.)

For details on the available build types, do "pmake help".  The current
BUILD options as of this writing:
    s (or SHIP)         highest optimization -- least debuggability
    x (or DEBUG)        slow -- debugging options on

For details on the version control system, check out doc\tlm.txt.

The editor of choice is M, partly because it has built-in support for 
checking out files, and partly because it's just a dang nice code editor. 
If you attempt to modify a read-only file, m will offer to attempt to check
it out for you.

////////////////////////////////////////////////////////////////////////////
//
//-DT- *tlib-revision-history*
//-DT- 1 readme.txt 09-Nov-2001,16:17:48,`JOEV2' Initial revision
//-DT- 2 readme.txt 09-Nov-2001,18:04:30,`JOEV2' DevTools version 0.0.3
//-DT-      Created initial versions of root/doc/make.inc files.
//-DT- 3 readme.txt 28-Feb-2002,17:24:40,`JOEV2' DevTools version 0.0.16
//-DT-      Updated network directory references.
//-DT- 4 readme.txt 16-Jun-2003,16:39:22,`JOEV3' DevTools version 0.0.42
//-DT-      Header cleanup.
//-DT- 5 readme.txt 12-Jan-2004,18:36:40,`JOEV4' DevTools version 0.0.82
//-DT-      Fixed up network path references.
//-DT- 6 readme.txt 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//-DT-      lint changes.
//-DT- 7 readme.txt 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//-DT-      Updated current copyright year.
//-DT- *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
