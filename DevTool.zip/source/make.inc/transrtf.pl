############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         transrtf.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Chip Moore)
#  DESCRIPTION:  Perl script used in makefiles to transform RTF files into
#                different forms, including substitution strings,
#                subsetting, and mapping.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# Specification.
#
# ( 1 )  Accept an RTF file and write a new RTF file. The new RTF file is a
# subset of the input RTF file. The header in the input RTF file is always
# written to the new RTF file. For each page of the input RTF file, if that
# page contains one of a set of build tag strings or does not contain a
# footnote, write that page to the output RTF file. An RTF file is binary.
#
# ( 2 )  Accept TIPS.RTF and a MAP file. The MAP file contains a list of tip
# aliases. Write a TIPS file. This is the file used to display tips of the
# day. It contains one tip per line. In the MAP file, following the heading
# "[ALAISES]", there is one tip alias on each line. The order in which the
# tip aliases appear is the order in which the tips associated with the
# aliases will appear in the TIPS file. When reading the MAP file, put the
# aliases, in order, into an array.
#
# For each paragraph in the TIPS.RTF file, grep for each of the tip aliases.
# If a grep succeeds, the tip associated with the matching alias appears in
# the paragraph. Find the tip and add it to an associative array. In this
# associative array, the alias is the key and the tip is the value for that
# key. After reading the TIPS.RTF file, iterate over the ordered list of
# aliases. For each alias, if that alias also appears in the associative
# array, write the tip associated with the alais to the TIPS file. A tip
# alias may appear in the MAP file and not appear in the TIPS.RTF file.
# Likewise, a tip alias may appear in the TIPS.RTF file and not appear in
# the MAP file.
#
# Parameters.
#
# The arguments are passed to the script in a file. The parameter file has
# one argument per line. The parameter file should not contain both a MAP
# parameter and a BUILD_TAGS parameter. If it does, the input RTF file will
# be rewritten to the output file and the TIPS file will not be written.
#
# ( A )  INPUT=Name_of_input_RTF_file.
#
# ( B )  OUTPUT=Name_of_output_RTF_file or Name_of_Tips_File.
#
# ( C )  MAP=Name_of_map_file. This is used write a TIPS file from the
# TIPS.RTF file. It contains, under the heading "[ALIASES]", a list of
# aliases, in the order in which the tip associated with each alias will
# appear in the TIPS file.
#
# ( D )  BUILD_TAGS=List_of_build_tags. This is a string of tokens with each
# token separated by a '|' character. Examples are "BASE" or
# "BASE|YES_SOMETHING".
#
# ( E ) SUBSTITUTIONS=List_of_string_substitution_strings. The strings in
# the list are separated by whitespace. Each string has the form "x=z". Each
# such string is split into a key, "x", and a value, "z". These are put into
# an associative array. Each item written to an output file is searched for
# instances of "x". Each instance of "x" is replaced by "z".

require 5;

#--------------------------------------------------------------------

# Globals

#--------------------------------------------------------------------

# Constants.

$TRUE = 1;
$FALSE = 0;

if ( ( "DEBUG" eq $ENV{ "DDTYPE" } ) || ( $ENV{ "DDCOMPDIR" } =~ /x/ ) )
{

    $DEBUGINFO = 1;

}
else
{

    $DEBUGINFO = 0;

}

#--------------------------------------------------------------------

# Test code here.

#--------------------------------------------------------------------

# Mainline.

#--------------------------------------------------------------------

# Name of input RTF file.
$infile = "";

# Buffer to hold contents of RTF file.
$file = "";

# Name of input tips mapping file and build tips file flag.
$mapfile = "";
$tipsFlag = $FALSE;

# Name of output RTF file.
$outfile = "";

# String containing list of build flags and rewrite RTF file flag.
$buildFlags = "";
$rewriteRTFFlag = $FALSE;

# List of string substitutions.
%subs = ();

# List of #defines
%isDefined = ();

parseArgs( \$infile, \$mapfile, \$tipsFlag, \$outfile, \$buildFlags,
           \$rewriteRTFFlag, \%subs, \%isDefined );

# Rewrite RTF file with set of build flags.

if ( $TRUE == $rewriteRTFFlag )
{
    # Load entire binary RTF file into a string.

    # Temp file.
    my $tf = $ENV{ TEMP }."\\tmp\$\$\$jo.\$\$\$";

    preProcess( $infile, $tf, \%isDefined, $isBinary );

    $file = loadFile( $tf, $TRUE );

    # Delete temp file.
    system( "del $tf" );

    open( OUT, ">$outfile" ) || die "\tCannot open $outfile for output.\n";

    # The output file is binary.
    binmode OUT;

    print "\tProcessing RTF File: $infile\n";

#   The next line replaces a line with the same form that called the 
#   processRTFFile subroutine.
#   processRTFFile2 is a simplified version of processRTFFile that does
#   string substitution of XXXfooXXX and restores the cr/lfs, but does 
#   NOT do Build Tag processing. (It does not use $buildFlags, but I want
#   to keep the signatures of the two routines the same.)

    processRTFFile2( OUT, \$file, $buildFlags, \%subs );

    print "\tFinished Building RTF File: $outfile\n";

}

# Build TIPS file.

elsif ( $TRUE == $tipsFlag )
{

    # Load entire binary RTF file into a string.
    $file = loadFile( $infile, $TRUE );

    open( MAP, "<$mapfile" ) || die "  Cannot find $mapfile for input.\n";
    open( OUT, ">$outfile" ) || die "  Cannot open $outfile for output.\n";

    # The output file is binary.
    binmode OUT;

    print "\tProcessing RTF File: $infile\n";
    print "\tProcessing MAP File: $mapfile\n";

    processTips( MAP, OUT, \$file, \%subs );

    print "\tFinished Building Tips File: $outfile\n";

}

# Program fails. Print usage message.

else
{

    usage();

}

#--------------------------------------------------------------------

# Functions.

#--------------------------------------------------------------------

# Get script parameters. The parameters are passed to the script in a file,
# the single argument on the command line.

sub parseArgs
{

    my ( $rInfile, $rMapfile, $rTipsFlag, $rOutfile, $rBuildFlags,
         $rRewriteRTFFlag, $rSubs, $rIsDefined ) = @_;

    &usage if ( 0 == @ARGV );

    open( PARAM, "<$ARGV[0]" ) ||
        die "  Cannot find $ARGV[0], the parameter file.\n";

    # Get the name of input RTF file, the name of output file and the name
    # of input MAP file. Also, get a list of build flags. The build flags
    # string is a list of tokens, each separated by a '|'. Lastly, get list
    # of string substitutions. These string substitution strings have the
    # form "string1=string2". In an output file, each instance of "string1"
    # will be replaced by "string2". The string substitutions are stored in
    # a associative array.
    while ( <PARAM> )
    {

        # Get name of input RTF file.
        if ( $_ =~ /^INPUT/ )
        {

            chop;
            $$rInfile = substr( $_, length( "INPUT=" ) );
            
        }

        # Get name of output file.
        if ( $_ =~ /^OUTPUT/ )
        {

            chop;
            $$rOutfile = substr( $_, length( "OUTPUT=" ) );
            
        }

        # Get name of input MAP file. Set build tips file flag to $TRUE.
        if ( $_ =~ /^MAP/ )
        {

            chop;
            $$rMapfile = substr( $_, length( "MAP=" ) );
            $$rTipsFlag = $TRUE;
            
        }

        # Get list of build tags. These are also used for preprocessing. Set
        # rewrite RTF file flag to $TRUE.
        if ( $_ =~ /^BUILD_TAGS/ )
        {

            chop;

            # Strip "BUILD_TAGS=" from string.
            $$rBuildFlags = substr( $_, length( "BUILD_TAGS=" ) );

            # Put each of the build flags into a hash table with a value of
            # 1. The hash table is used when preproccessing an RTF file to
            # find those symbols that are defined.
            my @defines = split( /\|/, $$rBuildFlags );
            my $symbol = "";
            foreach $symbol ( @defines )
            {

                $$rIsDefined{ $symbol } = 1;

            }

            # The string might come in looking like this:
            #
            #   BUILD_TAGS=BASE|YES_UI|YES_TTS
            #
            # To match properly, strip off "BUILD_TAGS=" and mangle the
            # sting to look like this:
            #
            #   \s+BASE[};]|\s+YES_UI[};]|\s+YES_TTS[};]            
            $$rBuildFlags = "\\s+".$$rBuildFlags."[};]";
            $$rBuildFlags =~ s/\|/\*/g;
            $$rBuildFlags =~ s/\*/\[};\]|\\s+/g;
    
            $$rRewriteRTFFlag = $TRUE;
            
        }
        
        # Get list of string substitutions and load these into an
        # associative array.
        if ( $_ =~ /^SUBSTITUTIONS/ )
        {

            chop;
            my $subsString = substr( $_, length( "SUBSTITUTIONS=" ) );
            my @subsPairs = split( /\s/, $subsString );

            # Get list of string substitutions. These string substitution
            # strings have the form "string1=string2". In an output file,
            # each instance of "string1" will be replaced by "string2". The
            # string substitutions are stored in a associative array.
            my $entry;
            foreach $entry ( @subsPairs )
            {

                my @pair = split( /=/, $entry );
                # Replace underscore characters with a space characters in
                # string that will be inserted.
                $pair[1] =~tr/_/ /;
                $$rSubs{ $pair[0] } = $pair[1];
                
            }

        }
        
    } # while - loop

} # sub parseArgs

#--------------------------------------------------------------------

# This routine is currently not used. We are retaining it because it may
# be required again in the future.
# Read an RTF file, which is passed in as a reference to a string, the
# string holding the contents of the file. Write to the new RTF file only
# those pages that contain a build flag found in the array of build flags.

# TODO: This is a good question. Why, when I could do a global addition of
# CR/LF before every "\par" in a RTF file, by doing the substitution on the
# $$rRTFFile variable, do I do the substition every time I cut a page from
# the RTF file? This seems brain-dead. Get some test file and test this
# change.

sub processRTFFile
{

    my ( $OUT, $rRTFFile, $buildFlags, $rSubs ) = @_;

    # MS Word may insert formatting codes, enclosed in curly braces, around
    # page breaks in a RTF file. These formatting codes have no function and
    # the curly braces screw up my parsing of an RTF file. I want to remove
    # all of this and retain only the naked page break. I want to replace
    # "{\b0\cf6 \page }" with "\page" or "{\cf6 \page \par }" with "\page
    # \par".
    $$rRTFFile =~ s /{(\\\w+\s*)*\s+\\page(\s+\\par)?\s+}/ \\page $2 /g;
    $$rRTFFile =~ s/\s+\\page\s+/ \\page /g;
    $$rRTFFile =~ s/\s+\\par\s+/ \\par /g;
#   $$rRTFFile =~ s /{(\\\w+\s*)*\s+\\page(\s+\\par)?\s+}/\\page$2/g;

    # Process header of RTF file.
    my $buf = cutAndPaste( $rRTFFile, "\\\\pard" );

    # Remember, we removed every CR/LF character from the input stream when
    # we loaded the file. Now, before printing, we are going to insert a
    # CR/LF character before every instance of "\par" in this buffer.
    $buf =~ s /\\par[^d]/\n$&/g;
    print $OUT $buf;
    
    $buf = "";

    # Process individual pages in RTF file.
    while ( $$rRTFFile =~ /\\page/ )
    {

        # Remove and process individual pages from the input stream. $buf
        # contains the concatenation of the that in the input stream that
        # precedes "\page" (found in the $` variable) and that in the input
        # stream that matches the expression (found in the $& variable). 
        $buf = $`.$&;
        $$rRTFFile = $';
        
        if ( isBuildable( $buf, $buildFlags ) )
        {

            # Remember, we removed every CR/LF character from the input
            # stream when we loaded the file. Now, before printing, we are
            # going to insert a CR/LF character before every instance of
            # "\par" in this buffer.
            $buf =~ s /\\par[^d]/\n$&/g;
            $buf = stringSubs( $buf, $rSubs );
            print $OUT $buf;
            
        }
        
    } # while - loop

    # If last bit of file contains a build tag, write it to the output file.
    # If it does not contain a build tag, close RTF file with a right curly
    # bracket to match left curly bracket at top of file.
    if ( isBuildable( $$rRTFFile, $buildFlags ) )
    {

        # Remember, we removed every CR/LF character from the input stream
        # when we loaded the file. Now, before printing, we are going to
        # insert a CR/LF character before every instance of "\par" in this
        # buffer.
        $buf =~ s /\\par[^d]/\n$&/g;
        $$rRTFFile = stringSubs( $$rRTFFile, $rSubs );
        print $OUT $$rRTFFile;

    }
    else
    {

        print $OUT " }";

    }
    
} # sub processRTFFile

#--------------------------------------------------------------------

# This is a simplified version of the processRTFFile. It does the following:
# Read an RTF file, which is passed in as a reference to a string, the
# string holding the contents of the file. 
# Insert a R/LF character before every instance of "\par" in this buffer.   
# (Remember, we removed every CR/LF character from the input stream when
# we loaded the file.)
# Process the substitution strings passed in as $rSubs
# Write to the new RTF file 

sub processRTFFile2
{

    my ( $OUT, $rRTFFile, $buildFlags, $rSubs ) = @_;

    $$rRTFFile =~ s /\\par[^d]/\n$&/g;
    $$rRTFFile = stringSubs( $$rRTFFile, $rSubs );
    print $OUT $$rRTFFile;
    
} # sub processRTFFile2

#--------------------------------------------------------------------
# Write TIPS file from TIPS.RTF file and TIPMAP.TXT file. The TIPS.RTF file
# is passed in as a reference to a string, the string holding the contents
# of the file.

sub processTips
{

    my ( $MAP, $OUT, $rRTFFile, $rSubs ) = @_;

    my %tipMap = ();
    my @tipAliases = ();

    processMapFile( $MAP, \@tipAliases );
    processTipsRTFFile( $rRTFFile, \@tipAliases, \%tipMap );
    writeTipsFile( $OUT, \@tipAliases, \%tipMap, $rSubs );
    

} # sub processTips

#--------------------------------------------------------------------

# Read TIP MAP file. Following the header "[ALIASES]" is a list of tip
# aliases, one alias per line. Each alias is added to the end of the
# @$rTipAliases array. The order in which tip aliases appear in TIP MAP file
# is the order in which the tips appear in the TIP file.

sub processMapFile
{

    my ( $MAP, $rTipAliases ) = @_;

    my $aliasFlag = 0;

    while ( <$MAP> )
    {

        # Skip blank lines and comment lines. A semi-colon is the comment
        # character. 
        next if ( /^$/ );
        next if ( /^;/ );

        # Add, in order, the aliases for help tips to array.
        if ( $aliasFlag )
        {

            chop;
            push( @$rTipAliases, $_ );
            
        }

        # Find start of tip aliases.
        if ( /^\[ALIASES\]/ )
        {

            $aliasFlag = 1;

        }
        
    } # while - loop

} # sub processMapFile

#--------------------------------------------------------------------

# Read RTF file and find TIPS. The RTF file is passed in as a reference to a
# string, the string holding the contents of the file. Within the RTF file,
# each TIP is preceded by an ALIAS. The RTF file will contain a stream that
# looks like "\v BlahBlahBlah [MICROPHONE_Accuracy] BlahBlahBlah } This is
# the TIP". The ALIAS is "MICROPHONE_Accuracy". The TIP is "This is the
# TIP". The ALIAS and the TIP are added to an associative array. The ALIAS
# is the key. The TIP is the value.

sub processTipsRTFFile
{

    my ( $rRTFFile, $rTipAliases, $rTipMap ) = @_;

    while ( $$rRTFFile =~ /\\par/ )
    {

        my $alias = "";

        # Remove and process individual paragraphs from the input stream.
        # $buf contains the concatenation of the that in the input stream
        # that precedes "\par" (found in the $` variable) and that in the
        # input stream that matches the expression (found in the $&
        # variable). 
        my $buf = $`.$&;
        $$rRTFFile = $';

        if ( "" ne ( $alias = hasString( $buf, $rTipAliases ) ) )
        {

            # The paragraph had better match this expression, otherwise
            # there is a problem in the TIPS.RTF file and we will have to
            # die. What we want is that part of the paragraph that follows
            # the expression. This is the tip string that goes with the
            # alias, followed by the token "\par". What we want is contained
            # in the special perl variable $'. It holds the part of a
            # string that follows a match.
            if ( $buf =~ /\\v[^\{\}]*$alias[^\{\}]*\}/ )
            {

                $buf = substr( $', 0, ( length( $' ) - 4 ) );
                cleanTip( \$buf );
                
            }
            else
            {

                die "Cannot find tip for alias: $alias\n";;
                
            }

            # Put tip into associative array of aliases and tips.
            $$rTipMap{ $alias } = $buf;

        }

    } # while - loop

} # sub processTipsRTFFile

#--------------------------------------------------------------------

# The TIPS file contains one tip per line. The order of the TIPS is the
# order of ALIASES in the array @$rTipAliases. The function iterates over
# this array, looking-up each ALIAS in the associative array %$rTipMap and
# writing the value of the ALIAS to the output file.

# Before writing any string to the output file, make appropriate
# substitutions within the string from the associative array of string
# substitutions. For instance, if the string contains the substring
# "XXXProductNameXXX" and the string substitution array contains the key
# "XXXProductNameXXX", replace the substring "XXXProductNameXXX" with the
# value associated with "XXXProductNameXXX" in the string substitution
# array. 

sub writeTipsFile
{

    my ( $OUT, $rTipAliases, $rTipMap, $rSubs ) = @_;

    my $alias;

    foreach $alias ( @$rTipAliases )
    {

        if ( defined( $$rTipMap{ $alias } ) )
        {

            my $localizedTip = stringSubs( $$rTipMap{ $alias }, $rSubs );
            print $OUT $localizedTip;

        }
        
    }

} # sub writeTipsFile

#--------------------------------------------------------------------

# Remove unwanted junk from a TIP string, such as RTF formatting commands,
# RTF escape characters and unwanted newlines. Also convert RTF
# representation of high-bit characters into characters themselves.

sub cleanTip
{
    my $rTip = shift;

    # Delete any newlines and carriage returns from tip.
    $$rTip =~ s /[\n\r]//g;

    # Replace formatted NaturallySpeaking commands, such as "{ \b Auf}", with
    # the command itself, 'Auf', enclosed in single quotes.
    $$rTip =~ s  /\{\\b\s*([^\}\{]*)\}/'$1'/g;
    # Need to preserve text that is in italics, as above
    $$rTip =~ s  /\{\\i\s*([^\}\{]*)\}/$1/g;

    # \~ is a hard space.  Convert to its ASCII value 0xa0 so that Binary
    # Conversion rule can deal with it.
    $$rTip =~ s/\\~/\\'a0/g;

    #Binary Conversion was here before!!!

    # Remove any other formatting commands. Formatting commands are enclosed
    # in curly braces and always contain some token that begins with a
    # backslash ( '\' ). A curly brace that is preceded by a backslash is
    # not part of a formatting command.

    # The General Prupose cleanup line at the end of this comment is too
    # broad and has been commented out.  I am replacing it with more
    # special-case handling. Even in ENU Word 97 RTF it also did not do the
    # entire trick, as the use of braces has been expanded. (All text is now
    # in braces.) Also, Word 97 frequently puts a \v0 before \par, so the
    # \v0 ends the line being processed, with no closing brace, and fell
    # through here.
    #  $$rTip =~ s /\{[^\}\{]*\\[^\}\{]*\}//g;

    # The following lines are specific to Asian languages and eliminate 
    # RTF that identifies the fonts for different types of characters
    $$rTip =~ s /\{\\[a-z][a-z]ch\\a?f\d\d?//g;
    $$rTip =~ s /\\?..ch\\a?f\d\d? //g;
    $$rTip =~ s /\\?..ch\\a?f\d\d?//g;

    # The following lines clean up curly single and double quotes
    $$rTip =~ s /\\rquote /'/g;
    $$rTip =~ s /\\lquote /'/g;
    $$rTip =~ s /\\rdblquote /"/g;
    $$rTip =~ s /\\ldblquote /"/g;

    # The following line cleans up any inline explicit font size settings
    $$rTip =~ s /\\fs[0-9]{1,2}//g;

    # The following lines clean up language setting information.
    $$rTip =~ s /\{?\\lang10.. //g;
    $$rTip =~ s /\{?\\c[a-z][0-9]{1,2}//g;

    # The following lines are Dutch Specific and clean up language setting
    # information.
    $$rTip =~ s /\\v//g;

    # The following entries were added to fix problems encountered 
    # with RTF generated by Word 97. 
    # Before commenting out the "all purpose clean up" line in a previous
    # Section, they had no effect on most Word 95. Now some of it probably
    # Cleans up Word 95 docs too.
    # Note that these lines still do not cope when a hidden character 
    # style is applied to text and the text is explicitly made unhidden.
    # It may have other fragilities with character styles in general.
    # 1) Delete any instances of {\v0 at end of line. (\v0 turns off
    # hidden text, often precedes a \par in a curly brace expression).
    $$rTip =~ s /\{\\v0$//g;
    # 2) Delete any instances of open curly brace at the start of the 
    # string (that is, at the start of a paragraph).
    $$rTip =~ s /^\{//g;
    # 3) Delete curly braces that are not preceded by a \ (brace chars in
    # text have a preceding \). This code deletes all unwanted braces 
    # except the last brace when there are multiple braces in a row
    $$rTip =~ s /([^\\])[\{\}]/$1/g;
    # 4) Most remaining singleton "bad" curly braces are at end of a string
    $$rTip =~ s /[\{\}]$//g;
    # 5) In German, I'm getting "bad" curly braces at the end of sentences
    # too.
    $$rTip =~ s /([\.:])\{/$1/g;

    # More Special-case Dutch cleanup. Must follow preceding block.
    $$rTip =~ s /\\f1]\{//g;
    $$rTip =~ s /\\f1//g;
    #This one is particularly embarrasing, in here for one just one case.
    $$rTip =~ s /'\.\{/'\./g;
    $$rTip =~ s /\\v//g;

    #In Chinese we are still getting unwanted "{ ". Lets hope that this
    #fixes it without breaking anything.
    $$rTip =~ s /\{ //g;
    $$rTip =~ s /^ //g;
    $$rTip =~ s /([^\0203\0226])\{/$1/g;
    $$rTip =~ s /^\]//g;

    # Delete any escape characters ( '\' ) from tip.
    # This should not be necessary, so I commented out to allow path names 
    # etc. in text.
    # $$rTip =~ s /\\//g;

    # RTF files encode high bit characters, such as a german omlaut 'o' and
    # Japanese (e.g., SJIS) characters with "\'xx" where "xx" is the hex 
    # value of the character and "\'" is the escape sequence. In a TIP,
    # replace "\'f6" with the character represented by "f6".
    $$rTip =~ s /\\\'(..)/pack( "H2", "$1" )/eg;

    # Still more RTF cleanup - remove }0 and 0 at end of tips
    $$rTip =~ s /\{*0$//g;

    # Lastly, compress multiple spaces between tokens into a single space.
    $$rTip =~ tr / //s;

    # Add newline to end of TIP.
    $$rTip = $$rTip."\r\n";
    
} # sub cleanTip

#--------------------------------------------------------------------

# Open and load a file into a string. The file can be opened in either text
# or binary mode.

sub loadFile
{

    my ( $filename, $isBinary ) = @_;

    open( IN, "<$filename" ) || die "\tCannot load $filename.\n";

    # Open in Binary mode.
    if ( $TRUE == $isBinary )
    {

        binmode IN;

    }
    
    # Length of file.
    my $size = -s $filename;

    # Read file into a string.
    my $file = "";
    read( IN, $file, $size );
    close( IN );

    # Remove all CR/LF characters from the input stream. These will
    # reinserted before every "\par" token when writing to the output
    # stream. Currently, the CR/LF characters are being inserted
    # automatically by Word. Automatic insertion of CR/LF characters is
    # screwing-up name substitution and #ifdef processing.
    $file =~ s /[\r\n]//g;
    
    return $file;
    
} # sub loadFile

#--------------------------------------------------------------------

# Accept a handle to an input file and to an output file. Rewrite input file
# to output file in accord with #ifdef - #endif statements in input file.

sub preProcess
{

    my ( $infile, $outfile, $rIsDefined, $isBinary ) = @_;

    open( OUT, ">$outfile" ) ||
        die "\tCannot preprocess $infile to $outfile.\n";

    if ( $TRUE == $isBinary )
    {

        binmode OUT;

    }
    
    # Read file into string.
    my $file = loadFile( $infile, $isBinary );
    #The following deletes font formatting inserted into ifdef statements
    #in Japanese
    $file =~ s/(\[#.*?)\\loch\\f11 /$1/g;

    # Current level of ifdef nesting.
    my $ifdefLevel = 0;
    # Current level of else nesting. This number should never exceed one.
    my $elseLevel = 0;

    # The default printing value is TRUE.
    my @stack = ();
    push( @stack, $TRUE );
    
    while( $file =~
      /\[[^\[\]]*((\#endif)|(\#else)|(\#ifdef)|(\#ifndef))\s*(\w*)[^\[\]]*\]/ )
    {

        # The concatenation of these four variables is the value of #ifdef
        # or #ifndef or #else or #endif currently matched. The value of the
        # variables not matched is "".
        my $match = $2.$3.$4.$5;
        my $symbol = $6;

        # Read value on top of stack in order to know whether or not to
        # print.
        my $stackValue = pop( @stack );
        $stackValue = 0 if ( "" eq $stackValue );

        $file = $';

        if ( $TRUE == $stackValue )
        {

            print OUT $`;

        }

        if ( $match eq "#endif" )
        {

            ( $ifdefLevel > 0 ) ||
                die "$0: #endif with no matching #ifdef in $infile\n";

            # Decrement nesting level.
            $ifdefLevel--;

            # Cancel else nesting.
            $elseLevel = 0;

            # Maintain stack. When reaching the end of a set of #ifdefs,
            # push TRUE on the stack. Printing is the default behavior.
            if ( 0 == $ifdefLevel )
            {

                push( @stack, $TRUE );

            }

            if ( ($DEBUGINFO == 1) )
            {

                print "Parsed '#endif' at line $.";
                print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
                
            }
            
        } #endif

        elsif ( $match eq "#else" )
        {

            ( $ifdefLevel > 0 ) ||
                die "$0: #else with no matching #ifdef in $infile\n";
            ( $elseLevel < 1 ) ||
                die "$0: #else with no matching #ifdef\n";

            # Bump else - nesting level.
            $elseLevel++;

            # Maintain stack.
            # TODO: comment.
            my $priorStackValue = pop( @stack );
            if ( $TRUE == $priorStackValue )
            {

                push( @stack, $priorStackValue );
                push( @stack, !$stackValue );

            }
            else
            {

                push( @stack, $priorStackValue );
                push( @stack, $stackValue );

            }

            if ( ($DEBUGINFO == 1) )
            {

                print "Parsed '#else' at line $.";
                print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
                
            }
            
        } #else

        elsif ( $match eq "#ifdef" )
        {

            # Bump nesting level.
            $ifdefLevel++;

            # Cancel else nesting.
            $elseLevel = 0;

            # Maintain stack. If $symbol is defined and the current state of
            # the stack is TRUE, push the current state followed by TRUE on
            # the stack, else push the current state followed by FALSE on
            # the stack.
            if ( $TRUE == $stackValue )
            {

                push( @stack, $stackValue );
                push( @stack, $$rIsDefined{ $symbol } );

            }
            else
            {

                push( @stack, $stackValue );
                push( @stack, $FALSE );

            }

            if ( ($DEBUGINFO == 1) )
            {

                print "Parsed '#ifdef $symbol' at line $.";
                print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
                
            }
            
        } #ifdef

        elsif ( $match eq "#ifndef" )
        {

            # Bump nesting level.
            $ifdefLevel++;

            # Cancel else nesting.
            $elseLevel = 0;

            # Maintain stack. If $symbol is defined and the current state of
            # the stack is TRUE, push the current state followed by TRUE on
            # the stack, else push the current state followed by FALSE on
            # the stack.
            if ( $TRUE == $stackValue )
            {

                push( @stack, $stackValue );
                push( @stack, !$$rIsDefined{ $symbol } );

            }
            else
            {

                push( @stack, $stackValue );
                push( @stack, $FALSE );

            }

            if ( ($DEBUGINFO == 1) )
            {

                print "Parsed '#ifndef $symbol' at line $.";
                print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
                
            }
            
        } #ifndef

    } # while - loop

    0 == $ifdefLevel || die "#ifdef or #ifndef with no matching #endif\n";
    
    # Finished processing all paragraphs in file. Now print the stub of the
    # file. 
    print OUT $file;
    
    close( OUT );

} # sub preProcess

#--------------------------------------------------------------------

# In a string, find some regular expression. Remove everything in the string
# up to and including that part of the string that matches the regular
# expression. Copy stuff removed into a new string. Return the new string.
# The string passed to the function IS modified. This is the behavior I
# desire.

sub cutAndPaste
{

    my ( $rString, $regexp ) = @_;

    my $buf = "";

    if ( $$rString =~ /$regexp/ )
    {

        # Get everything in $$rString up to and including that part of
        # $$rString that matches the regular expression. That part of the
        # string that matches the regular expression is found in the $&
        # variable. That part of the string that precedes the part of the
        # string that matches the regular expression is found in the $`
        # variable.
        #
        # The input stream is modified. After processing, the $$rString
        # contains only that part of the string that follows the part of the
        # string that matches the regular expression. This is stored in the
        # $' variable. 
        $buf = $`.$&;
        $$rString = $';

    }

    return $buf;
    
} # sub cutAndPaste

#--------------------------------------------------------------------

# For each key in the associative array %$rSubs, if that token appears in the
# string $buf, replace it with the value associated with the key in the
# associative array.

sub stringSubs
{

    my ( $buf, $rSubs ) = @_;
    my ( $key, $value );

    # Iterate over keys in associative array.
    while ( ( $key, $value ) = each %$rSubs )
    {

        $buf =~ s/$key/$value/g;
        
    } # outer while - loop

    return $buf;
    
} # stringSubs

#--------------------------------------------------------------------

# Test if one of the strings in an array of strings appears in another
# string. If so, return matching string. If not, return empty string.

sub hasString
{

    my ( $buf, $rStrings ) = @_;

    my $string = "";

    foreach $string ( @$rStrings )
    {

        if ( $buf =~ /$string/ )
        {

            return $string;

        }
        
    }
    
    return "";

} # sub hasString

#--------------------------------------------------------------------

# Boolean Functions

#--------------------------------------------------------------------

# Function returns TRUE if a page buffer contains one of the build flags in
# the array of build flags or if the page buffer does not contain a
# footnote. If either of these conditions is TRUE, the page buffer should be
# included in the HELP build.

sub isBuildable
{

    my ( $buf, $buildFlags ) = @_;

    return ( ( $buf =~ /$buildFlags/ ) || ( $buf !~ /\*{\\footnote/ ) );
    
} # sub isBuildable

#--------------------------------------------------------------------

# Printing functions.

#--------------------------------------------------------------------

# Print usage message.

sub usage
{

    print STDERR "\n";
    print STDERR "perl5 $0 [parameter file name]\n\n";
    print STDERR "      The parameter file has one argument per line.\n\n";
    print STDERR "      INPUT=[name of input RTF file]\n";
    print STDERR "      OUTPUT=[name of output file]\n";
    print STDERR "      MAP=[name of map file used to make TIPS file]\n";
    print STDERR "      BUILD_TAGS=[string of build tags, " .
        "each separated by a '|' character]\n";
    print STDERR "      SUBSTITUTIONS=[list of string substitutions, " .
        "of the form stringA=stringB]\n";
    print STDERR "      ( Whitespace separates string substitution " .
        "pairs in the list. )\n\n";
    print STDERR "      Do not include a MAP file when rewriting " .
        "an RTF file.\n";
    die "      Do not include a BUILD_TAGS string when writing a TIPS file.\n";
    
} # sub usage

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 transrtf.pl 09-Nov-2001,17:49:40,`JOEV2' Initial revision
#-DT- 2 transrtf.pl 09-Nov-2001,17:54:34,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 transrtf.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 transrtf.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 5 transrtf.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 6 transrtf.pl 04-Feb-2004,19:35:06,`JOEV4' DevTools version 0.0.86
#-DT-      Fixed some high-bit ASCII characters.
#-DT- 7 transrtf.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 8 transrtf.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
