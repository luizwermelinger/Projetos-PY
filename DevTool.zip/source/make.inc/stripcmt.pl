############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         stripcmt.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Steve Squires)
#  DESCRIPTION:  Perl script used in makefiles to strip comments from
#                various text files.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# This perl script is run as
#     perl stripcmt.pl -M{D,C,H,E} [-DFOO[=VALUE]] -i{in} -o{out}
# (NOTE: For use in batch files, '#' may be used instead of '=')
#
# It is intended for stripping comments out of files before they are shipped
# to where customers can read them and for conditional inclusion of
# features.
#
# If -MD is specified (the mode used for .dvc files such as global.dvc) it
# does a file copy, removing all lines that start with # or white space
# followed by # (except for # directives).
#
# If -MC is specified (the mode used for .cnt files such as dragon.cnt), then
# the removal criterion is that lines start with a semicolon.  Also, #
# directives are parsed slightly differently than with -MD; rather than
# "#ifdef X" and "#endif", expressions like "3 #ifdef X=0" and "#endif=0"
# are used.  This is done in order to allow the .cnt files to be used
# directly by RoboHelp in addition to being preprocessed during the build
# process.  Furthermore, when taking "-DFOO#VALUE" definitions from the
# command line, VALUE has any underscores replaced with spaces before being
# inserted.
#
# If -MH is specified (the mode used for .hpj files such as dragon.hpj),
# then the removal criterion is that lines start with a semicolon.  #
# directives are parsed as with -MD.  Furthermore, when taking "-DFOO#VALUE"
# definitions from the command line, VALUE has any underscores replaced with
# spaces before being inserted.
#
# If -ME is specified (the mode used for .def files such as mrec.def),
# then the removal criterion is that lines start with a semicolon.  #
# directives are parsed as with -MD.
#
# You may also supply any number of argument pairs of the form "-DFOO" or
# "-DFOO=VALUE" or "-DFOO#VALUE" to control conditional code within the
# file.  "-DFOO" defines FOO to be the empty string.
#
# In the file, the syntax is
#     #ifdef FOO
#         code to conditionally include
#     #endif
#
# The following standard C # directives are supported: #ifdef, #ifndef,
# #endif, #else, #define, #undef. In addition, #redefine is available,
# which is a synonym for #undef followed by #define.
#
# Differences from C:
# 1. Important! To cause a defined symbol FOO to be replaced with its
#    definition, use $(FOO).
# 1. #define won't define macros with arguments.
# 2. #define will cause substitutions within strings.
# 3. No space is allowed between a '#' and the name of the directive.
#    This is so that comments aren't confused with directives.
#
# There is an additional pair of # directives supported: #macro, #endmacro.
# The syntax is
#     #macro SYMBOL
#         lines of code to insert
#     #endmacro
# To invoke a macro, put SYMBOL on a line by itself. This is exactly
# like inserting the lines at that point. Any macro/define invocations
# within a macro will be parsed in the context of the insertion point.
#
# In addition, you can package up any subset of arguments (separated
# by white space) into a file and pass it on the command line as '@file'.

$replaceUnderscoreInDefineValue = '_';
$formatSet = 0;

while( @ARGV )
{
    $_ = shift;

    if( /^-M([DCHE])$/ )
    {
        $localFormat = $1;
        if( $formatSet == 1 )
        {
            die "Format already specified before argument $_";
        }
        $formatSet = 1;
        if( $localFormat eq 'D' )
        {
            $commentExpr = '^[ \t]*(#|$)';
            $beforeDirectiveExpr = '^\s*';
        }
        elsif( $localFormat eq 'C' )
        {
            $commentExpr = '^;';
            $beforeDirectiveExpr = '^\d+ ';
            $replaceUnderscoreInDefineValue = ' ';
        }
        elsif( $localFormat eq 'H' )
        {
            $commentExpr = '^;';
            $beforeDirectiveExpr = '^\s*';
            $replaceUnderscoreInDefineValue = ' ';
        }
        elsif( $localFormat eq 'E' )
        {
            $commentExpr = '^;';
            $beforeDirectiveExpr = '^\s*';
        }
        else
        {
            die "Unexpected format in argument $_";
        }
        next;
    }
    
    if( /^-D(\w+)[=#](\S+)$/ )
    {
        $localDefineName = $1;
        $localDefineVal = $2;
        $localDefineVal =~ s/_/$replaceUnderscoreInDefineValue/g;
        setDefinition( $localDefineName, $localDefineVal );
        next;
    }

    if( /^-D(\w+)$/ )
    {
        setDefinition( $1 );
        next;
    }

    if( /^-i(\S+)$/ )
    {
        $inputFile = $1;
        next;
    }

    if( /^-o(\S+)$/ ) {
        $outputFile = $1;
        next;
    }

    if( /^@(\S+)/ ) {
        $atFile = $1;
        open( $atFile, $atFile ) or die "Can't open '$atFile' ($!)";
        @newArgs = ();
        while( <$atFile> )
        {
            # Read white-space-separated arguments.
            @argsOnLine = split( /\s+/ );
            push( @newArgs, @argsOnLine );
        }
        close( $atFile );
        # Insert the new arguments at the head of the queue.
        unshift( @ARGV, @newArgs );
        next;
    }

    die "Invalid argument $_";
}

defined( $inputFile ) and
defined( $outputFile ) and
defined( $commentExpr ) and
defined( $beforeDirectiveExpr ) and
$formatSet == 1 or
die "Usage: perl stripcmt.pl -M{D,C,H} [-D{symbol}[={value}]] -i{in} -o{out}";

print "Stripping comments from '$inputFile' to '$outputFile'\n";

open( IN, "<$inputFile" ) || die "Can't open $inputFile ($!)\n";
( ! -e $outputFile ) || ( -w $outputFile ) || chmod 0666, $outputFile;
open( OUT, ">$outputFile" ) || die "Can't open $outputFile ($!)\n";

$ifdefExpr = $beforeDirectiveExpr . '#ifdef\s+(\w+)';
$ifndefExpr = $beforeDirectiveExpr . '#ifndef\s+(\w+)';
$endifExpr = $beforeDirectiveExpr . '#endif\b';
$elseExpr = $beforeDirectiveExpr . '#else\b';
$defineExpr = $beforeDirectiveExpr . '#define\s+(\w+)\s*$';
$defineValueExpr = $beforeDirectiveExpr . '#define\s+(\w+)\s+(\S.*)$';
$macroExpr = $beforeDirectiveExpr . '#macro\s+(\w+)';
$endmacroExpr = $beforeDirectiveExpr . '#endmacro';
$undefExpr = $beforeDirectiveExpr . '#undef\s+(\w+)';
$redefineExpr = $beforeDirectiveExpr . '#redefine\s+(\w+)\b(.*)\s*$';

$ndefLevel = 0; # level of ifdef that isn't satisfied
$ifdefLevel = 0; # current level of ifdef nesting
# if ndefLevel > 0, then we're not printing.

# Change the below from 0 to 1 to get debug info.
$debugInfo = 0;

# Read in whole file
@lines = <IN>;

LINE:
while( $_ = shift( @lines ) )
{
    # is line an '#ifdef SYMBOL'?
    if ( ($symbol) = /$ifdefExpr/ )
    {
        # bump nesting level
        $ifdefLevel++;

        # we only care about symbol if we're printing
        if ( ($ndefLevel == 0) )
        {
            # Are we defined?
            if( !&isDefined( $symbol ) )
            {
                $ndefLevel = $ifdefLevel;
            }
        }

        if ( ($debugInfo == 1) )
        {
            print "Parsed '#ifdef $symbol' at line $. " .
                  "($ifdefLevel,$ndefLevel).\n";
        }
        
        next;
    }

    # is line an '#ifndef SYMBOL'?
    if ( ($symbol) = /$ifndefExpr/ )
    {
        # bump nesting level
        $ifdefLevel++;

        # we only care about symbol if we're printing
        if ( ($ndefLevel == 0) )
        {
            # Are we defined?
            if( &isDefined( $symbol ) )
            {
                $ndefLevel = $ifdefLevel;
            }
        }

        if ( ($debugInfo == 1) )
        {
            print "Parsed '#ifndef $symbol' at line $. " .
                  "($ifdefLevel,$ndefLevel).\n";
        }
        
        next;
    }

    # does line start with '#endif'?
    if ( /$endifExpr/ )
    {
        ( $ifdefLevel > 0 ) or die "#endif with no matching #ifdef";
        # if it matches the outermost failing ifdef, cancel the ndef.
        if( $ifdefLevel == $ndefLevel )
        {
            $ndefLevel = 0;
        }
        $ifdefLevel--;

        if ( ($debugInfo == 1) )
        {
            print "Parsed '#endif' at line $. ($ifdefLevel,$ndefLevel).\n";
        }
        
        next;
    }

    # does line start with '#else'?
    if ( /$elseExpr/ )
    {
        ( $ifdefLevel > 0 ) or die "#else with no matching #ifdef";
        # if it matches the outermost failing ifdef, cancel the ndef.
        if( $ifdefLevel == $ndefLevel )
        {
            $ndefLevel = 0;
        }
        # else make the nfdef if not already set
        elsif( $ndefLevel == 0 )
        {
            $ndefLevel = $ifdefLevel;
        }

        if ( ($debugInfo == 1) )
        {
            print "Parsed '#else' at line $. ($ifdefLevel,$ndefLevel).\n";
        }
        
        next;
    }

    if( $ndefLevel == 0 )
    {

        # is line a '#define SYMBOL'?
        if ( ($symbol) = ( /$defineExpr/ ) )
        {

            &setDefinition( $symbol );

            if ( ($debugInfo == 1) )
            {
                print "Parsed '#define $symbol' at line $..\n";
            }
            
            next;
        }

        # is line a '#define SYMBOL VALUE'?
        if ( ($symbol, $value) = ( /$defineValueExpr/ ) )
        {

            &setDefinition( $symbol, $value );

            if ( ($debugInfo == 1) )
            {
                print "Parsed '#define $symbol $value' at line $..\n";
            }
            
            next;
        }

        # is line a '#macro SYMBOL'?
        if( ($symbol) = ( /$macroExpr/ ) )
        {
            # Value is concatenation of following lines up to #endmacro
            $value = '';
            for(;;)
            {
                ( $_ = shift( @lines ) ) or die "#macro without #endmacro";
                last if /$endmacroExpr/;
                $value = $value . $_;
            }

            &setMacro( $symbol, $value );

        }
        
        # is line an '#undef SYMBOL'?
        if ( ($symbol) = ( /$undefExpr/ ) )
        {
            # error to undef an undefined a symbol
            $isDefined{ $symbol } or die "Undef of undefined symbol '$symbol'";

            delete( $definition{ $symbol } );
            delete( $macro{ $symbol } );
            delete( $isDefined{ $symbol } );

            if ( ($debugInfo == 1) )
            {
                print "Parsed '#undef $symbol' at line $..\n";
            }
            
            next;
        }

        # '#redefine SYMBOL x' is like
        # '#undef SYMBOL' followed by '#define SYMBOL x'
        if ( ($symbol, $rest) = ( /$redefineExpr/ ) )
        {
            unshift( @lines, "#define $symbol$rest\n" );
            unshift( @lines, "#undef $symbol\n" );
            next;
        }

        # skip comment lines
        if ( /$commentExpr/ )
        {
            next;
        }

        # handle macros
        $macroName = "";
        $macro = "";
        while ( ($symbol, $macroLines) = each %macro )
        {
            # find longest matching macro so that line like SET_FONT_FACE1
            # doesn't get confused with SET_FONT_FACE.
            if( ($m) = (/^\s*$symbol\s*$/) )
            {
                if ( length($m) > length($macroName) )
                {
                    $macroName = $m;
                    $macro = $macroLines;
                }
            }
        }

        if ( $macroName ne "" )
        {
            @macroSplit = split( /\n/, $macro );
            # put the \n's back:
            @macroLines = ();
            foreach $line (@macroSplit)
            {
                push( @macroLines, $line . "\n" );
            }
            # put macro lines at front of queue
            unshift( @lines, @macroLines );

            # and process those lines
            next LINE;
        }

        # Do symbolic replacement (recursively!)
        while ( ($symbol, $value) = each %definition )
        {
            if( s/\$\($symbol\)/$value/ )
            {
                unshift( @lines, $_ );
                # need to empty out the iterator
                while( each %definition ) {}
                next LINE;
            }
        }
        # Make sure we've got everything
        !/\$\((\w+)\)/ or die "'$1' not defined";
        
        print OUT $_;
    }
}

( $ifdefLevel == 0 ) or die "#ifdef without matching #endif";

sub setDefinition
{
    ( $symbol, $value ) = @_;
    defined( $symbol ) or die "Bug in perl script";

    !$isDefined{ $symbol } or die "Redefinition of symbol '$symbol'";

    if( defined( $value ) ) {
        $definition{ $symbol } = $value;
    }
    else {
        $definition{ $symbol } = '';    # empty string
    }
        
    $isDefined{ $symbol } = 1;
}

sub setMacro
{
    ( $symbol, $value ) = @_;
    defined( $value ) or die "Bug in perl script";

    !$isDefined{ $symbol } or die "Redefinition of symbol '$symbol'";

    $macro{ $symbol } = $value;
    $isDefined{ $symbol } = 1;
}

sub isDefined
{
    ( $symbol ) = @_;
    defined( $symbol ) or die "Bug in perl script";

    return $isDefined{ $symbol };
}

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 stripcmt.pl 09-Nov-2001,17:35:30,`JOEV2' Initial revision
#-DT- 2 stripcmt.pl 09-Nov-2001,17:54:28,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 stripcmt.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 stripcmt.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 5 stripcmt.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 6 stripcmt.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 7 stripcmt.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
