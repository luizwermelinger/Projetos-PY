############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         linterr.py
#  DATE:         13-Mar-03
#  AUTHOR:       Steven Sillis
#  DESCRIPTION:  Parses a file, prints error messages if a line exceeds 79
#                characters, ignoring lines between tlib-revison-history
#
# Copyright (c) 2003-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# standard modules
#
import sys
import os
from time import time
import re
import sets
import string
import pdb
# local modules
#
import lintutil
import lintproj

# declare global constants
#
gTotalTime = 0
gError = 0
gNonPrintableRE = re.compile("[^\t\r\n -~]")

# string formats
#
gLongLineErr = "line exceeds %d characters." % (lintutil.gMaxLength - 1)
gNonSynTabErr = "line contains one or more non-syntactic tabs."
gTabErr = "line contains one or more tabs."
gNonPrintableErr = "line contains one or more non-printable chars."
gBadCopyrightHolderErr = "copyright holder is wrong."
gBadCopyrightDateErr = "copyright date range is wrong."
gNoCopyrightErr = "no copyright in header."
gBadHdrErr = "invalid or missing header, run linthdr.py."
gNoRevHistErr = "no revision history"

gHdrTradeSecretMessagePrefixFmt = "%s Trade secret of "
gHdrCopyrightMessagePrefixFmt = "%s Copyright (c) "
gHdrCopyrightMessageSuffixFmt = "%s  All rights reserved."
gHdrBSDNeitherMessagePrefixFmt = "%s     Neither the name of "
gHdrBSDLicensedFmt = (
    "%s Redistribution and use in source and binary forms, with or without")

# commandline parsing and usage message
#
gCmdShortSwitches = "f:d:?"
gCmdLongSwitches = ["file=", "dir=", "help"]
gCmdSwitchMap = {"-f" : "--file",
                 "-d" : "--dir",
                 "-?" : "--help"}
gUsageFmt = """
Usage:
  %s <switches> <arguments>

Switches:
  -f<list file>     input file containing list of filenames to check
  -d<directory>     directory with respect to which the list entries should
                    be interpreted, rather than the current directory
  -?                show this help message

Arguments:
  <file>            filename to check

Notes:
  * arguments should be provided only after all the switches
  * any number of filename arguments can be provided
  * file argument can use wildcards
  * the -d (--dir=) switch only applies to the -f (--file=) list file
  * if a switch is provided multiple times, only its last value is used
"""

# print file(line): message
#
def printMsg(fileName, line, msg):
    global gError
    gError = 1
    print '%s(%d): ***error*** : %s' % (fileName, line, msg)

# check the lines in a given file for inconsistencies
#
def checkLines(file, boundChar, bIsMakefile, bHasLongLines,
               bHasNonPrintableChars):
    fileName = file.name
    tradeSecretMessagePrefix = gHdrTradeSecretMessagePrefixFmt % boundChar
    copyrightMessagePrefix = gHdrCopyrightMessagePrefixFmt % boundChar
    copyrightMessageSuffix = (
        gHdrCopyrightMessageSuffixFmt % lintproj.gCopyrightHolderPeriod)
    copyrightMessageSuffix2 = (
        gHdrCopyrightMessageSuffixFmt %
        lintproj.gAlternateCopyrightHolderPeriod)
    bsdNeitherMessagePrefix = gHdrBSDNeitherMessagePrefixFmt % boundChar
    bsdLicense = gHdrBSDLicensedFmt % boundChar
    quickRevHistLine = " *tlib-revision-history*"
    revHistLine = boundChar + quickRevHistLine
    dtRevHistLine1 = boundChar + "-DT-" + quickRevHistLine
    # some projects put a space in there
    dtRevHistLine2 = boundChar + " -DT-" + quickRevHistLine
    
    histLineFlag = 0
    hdrFlag = 0
    bValidHeader = False
    bFoundCopyright = False
    counter = 0
    for line in file:
        counter += 1

        # make sure we accept the first tab for a line in a makefile
        if bIsMakefile and line[0] == "\t":
            line = "        " + line[1:]

        find = line.find

        # stateful check on a valid header in the correct format, where the
        # correct format means the file begins with a contiguous block of
        # lines beginning with boundChar contains a trade secret or
        # copyright message
        if hdrFlag < 2:
            if find(boundChar) == 0:
                if hdrFlag == 0:
                    hdrFlag = 1
            elif hdrFlag == 1:
                hdrFlag = 2

            if( hdrFlag == 1
                and (find(tradeSecretMessagePrefix) == 0 or
                     find(bsdLicense) == 0)):
                bValidHeader = True
            
            if( hdrFlag == 1
                and find(tradeSecretMessagePrefix) == 0 ):
                currLen = len(tradeSecretMessagePrefix)
                if( find(lintproj.gCopyrightHolderPeriod) != currLen ):
                    printMsg(fileName, counter, gBadCopyrightHolderErr)
                
            if( hdrFlag == 1
                and find(copyrightMessagePrefix) == 0 ):
                currLen = len(copyrightMessagePrefix)
                assert len(lintproj.gCopyrightCurrentYear) == 4
                assert lintproj.gCopyrightCurrentYear.isdigit()
                if( line[currLen : currLen + 5] ==
                    lintproj.gCopyrightCurrentYear + " " ):
                    currLen += 5
                    if( find(copyrightMessageSuffix) != currLen and
                        find(copyrightMessageSuffix2) != currLen ):
                        printMsg(fileName, counter, gBadCopyrightHolderErr)
                elif( line[currLen + 4 : currLen + 4 + 6] ==
                      "-" + lintproj.gCopyrightCurrentYear + " " ):
                    if( line[currLen : currLen + 4] ==
                        lintproj.gCopyrightCurrentYear
                        or not line[currLen : currLen + 4].isdigit() ):
                        printMsg(fileName, counter, gBadCopyrightDateErr)
                    currLen += 4 + 6
                    if( find(copyrightMessageSuffix) != currLen and
                        find(copyrightMessageSuffix2) != currLen ):
                        printMsg(fileName, counter, gBadCopyrightHolderErr)
                else:
                    printMsg(fileName, counter, gBadCopyrightDateErr)
                bFoundCopyright = True
            
            if( hdrFlag == 1
                and find(bsdNeitherMessagePrefix) == 0 ):
                currLen = len(bsdNeitherMessagePrefix)
                if( find(lintproj.gCopyrightHolder) != currLen and
                    find(lintproj.gAlternateCopyrightHolder) != currLen):
                    printMsg(fileName, counter, gBadCopyrightHolderErr)
                
        # note: we allow two lines of anything before requiring header
        # since some scripts have to do something before any commentary
        if not bValidHeader and counter > 2 and hdrFlag != 1:
            printMsg(fileName, counter, gBadHdrErr)
            bValidHeader = True

        if not bFoundCopyright and counter > 2 and hdrFlag > 1:
            printMsg(fileName, counter, gNoCopyrightErr)
            bFoundCopyright = True
            
        # check for tabs
        if not bHasNonPrintableChars and find("\t") != -1:
            if bIsMakefile:
                printMsg(fileName, counter, gNonSynTabErr)
            else:
                printMsg(fileName, counter, gTabErr)

        # stateful skipping of the tlib section which is permitted to have
        # long lines
        if histLineFlag < 2:
            # the find here is expensive since the revision history comes
            # at the end of most files; first clause shortcircuits in one
            # test most lines which are guaranteed to also fail the other
            # checks, which, prior to the introduction of the early out
            # optimization, were the most expensive part of this function
            if( find(quickRevHistLine) != -1
                and (find(revHistLine) != -1
                     or find(dtRevHistLine1) != -1
                     or find(dtRevHistLine2) != -1) ):
                    histLineFlag += 1
            if histLineFlag == 1:
                continue

        # check non-printable only outside of the tlib section, since we
        # wouldn't be able to fix those even if we wanted to.
        if not bHasNonPrintableChars and gNonPrintableRE.search(line):
            printMsg(fileName, counter, gNonPrintableErr)

        # check line length
        if not bHasLongLines and len(line) > lintutil.gMaxLength:
            printMsg(fileName, counter, gLongLineErr)
                    
    if histLineFlag < 2:
        printMsg(fileName, counter, gNoRevHistErr)


# check a single input file
#
def checkFile(dirName, fileName, counter):
    global gTotalTime
    global gError
    boundChar, bIsMakefile, bHasLongLines, bHasNonPrintableChars = (
        lintutil.getBoundCharAndFlags(fileName))
    fileName = os.path.join(dirName, fileName).replace(os.altsep, os.sep)
    if boundChar is None:
        return 0
    try:
        fileObj = file(fileName, 'rU')
    except IOError, e:
        print "Skipped %s(%d): %s" % (fileName, counter, e)
        gError = 1
        return 0
        
    t = time()
    checkLines(fileObj, boundChar, bIsMakefile, bHasLongLines,
               bHasNonPrintableChars)
    gTotalTime += time() - t
    fileObj.close()
    return 1

# process the input data
#
def processFiles(argv):
    global gTotalTime

    isfile = os.path.isfile
    isdir = os.path.isdir
    splitext = os.path.splitext
    
    # parse the commandline
    opts, args = lintutil.parseCmdLine(argv[1:],
                                       gCmdShortSwitches,
                                       gCmdLongSwitches,
                                       gCmdSwitchMap,
                                       gUsageFmt % argv[0])
    get = opts.get
    
    # check that at least an argument file or a list file is specified
    listFileName = get("--file", None)
    if not listFileName and len(args) == 0:
        sys.exit(gUsageFmt % argv[0])

    # initialize counters
    nFiles = 0
    nProcessed = 0
    
    # if a list file is specified, process it first
    if listFileName:
        if not isfile(listFileName):
            raise "Error: %s is not a valid file" % listFileName
        
        # check if a directory is specified
        dirName = get("--dir", "")
        if dirName and not isdir(dirName):
            raise "Error: %s is not a valid directory" % dirName

        # open the list file, could raise an io exception
        listFile = file(listFileName)
        # process each line
        for fileName in listFile:
            #pdb.set_trace()
            nFiles += 1
            fileName = fileName.strip()
            if lintproj.allowCheckOrFixFile(fileName):
                nProcessed += checkFile(dirName, fileName, nFiles)
        listFile.close()

    # process argument files if any are provided
    for fileName in args:
        nFiles += 1
        nProcessed += checkFile("", fileName.strip(), nFiles)

    # print final statistics
    if nProcessed:
        print "Processed %d of %d files in %.4fs (avg per file: %.4fs)" % (
            nProcessed, nFiles, gTotalTime, gTotalTime/nProcessed)
        
# main function
#
if __name__ == "__main__":
    processFiles(sys.argv)
    sys.exit(gError)
    
############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 linterr.py 13-Dec-2006,22:24:30,`JOEV' Initial revision
#-DT- 2 linterr.py 14-Dec-2006,07:58:28,`JOEV' DevTools version 0.0.180
#-DT-      lint changes.
#-DT- 3 linterr.py 14-Dec-2006,14:21:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 4 linterr.py 14-Dec-2006,15:04:52,`JOEV' DevTools version 0.0.182
#-DT-      lint changes.
#-DT- 5 linterr.py 15-Dec-2006,15:25:12,`JOEV' DevTools version 0.0.183
#-DT-      lint enhancement.
#-DT- 6 linterr.py 02-Jan-2007,04:20:38,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- 7 linterr.py 02-Jan-2007,05:25:26,`JOEV' DevTools version 0.0.186
#-DT-      Minor lint enhancement and cleanup.
#-DT- 8 linterr.py 02-Jan-2007,05:37:20,`JOEV' DevTools version 0.0.188
#-DT-      Minor fix.
#-DT- 9 linterr.py 02-Jan-2007,05:56:00,`JOEV' DevTools version 0.0.189
#-DT-      Minor fix.
#-DT- *tlib-revision-history*
#
############################################################################
