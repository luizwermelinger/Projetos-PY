############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         transhm.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Hal Lichtin)
#  DESCRIPTION:  Perl script used in makefiles to convert a .hm file
#                intended for WinHelp into a .h style file intended for HTML
#                help.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

require 5;

# Constants.

$TRUE = 1;
$FALSE = 0;
print "Entering Transhm";

$hmfile = @ARGV[0];
if (-f $hmfile) {
   $file = loadFile( $hmfile, $TRUE );
   print "hmfile = $hmfile";
   $file =~ s/^(.*)/#define $1/gm; 
   open( OUT, ">$hmfile" ) || die "\tCannot open $hmfile for output. $! \n";
   binmode OUT;
   print OUT $file; 
   close(OUT) || die "\tCannot close output file $outfile. $!$ \n";
}

#----------------------------------------
#Subroubtines
#----------------------------------------

# Open and load a file into a string. The file can be opened in either text
# or binary mode.

sub loadFile
{
   my ( $filename, $isBinary ) = @_;
   open( IN, "<$filename" ) || die "\tCannot open $infile for input. $! \n";
   
   # Open in Binary mode.
   if ( $TRUE == $isBinary ) { 
      binmode IN;
   }
   
   # Length of file.
   my $size = -s $filename;
   # Read file into a string.
   my $file = "";
   read( IN, $file, $size );
   close(IN) || die "\tCannot close input file $infile. $! \n";
   return $file;
} # sub loadFile

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 transhm.pl 09-Nov-2001,17:40:18,`JOEV2' Initial revision
#-DT- 2 transhm.pl 09-Nov-2001,17:54:32,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 transhm.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 transhm.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 5 transhm.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 6 transhm.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
