############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         compile.py
#  DATE:         26-Jun-03
#  AUTHOR:       Doug Napoleone
#  DESCRIPTION:  Compile a set of python files into pyc or pyo form
#
# Copyright (c) 2003-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

"""Compile a set of python files into pyc or pyo form
"""

import os
import stat
import sys
import py_compile
import warnings

_gbVerbose = False

def _showwarning(message, category, filename, lineno, file=None):
    """Hook to write a warning; replaces warnings.showwarning()."""
    raise category, warnings.formatwarning(message,
                                           category, filename, lineno)
    
warnings.showwarning = _showwarning

def compile_one(pyfile, outdir, force):
    """compile a given python file into its pyc or pyo form, with a
    specific output location and checking to see if the target file
    is older than the base file (unless force is set)."""
    global _gbVerbose
    success = 1
    if os.path.isfile(pyfile):
        head, tail = pyfile[:-3], pyfile[-3:]
        ok = 1
        if tail == '.py':
            cfile = pyfile + (__debug__ and 'c' or 'o')
            if outdir is not None:
                cfile = outdir + os.sep + os.path.basename(cfile)
            ftime = os.stat(pyfile)[stat.ST_MTIME]
            try:
                ctime = os.stat(cfile)[stat.ST_MTIME]
            except os.error:
                ctime = 0
            if (ctime > ftime) and not force:
                return 1
            if _gbVerbose:
                print 'Compiling', pyfile, '...'
            try:
                py_compile.compile(pyfile, cfile, None, True)
            except KeyboardInterrupt:
                raise KeyboardInterrupt
            except py_compile.PyCompileError, e:
                print e.msg
                success = 0
            except:
                # XXX py_compile catches SyntaxErrors
                if type(sys.exc_type) == type(''):
                    exc_type_name = sys.exc_type
                else: exc_type_name = sys.exc_type.__name__
                print 'ERROR:', exc_type_name + ':',
                print sys.exc_value
                success = 0
        else:
            print 'ERROR:', pyfile, 'is not a python file.'
            success = 0
    else:
        print 'ERROR:', pyfile, 'could not be found.'
        success = 0
    return success

def _main(argv):
    """Script main program."""
    global _gbVerbose
    import getopt
    badargs = None
    try:
        opts, args = getopt.getopt(argv[1:], 'vfd:')
    except getopt.error, msg:
        badargs = msg
    force = 0
    outputDir = None
    if not badargs:
        for o, a in opts:
            if o == '-v': _gbVerbose = True
            if o == '-f': force = 1
            if o == '-d': outputDir = a
        if not len(args):
            badargs = "ERROR: Missing required files"
    if badargs:
        print badargs
        print "usage: python %s " % argv[0] + "[-v] [-f] [-d] file1 file2 ..." 
        print "-v         : verbose output"
        print "-f         : force recompile"
        print "-d outdir  : compile specified files to this directory"
        print "(e.g. python %s foo.py ../lib/base.py)" % argv[0]
        sys.exit(2)
    for file in args:
        if not compile_one(file, outputDir, force):
            return 0
    return 1

if __name__ == '__main__':
    exit_status = not _main(sys.argv)
    sys.exit(exit_status)

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 compile.py 13-Dec-2006,22:24:30,`JOEV' Initial revision
#-DT- 2 compile.py 14-Dec-2006,07:58:28,`JOEV' DevTools version 0.0.180
#-DT-      lint changes.
#-DT- 3 compile.py 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 4 compile.py 02-Jan-2007,04:20:38,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- 5 compile.py 09-Jan-2007,09:26:02,`JOEV' DevTools version 0.0.191
#-DT-      Minor cleanup.
#-DT- *tlib-revision-history*
#
############################################################################
