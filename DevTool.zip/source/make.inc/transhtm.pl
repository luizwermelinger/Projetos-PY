############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         transhtm.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Hal Lichtin)
#  DESCRIPTION:  Perl script used in makefiles to transform HTML into
#                different forms, including substitution strings,
#                subsetting, and mapping.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# Specification.
#
# ( 1 )  Accept an HTML file and write a new HTML file. The new HTML file is
# a subset of the input HTML file. The header in the input HTML file is
# always written to the new HTML file. An HTML file is binary.
#
# ( 2 )  Accept TIPS.HTM and a MAP file. The MAP file contains a list of tip
# aliases. Write a TIPS file. This is the file used to display tips of the
# day. It contains one tip per line. In the MAP file, following the heading
# "[ALAISES]", there is one tip alias on each line. The order in which the
# tip aliases appear is the order in which the tips associated with the
# aliases will appear in the TIPS file. When reading the MAP file, put the
# aliases, in order, into an array.
#
# For each paragraph in the TIPS.RTF file, grep for each of the tip aliases.
# If a grep succeeds, the tip associated with the matching alias appears in
# the paragraph. Find the tip and add it to an associative array. In this
# associative array, the alias is the key and the tip is the value for that
# key. After reading the TIPS.RTF file, iterate over the ordered list of
# aliases. For each alias, if that alias also appears in the associative
# array, write the tip associated with the alais to the TIPS file. A tip
# alias may appear in the MAP file and not appear in the TIPS.RTF file.
# Likewise, a tip alias may appear in the TIPS.RTF file and not appear in
# the MAP file.
#
# Parameters.
#
# The arguments are passed to the script in a file. The parameter file has
# one argument per line. The parameter file should not contain both a MAP
# parameter and a BUILD_TAGS parameter. If it does, the input HTML file will
# be rewritten to the output file and the TIPS file will not be written.
#
# ( A )  INPUT=Name_of_input_HTML_file.
#
# ( B )  OUTPUT=Name_of_output_HTML_file or Name_of_Tips_File.
#
# ( C )  MAP=Name_of_map_file. This is used write a TIPS file from the
# TIPS.RTF file. It contains, under the heading "[ALIASES]", a list of
# aliases, in the order in which the tip associated with each alias will
# appear in the TIPS file.
#
# ( D )  BUILD_TAGS=List_of_build_tags. This is a string of tokens with each
# token separated by a '|' character. Examples are "BASE" or
# "BASE|YES_SOMETHING".
#
# ( E ) SUBSTITUTIONS=List_of_string_substitution_strings. The strings in
# the list are separated by whitespace. Each string has the form "x=z". Each
# such string is split into a key, "x", and a value, "z". These are put into
# an associative array. Each item written to an output file is searched for
# instances of "x". Each instance of "x" is replaced by "z".

require 5;

#--------------------------------------------------------------------

# Globals

#--------------------------------------------------------------------

# Constants.

$TRUE = 1;
$FALSE = 0;

if ( ( "DEBUG" eq $ENV{ "DDTYPE" } ) || ( $ENV{ "DDCOMPDIR" } =~ /x/ ) )
{
$DEBUGINFO = 1;
}
else
{
$DEBUGINFO = 0;
}

#--------------------------------------------------------------------

# Test code here.

#--------------------------------------------------------------------

# Mainline.

#--------------------------------------------------------------------

# Name of input HTML file.
$infile = "";
# Buffer to hold contents of HTML file.
$file = "";
# Name of input tips mapping file and build tips file flag.
$mapfile = "";
$tipsFlag = $FALSE;
# Name of output HTML file.
$outfile = "";
# String containing list of build flags and rewrite HTML file flag.
$buildFlags = "";
$rewriteHTMLFlag = $FALSE;
# List of string substitutions.
%subs = ();
# List of #defines
%isDefined = ();

parseArgs( \$infile, \$mapfile, \$tipsFlag, \$outfile, \$buildFlags,
\$rewriteHTMLFlag, \%subs, \%isDefined );

# Rewrite HTML file with set of build flags.

if ( $TRUE == $rewriteHTMLFlag )
{
 # Load entire HTML file into a string.

   # Temp file.
   my $tf = $ENV{ TEMP }."\\tmp\$\$\$jo.\$\$\$";

   #PreProcess handles #ifdefs
   preProcess( $infile, $tf, \%isDefined, $isBinary );

   $file = loadFile( $tf, $TRUE );

   # Delete temp file.
   system( "del $tf" );

##Makedir code goes here
$outdir = $outfile;
if ($outdir =~ /.*htm/) {
   $outdir =~ s/(.*)\\\w*\.htm/$1/;
   print "The output directory is $outdir";
   if (!-d $outdir) {
      mkdir($outdir,0777) || die "\tCannot create directory $outdir.\n";
   }
}
   open( OUT, ">$outfile" ) || die "\tCannot open $outfile for output.\n";

   # The output file is binary.
   binmode OUT;
   print "\tProcessing HTML File: $infile\n";

 # Delete tlib History information by deleting everything up to the <HTML> tag
   $file =~ s/^.*?(<HTML>)/$1/si;

 # Do string substitution of XXXfooXXX
   processHTMLFile( OUT, \$file, \%subs );
   print "\tFinished Building HTML File: $outfile\n";
}

# Build TIPS file.

elsif ( $TRUE == $tipsFlag )
{
   # Load entire binary HTML file into a string.
   $file = loadFile( $infile, $TRUE );

   open( MAP, "<$mapfile" ) || die "  Cannot find $mapfile for input.\n";
   open( OUT, ">$outfile" ) || die "  Cannot open $outfile for output.\n";

   # The output file is binary.
   binmode OUT;

   print "\tProcessing HTML File: $infile\n";
   print "\tProcessing MAP File: $mapfile\n";

   processTips( MAP, OUT, \$file, \%subs );

   print "\tFinished Building Tips File: $outfile\n";
}

# Program fails. Print usage message.

else
{
   usage();
}

#--------------------------------------------------------------------

# Functions.

#--------------------------------------------------------------------

# Get script parameters. The parameters are passed to the script in a file,
# the single argument on the command line.

sub parseArgs
{
   my ( $rInfile, $rMapfile, $rTipsFlag, $rOutfile, $rBuildFlags,
      $rRewriteHTMLFlag, $rSubs, $rIsDefined ) = @_;

   &usage if ( 0 == @ARGV );

   open( PARAM, "<$ARGV[0]" ) ||
       die "  Cannot find $ARGV[0], the parameter file.\n";

   # Get the name of input HTML file, the name of output file and the name
   # of input MAP file. Also, get a list of build flags. The build flags
   # string is a list of tokens, each separated by a '|'. Lastly, get list
   # of string substitutions. These string substitution strings have the
   # form "string1=string2". In an output file, each instance of "string1"
   # will be replaced by "string2". The string substitutions are stored in
   # a associative array.
   while ( <PARAM> )
   {
      # Get name of input HTML file.
      if ( $_ =~ /^INPUT/ )
      {
         chop;
         $$rInfile = substr( $_, length( "INPUT=" ) );
      }
      
      # Get name of output file.
      if ( $_ =~ /^OUTPUT/ )
      {
         chop;
         $$rOutfile = substr( $_, length( "OUTPUT=" ) );
      }

      # Get name of input MAP file. Set build tips file flag to $TRUE. 
      if ( $_ =~ /^MAP/ )
      {
         chop;
         $$rMapfile = substr( $_, length( "MAP=" ) );
         $$rTipsFlag = $TRUE;
      }

      # Get list of build tags. These are also used for preprocessing. Set
      # rewrite HTML file flag to $TRUE. 
      if ( $_ =~ /^BUILD_TAGS/ )
      {
         chop;

         # Strip "BUILD_TAGS=" from string.
         $$rBuildFlags = substr( $_, length( "BUILD_TAGS=" ) );

         # Put each of the build flags into a hash table with a value of
         # 1. The hash table is used when preproccessing an HTML file to
         # find those symbols that are defined.
         my @defines = split( /\|/, $$rBuildFlags );
         my $symbol = "";
         foreach $symbol ( @defines )
         {
            $$rIsDefined{ $symbol } = 1;
         }

         $$rRewriteHTMLFlag = $TRUE;
      }
      
      # Get list of string substitutions and load these into an
      # associative array.
      if ( $_ =~ /^SUBSTITUTIONS/ )
      {
         chop;
         my $subsString = substr( $_, length( "SUBSTITUTIONS=" ) );
         my @subsPairs = split( /\s/, $subsString );

         # Get list of string substitutions. These string substitution
         # strings have the form "string1=string2". In an output file,
         # each instance of "string1" will be replaced by "string2". The
         # string substitutions are stored in a associative array.
         my $entry;
         foreach $entry ( @subsPairs )
         {
            my @pair = split( /=/, $entry );
            # Replace underscore characters with a space characters in
            # string that will be inserted.
            $pair[1] =~tr/_/ /;
            $$rSubs{ $pair[0] } = $pair[1];
         }
      }
   } # while - loop

} # sub parseArgs

#--------------------------------------------------------------------

# Read an HTML file, which is passed in as a reference to a string, the
# string holding the contents of the file. 
# Fix pathing and then process the substitution strings passed in as $rSubs
# Write to the new HTML file 

sub processHTMLFile
{
   my ( $OUT, $rHTMLFile, $rSubs ) = @_;
#Replace pathing in sources with appropriate object pathing
#Html files are copied to object hierarchy
#Don't strip paths from text in .hhc files
   if ( ! $rHTMLFile =~ /\w*\.hhc/) {
      $$rHTMLFile =~ s/\"\S*\\(\w*\.htm)/\"$1/ig; 
   }
#THIS BLOCK OF PROCESSING enables us to use relative paths above the 
#sources in the src directory so that we can edit and display live 
#and then fix the paths for building.
# Don't think it's necessary because it is subsumed in the next block
#Language independent images are not copied; reference relative to [Files]
#   $$rHTMLFile =~ s/\"\.\.\\\\.\.\\\.\.\\bitmap\\(\w*\.gif)/\"\/$1/ig;
#Similarly, the master CSS and Javascript files are nto copied.
#   $$rHTMLFile =~ s/\"\.\.\\\\.\.\\\.\.\\bin\\(\w*\.js)/\"\/$1/ig;
#   $$rHTMLFile =~ s/\"\.\.\\\\.\.\\\.\.\\(\w*\.css)/\"\/$1/ig;


#The following code fixes ALL pathing for the listed file types 
#So that they use the /filename format instead of a relative path
#This requires the real location of the file to be specified in the
#[files] section.
#The compler warns on the references to the .css and .js files 
#for the first html file compiled.
   $$rHTMLFile =~ s/\"\S*\\(\w*\.(avi|gif|bmp|wav|css|js))/\"\/$1/ig;

#The following line fixes bad Index entries generated by RoboHelp
   $$rHTMLFile =~ s/(\"MS-HKWD\" CONTENT=\"[\w -]+): */$1,/g;
#Now do string substitutions
   $$rHTMLFile = stringSubs( $$rHTMLFile, $rSubs );
   print $OUT $$rHTMLFile;  
} # sub processHTMLFile


#--------------------------------------------------------------------
# Write TIPS file from TIPS.HTML file and TIPMAP.TXT file. The TIPS.HTML file
# is passed in as a reference to a string, the string holding the contents
# of the file.

sub processTips
{

   my ( $MAP, $OUT, $rHTMLFile, $rSubs ) = @_;

   my %tipMap = ();
   my @tipAliases = ();

   processMapFile( $MAP, \@tipAliases );
   processTipsHTMLFile( $rHTMLFile, \@tipAliases, \%tipMap );
   writeTipsFile( $OUT, \@tipAliases, \%tipMap, $rSubs );
   

} # sub processTips

#--------------------------------------------------------------------

# Read TIP MAP file. Following the header "[ALIASES]" is a list of tip
# aliases, one alias per line. Each alias is added to the end of the
# @$rTipAliases array. The order in which tip aliases appear in TIP MAP file
# is the order in which the tips appear in the TIP file.

sub processMapFile
{
   my ( $MAP, $rTipAliases ) = @_;

   my $aliasFlag = 0;

   while ( <$MAP> )
   {
      # Skip blank lines and comment lines. A semi-colon is the comment
      # character. 
      next if ( /^$/ );
      next if ( /^;/ );

      # Add, in order, the aliases for help tips to array.
      if ( $aliasFlag )
      {
         chop;
         push( @$rTipAliases, $_ );
      }

      # Find start of tip aliases.
      if ( /^\[ALIASES\]/ )
      {
         $aliasFlag = 1;
      }
   } # while - loop

} # sub processMapFile

#--------------------------------------------------------------------

# Read HTML file and find TIPS. The HTML file is passed in as a reference to a
# string, the string holding the contents of the file. Within the HTML file,
# each TIP is preceded by an ALIAS. The HTML file will contain a stream that
# looks like "\v BlahBlahBlah [MICROPHONE_Accuracy] BlahBlahBlah } This is
# the TIP". The ALIAS is "MICROPHONE_Accuracy". The TIP is "This is the
# TIP". The ALIAS and the TIP are added to an associative array. The ALIAS
# is the key. The TIP is the value.

sub processTipsHTMLFile
{
   my ( $rHTMLFile, $rTipAliases, $rTipMap ) = @_;
##NEED TO REPLACE \\Par with HTML MARKUP
##Other Procssing changes may be needed for HTML Markup
   while ( $$rHTMLFile =~ /\\par/ )
   {
      my $alias = "";

      # Remove and process individual paragraphs from the input stream.
      # $buf contains the concatenation of the that in the input stream
      # that precedes "\par" (found in the $` variable) and that in the
      # input stream that matches the expression (found in the $&
      # variable). 
      my $buf = $`.$&;
      $$rHTMLFile = $';

      if ( "" ne ( $alias = hasString( $buf, $rTipAliases ) ) )
      {

         # The paragraph had better match this expression, otherwise
         # there is a problem in the TIPS.HTML file and we will have to
         # die. What we want is that part of the paragraph that follows
         # the expression. This is the tip string that goes with the
         # alias, followed by the token "\par". What we want is contained
         # in the special perl variable $'. It holds the part of a
         # string that follows a match.
##Fix this Regexp for HTML
         if ( $buf =~ /\\v[^\{\}]*$alias[^\{\}]*\}/ )
         {
##I think the -4 is for \Par
            $buf = substr( $', 0, ( length( $' ) - 4 ) );
            cleanTip( \$buf );
         }
         else
         {
            die "Cannot find tip for alias: $alias\n";;
         }

         # Put tip into associative array of aliases and tips.
         $$rTipMap{ $alias } = $buf;
      }
   } # while - loop
} # sub processTipsHTMLFile

#--------------------------------------------------------------------

# The TIPS file contains one tip per line. The order of the TIPS is the
# order of ALIASES in the array @$rTipAliases. The function iterates over
# this array, looking-up each ALIAS in the associative array %$rTipMap and
# writing the value of the ALIAS to the output file.

# Before writing any string to the output file, make appropriate
# substitutions within the string from the associative array of string
# substitutions. For instance, if the string contains the substring
# "XXXProductNameXXX" and the string substitution array contains the key
# "XXXProductNameXXX", replace the substring "XXXProductNameXXX" with the
# value associated with "XXXProductNameXXX" in the string substitution
# array. 

sub writeTipsFile
{
   my ( $OUT, $rTipAliases, $rTipMap, $rSubs ) = @_;
   my $alias;

   foreach $alias ( @$rTipAliases )
   {
      if ( defined( $$rTipMap{ $alias } ) )
      {
         my $localizedTip = stringSubs( $$rTipMap{ $alias }, $rSubs );
         print $OUT $localizedTip;
      }
   }
} # sub writeTipsFile

#--------------------------------------------------------------------

# Remove unwanted junk from a TIP string, such as HTML formatting commands,
# HTML escape characters and unwanted newlines. Also convert HTML
# representation of high-bit characters into characters themselves.

## THIS NEEDS REPLACEMENT WITH STUFF TO REMOVE ANY UNWANTED HTML
sub cleanTip
{
   my $rTip = shift;

   # Delete any newlines and carriage returns from tip?

   # Remove formatting (bold, italics)

   # Remove any markup that identifies the fonts for different types of
   # characters

   # The following lines clean up curly single and double quotes

   # The following line cleans up any inline explicit font size settings

   # The following lines clean up language setting information.

   # RTF files encode high bit characters, such as a german omlaut 'o' and
   # Japanese (e.g., SJIS) characters with "\'xx" where "xx" is the hex 
   # value of the character and "\'" is the escape sequence. In a TIP,
   # replace "\'f6" with the character represented by "f6".
   $$rTip =~ s /\\\'(..)/pack( "H2", "$1" )/eg;

   # Lastly, compress multiple spaces between tokens into a single space.
   $$rTip =~ tr / //s;

   # Add newline to end of TIP?
   
} # sub cleanTip

#--------------------------------------------------------------------

# Open and load a file into a string. The file can be opened in either text
# or binary mode.

sub loadFile
{
   my ( $filename, $isBinary ) = @_;

   open( IN, "<$filename" ) || die "\tCannot load $filename.\n";

   # Open in Binary mode.
   if ( $TRUE == $isBinary )
   {
      binmode IN;
   }
   
   # Length of file.
   my $size = -s $filename;

   # Read file into a string.
   my $file = "";
   read( IN, $file, $size );
   close( IN );

   return $file;
} # sub loadFile

#--------------------------------------------------------------------

# Accept a handle to an input file and to an output file. Rewrite input file
# to output file in accord with #ifdef - #endif statements in input file.

sub preProcess
{
   my ( $infile, $outfile, $rIsDefined, $isBinary ) = @_;

   open( OUT, ">$outfile" ) ||
       die "\tCannot open $outfile for preprocessing of $infile.\n";

   if ( $TRUE == $isBinary )
   {
      binmode OUT;
   }
   
   # Read file into string.
   my $file = loadFile( $infile, $isBinary );

   # Current level of ifdef nesting.
   my $ifdefLevel = 0;
   # Current level of else nesting. This number should never exceed one.
   my $elseLevel = 0;

   # The default printing value is TRUE.
   my @stack = ();
   push( @stack, $TRUE );
   
   while( $file =~ /\[((\#endif)|(\#else)|(\#ifdef)|(\#ifndef))\s*(\w*)\]/ )
   {

      # The concatenation of these four variables is the value of #ifdef
      # or #ifndef or #else or #endif currently matched. The value of the
      # variables not matched is "".
      my $match = $2.$3.$4.$5;
      my $symbol = $6;

      # Read value on top of stack in order to know whether or not to
      # print.
      my $stackValue = pop( @stack );
      $stackValue = 0 if ( "" eq $stackValue );

      $file = $';

      if ( $TRUE == $stackValue )
      {
         print OUT $`;
      }

      if ( $match eq "#endif" )
      {
         ( $ifdefLevel > 0 ) ||
             die "$0: #endif with no matching #ifdef in $infile\n";

         # Decrement nesting level.
         $ifdefLevel--;

         # Cancel else nesting.
         $elseLevel = 0;

         # Maintain stack. When reaching the end of a set of #ifdefs,
         # push TRUE on the stack. Printing is the default behavior.
         if ( 0 == $ifdefLevel )
         {
            push( @stack, $TRUE );
         }

         if ( ($DEBUGINFO == 1) )
         {
            print "Parsed '#endif' at line $.";
            print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
         }
      } #endif

      elsif ( $match eq "#else" )
      {
         ( $ifdefLevel > 0 ) ||
             die "$0: #else with no matching #ifdef in $infile\n";
         ( $elseLevel < 1 ) ||
             die "$0: #else with no matching #ifdef\n";

         # Bump else - nesting level.
         $elseLevel++;

         # Maintain stack.
         # TODO: comment.
         my $priorStackValue = pop( @stack );
         if ( $TRUE == $priorStackValue )
         {
            push( @stack, $priorStackValue );
            push( @stack, !$stackValue );
         }
         else
         {
            push( @stack, $priorStackValue );
            push( @stack, $stackValue );
         }

         if ( ($DEBUGINFO == 1) )
         {
            print "Parsed '#else' at line $.";
            print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
         }
      } #else

      elsif ( $match eq "#ifdef" )
      {
          # Bump nesting level.
         $ifdefLevel++;

         # Cancel else nesting.
         $elseLevel = 0;

         # Maintain stack. If $symbol is defined and the current state of
         # the stack is TRUE, push the current state followed by TRUE on
         # the stack, else push the current state followed by FALSE on
         # the stack.
         if ( $TRUE == $stackValue )
         {
            push( @stack, $stackValue );
            push( @stack, $$rIsDefined{ $symbol } );
         }
         else
         {
            push( @stack, $stackValue );
            push( @stack, $FALSE );
         }

         if ( ($DEBUGINFO == 1) )
         {
            print "Parsed '#ifdef $symbol' at line $.";
            print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
         }
      } #ifdef

      elsif ( $match eq "#ifndef" )
      {
           # Bump nesting level.
         $ifdefLevel++;

         # Cancel else nesting.
         $elseLevel = 0;

         # Maintain stack. If $symbol is defined and the current state of
         # the stack is TRUE, push the current state followed by TRUE on
         # the stack, else push the current state followed by FALSE on
         # the stack.
         if ( $TRUE == $stackValue )
         {
            push( @stack, $stackValue );
            push( @stack, !$$rIsDefined{ $symbol } );
         }
         else
         {
            push( @stack, $stackValue );
            push( @stack, $FALSE );
         }

         if ( ($DEBUGINFO == 1) )
         {
            print "Parsed '#ifndef $symbol' at line $.";
            print "( $ifdefLevel, $stackValue, $elseLevel ).\n";
         }
      } #ifndef
   } # while - loop

   0 == $ifdefLevel || die "#ifdef or #ifndef with no matching #endif\n";
   
   # Finished processing all paragraphs in file. Now print the stub of the
   # file. 
   print OUT $file;
   
   close( OUT );

} # sub preProcess

#--------------------------------------------------------------------

# For each key in the associative array %$rSubs, if that token appears in the
# string $buf, replace it with the value associated with the key in the
# associative array.

sub stringSubs
{
   my ( $buf, $rSubs ) = @_;
   my ( $key, $value );

   # Iterate over keys in associative array.
   while ( ( $key, $value ) = each %$rSubs )
   {
      $buf =~ s/$key/$value/g;
   } # outer while - loop

   return $buf;
} # stringSubs

#--------------------------------------------------------------------

# Test if one of the strings in an array of strings appears in another
# string. If so, return matching string. If not, return empty string.

sub hasString
{
   my ( $buf, $rStrings ) = @_;
   my $string = "";

   foreach $string ( @$rStrings )
   {
      if ( $buf =~ /$string/ )
      {
         return $string;
      }
   }
   
   return "";
} # sub hasString

#--------------------------------------------------------------------

# Printing functions.

#--------------------------------------------------------------------

# Print usage message.

sub usage
{
   print STDERR "\n";
   print STDERR "perl5 $0 [parameter file name]\n\n";
   print STDERR "      The parameter file has one argument per line.\n\n";
   print STDERR "      INPUT=[name of input HTML file]\n";
   print STDERR "      OUTPUT=[name of output file]\n";
   print STDERR "      MAP=[name of map file used to make TIPS file]\n";
   print STDERR "      BUILD_TAGS=[string of build tags, " .
       "each separated by a '|' character]\n";
   print STDERR "      SUBSTITUTIONS=[list of string substitutions, " .
       "of the form stringA=stringB]\n";
   print STDERR "      ( Whitespace separates string substitution " .
       "pairs in the list. )\n\n";
   print STDERR "      Do not include a MAP file when rewriting " .
       "an HTML file.\n";
   die "      Do not include a BUILD_TAGS string when writing a TIPS file.\n";
} # sub usage

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 transhtm.pl 09-Nov-2001,17:53:40,`JOEV2' Initial revision
#-DT- 2 transhtm.pl 09-Nov-2001,17:54:32,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 transhtm.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 transhtm.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 5 transhtm.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 6 transhtm.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 7 transhtm.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
