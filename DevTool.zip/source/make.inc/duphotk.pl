############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         duphotk.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Dean Sturtevant)
#  DESCRIPTION:  Perl script used by targets.mak to check .rc files
#                for duplicate hotkeys before compiling them into
#                resource files.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

#   Usage: perl -w duphotk.pl [-I{include path} ...] {.rc files}
#
#   For each .rc file specified, it will look for duplicate hot key
#   definitions in BEGIN-END blocks, arbitrarily nested. It will
#   ignore duplicate hotkeys in blocks whose BEGIN line is immediately
#   preceded by a line starting "STRINGTABLE".
#
#   Files #included in the .rc file will also be processed. Such files
#   will be looked for via the following algorithm:
#   If the name of the include file is in quotes, it will first be
#   looked for in the current directory AND the directory of the
#   .rc file. Next, it will be looked for in the directories
#   supplied to the -I argument(s) on the command line.
#
#   All duplicate hot keys found will be reported via STDOUT. If there are
#   any, the perl script will exit with an error message and a non-zero
#   exit code.

@ignoreFiles = qw(macwin32.h macname1.h macname2.h rpcmac.h rpcerr.h
                  winwlm.h macpub.h macapi.h macname.h ole.h);
@includesToIgnore{@ignoreFiles} = (1) x @ignoreFiles;

$ok = 1;
while( @ARGV )
{
    $_ = shift;
    if( /^-I(\S+)/ ) {
        push( @includePaths, $1 );
        next;
    }

    &processRcFile( $_ );
}
if( !$ok ) {
    die "Errors found by duphotk.pl.\n";
}

sub reportError
{
    ( $rcFile, $rcLine, $message ) = @_;
    print "$rcFile($rcLine) : Error: $message\n";
    $ok = 0;
}

sub processRcFile
{
    my( $rcFile ) = @_;

    # Avoid infinite recursion
    if( defined( $processed{$rcFile} ) ) {
        return;
    }
    $processed{ $rcFile } = 1;

    if( !open( $rcFile, $rcFile ) ) {
        &reportError( $rcFile, 0, "Can't open $rcFile ($!)" );
        return;
    }
    
    my $rcLine = 0;
    my $level = 0;
    my $lastLine = '';
    my $inStringTable = 0;
    my @hotKeyLine = ();
    my( $includeName, $fullName, $success );

    # determine path of file, which is everything before the last '\' or ':'
    # whichever is later. If no '\' or ':', it's the whole thing.
    # Kludge: we'll only look for '\', assuming that if ':' is supplied,
    # there'll be a '\'.
    my $rcPath;
    if( $rcFile =~ /^(\S*\\)[^\\]+$/ )
    {
        $rcPath = $1;
    }
    else
    {
        $rcPath = '';
    }
    
    for( ;$_ = <$rcFile>; $lastLine = $_ )
    {
        $rcLine++;
        if( /^\s*#\s*include\s+\"([^"]+)\"/ )
        {
            # Include in quotes - look first in directory of file,
            # then in current directory. I'm surprised this is what
            # is needed.
            $includeName = $1;
            $fullName = $rcPath . $includeName;
            $success = 0;
            # If they both exist, look at both of them. I don't know
            # which one is actually included.
            if( -e $fullName ) {
                &processRcFile( $fullName );
                $success = 1;
            }
            if( -e $includeName ) {
                &processRcFile( $includeName );
                $success = 1;
            }
            next if $success;

            if ($includesToIgnore{$includeName}) {
                next;
            }
            
            if( !&processIncludeFromPath( $includeName ) )
            {
                &reportError( $rcFile, $rcLine,
                              "Couldn't find include file '$includeName'" );
            }
            next;

        }
        if( /^\s*#\s*include\s+<([^>]+)>/ )
        {
            # Include in brackets - look only in path
            $includeName = $1;
            if ($includesToIgnore{$includeName}) {
                next;
            }
            
            if( !&processIncludeFromPath( $includeName ) )
            {
                &reportError( $rcFile, $rcLine,
                              "Couldn't find include file '$includeName'" );
            }
            next;
        }
        
        if( /^(\s*)BEGIN\b/ )
        {
            # Ignore duplicate hotkeys in string tables
            if( $lastLine =~ /^STRINGTABLE/ ) {
                if( $level != 0 ) {
                    # This would violate an assumption of this script...
                    &reportError( $rcFile, $rcLine,
                                  "Nested STRINGTABLE: rewrite duphotk.pl" );
                }
                $inStringTable = 1;
                next;
            }
            $level++;
            %{$hotKeyLine[$level]} = ();
            next;
        }
        if( /^(\s*)END\b/ )
        {
            if( $inStringTable ) {
                $inStringTable = 0;
                next;
            }
            $level--;
            next;
        }

        # Only look for hotkeys within BEGIN-END
        next if $level == 0;

        # Skip commented-out lines
        next if( m|^\s*//| );
        
        if( /&([a-zA-Z])/ )
        {
            my $key = $1;
            $key =~ tr/A-Z/a-z/;
            if( defined( ${$hotKeyLine[$level]}{ $key } ) )
            {
                $prevLine = ${$hotKeyLine[$level]}{ $key };
                &reportError( $rcFile, $rcLine,
                              "Hotkey '$key' duplicates line $prevLine" );
            }
            else
            {
                ${$hotKeyLine[$level]}{ $key } = $rcLine;
            }
            next;
        }
    }

    close( $rcFile );
}

sub processIncludeFromPath
{
    my( $includeName ) = @_;
    my( $includePath, $fullName );
    foreach $includePath (@includePaths)
    {
        $fullName = "$includePath\\$includeName";
        if( -e $fullName ) {
            &processRcFile( $fullName );
            return 1;
        }
    }
    return 0;
}

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 duphotk.pl 09-Nov-2001,17:25:38,`JOEV2' Initial revision
#-DT- 2 duphotk.pl 09-Nov-2001,17:54:20,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 duphotk.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 duphotk.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 5 duphotk.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 6 duphotk.pl 19-Jun-2003,15:33:14,`JOEV3' DevTools version 0.0.48
#-DT-      Added another file to ignore in processing #includes while doing
#-DT-      duplicate hotkey checking.
#-DT- 7 duphotk.pl 18-Jul-2005,17:53:26,`DOUG1' DevTools version 0.0.113
#-DT-      WinCE support and removal of include not found error generation
#-DT- 8 duphotk.pl 07-Nov-2005,15:30:08,`JOEV' DevTools version 0.0.120
#-DT-      Minor fixes, enhancements, and cleanup.
#-DT- 9 duphotk.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 10 duphotk.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
