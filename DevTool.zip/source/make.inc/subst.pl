############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         subst.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author David Wald)
#  DESCRIPTION:  Do various file substitutions.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# Comment this in if you're using a full perl and you want more detailed
# timing information.
#use Time::HiRes qw(time);

($PROGRAM_NAME = $0) =~ s/.*[\/\\]//g;
$gStartTime = time;

sub print_help
{
    print <<"END_OF_HELP";

Usage: $PROGRAM_NAME options

Substitutions are done in the following order:
  - all per-file substitutions
  - all per-line simple substitutions
  - all per-line regexp substitutions
  
Options:
  -n filename    Take input from file (required)
  -o filename    Print output to file (required)
  -m filename    Append per-file perl regexps substitutions from file
  -e filename    Append per-line simple substitution list from file
  -r filename    Append per-line perl regexp substitution list from file
  -i             Match simple substitutions case insensitively
  -t             Finish the output file with boilerplate and file info
  -b             Use brief format for -t boilerplate and file info
  -f filename    Read more arguments from file
  -l filename    Log substitution script and timing stats to file

END_OF_HELP
}


@argv = @ARGV;

$inFile = "";
$outFile = "";
$CASE = "";
$logFile = "";
$appendText = 0;
$appendBrief = 0;

@fileRegs = ();
@lineSubs = ();
@lineRegs = ();


# return reference to array of lines from file
sub getLines
{
    my $file = shift;
    open $file, "<$file" or die "Couldn't open file $file.\n";
    my @lines = grep s/\x0d?\n$// || 1, <$file>;
    close $file;
    \@lines
}

@args = @ARGV;

while (@args && ( $args[0] =~ /^-/ ) )
{
    $_ = shift(@args);

    if (/^-f(.*)$/)
    {
        my $file = shift(@args);
        open( $file, "<$file" ) or die "Couldn't open file $file: $!\n";
        my $lines = join(' ',<$file>);
        close $file;
        @args = (split(' ', $lines), @args);
        next;
    }
    if (/^-n(.*)$/)
    {
        die "repeated -n option\n" if $inFile;
        $inFile = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        open( $inFile, "<$inFile" ) or
            die "couldn't open file '$inFile' for read: $!\n";
        next;
    }
    if (/^-o(.*)$/)
    {
        die "repeated -o option\n" if $outFile;
        $outFile = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        open( $outFile, ">$outFile" ) or
            die "couldn't open file '$outFile' for write: $!\n";
        next;
    }

    if (/^-i(.*)$/)
    {
        $CASE = "i";
        next;
    }
    if (/^-e(.*)$/)
    {
        $file = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        my $rLines = getLines $file;
        die "Pattern parsing error: File '$file' has " .
            "odd number of substitution lines\n" if @$rLines % 2;
        push(@lineSubs, @$rLines);
        next;
    }
    if (/^-r(.*)$/)
    {
        $file = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        my $rLines = getLines $file;
        die "Pattern parsing error: File '$file' has " .
            "odd number of substitution lines\n" if @$rLines % 2;
        push(@lineRegs, @$rLines);
        next;
    }
    if (/^-m(.*)$/)
    {
        $file = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        my $rLines = getLines $file;
        die "Pattern parsing error: File '$file' has " .
            "odd number of substitution lines\n" if @$rLines % 2;
        push(@fileRegs, @$rLines);
        next;
    }
    if (/^-t(.*)$/)
    {
        die "repeated -t option\n" if $appendText;
        $appendText = 1;
        next;
    }
    if (/^-b(.*)$/)
    {
        die "repeated -b option\n" if $appendBrief;
        $appendBrief = 1;
        next;
    }
    if (/^-l(.*)$/)
    {
        die "repeated -l option\n" if $logFile;
        $logFile = ($1 =~ /^\s*$/) ? shift(@args) : $1;
        open( $logFile, ">$logFile" ) or
            die "couldn't open file '$logFile' for write: $!\n";
        next;
    }

    &print_help(), exit 1;
}

die "missing required arguments\n" unless $inFile && $outFile;
die "unexpected arguments\n" if @args;


# Starting banner
if( $logFile )
{
    my($sec,$min,$hour,$mday,$mon,$year,@foo) = localtime time;
    my $dateStr = sprintf "Date: %04d-%02d-%02d  Time: %02d:%02d:%02d",
                            $year+1900,$mon+1,$mday,$hour,$min,$sec;
    print $logFile "Command Line: $0 @argv\n$dateStr\n\n";
}



# Timing logic for script to log elapsed time difference.
# Assumes $logFile is a valid file handle.

# this called by the client using addCode, it doesn't
# put in newlines
sub elapsedTime
{
    my $timeDiff = time - $gStartTime;
    my $tag = join( ' ', @_ );
    printf $logFile "    %.4f   elapsed time %s  ", ($timeDiff, $tag);
}

# you get one checkpoint timer
# this called by the client using addCode, it doesn't
# put in newlines
$oldCheckPointTime = $gStartTime;
sub checkPointTime
{
    my $timeDiff = time - $oldCheckPointTime;
    $oldCheckPointTime += $timeDiff;
    my $tag = join( ' ', @_ );
    printf $logFile "    %.4f   checkpoint %s  ", ($timeDiff, $tag);
}

# this is used internally by addCode
$prevTime = $gStartTime;
sub printTime
{
    my $timeDiff = time - $prevTime;
    $prevTime += $timeDiff;
    my $tag = join( ' ', @_ );
    printf $logFile "%.4f   %s\n", ($timeDiff, $tag);
}

#sub printLength
#{
#    print "inData length: ", length($inData), "\n";
#    #open( $inDataFile, ">argh.txt" );
#    #print $inDataFile $inData;
#    #close( $inDataFile );
#}


# convert file stats to look like this:
#-rw--m     383485     376.0K   937024818 Sep 13 16:35   is\inmsi\tmpfgood.log
@months = ( "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" );
sub formatFileStats
{
    my( $brief, $name, $dev, $ino, $mode, $nlink, $uid, $gid, $rdev,
        $size, $atime, $mtime, $ctime, $blksize, $blocks ) = @_;

    # setup mode
    my $modeStr = "rwxrwxrwx";
    grep( (($mode >> $_) & 1) || (substr($modeStr, 8 - $_, 1) = "-"), 0 .. 8 );

    my( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = (
        localtime $mtime);

    if( $brief )
    {
        sprintf( "%9s %10d %7dK  %3s %2d %02d:%02d:%02d  %s",
                 $modeStr, $size, int($size/1024),
                 $months[$mon], $mday, $hour, $min, $sec,
                 $name);
    }
    else
    {
        sprintf( "%9s %10d %7dK  %10d %3s %2d %02d:%02d:%02d   %s",
                 $modeStr, $size, int($size/1024),
                 $mtime, $months[$mon], $mday, $hour, $min, $sec,
                 $name);
    }
}


# Build the script for system or eval

$script = "### automatically generated script ###\n\n";

# to add code to script, perhaps with timing
sub addCode
{
    my $code = join( ' ', @_ );
    #$script .= "   printLength;\n\n";
    if( $logFile )
    {
#        my $c = "   print \$logFile '$code\n';\n";
#        $script .= $c;
    }
    $script .= $code;
    $script .= "\n";
    $code =~ s/\\\\/\\\\\\\\/g;
    $script .= "   printTime '$code';\n\n" if $logFile;
}

addCode 'checkPointTime( "start up" );' if $logFile;
addCode;

# Stat the file
addCode '@inFileStat = stat $inFile; ' .
    '$inFileStats = formatFileStats( $appendBrief, $inFile, @inFileStat );';

# Do file-based (multi-line) substitutions first, case sensitive

# Read the entire file into $inData
addCode '$inData=""; read $inFile, $inData, $inFileStat[7]; close $inFile;';
# checkpoint after the IO
addCode 'checkPointTime("file input");' if $logFile;
addCode;

addCode '### deletions';
while( @fileRegs )
{
    my $pat = shift @fileRegs;
    my $sub = shift @fileRegs;
    addCode "1 while \$inData =~ s/$pat/$sub/g;";
}
addCode;
# checkpoint after the IO
addCode 'checkPointTime("multi-line substitutions");' if $logFile;
addCode;

# direct substitutions, case insensitive ok
if( @lineSubs )
{
    addCode '### simple substitutions';
    while(@lineSubs)
    {
        my $pat = shift @lineSubs;
        my $sub = shift @lineSubs;

        $pat =~ s/(\W)/\\$1/g;
        $sub =~ s/([\/\\\$])/\\$1/g;

        addCode "\$inData =~ s/$pat/$sub/mg$CASE;";
    }
    addCode;
}

# regexp work, case sensitive
if( @lineRegs )
{
    addCode '### regexp substitutions';
    while(@lineRegs)
    {
        my $pat = shift @lineRegs;
        my $sub = shift @lineRegs;

        addCode "\$inData =~ s/$pat/$sub/mg;";
    }
    addCode;
}

#checkpoing after the subst work
addCode 'checkPointTime("substitution work");' if $logFile;
addCode;

# setup boilerplate text; this boilerplate is inserted in the output of
# this script. in the middle of the boilerplate we insert a single-line
# difference, where that difference arises from two different values of
# $inFileStats in two different runs of this script. the idea is to make
# diff find the alignment and the differences that we have forced to appear
# so that we can verify that diff worked.
addCode '@extraLines = ();';
@diffVerifier1 = ();
@diffVerifier2 = ();
if( $appendText )
{
    # make enough boilerplate enough so that diff will align these parts
    my $boiler = "subst: diff-alignment boilerplate ";
    grep push( @diffVerifier1, $boiler . "$_" ) && 0, ( 0 .. 4 );
    grep push( @diffVerifier2, $boiler . "$_" ) && 0, ( 5 .. 9);

    # note: $inFileStats is created early in eval of the script, it
    # doesn't exist while *this* code is executing.
    addCode 'push( @extraLines, @diffVerifier1 );';
    addCode 'push( @extraLines, "subst: $inFileStats" );';
    addCode 'push( @extraLines, @diffVerifier2 );';
}

# write it all out
addCode 'print $outFile $inData;';
addCode 'print $outFile join( "\n", @extraLines, "" ) if @extraLines;';
addCode 'checkPointTime("file output");' if $logFile;
addCode;
addCode 'elapsedTime;' if $logFile;

# Script now exists in $script


if( $logFile )
{
    print $logFile <<"END_OF_LOG_SEP";
$script
### end of script ###


### start of timings ###

Substitution timings in seconds

END_OF_LOG_SEP
}


# Run the script
eval $script;
if ($@)
{
    if ($@ =~ /at \(eval \d+\) line (\d+).$/)
    {
        $line = $1;
        $@ =~ s/\.$/\:/;
        @lines = split('\n', $script);
        $errorLine = $lines[$line-1];
        die "Pattern parsing error: $@$errorLine\n";
    }
    else
    {
        die "Pattern parsing error: $@";
    }
}

if( $logFile )
{
    my $timeDiff = time - $gStartTime;
    print $logFile "\n$PROGRAM_NAME elapsed time: $timeDiff seconds\n";
}

exit;

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 subst.pl 09-Nov-2001,18:50:42,`JOEV2' Initial revision
#-DT- 2 subst.pl 09-Nov-2001,18:50:50,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 3 subst.pl 11-Jun-2003,15:32:02,`JOEV3' DevTools version 0.0.38
#-DT- 4 subst.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 5 subst.pl 16-Jun-2003,16:20:56,`JOEV3' DevTools version 0.0.43
#-DT- 6 subst.pl 23-Oct-2006,16:06:28,`JOEV3' DevTools version 0.0.167
#-DT-      Better diagnostic timing option.
#-DT- 7 subst.pl 26-Oct-2006,09:38:16,`JOEV3' DevTools version 0.0.168
#-DT-      Substitution enhancements and speedups.
#-DT- 8 subst.pl 30-Oct-2006,13:43:54,`JOEV3' DevTools version 0.0.169
#-DT-      Substitution fixes and cleanup.
#-DT- 9 subst.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 10 subst.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
