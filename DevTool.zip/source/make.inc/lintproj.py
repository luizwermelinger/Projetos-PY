############################################################################
#
#  FILE:         lintproj.py
#  DATE:         13-Dec-06
#  AUTHOR:       Joev Dubach
#  DESCRIPTION:  Project-specific option module for use in linterr.py and
#                linthdr.py.
#
# Copyright (c) 2003-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

import sets

gCopyrightHolder = "Nuance Communications, Inc."
gCopyrightHolderPeriod = "Nuance Communications, Inc."
gCopyrightCurrentYear = "2007"

gAlternateCopyrightHolder = "Nuance Communications, Inc."
gAlternateCopyrightHolderPeriod = "Nuance Communications, Inc."

# These files are excluded from both checking (linterr.py) and fixing
# (linthdr.py).

_gFilesToExclude = sets.ImmutableSet(["changes.txt",
                                      "license.txt",
                                      "make.inc\\xcompdef.mak",
                                      "make.inc\\xcompext.mak",
                                      "make.inc\\xcompfix.mak",
                                      "rootdir.mak",
                                      "snapshot.txt"])

_gFilesToAllowLongLines = sets.ImmutableSet([])
_gFilesToAllowNonPrintableChars = sets.ImmutableSet([])

def allowCheckOrFixFile(filename):
    global _gFilesToExclude
    if filename in _gFilesToExclude:
        return False
    else:
        return True

def allowLongLinesInFile(filename):
    global _gFilesToAllowLongLines
    if filename in _gFilesToAllowLongLines:
        return True
    else:
        return False

def allowNonPrintableCharsInFile(filename):
    global _gFilesToAllowNonPrintableChars
    if filename in _gFilesToAllowNonPrintableChars:
        return True
    else:
        return False

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 lintproj.py 13-Dec-2006,22:27:26,`JOEV' Initial revision
#-DT- 2 lintproj.py 14-Dec-2006,07:58:28,`JOEV' DevTools version 0.0.180
#-DT-      lint changes.
#-DT- 3 lintproj.py 14-Dec-2006,14:33:56,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 4 lintproj.py 15-Dec-2006,15:26:08,`JOEV' DevTools version 0.0.183
#-DT-      lint enhancement.
#-DT- 5 lintproj.py 02-Jan-2007,04:20:38,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- 6 lintproj.py 02-Jan-2007,05:25:26,`JOEV' DevTools version 0.0.186
#-DT-      Minor lint enhancement and cleanup.
#-DT- 7 lintproj.py 02-Jan-2007,05:37:22,`JOEV' DevTools version 0.0.188
#-DT-      Minor fix.
#-DT- *tlib-revision-history*
#
############################################################################
