############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         lintutil.py
#  DATE:         20-Jun-03
#  AUTHOR:       Neeraj Deshmukh
#  DESCRIPTION:  General utility module for use in linterr.py and linthdr.py
#
# Copyright (c) 2003-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# system modules
#
import os
import sys
import glob
import getopt
import tempfile
import sets
import pdb
import re
import lintproj

# path separator to work on both Windows and Linux
#
if os.sep == "\\":
    os.altsep = "/"
elif os.sep == "/":
    os.altsep = "\\"

# max length of line in a file
#
gMaxLength = 80

# global map of file extensions and boundary characters
#
gExtCharDict = {
    ".bat" : "rem",
    ".c"   : "//",
    ".cfg" : ";;",
    ".cpp" : "//",
    ".def" : ";;",
    ".grm" : ";;",
    ".h"   : "//",
    ".htm" : "//",
    ".inl" : "//",
    ".mak" : "#",
    ".pl"  : "#", 
    ".pm"  : "#",
    ".ptr" : "//",
    ".py"  : "#",
    ".rc"  : "//",
    ".reg" : ";;",
    ".rsp" : ";;",
    ".rul" : ";;",
    ".swg" : "//",
    ".txt" : "//",
    ".ver" : "#",
    }

# get the boundary character based on file extension, a boolean indicating
# whether the file is a makefile, a boolean indicating whether the file has
# long lines, and a boolean indicating whether the file has non-printable
# characters.
#
def getBoundCharAndFlags(filename):
    global gExtCharDict
    base = os.path.basename(filename.replace(os.altsep, os.sep))
    root, ext = os.path.splitext(base)
    # makefile is a special, extensionless case
    if root.lower() == "makefile" and ext == "":
        return gExtCharDict.get(".mak"), True, False, False
    elif base == "tlib.cfg" or base == "tlibuser.cfg" or base == "tlmuser.cfg":
        return None, False, False, False
    elif base == "tlibproj.cfg":
        return "!!", False, True, True
    elif base == "tlmproj.cfg":
        return "//", False, True, False
    else:
        return (gExtCharDict.get(ext), ext == ".mak",
                lintproj.allowLongLinesInFile(filename),
                lintproj.allowNonPrintableCharsInFile(filename))

# parse the commandline arguments
#
def parseCmdLine(argv, cmdShortSwitches, cmdLongSwitches,
                 cmdSwitchMap, usageMsg):
    
    try:
        opts, args = getopt.getopt(argv, cmdShortSwitches, cmdLongSwitches)
    except getopt.error:
        sys.exit(usageMsg)

    optDict = {}
    for opt, val in opts:
        if len(opt) == 2:
            opt = cmdSwitchMap.get(opt, None)
        if opt is None:
            sys.exit(usageMsg)
        optDict[opt] = val

    argList = []
    for arg in args:
        fList = glob.glob(arg)
        if len(fList) == 0:
            print "Skipped %s: not a valid argument" % arg
            continue
        argList.extend(fList)
    argList.sort()

    return optDict, argList

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 lintutil.py 13-Dec-2006,22:24:30,`JOEV' Initial revision
#-DT- 2 lintutil.py 14-Dec-2006,07:58:28,`JOEV' DevTools version 0.0.180
#-DT-      lint changes.
#-DT- 3 lintutil.py 14-Dec-2006,14:29:58,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 4 lintutil.py 02-Jan-2007,04:20:38,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- 5 lintutil.py 02-Jan-2007,05:25:28,`JOEV' DevTools version 0.0.186
#-DT-      Minor lint enhancement and cleanup.
#-DT- 6 lintutil.py 02-Jan-2007,05:37:22,`JOEV' DevTools version 0.0.188
#-DT-      Minor fix.
#-DT- 7 lintutil.py 10-Jan-2007,09:50:16,`JOEV' DevTools version 0.0.192
#-DT-      Minor fix.
#-DT- *tlib-revision-history*
#
############################################################################
