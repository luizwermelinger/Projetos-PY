############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         mkdep.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author Dean Sturtevant)
#  DESCRIPTION:  Perl script for creating target dependencies.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

sub printHelp
{
    # Use single quotes around END_OF_HELP so escaping in the text isn't
    # necessary.
    print <<'END_OF_HELP';
mkdep.pl - automatic dependency-generating Perl script
Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
Usage: perl -w mkdep.pl [Options] source files...
Options:
   -b
   Do not create dependencies on files specified in angle brackets.

   -d[file]
   Send debug output to stderr or, if specified, file.

   -D{dir}
   Make directory {dir} if it doesn't exist

   -E{exclude path}
   Search for included files in {exclude path} but do not add
   them to the list of dependencies.  You may use multiple
   -E{} directives.

   -h, -?, --help   Produce this usage message and quit.

   -I{include path}
   Search for included files in {include path} and permit
   adding them to the list of dependencies.  You may use
   multiple -I{} directives.

   -m
   Missing dependency files are ok - use a FORCE target instead.

   -M{file}
   {file} is a built file. If it doesn't exist, then a dependency
   will be created for it. {file} should include the path.

   -u
   Switch to UNIX output format (.o for object file extension,
   / for path separator.)  Microsoft format is the default.

   -U
   Switch to using a backslash as the line continuation character
   rather than a caret.  Separated out from -u because we now want to
   specify this in Win32 as well.

   -o{dependFile}
   If the file {dependFile} exists, it will be scanned for
   incremental updating. Otherwise it will be created.

   -c{modsNecessaryCookieFile}
   If dependency modifications were necessary, a cookie file
   will be created with this name.

   -C{genericCookieFile}
   If processing finishes, a cookie file will be created with this name.

   -v{varname}
   Add a line "{varname} = {dependency list}" where {dependency list}
   is the list of all the source files and dependencies considered by
   mkdep.

   -V{varname}
   Add a line "{varname} = {unbuilt dependency list}" where
   {unbuilt dependency list} is the list of all the source files and
   dependencies considered by mkdep, except for those specified by
   the -M flag.

   -f{varname}
   Add an extra force dependency on "$({varname})" to each of the targets.
   
   -p{prefix}
   Make all targets begin with this prefix.  E.g., if {prefix} is
   "inmsg\", and a dependency for "foo.obj" would ordinarily be
   generated, make one for "inmsg\foo.obj" instead.

   -s{suffix}
   In addition to making .obj/.o targets (switching based on the -u flag)
   for .c/.cpp files, also make {suffix} targets for them.  E.g., to also
   get .s and .i targets for all .c/.cpp files, say "-s.s -s.i".
   
   source files...
   Currently handles .h.cpp (for .pch files), .hh (for .gch files),
   .c, .cpp, .asm, .rc.

   Note: In addition, you can package up any subset of arguments (separated
   by white space) into a file and pass it on the command line as '@file'.
END_OF_HELP
}

# Some design notes:
#
# First look at a typical output file where you will see a header followed
# by a typical makefile dependency section.  Note that the header expresses
# all the dependecy information in a different format.
#
# To completely enumerate dependencies you must explore them recursively.
# The result can be expressed two ways: a list of local dependencies for
# each file visited or the complete list of dependencies encountered
# starting at a particular source file.  This program does both!  The list
# of local dependencies for each file encountered is put in the
# "Dependencies" section of the output header.  The complete list for each
# file specified on the command line or @file follows in the body and is
# used by make.
#
# The header format enables both detection of changes in command line args
# that require rebuilding and incremental updating of dependencies.

# initialize some globals
$FormatVersion = 5;
$MAXLINE = 78;
$modified = 0;
$existingFileOK = 0;
#$fudgedAgeForDetectingFilesDatedInTheFuture = -2/(24*60*60); # -2 sec

# initialize globals that can get modified by command-line processing
$ignoreBracketedIncludes = 0;
$missingFileOK = 0;
$directoryToMake = '';
$objExt = 'obj';
$pathSep = '\\';
$UNIX = 0;
$continuationSuffix = ' ^';
@includePaths = ();
@excludedPaths = ();
$outputFile = '';
$modsNecessaryCookieFile = '';
$genericCookieFile = '';
$noisy = 0;
$noisyFile = STDOUT;
$depVarName = '';
$unbuiltVarName = '';
$forceDependency = '';
$targetPrefix = '';
@extraTargetSuffixes = ();
%target = ();
@srcFiles = ();

while( @ARGV )
{
    $_ = shift;

    if( /^-h/ || /^-\?/ || /^--help/ )
    {
        &printHelp();
        exit();
    }

    if( /^-b/ )
    {
        $ignoreBracketedIncludes = 1;
        next;
    }

    if( /^-m/ )
    {
        $missingFileOK = 1;
        next;
    }

    if( /^-M(\S+)/ )
    {
        my $builtFile = $1;
        $isBuiltInclude{$builtFile} = 1;
        next;
    }

    if( /^-D(\S+)/ )
    {
        $directoryToMake = $1;
        next;
    }
    
    if( /^-u/ )
    {
        $objExt = "o";
        $pathSep = '/';
        $UNIX = 1;
        next;
    }

    if( /^-U/ )
    {
        $continuationSuffix = ' \\';
        next;
    }

    if( /^-I(\S+)/ ) {
        my $includeDir = $1;
        push( @includePaths, $includeDir );
        next;
    }

    if( /^-E(\S+)/ ) {
        my $excludeDir = $1;
        push( @excludedPaths, $excludeDir );
        next;
    }

    if( /^-o(\S+)/ ) {
        $outputFile = $1;
        next;
    }

    if( /^-c(\S+)/ ) {
        $modsNecessaryCookieFile = $1;
        next;
    }

    if( /^-C(\S+)/ ) {
        $genericCookieFile = $1;
        next;
    }

    if( /^-d(\S*)/ ) {
        $noisy = 1;
        if( $1 ) {
            $noisyFile = $1;
            open( $noisyFile, ">$noisyFile" ) or
                &reportAndDie( "Can't open $noisyFile ($!)" );
        }
        next;
    }

    if( /^-v(\S+)/ ) {
        $depVarName = $1;
        next;
    }

    if( /^-V(\S+)/ ) {
        $unbuiltVarName = $1;
        next;
    }

    if( /^-f(\S+)/ ) {
        $forceDependency = $1;
        next;
    }

    if( /^-p(\S+)/ ) {
        $targetPrefix = $1;
        next;
    }

    if( /^-s(\S+)/ ) {
        push( @extraTargetSuffixes, $1 );
        next;
    }
    
    if( /^-(\S+)/ ) {
        &reportAndDie( "Invalid option '-$1'" );
    }

    if( /^@(\S+)/ ) {
        my $atFile = $1;
        open( $atFile, $atFile ) or
            &reportAndDie( "Can't open '$atFile' ($!)" );
        my @newArgs = ();
        while( <$atFile> )
        {
            # Read white-space-separated arguments.
            @argsOnLine = split( /\s+/ );
            push( @newArgs, @argsOnLine );
        }
        close( $atFile );
        # Insert the new arguments at the head of the queue.
        unshift( @ARGV, @newArgs );
        next;
    }

    # Process only files with known extensions.
    
    if( /^(\S+\.)h\.cpp$/ ) {
        $target{ $_ } = $1 . 'pch';
    }
    elsif( /^(\S+\.)hh$/ ) {
        $target{ $_ } = $1 . 'hh.gch';
    }
    elsif( /^(\S+)\.(cpp|c)$/ ) {
        $target{ $_ } = $targetPrefix . $1 . '.' . $objExt;
        foreach $suffix (@extraTargetSuffixes)
        {
            $target{ $_ } = $target{ $_ } . ' ' . $targetPrefix . $1 . $suffix;
        }
    }
    elsif( /^(\S+\.)(asm)$/ ) {
        $target{ $_ } = $targetPrefix . $1 . $objExt;
    }
    elsif( /^(\S+\.)rc$/ ) {
        $target{ $_ } = $targetPrefix . $1 . 'res';
    }
    else {
        next;
    }

    push( @srcFiles, $_ );
}
@srcFiles = sort @srcFiles;


if($directoryToMake)
{
    if (-e $directoryToMake)
    {
        if (!(-d $directoryToMake))
        {
            &reportAndDie(
                "File $directoryToMake exists but is not a directory");
        }
    }
    else
    {
        print "$directoryToMake doesn't exist\n";
        if (!(mkdir $directoryToMake, 0777))
        {
            &reportAndDie( "Error creating $directoryToMake ($!)" );
        }
        if (!(-e $directoryToMake))
        {
            &reportAndDie( "$directoryToMake still doesn't exist" );
        }
    }
}

if( $outputFile )
{
    if( -e $outputFile ) {
        &printNoisy( "Reading existing output file $outputFile\n" );
        # Do an eval to catch 'exceptions':
        open( $outputFile, $outputFile ) or
            &reportAndDie( "Can't open existing file '$outputFile' for reading"
                           . " ($!)" );

        eval '&readExistingFile()';
        
        if( $@ ) {
#            &printLog( $@ );
            &printStatus( $@ );
            &printStatus( "$outputFile needs to be rebuilt.\n" );
        }
        else {
            $baseAge = -M $outputFile;
            $existingFileOK = 1;
        }
        
        close( $outputFile );
    }
    else {
        &printNoisy( "Building new output file $outputFile\n" );
    }
}

my $srcFile;
foreach $srcFile ( @srcFiles )
{
    # Determine dependencies
    &processSrcFile( $srcFile );
}


if( $genericCookieFile )
{
    if( -e $genericCookieFile )
    {
        &reportAndDie( "Found existing cookie file '$genericCookieFile'"
                       . " ($!)" );
    }
            
    open( $genericCookieFile, ">$genericCookieFile" ) or
        &reportAndDie(
            "Can't open $genericCookieFile for writing ($!)" );
    print $genericCookieFile "# The existence of this file means " .
        "that mkdep.pl has run.\n";
    close( $genericCookieFile );
}

if( $existingFileOK && !$modified ) {
    &printStatus( "No modifications to $outputFile necessary.\n" );
    exit 0;
}

if( $modsNecessaryCookieFile )
{
    if( -e $modsNecessaryCookieFile )
    {
        &reportAndDie( "Found existing cookie file '$modsNecessaryCookieFile'"
                       . " ($!)" );
    }
            
    open( $modsNecessaryCookieFile, ">$modsNecessaryCookieFile" ) or
        &reportAndDie(
            "Can't open $modsNecessaryCookieFile for writing ($!)" );
    print $modsNecessaryCookieFile "# The existence of this file means " .
        "that mkdep.pl has made dependency changes.\n";
    close( $modsNecessaryCookieFile );
}

if( $outputFile )
{
    open( $outputFile, ">$outputFile" ) or
        &reportAndDie( "Can't open $outputFile for writing ($!)" );
}
else
{
    $outputFile = STDOUT;
}
    
print $outputFile <<STOP_HERE;
# Dependency file generated by the PERL script $0.
# Don't modify!
# Format version $FormatVersion
#
STOP_HERE

# Print special options.
if( $ignoreBracketedIncludes )
{
    $specialOptionSpecified = 1;
    print $outputFile "# Bracketed includes ignored.\n";
}
if( $depVarName )
{
    $specialOptionSpecified = 1;
    print $outputFile "# Varname = $depVarName\n";
}
if( $unbuiltVarName )
{
    $specialOptionSpecified = 1;
    print $outputFile "# UnbuiltVarname = $unbuiltVarName\n";
}
if( $forceDependency )
{
    $specialOptionSpecified = 1;
    print $outputFile "# ForceDependency = $forceDependency\n";
}
if( $targetPrefix )
{
    $specialOptionSpecified = 1;
    print $outputFile "# TargetPrefix = $targetPrefix\n";
}
print $outputFile "# ContinuationSuffix = \"$continuationSuffix\"\n";
print $outputFile "#\n";

if( @extraTargetSuffixes )
{
    print $outputFile "# Extra target suffixes:\n";
    &printWrapped( $outputFile, '#', '# ', '', @extraTargetSuffixes );
    print $outputFile "#\n";
}
else
{
    print $outputFile "# No extra target suffixes specified.\n#\n";
}

if( @includePaths )
{
    print $outputFile "# Include paths:\n";
    &printWrapped( $outputFile, '#', '# ', '', @includePaths );
    print $outputFile "#\n";
}
else
{
    print $outputFile "# No include paths specified.\n#\n";
}

if( @excludedPaths )
{
    print $outputFile "# Excluded paths:\n";
    &printWrapped( $outputFile, '#', '# ', '', @excludedPaths );
    print $outputFile "#\n";
}
else
{
    print $outputFile "# No excluded paths specified.\n#\n";
}

print $outputFile "# Source files:\n";
&printWrapped( $outputFile, '#', '# ', '', @srcFiles );
print $outputFile "#\n";

print $outputFile "# Dependencies:\n";
&printDependencies();

print $outputFile "\n";

if( $depVarName )
{
    # Collect all dependencies
    &printWrapped( $outputFile, "$depVarName =", '    ', $continuationSuffix,
                   keys %dependsOn );

    print $outputFile "\n";
}

if( $unbuiltVarName )
{
    # Remove built dependencies from list
    @unbuiltDeps = ();
    foreach $dep ( keys %dependsOn )
    {
        if( !$isBuiltInclude{$dep} )
        {
            push( @unbuiltDeps, $dep );
        }
    }

    &printWrapped( $outputFile, "$unbuiltVarName =", '    ',
                   $continuationSuffix, @unbuiltDeps );

    print $outputFile "\n";
}


&printNoisy( "Making full dependencies...\n");
&makeFullDeps();

&printNoisy( "Printing full dependencies\n" );
foreach $srcFile ( @srcFiles )
{
    # Print dependencies
    $target = $target{$srcFile};

    $refToFullDeps = $fullDeps{$srcFile};
    $extraArg = "";
    if ($forceDependency)
    {
        $extraArg = "\$\($forceDependency\)";
    }
    &printWrapped( $outputFile, "$target :", '    ', $continuationSuffix,
                   @$refToFullDeps, $extraArg);

    print $outputFile "\n";
}

# End of main program
#-------------------------------

sub makeFullDeps
{
    while( ($file, $refToDeps) = each( %dependsOn ) )
    {
        &makeFullDepsForFile( $file, $refToDeps );
    }
}

# Return reference to full dependency list.
sub makeFullDepsForFile
{
    my( $file, $refToDeps ) = @_;

    if( defined( $fullDeps{$file} ) )
    {
        return $fullDeps{$file};
    }

    &printNoisy( "Making full dependencies for $file\n" );

    # In case of include file recursion, initialize to empty list.
    $fullDeps{$file} = [];

    # initialize temporary hash
    my %isADep = ();

    my $include;
    my $dep;
    foreach $include ( @$refToDeps )
    {
        $refToMerge =
            &makeFullDepsForFile( $include, $dependsOn{$include} );

        foreach $dep ( @$refToMerge )
        {
            if( $dep eq 'FORCE' ) {
                $fullDeps{$file} = [ $file, 'FORCE' ];
                return $fullDeps{$file};
            }
            $isADep{$dep} = 1;
        }
    }

    # Initialize reference to array.
    $fullDeps{$file} = [ $file, keys( %isADep ) ];

    return $fullDeps{$file};
}

sub processSrcFile
{
    my( $srcFile ) = @_;

    # Avoid infinite recursion
    if( defined( $dependsOn{$srcFile} ) ) {
        return;
    }

    &printNoisy( "Processing $srcFile\n" );

    my $inRcFile = ( $srcFile =~ /\.rc$/ );
    
    # initialize dependency list
    $dependsOn{$srcFile} = [];
    my $refToDependsOn = $dependsOn{$srcFile};

    # Check to see if have dependencies from existing file.
    my $refToOldDepends = ();
    my $compareWithOld = 0;
    my $include;
    if( $existingFileOK && defined( $oldDeps{$srcFile} ) )
    {
        $refToOldDepends = $oldDeps{$srcFile};

        $age = -M $srcFile;
        if( $age < $baseAge ) { # file was modified
            &printNoisy( "$srcFile was modified.\n" );
            $compareWithOld = 1;
        }
        else {
            &printNoisy( "$srcFile wasn't modified.\n" );
            @{$dependsOn{$srcFile}} = @$refToOldDepends;

            foreach $include ( @$refToOldDepends )
            {
                &processSrcFile( $include );
            }
            return;
        }
    }
    else {
        $modified = 1;
    }

    if( !open( $srcFile, $srcFile ) ) {
        if( $isBuiltInclude{ $srcFile } )
        {
            &printWarning( "Can't open $srcFile ($!)\n" );
            @$refToDependsOn = ();
            $modified = 1;
            return;
        }
        if( $missingFileOK )
        {
            &printWarning( "Can't open $srcFile ($!)\n" );
            @$refToDependsOn = ( 'FORCE' );
            $modified = 1;
            return;
        }
        reportAndDie( "Can't open $srcFile ($!)" );
    }

    &printNoisy( "Reading $srcFile\n" );
    my( $includeName, $success );

    # determine path of file, which is everything before the last '\' or ':'
    # whichever is later. If no '\' or ':', it's the whole thing.
    # Kludge: we'll only look for '\', assuming that if ':' is supplied,
    # there'll be a '\'.
    my $srcPath;
    if( $srcFile =~ /^(\S*[\\\/])[^\\\/]+$/ )
    {
        $srcPath = $1;
    }
    else
    {
        $srcPath = '';
    }


    my $srcLine = 0;
    my $unfoundInclude = '';
    while( <$srcFile> )
    {
        $srcLine++;
        if( /^\s*#\s*include\s+\"([^"]+)\"/ )
        {
            # Include in quotes - look in current directory,
            # then directory of file, then search paths.
            my $incFile = $1;
            if( !&processDependency( $incFile, $refToDependsOn,
                                     1, 1, $srcPath ) )
            {
                $unfoundInclude = $incFile;
                last;
            }
            next;
        }

        if( !$ignoreBracketedIncludes && /^\s*#\s*include\s+<([^>]+)>/ )
        {
            my $incFile = $1;
            # Include in brackets - look only in path
            if( !&processDependency( $incFile, $refToDependsOn, 0, 1 ) )
            {
                $unfoundInclude = $incFile;
                last;
            }
            next;
        }
        if( !$inRcFile ) {
            next;
        }
        # More search algorithms for .RC dependencies:
        if( /^\S+\s+(\S+)\s+DISCARDABLE\s+(\S+)\s*(\/\/.*)?$/ or
            /^\S+\s+(\S+)\s+MOVEABLE PURE\s+(\S+)\s*(\/\/.*)?$/ )
        {
            # DIALOGs aren't found in files...
            if( $1 eq 'DIALOG' ) {
                next;
            }
            # Add $2 as a dependency, but don't scan it. It may be
            # in quotes...
            $includeName = $2;
            if( $includeName =~ /^\"(\S+)\"$/ ) {
                $includeName = $1;
                if ($UNIX) {
                    $includeName =~ s/\\/\//g;
                }
                # Replace \\ by \
                $includeName =~ s/\\\\/\\/g;
                $includeName =~ s/\/\//\//g;
            }
            if( !&processDependency( $includeName, $refToDependsOn,
                                     1, 0, $srcPath ) )
            {
                $unfoundInclude = $includeName;
                last;
            }
            next;
        }
    }

    close( $srcFile );

    if( $unfoundInclude )
    {
        my $msg = "$srcFile($srcLine) : " .
                          "Couldn't find include file '$unfoundInclude'\n";
        if( $missingFileOK )
        {
            &printWarning( $msg );
            # Clean out list and force rebuild.
            @$refToDependsOn = ( "FORCE" );
        }
        else
        {
            &reportAndDie( $msg );
        }
    }
    

    if( $compareWithOld )
    {
        if( !arraysEqual( $refToOldDepends, $refToDependsOn ) )
        {
            &printStatus( "Dependency list for $srcFile has changed.\n" );
            $modified = 1;
        }
    }
    else
    {
        &printStatus( "Built dependency list for $srcFile.\n" );
    }

    if( $noisy )
    {
        &printWrapped( $noisyFile, "Dependencies for $srcFile:",
                       '    ','', @{$dependsOn{$srcFile}} );
    }
}

# bool processDependency( string $includeName, array& $refToDependsOn,
#                         bool $lookInCurDir, bool $processInclude,
#                         string $srcPath )
#
# Look for the given file $includeName. If $lookInCurDir, first look in the
# current directory. If $srcPath is nonempty, next look for it there. Then
# look in @includePaths. If it's found in any of these places, add the full
# name of the file (call it $fullname) to the list @$refToDependsOn. In
# addition, if $processInclude, search for dependencies in the file, else
# set the array reference $dependsOn{$fullname} to the empty array. If file
# isn't found, check to see if the file's been specified as a built include.
# If so, add it to the dependency list. Otherwise return 0.
sub processDependency
{
    my( $includeName, $refToDependsOn, $lookInCurDir,
        $processInclude, $srcPath ) = @_;

    my $fullName = '';
    my $status = &findIncludeFile( $includeName, \$fullName, $lookInCurDir,
                                   $srcPath );
    if( $status == 0 )
    {
        return 0;
    }
    if( $status == 3 )
    {
        # Let the '$status == 1' case handle this, but be careful
        # not to process the file.
        $status = 1;
        $processInclude = 0;
    }
    if( $status == 1 )
    {
        # found in included paths
        if( $processInclude ) {
            &processSrcFile( $fullName );
        }
        else
        {
            if( !defined($dependsOn{$fullName}) )
            {
                $dependsOn{$fullName} = [];
            }
        }
        push( @$refToDependsOn, $fullName );
    }
    return 1;
}

sub findInPathList
{
    my( $fileName, $refToPathList ) = @_;
    my( $path, $fullName );

    foreach $path (@$refToPathList)
    {
        $fullName = $path . $pathSep . $fileName;
        if( -e $fullName ) {
            return $fullName;
        }
    }

    return 0;
}

sub findBuiltIncludeInIncludePaths
{
    my( $fileName ) = @_;
    my( $path, $fullName );

    foreach $path (@includePaths)
    {
        $fullName = $path . $pathSep . $fileName;
        if( $isBuiltInclude{ $fullName } ) {
            return $fullName;
        }
    }

    return 0;
}

# int findIncludeFile( string $includeName, string& $refToFullName,
#                      bool $lookInCurDir, string $srcPath );
#
# Look for the file $includeName. If $lookInCurDir, look for it first in the
# current directory. If $srcPath isn't empty, look for it next in that
# directory. Then look in @includePaths, then in @excludedPaths. If found,
# set $$refToFullName to the concatenation of the found path and
# $includeName and return 1, unless it was found in @excludedPaths, in which
# case return 2. If not found, return 0.
sub findIncludeFile
{
    my( $includeName, $refToFullName, $lookInCurDir, $srcPath ) = @_;

    if( $lookInCurDir )
    {
        if( -e $includeName )
        {
            $$refToFullName = $includeName;
            return 1;
        }
        if( $isBuiltInclude{$includeName} )
        {
            $$refToFullName = $includeName;
            return 3;
        }
    }

    if( $srcPath )
    {
        $fullName = $srcPath . $includeName;
        if( -e $fullName )
        {
            $$refToFullName = $fullName;
            return 1;
        }
        if( $isBuiltInclude{$fullName} )
        {
            $$refToFullName = $fullName;
            return 3;
        }
    }

    $fullName = &findInPathList( $includeName, \@includePaths );
    if( $fullName )
    {
        $$refToFullName = $fullName;
        return 1;
    }
    $fullName = &findBuiltIncludeInIncludePaths( $includeName );
    if( $fullName )
    {
        $$refToFullName = $fullName;
        return 3;
    }

    if( &findInPathList( $includeName, \@excludedPaths ) ) {
        return 2;
    }
    else {
        return 0;
    }
}

sub printDependencies
{
    my $file;
    my $deps;

    while( ( $file, $deps ) = each %dependsOn )
    {
        printWrapped( $outputFile, "# $file :", '#    ', '', @$deps );
        print $outputFile "#\n";
    }
}

sub printWrapped
{
    my( $outputFile, $firstPrefix, $prefix, $lineContinuer, @list ) = @_;

    my $continuerLen = length( $lineContinuer );
    my $prefixLen = length( $prefix );
    $lineLimit = $MAXLINE - $continuerLen;

    $firstPrefixLen = length( $firstPrefix );
    print $outputFile $firstPrefix;
    $lineLeft = $lineLimit - $firstPrefixLen;
    foreach $item (@list)
    {
        $len = length( $item );
        if( $len > $lineLeft ) {
            print $outputFile "$lineContinuer\n$prefix$item";
            $lineLeft = $lineLimit - $prefixLen - $len;
        }
        else {
            print $outputFile " $item";
            $lineLeft -= ($len + 1);
        }
    }

    print $outputFile "\n";
}

sub nextLine
{
    &reportAndDie( "Unexpected end of $outputFile" ) if !($_ = <$outputFile>);
    $existingLine++;
}

sub throwExistingFileError
{
    my ( $message ) = @_;
    &reportAndDie( "$outputFile($existingLine) : $message" );
}

sub throwExistingFileArgChange
{
    ( $message ) = @_;
    &reportAndDie( "$outputFile($existingLine) : $message" );
}

sub currentLineMustMatch
{
    ( $pattern, $numToMatch ) = @_;
    @fields = /^$pattern$/;
    if( !defined( @fields ) )
    {
        &throwExistingFileError( "Doesn't match expected pattern:\n" .
                                 "\"$pattern\"" );
    }
    if( ($numToMatch != 0 && @fields != $numToMatch) )
    {
        &throwExistingFileError( "Doesn't match expected pattern:\n" .
                                 "\"$pattern\" (@fields, $numToMatch)" );
    }
}

sub nextLineMustMatch
{
    ( $pattern, $numToMatch ) = @_;
    &nextLine();
    &currentLineMustMatch( $pattern, $numToMatch );
}


sub readExistingFile
{
    $existingLine = 0;

    if( -M $0 < -M $outputFile )
    {
        # Just force a full rebuild; this is easiest and safest.
        &throwExistingFileArgChange( "Existing file is " .
                                     "older than mkdep.pl" );
    }
    
    # Verify version.
    &nextLineMustMatch(
        "# Dependency file generated by the PERL script \\S+", 0 );
    &nextLineMustMatch( "# Don't modify!", 0 );
    &nextLineMustMatch( "# Format version (\\d+)", 1 );
    $oldFormatVersion = $fields[0];
    if( $oldFormatVersion != $FormatVersion )
    {
        &throwExistingFileArgChange( "Format of existing file is " .
                                     "$oldFormatVersion," .
                                     "expecting $FormatVersion" );
    }
    &nextLineMustMatch( "#", 0 );

    # Read optional information, if present.
    $oldVarName = '';
    $oldUnbuiltVarName = '';
    $oldForceDependency = '';
    $oldTargetPrefix = '';
    $oldIgnoreBracketedIncludes = 0;

    &nextLine();
    # Read special options. At the very least, the continuation suffix
    # is guaranteed to be mentioned.
    for(;;)
    {
        if( /^# Bracketed includes ignored.$/ )
        {
            $oldIgnoreBracketedIncludes = 1;
        }
        elsif( /^# Varname = (\S+)$/ )
        {
            $oldVarName = $1;
        }
        elsif( /^# UnbuiltVarname = (\S+)$/ )
        {
            $oldUnbuiltVarName = $1;
        }
        elsif( /^# ForceDependency = (\S+)$/ )
        {
            $oldForceDependency = $1;
        }
        elsif( /^# TargetPrefix = (\S+)$/ )
        {
            $oldTargetPrefix = $1;
        }
        elsif( /^# ContinuationSuffix = \"(.*)\"$/ )
        {
            $oldContinuationSuffix = $1;
        }
        else
        {
            &currentLineMustMatch( "#", 0 );
            last;
        }
        &nextLine();
    }
    if( $oldIgnoreBracketedIncludes != $ignoreBracketedIncludes ) {
        # Completely rebuild dependencies.
        &throwExistingFileArgChange( $oldIgnoreBracketedIncludes ?
            "Existing file ignored bracketed includes.\n" :
            "Existing file didn't ignore bracketed includes.\n" );
    }
    if( $oldVarName ne $depVarName ) {
        # Not necessary to rebuild dependencies, just mark modified.
        &printStatus( "Change in name of dependency variable.\n" );
        $modified = 1;
    }
    if( $oldUnbuiltVarName ne $unbuiltVarName ) {
        # Not necessary to rebuild dependencies, just mark modified.
        &printStatus( "Change in name of unbuilt dependency variable.\n" );
        $modified = 1;
    }
    if( $oldForceDependency ne $forceDependency ) {
        # Not necessary to rebuild dependencies, just mark modified.
        &printStatus( "Change in name of force dependency variable.\n" );
        $modified = 1;
    }
    if( $oldTargetPrefix ne $targetPrefix ) {
        # Not necessary to rebuild dependencies, just mark modified.
        &printStatus( "Change in name of target prefix.\n" );
        $modified = 1;
    }
    if( !defined( $oldContinuationSuffix ) ) {
        # File corrupted or a bug in mkdep
        &throwExistingFileError( "No continuation suffix defined" );
    }
    if( $oldContinuationSuffix ne $continuationSuffix ) {
        # Not necessary to rebuild dependencies, just mark modified.
        &throwExistingFileArgChange( "Change in continuation suffix." );
        $modified = 1;
    }
    
    # Read extra target suffixes, if present
    &nextLine();
    if( /^# Extra target suffixes:$/ )
    {
        for(;;)
        {
            &nextLine();
            last if /^#$/;
            &currentLineMustMatch( "# (.*)", 1 );
            @fields = split( /\s+/, $fields[0] );
            push( @oldExtraTargetSuffixes, @fields );
        }
        &nextLine();
    }
    elsif( /^# No extra target suffixes specified\.$/ )
    {
        &nextLineMustMatch( "#", 0 );
        &nextLine();
    }

    if( !arraysEqual( \@extraTargetSuffixes, \@oldExtraTargetSuffixes ) )
    {
        # Not necessary to rebuild dependencies, just mark modified.
        &printStatus( "Change in set of extra target suffixes.\n" );
        $modified = 1;
    }

    # Read include paths
    if( /^# Include paths:$/ )
    {
        for(;;)
        {
            &nextLine();
            last if /^#$/;
            &currentLineMustMatch( "# (.*)", 1 );
            @fields = split( /\s+/, $fields[0] );
            push( @oldIncludes, @fields );
        }
    }
    else
    {
        &currentLineMustMatch( "# No include paths specified\.", 0 );
        &nextLineMustMatch( "#", 0 );
    }

    if( !arraysEqual( \@includePaths, \@oldIncludes ) )
    {
        &printLog( "Include paths from command line:\n" );
        &printArray( ';', @includePaths );
        &printLog( "Include paths from file:\n" );
        &printArray( ';', @oldIncludes );
        &throwExistingFileArgChange( "New include path list." );
    }

    # Read excluded paths
    &nextLine();
    if( /^# Excluded paths:$/ )
    {
        for(;;)
        {
            &nextLine();
            last if /^#$/;
            &currentLineMustMatch( "# (.*)", 1 );
            @fields = split( /\s+/, $fields[0] );
            push( @oldExcludeds, @fields );
        }
    }
    else
    {
        &currentLineMustMatch( "# No excluded paths specified\.", 0 );
        &nextLineMustMatch( "#", 0 );
    }

    if( !arraysEqual( \@excludedPaths, \@oldExcludeds ) )
    {
        &printLog( "Excluded paths from command line:\n" );
        &printArray( ';', @excludedPaths );
        &printLog( "Excluded paths from file:\n" );
        &printArray( ';', @oldExcludeds );
        &throwExistingFileArgChange( "New excluded path list." );
    }
    
    # Read source list
    &nextLineMustMatch( "# Source files:", 0 );
    for(;;)
    {
        &nextLine();
        last if /^#$/;
        &currentLineMustMatch( "# (.*)", 1 );
        @fields = split( /\s+/, $fields[0] );
        push( @oldSrc, @fields );
    }

    if( !arraysEqual( \@srcFiles, \@oldSrc ) )
    {
        &printNoisy( "New source list.\n" );
        $modified = 1;
    }
    
    # Read dependency lists.
    &nextLineMustMatch( "# Dependencies:", 0 );
    for(;;)
    {
        &nextLine();
        last if /^$/;
        &currentLineMustMatch( "# (\\S+) :\\s*(.*)", 2 );

        $srcFile = $fields[0];

        # abort if file doesn't exist
        if( !-e $srcFile ) {
            &throwExistingFileArgChange( "'$srcFile' doesn't exist." );
        }

        $oldDeps{$srcFile} = [];
        $refToDeps = $oldDeps{$srcFile};
        $_ = $fields[1];
        
        # If dependency list on first line is empty, either the
        # dependency list is empty or the first dependency doesn't fit
        # on the first line. Handle both these cases appropriately.
        if( !$_ )
        {
            &nextLineMustMatch( "#\\s*(.*)", 1 );
            $_ = $fields[0];
            if( !$_ ) {
                # really empty
                next;
            }
        }

        # Handle empty dependency list
        if( !$_ )
        {
            &nextLineMustMatch( "#", 0 );
            next;
        }

        # Handle FORCE
        if( /^FORCE$/ )
        {
            undef $oldDeps{$srcFile};
            &nextLineMustMatch( "#", 0 );
            next;
        }

        # Non-empty dependency list
        for(;;)
        {
            @fields = split;

            foreach $dep (@fields)
            {
                push( @$refToDeps, $dep );
            }
            &nextLine();
            last if /^#$/;
            &currentLineMustMatch( "#\\s+(.*)", 1 );
            $_ = $fields[0];
        }
    }


    &printNoisy( "Old dependencies:\n" );
    while( ($file,$refTodeps) = each( %oldDeps ) )
    {
        local $, = ' ';  # dynamic scope has its place
        &printNoisy( "$file :", @$refTodeps, "\n" );
    }
}


sub arraysEqual
{
    ( $refToArray1, $refToArray2 ) = @_;

    $size1 = @$refToArray1;
    $size2 = @$refToArray2;
    if( $size1 != $size2 )
    {
        return 0;
    }

    for( $i = 0; $i < $size1; $i++ ) {
        if( $$refToArray1[$i] ne $$refToArray2[$i] ) {
            return 0;
        }
    }

    return 1;
}

sub printNoisy
{
    if( $noisy ) {
        print $noisyFile @_;
    }
}
sub printStatus
{
    print STDOUT ( '[MKDEP] ', @_ );
}

sub printLog
{
    print STDOUT ( '[MKDEP] ', @_ );
}

sub printArray
{
    my($sep, @array) = @_;
    print STDOUT '[MKDEP] ';
    {
        local($,) = $sep;   # set $, local to this block
        print STDOUT @array;
    }
    print STDOUT "\n";
}

sub printWarning
{
    print STDOUT ( "[MKDEP] Warning: ", @_ );
}

sub reportAndDie
{
    print STDOUT ( "[MKDEP] Error: ", @_, "\n" );
    die "\n";
}

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 mkdep.pl 09-Nov-2001,17:32:10,`JOEV2' Initial revision
#-DT- 2 mkdep.pl 09-Nov-2001,17:54:26,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 mkdep.pl 09-Nov-2001,18:54:56,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 4 mkdep.pl 17-Jan-2002,14:21:10,`JOEV2' DevTools version 0.0.12
#-DT-      Fixed a mkdep.pl bug in handling .rc file references that had trailing
#-DT-      whitespace or comments after the name of the referenced file.
#-DT- 5 mkdep.pl 28-Feb-2002,15:42:38,`JOEV2' DevTools version 0.0.15
#-DT-      Fixed a case-sensitivity bug in mkdep.pl.
#-DT- 6 mkdep.pl 16-Jun-2003,13:56:18,`JOEV3' DevTools version 0.0.41
#-DT-      Fixed some overlong lines and non-syntactic tab characters.
#-DT- 7 mkdep.pl 16-Jun-2003,16:25:42,`JOEV3' DevTools version 0.0.43
#-DT- 8 mkdep.pl 09-Jul-2003,18:12:30,`JOEV3' DevTools version 0.0.56
#-DT-      Stop lower-casing file and directory names.
#-DT- 9 mkdep.pl 24-Apr-2006,22:21:54,`JOEV' DevTools version 0.0.139
#-DT-      Cleaned up special targets, changed precompiled header mechanism.
#-DT- 10 mkdep.pl 01-May-2006,11:19:16,`JOEV4' DevTools version 0.0.141
#-DT-      Added support for gcc 4.1.0.
#-DT- 11 mkdep.pl 02-May-2006,19:15:28,`JOEV' DevTools version 0.0.142
#-DT-      Shared makefile fixes, enhancements, and cleanup.
#-DT- 12 mkdep.pl 08-May-2006,14:52:46,`JOEV4' DevTools version 0.0.144
#-DT-      Enabled more gcc warnings, fixed gcc precompiled header problems.
#-DT- 13 mkdep.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 14 mkdep.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
