############################################################################
# ******************************** WARNING *******************************
#
# This makefile is shared between DevTools, MREC, NatSpeak, and many
# other projects (see make.inc\shared.txt for details on the set of
# shared files.)  Its primary location is in DevTools.  If you make
# modifications to it, make sure that they are either universally
# desirable or appropriately conditionalized to your project
# (preferably through a simple new PROJECT_* variable setting in
# project.mak, though it is very occasionally appropriate to
# conditionalize on project.mak's PROJECT_NAME setting directly
# instead.)
#
# Then, if you are modifying it in a subsidiary (non-DevTools)
# project, it is your responsibility to make sure that your changes
# are migrated (by you or someone else) to the DevTools version.
# Likewise, if you are modifying it in DevTools, it is your
# responsibility to make sure that the new version is propagated to
# the subsidiary projects.  However, note that due to the large
# number of projects using the shared makefiles, and the difficulty
# of merging changes between them, it is altogether preferable to
# make your shared makefile changes directly in DevTools, and only
# ever change your project's shared makefiles by repropagating the
# current versions from DevTools into your project.
#
# ****************************** END WARNING *****************************
############################################################################
#
#  FILE:         update.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach
#  DESCRIPTION:  Perl script for refreshing out-of-date copied files.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# LIMITATIONS:
# Won't handle filenames or directories with spaces in them.


sub printHelp
{
    # Use single quotes around END_OF_HELP so escaping in the text isn't
    # necessary.
    print <<'END_OF_HELP';
update.pl - file-updating Perl script
Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
Usage: perl -w update.pl [Options] {copycmd} {command file}
Options:
   -h
   Produce this usage message and quit.

   -u
   Assume UNIX execution (/ for path separator.)  Windows execution
   is the default.

   {copycmd} should be a command that forces a copy, touching the target.

   {command file} should be a file where each line is of the following format:
   {target directory} {source directory} {file1} {file2} ...

   All fields are optional.  If there are less than 3 fields, no action is
   taken.  Otherwise, each listed file in the source directory that is
   newer than the file with the same name in the target directory is
   copied to the target directory using {copycmd}.  The copy will also be
   done if the file doesn't exist in the target directory.  The copy will
   also be done if the file has a different size in the target directory,
   though a warning will be issued and it's generally a bad idea to rely
   on this, since file sizes can be the same without the underlying
   contents being the same.
END_OF_HELP
}

$pathSep = '\\';
$pathSep2 = '\\\\';
$UNIX = 0;

# get name of perl script. Strip off directory info.
$scriptname = $0;
if( $scriptname =~ /[\\:]([^\\:]*)$/ ) {
    $scriptname = $1;
}

# parse command-line for options:
{
    my $ind = 0;
    while( $ind < @ARGV )
    {
        # default is to remove the argument
        my $arg = splice @ARGV, $ind, 1;
        $arg =~ s/^\s+//;
        $arg =~ s/\s+$//;

        if( $arg =~ /^-h/ )
        {
            &printHelp();
            exit 0;
        }

        # switch to Unix mode
        if( $arg =~ /^-u(.*)/ )
        {
            die "$gProgramName: repeated option '$arg'\n" if $UNIX;
            die "$gProgramName: extra text in option '$arg'\n" if $1;
            $pathSep = '/';
            $pathSep2 = '/';
            $UNIX = 1;
            next;
        }

        if( $arg =~ /^-(\S+)/ )
        {
            die "Invalid option '-$1'";
        }
        
        # otherwise, put arg back and move on
        splice @ARGV, $ind, 0, $arg;
        ++$ind;
    }

    if( @ARGV != 2 )
    {
        &printHelp();
        exit 1;
    }

    $copycmd = shift;
    $cmdfile = shift;
}

if( !open( $cmdfile, $cmdfile ) ) {
    &reportError( "Failed to open $cmdfile ($!)" );
}

$cmdline = 0;
while( <$cmdfile> )
{
    $cmdline++;
    
    # TODO: Handle quoted names
    ( $targetdir, $sourcedir, @files ) = split;

    # For convenience of invoking from make, if no files are specified,
    # just go on.
    if( @files == 0 ) {
        next;
    }

    # Strip trailing slashes if necessary:
    if( $targetdir =~ /$pathSep2$/ ) {
        $targetdir = $`;
    }
    if( $sourcedir =~ /$pathSep2$/ ) {
        $sourcedir = $`;
    }

    # Verify target and source directories
    -d $targetdir or &reportError( "'$targetdir' isn't a directory." );
    -d $sourcedir or &reportError( "'$sourcedir' isn't a directory." );

    while( @files ) {
        $base = shift( @files );

        # $base might be a wildcard.
        if( $base =~ /[*?]/ )
        {
            &reportError( "Wildcard character detected in '$base'." );
        }
        
        $file = $sourcedir . $pathSep . $base;

        # Work around cp bug: remove leading .\
        while( $file =~ /^.$pathSep2/ ) {
            $file = $';
        }

        # Verify source file exists and get its time of last mod.
        $sourceTime = 0;
        $sourceSize = 0;
        if( !getfileinfo( $file, \$sourceTime, \$sourceSize ) ) {
            &reportError( "getfileinfo( $file ) failed ($!)." );
        }

        # Warn if age of source is negative, meaning that touching
        # the target will not cause it to be newer than the source.
        $now = time();
        if( $sourceTime > $now ) {
            &warn( "'$file' is dated in the future.\n" .
                   "filetime = $sourceTime, now = $now" );
        }
        
        $target = $targetdir . $pathSep . $base;
        $targetTime = 0;
        $targetSize = 0;

        if( getfileinfo( $target, \$targetTime, \$targetSize ) )
        {
            # If target time is later than now, force update (with
            # warning).
            if( $targetTime > $now ) {
                &warn( "'$target' is dated in the future, forcing update.\n" .
                       "filetime = $targetTime, now = $now" );
            }

            # If source is later than target, force update.
            elsif( $targetTime < $sourceTime ) {
            }

            # If target and source sizes are different, force update
            # (with warning).
            elsif( $targetSize != $sourceSize ) {
                &warn( "'$target' and '$file' have different sizes, " .
                       "forcing update." );
            }

            # Otherwise, do nothing.
            else {
                next;
            }
        }

        # If we got here, copy the file
        $cmd = "$copycmd $file $targetdir";
        printStatus( $cmd );
        system( $cmd );

        # Check that target time is later than 'now'
        if( !getfileinfo( $target, \$targetTime, \$targetSize ) ) {
            &reportError( "Copy failed ($!)" );
        }
        # We need a fudge because, at least on Win95, we can touch a file
        # and its time could be a second earlier than 'now'.
        if( $targetTime < ($now-1) ) {
            &reportError( "Copy failed to touch target.\n" .
                          "filetime = $targetTime, now = $now" );
        }
        # Check that size of target is same as size of source
        if( $targetSize != $sourceSize ) {
            &reportError( "'$target' has different size ($targetSize) than " .
                          "'$file' ($sourceSize)." );
        }
    }
}


sub getfileinfo
{
    my ( $filename, $timeref, $sizeref ) = @_;
    @stat = stat( $filename );
    if( @stat ) {
        $$sizeref = $stat[7];
        $$timeref = $stat[9];    # mtime = time of last modification
        return 1;
    }
    else {
        return 0;
    }
}

sub getfilesize
{
    my ( $filename, $sizeref ) = @_;
    @stat = stat( $filename );
    if( @stat ) {
        $$sizeref = $stat[7];
        return 1;
    }
    else {
        return 0;
    }
}

sub printStatus
{
    my ( $message, $printCmdFileLine ) = @_;
    if( $printCmdFileLine ) {
        $fileline = "$cmdfile($cmdline) ";
    }
    else {
        $fileline = '';
    }
    $fullmessage = "[$scriptname] $fileline$message\n";
    print $fullmessage;
}

sub getCmdFileLine
{
}

sub reportError
{
    my ( $message ) = @_;
    &printStatus( "Error: $message", $cmdline > 0 );
    exit( 1 );
}

sub warn
{
    my ( $message ) = @_;
    &printStatus( "Warning: $message", $cmdline > 0 );
}

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 update.pl 09-Nov-2001,17:52:12,`JOEV2' Initial revision
#-DT- 2 update.pl 09-Nov-2001,17:54:34,`JOEV2' DevTools version 0.0.3
#-DT-      Created initial versions of root/doc/make.inc files.
#-DT- 3 update.pl 25-Jan-2002,16:26:30,`JOEV2' DevTools version 0.0.14
#-DT-      Minor fixes and enhancements.
#-DT- 4 update.pl 16-Jun-2003,16:25:44,`JOEV3' DevTools version 0.0.43
#-DT- 5 update.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 6 update.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
