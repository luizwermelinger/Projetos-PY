////////////////////////////////////////////////////////////////////////////
//
//  FILE:         killproc.cpp
//  DATE:         2-Jan-03
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Kill all processes with the specified base name.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _MSC_VER
#include <windows.h>
#include <tlhelp32.h>
#endif

int main(int argc, char **argv)
{
    if(argc != 2)
    {
        printf("Usage: killproc <exe_name>\n\n");
        printf("Kill any running processes with the specified base name.\n");
        return 1;
    }
    const char *pBaseToKill=argv[1];

#ifndef _MSC_VER
    printf("Don't know how to kill processes on this OS.\n");
    return 0;
#else
    HANDLE hSnap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if(hSnap == (HANDLE)-1)
    {
        printf("CreateToolhelp32Snapshot failed.\n");
        return 1;
    }
    PROCESSENTRY32 pe;
    if(!Process32First(hSnap, &pe))
    {
        printf("Process32First failed.\n");
        return 1;
    }
    do
    {
        const char *pFileName = pe.szExeFile;
        const char *pLastSlash = strrchr(pFileName, '\\');
        const char *pBaseName = (
            pLastSlash == NULL ? pFileName : pLastSlash + 1);
        const char *pBaseDot = strchr(pBaseName, '.');
        unsigned int baseLen = (
            pBaseDot == NULL ? strlen(pBaseName) :
            (int)(pBaseDot - pBaseName));
        if(baseLen == strlen(pBaseToKill) &&
           !_strnicmp(pBaseName, pBaseToKill, baseLen))
        {
            printf("Killing process %s.\n", pe.szExeFile);
            HANDLE hProc=OpenProcess(PROCESS_TERMINATE, TRUE,
                                     pe.th32ProcessID);
            if(hProc == NULL)
            {
                printf("OpenProcess failed.\n");
                return 1;
            }
            if(!TerminateProcess(hProc, 1))
            {
                printf("TerminateProcess failed.\n");
                return 1;
            }
            if(!CloseHandle(hProc))
            {
                printf("CloseHandle failed.\n");
                return 1;
            }
        }
    }
    while(Process32Next(hSnap, &pe));
    return 0;
#endif
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 killproc.cpp 02-Jan-2003,20:00:24,`JOEV4' Initial revision
// 2 killproc.cpp 08-Jan-2003,17:32:12,`JOEV4' DevTools version 0.0.30
// 3 killproc.cpp 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 killproc.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 5 killproc.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
