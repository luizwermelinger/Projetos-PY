////////////////////////////////////////////////////////////////////////////
//
//  FILE:         tlmres.h
//  DATE:         9-Nov-01
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Resource type and ID definitions for tlm.rc.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

// User-defined resource types
#define IDT_TEXT_FILE 1000

// User-defined resources
#define IDR_TLM_TXT 100
#define IDR_TLM_TXT_SEP 101
#define IDR_TLM_CPP 102
#define IDR_TLM_CPP_SEP 103

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 tlmres.h 09-Nov-2001,18:57:28,`JOEV2' Initial revision
// 2 tlmres.h 09-Nov-2001,18:57:42,`JOEV2' DevTools version 0.0.4
//      Created initial versions of tools files, minor cleanup.
// 3 tlmres.h 16-Jun-2003,16:46:38,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 tlmres.h 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 5 tlmres.h 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
