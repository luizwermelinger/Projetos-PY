////////////////////////////////////////////////////////////////////////////
//
//  FILE:         tlm.cpp
//  DATE:         19-Feb-96
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Executable which does all tlib operations, in a more
//                accessible fashion than tlib itself offers.
//                (originally existed as tl.bat by Paul van Mulbregt.)
//
// Copyright (c) 1996-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

// In order to profile TLM, you need to use the inmsp version, then build in
// mrecutil before building TLM.  Then, profiles will be written to
// bin\inmsp\tlm.pr? for each tlm command.  This hasn't been reimplemented
// since the move to DevTools, though.

#ifndef _WIN32
#error "TLM only works under Win32."
#endif

#define WIN32
#include <windows.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <direct.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include <share.h>

#ifndef __MWERKS__
#include <process.h>
#include <dos.h>
#endif

#include <conio.h>

#ifndef BUILD_COMPILER_DIR
#define BUILD_COMPILER_DIR "none"
#define NAKED_CPP_FILE 1
#endif

#ifndef NAKED_CPP_FILE
#include "tlmres.h"
#endif

typedef int BOOL;

#undef FALSE
#undef TRUE
#define FALSE 0
#define TRUE 1

typedef unsigned int uint;
typedef unsigned char uchar;

#define ISALPHA(x) ((uchar)(x) < 128 && isalpha((uchar)(x)))
#define ISUPPER(x) ((uchar)(x) < 128 && isupper((uchar)(x)))
#define ISLOWER(x) ((uchar)(x) < 128 && islower((uchar)(x)))
#define ISDIGIT(x) ((uchar)(x) < 128 && isdigit((uchar)(x)))
#define ISXDIGIT(x) ((uchar)(x) < 128 && isxdigit((uchar)(x)))
#define ISSPACE(x) ((uchar)(x) < 128 && isspace((uchar)(x)))
#define ISPUNCT(x) ((uchar)(x) < 128 && ispunct((uchar)(x)))
#define ISALNUM(x) ((uchar)(x) < 128 && isalnum((uchar)(x)))
#define ISPRINT(x) ((uchar)(x) < 128 && isprint((uchar)(x)))
#define ISGRAPH(x) ((uchar)(x) < 128 && isgraph((uchar)(x)))
#define ISCNTRL(x) ((uchar)(x) < 128 && iscntrl((uchar)(x)))
#define ISASCII(x) ((uchar)(x) < 128 && isascii((uchar)(x)))

//////////////////////////////////////////////////////////////////////
// Helper macros for using newer C run-time variants that can prevent buffer
// overruns and non-threadsafe errno use.  Note that we are not claiming the
// functions called by the non-Microsoft versions of these macros are
// available on every non_Microsoft platform; but if they are, these macros
// will use them properly, assuming the proper header inclusions.

// String functions
#define DgnStrcpy(pBuf, lBuf, pSrc) strcpy_s(pBuf, lBuf, pSrc)
#define DgnStrncpy(pBuf, lBuf, pSrc, count) strncpy_s(pBuf, lBuf, pSrc, count)
#define DgnStrcat(pBuf, lBuf, pSrc) strcat_s(pBuf, lBuf, pSrc)
#define DgnStrncat(pBuf, lBuf, pSrc, count) strncat_s(pBuf, lBuf, pSrc, count)
#define DgnSprintf(pBuf, lBuf, pFmt, ...) \
    sprintf_s(pBuf, lBuf, pFmt, __VA_ARGS__)
#define DgnSscanf(pBuf, pFmt, ...) \
    sscanf_s(pBuf, pFmt, __VA_ARGS__)
#define DgnSscanfSizedArgument(pBuf, lBuf) pBuf, lBuf

// High-level I/O functions
#define DgnFopen(ppFile, filename, mode) \
    *ppFile = ::_fsopen(filename, mode, _SH_DENYNO)

// Low-level I/O functions
#define DgnOpen(pFd, filename, oflag) \
    ::_sopen_s(pFd, filename, oflag, _SH_DENYWR, _S_IREAD | _S_IWRITE)

// Other functions
#define DgnGetenv(pRet, pBuf, lBuf, pVarName) \
    ::getenv_s(pRet, pBuf, lBuf, pVarName)

#define TL_MAXSTRSIZE 2000
#define TL_BIGMAXSTRSIZE 30000

#define TLIBBS_NAME "tlibbs"
#define TLM_NAME "tlm"
#define TLM_NEXT_CHECKIN_COMMENTS " *tlm-next-checkin-comments*"
#define TLM_MAX_REV_COL 4

// The following lines set up the version info.  Don't modify!
// *tlib-keyword-flag* "%v"
const char *gTlmVersionNumber = "257";
// *tlib-keyword-flag* "%w"
const char *gTlmLastModifier = "JOEV3";
// *tlib-keyword-flag* "%f"
const char *gTlmLastModifiedTimestamp = "01-Feb-07,14:37:24";

const char *gTlmCompileDate = __DATE__ ", " __TIME__;

const char *gTlmCompilerName =
#if defined(_MSC_VER)
 "MS VC++"
#else
 "Unknown compiler"
#endif
 " (" BUILD_COMPILER_DIR ")"
;

// Alpha equiv of int3
#if defined(_MSC_VER) && defined(__alpha)
extern "C" { void __PAL_GENTRAP(unsigned __int64); };
#pragma intrinsic(__PAL_GENTRAP)
#endif

extern "C" void tlmCrashIntoDebugger(void)
{
#ifdef _MSC_VER
#ifdef __alpha
    __PAL_GENTRAP(0);
#else
    _asm { int 3 };
#endif
#endif
}

typedef enum MangleTypeEnum
{
    ENoMangle = 0,
    EMangleForLibrary = 1,
    EMangleForLock = 2
} MangleTypeEnum;

typedef enum NewLineTypeEnum
{
    E_CRLF,
    E_LF,
    E_CR
} NewLineTypeEnum;


char gLibDir[TL_MAXSTRSIZE+1]="";
char gLibDirSlash[TL_MAXSTRSIZE+1]="";
char gLokDir[TL_MAXSTRSIZE+1]="";
char gLokDirSlash[TL_MAXSTRSIZE+1]="";
BOOL gbLibDirIsLokDir;
char gLibExt[TL_MAXSTRSIZE+1]="";
char gLokExt[TL_MAXSTRSIZE+1]="";
int gMaxExtLen;
BOOL gbAllowLongNames;
BOOL gbAllowMixedCaseNames;    // Note that we don't allow mixed-case
                               // directory names even if
                               // gbAllowMixedCaseNames is TRUE, since this
                               // would be tricky and probably unnecessary.
char gGoodExtensions[TL_MAXSTRSIZE+1]="";
char gExtraTrackedExtensions[TL_MAXSTRSIZE+1]="";
BOOL gbMangleExtensions;
char gNetworkDirectory[TL_MAXSTRSIZE+1]="";
char gWorkDirectory[TL_MAXSTRSIZE+1]="";
BOOL gbExecutedFromRoot;

const char *gMarkerForComments = "// Marker for Comments";

// The following should all be set by looking at environment variables in
// initEnvironmentVariables.  None should be examined unless
// gbEnvironmentInitialized is TRUE.
BOOL gbEnvironmentInitialized=FALSE;
BOOL gbAlwaysVerbose=FALSE; // whether to always be verbose, overriding
                            // the setting of gbVerbose.
BOOL gbUsingDave=FALSE; // whether to work around some bugs with local
                        // drives that have been shared from a Mac using
                        // DAVE.
BOOL gbPreventChanges=FALSE; // whether to prevent update/edit/checkin/etc.
                             // operations from this installation.
NewLineTypeEnum gNewLineType=E_CRLF;
BOOL gbCustomDiffExecutableIsInteractive=FALSE;

char gNoCheckinTopDirs[TL_MAXSTRSIZE+1]="";

char gFullTlmPath[TL_MAXSTRSIZE+1]="";
char gTlibbsPath[TL_MAXSTRSIZE+1]="";
char gTlibcompPath[TL_MAXSTRSIZE+1]="";
char gCustomDiffExecutablePath[TL_MAXSTRSIZE+1]="";
char gTlmergePath[TL_MAXSTRSIZE+1]="";
char gTlibSerPath[TL_MAXSTRSIZE+1]="";
char gTempPath[TL_MAXSTRSIZE+1]="";
char gUserName[TL_MAXSTRSIZE+1]="";
char gChmodPath[TL_MAXSTRSIZE+1]="";
char gTailPath[TL_MAXSTRSIZE+1]="";
char gDiffPath[TL_MAXSTRSIZE+1]="";
char gWinMergePath[TL_MAXSTRSIZE+1]="";
char gMorePath[TL_MAXSTRSIZE+1]="";

char gComSpecPath[TL_MAXSTRSIZE+1]="";

char gTlibMinVerStr[TL_MAXSTRSIZE+1]="5.53f";
int gTlibMinVerMajor=5;
int gTlibMinVerMinor=53;
char gTlibMinVerCharacter='f';

#define TLIB_EXAMPLE_DIR "c:\\tlib553f"

char gTlibCurVerStr[TL_MAXSTRSIZE+1]="";
int gTlibCurVerMajor=0;
int gTlibCurVerMinor=0;
char gTlibCurVerCharacter='a';

// Old logic:
//
// A full file name, with path, was forced by TLIB to be under 80
// characters. However, TLIB also folded into that 80-character limit the
// length of the network directory and tlib/tlok directory.  I.e., for a
// file in src.lst "pathxyz\file", "g:\projroot\pathxyz\tlok\file" had to be
// under 80 characters.  This meant that if "g:\projroot" changed (e.g.,
// because of a different drive mapping, or because the project was cloned
// to a longer name), space could suddenly get tighter.  So, TLM was even
// more stringent and limited file-in-src.lst length to 55 characters,
// hopefully short-circuiting such problems without causing too onerous of
// an additional restriction.  Logically, this would have required a
// directory name length limit of 20 characters, but this was never
// implemented.
//
// New logic:
//
// Now that we require tlib32c, some of the limits have gone away.  Here
// are the rationales for the ones that remain:
//     1. A local or network tlibwork.trk file has a well-defined format, in
//        which there's only room for 125 bytes of data per file (the
//        126th-128th being ".<CR><LF>".)  In this format, the only relevant
//        possible fields (in their maximum semi-plausible lengths) can be
//        enumerated as "<filename> v=999999 t=L l=999999999".  The
//        characters after the filename take up 25 bytes, and we must
//        therefore limit the filename itself to at most 100 bytes.  Of
//        course, overlong filenames are to be discouraged; the tlm xcheck
//        and tlm info output formats, for instance, only have room for 35
//        characters without overflowing.
//     2. Experimentally, I've tested and found that a netdir of 118
//        characters (and a "SET NETDIR=" line of 129 characters) works, but
//        one more character causes corruption.  With a netdir of 118
//        characters, a filename of 55 characters works, but one more
//        character causes corruption.  So while there's no well-defined
//        limit, we'd be well-advised to avoid going nuts.
//     3. Experimentally, I've found that creating a file whose
//        name-without-directory is more than 48 characters long (such
//        as "reallylongname1reallylongname2reallylongn.longext") causes
//        corruption in the TLIB revision history comments.  We'll restrict
//        this to 40 characters to be safe.
//
// The new limits I've settled on are within the bounds of possibility,
// without either stretching it to its limits or encouraging overlong
// names (which would slow people down.)

// "h:\tlmtestextralongtlmtestextralong0123\"
const int gMaxNetDirLen=40;
// "d:\tlmtestextralongtlmtestextralong0123\"
const int gMaxWorkDirLen=40;
//"reallylongdir1\reallylongdir2\reallylongdir3\reallylongname10000000.longext"
const int gMaxFileNameLen=75;
//"reallylongname1reallylongname2re.longext"
const int gMaxFileNodeLen=40;

// The following is set by asking the OS what it is.
BOOL gbWinNT=FALSE;

// The following are set by command line options.
BOOL gbVerbose=FALSE;
BOOL gbAnswerYes=FALSE;
BOOL gbNeverPause = FALSE;
BOOL gbNeverBeep = FALSE;
BOOL gbFailureShouldStopBatch=FALSE;

void PrintWrapped(const char *pch)
{
    char tempString[TL_MAXSTRSIZE+1]="";
    int lft;
    int len;

    for (lft = 0;
         lft < ((int)strlen(pch)) && pch[lft] != '\0';
         lft = lft + len)
    {
        int tmp;

        len = 0;
        for (tmp = lft;
             (lft==0 && ((tmp-lft) < 75)) ||
             (lft!=0 && ((tmp-lft) < 71)) ||
             len == 0; //line break before 75 unless it's an 75+ char word.
             tmp++)
        {
            if (pch[tmp] == '\0' || pch[tmp] == '\n' || pch[tmp] == ' ')
            {
                len = tmp - lft;
            }
            if (pch[tmp] == '\0' || pch[tmp] == '\n')
            {
                break;     //line break at end of string or end of line
            }
        } // for (tmp; ...)
        if(lft!=0)
        {
            printf("    ");
        }
        DgnStrncpy(tempString, sizeof(tempString), pch+lft, len);
        tempString[len]='\n';
        tempString[len+1]='\0';
        printf("%s", tempString);
        if (pch[lft + len] == ' ' || pch[lft + len] == '\n')
        {
            while (((lft+len) < ((int)strlen(pch))) &&
                   (pch[lft + len] == ' ' || pch[lft + len] == '\n'))
            {
                len++;
            }
        }
    } // for (lft; ...)
}

void PrintWrapped0(const char *pch)
{
    char temp[TL_MAXSTRSIZE+1]="";
    DgnSprintf(temp, sizeof(temp), pch);
    assert(strlen(temp) <= TL_MAXSTRSIZE);
    PrintWrapped(temp);
}

void MultiPrintWrapped0(const char *stringList[])
{
    for(int i=0; stringList[i]!=NULL; i++)
    {
        PrintWrapped0(stringList[i]);
    }
}

void PrintWrapped1(const char *pch, const char *arg1)
{
    char temp[TL_MAXSTRSIZE+1]="";
    DgnSprintf(temp, sizeof(temp), pch, arg1);
    PrintWrapped(temp);
}

void PrintWrapped2(const char *pch, const char *arg1, const char *arg2)
{
    char temp[TL_MAXSTRSIZE+1]="";
    DgnSprintf(temp, sizeof(temp), pch, arg1, arg2);
    PrintWrapped(temp);
}

void PrintWrapped3(const char *pch, const char *arg1, const char *arg2,
                   const char *arg3)
{
    char temp[TL_MAXSTRSIZE+1]="";
    DgnSprintf(temp, sizeof(temp), pch, arg1, arg2, arg3);
    PrintWrapped(temp);
}

void PrintWrapped4(const char *pch, const char *arg1, const char *arg2,
                   const char *arg3, const char *arg4)
{
    char temp[TL_MAXSTRSIZE+1]="";
    DgnSprintf(temp, sizeof(temp), pch, arg1, arg2, arg3, arg4);
    PrintWrapped(temp);
}

void PrintErrno()
{
    char temp[TL_MAXSTRSIZE+1]="";
    char temp2[TL_MAXSTRSIZE+1]="";
    int errnum=errno;
    strerror_s(temp2, sizeof(temp2), errnum);
    DgnSprintf(temp, sizeof(temp),
               "The errno was %d, meaning %s.", errnum, temp2);
    PrintWrapped(temp);
}

void generateControlC()
{
    GenerateConsoleCtrlEvent(CTRL_C_EVENT, 0);
    // The generated event doesn't necessarily kick in immediately, but
    // on the other hand, we don't want to do anything more.  So we'll
    // infinite loop while waiting to die.
    while(TRUE)
    {
        Sleep(1000);
    }
    assert(!"Should not be reached.");
}

char waitForChar()
{
    fflush(stdout);
#ifdef __MWERKS__
    char ch=(char)__getch();
#else
    char ch=(char)_getch();
#endif
    // special case: allow ctrl-C to terminate us.
    if(ch==0x03)
    {
        generateControlC();
    }
    return ch;
}

void printBeep()
{
    if(gbNeverBeep)
    {
        printf("<BEEP>\n");
    }
    else
    {
        printf("%c", 0x07);
    }
}

void pauseAndWarn()
{
    printBeep();
    if(gbNeverPause)
    {
        printf("Continuing...\n");
    }
    else
    {
        printf("Press any key to continue...\n");
        waitForChar();
    }
}

void failAndExit()
{
    if(gbFailureShouldStopBatch)
    {
        exit(2);    // '@' batch handling checks for this return value and
                    // stops the batch.
    }
    else
    {
        exit(1);
    }
}

void pauseAndExit()
{
    printBeep();
    if(gbNeverPause)
    {
        printf("Exiting...\n");
    }
    else
    {
        printf("Press any key to exit...\n");
        waitForChar();
    }
    failAndExit();
}

void pauseForKey(BOOL bAllowOverride)
{
    printf("Press any key to continue...\n");
    if(bAllowOverride && gbAnswerYes)
    {
        printf("...automatically continuing due to -y switch...\n");
    }
    else
    {
        waitForChar();
    }
}

BOOL waitSeconds(const char *pPreMessage, BOOL bStopOnKey,
                 int nSeconds)
{
    printf("%s", pPreMessage);
    for(int i=0; i<nSeconds; i++)
    {
        if(bStopOnKey && _kbhit())
        {
            waitForChar();  // not actually waiting, just eating it
            printf("\n");
            return TRUE;
        }
        putchar('.');
        Sleep(1000);
    }
    putchar('\n');
    return FALSE;
}

BOOL pauseForYesOrNo(const char *pYesNoQuery)
{
    char ch;
    if(gbAnswerYes)
    {
        printf("%s (y/n) ", pYesNoQuery);
        printf("y\n");
        printf("...automatically continuing due to -y switch...\n");
    }
    else
    {
        do
        {
            printf("%s (y/n) ", pYesNoQuery);
            ch=waitForChar();
            printf("%c\n", ch);
        }
        while(ch != 'y' && ch != 'n' && ch != 'Y' && ch != 'N');
        if(ch == 'n' || ch == 'N')
        {
            return FALSE;
        }
    }
    return TRUE;
}

void pauseForYes()
{
    if(!pauseForYesOrNo("Continue?"))
    {
        failAndExit();
    }
}

void pauseForComprehensionOfUpdate()
{
    BOOL bComprehension=FALSE;
    while(!bComprehension)
    {
        bComprehension=pauseForYesOrNo(
            "Do you accept that this means you are "
            "not currently up-to-date?");
    }
}

static int shSavedDupFD=-1;
static int shSavedDupStderrFD=-1;

int reopenFDToFile(const char* filename, int flags, int oldFD)
{
    int newFD = -1;
    DgnOpen(&newFD, filename, flags);
    if( newFD == -1 || _dup2(newFD, oldFD) == -1 )
    {
        return -1;
    }
    _close(newFD);
    return oldFD;
}

void redirectOutput(const char *filename, BOOL bCaptureStderr)
{
    // Make sure we've flushed output streams before redirecting them.
    fflush(stdout);
    fflush(stderr);

    shSavedDupFD = _dup(_fileno(stdout));

    if(reopenFDToFile(filename,
                      _O_TEXT | _O_WRONLY | _O_CREAT | _O_TRUNC,
                      _fileno(stdout)) == -1)
    {
        printf("Unable to redirect output to file '%s'.\n", filename);
        pauseAndExit();
    }

    _fseeki64(stdout, 0, SEEK_END);

    if(bCaptureStderr)
    {
        shSavedDupStderrFD = _dup(_fileno(stderr));

        if(_dup2(_fileno(stdout), _fileno(stderr)))
        {
            printf("Unable to redirect stdout to stderr.\n");
            pauseAndExit();
        }
    }
}

void closeRedirectedOutput()
{
    if(shSavedDupFD != -1)
    {
        fflush(stdout);
        int result = _dup2(shSavedDupFD, _fileno(stdout));
        _close(shSavedDupFD);
        if(result == -1)
        {
            printf("Unable to close redirected output.\n");
            pauseAndExit();
        }
        shSavedDupFD = -1;
    }

    if(shSavedDupStderrFD != -1)
    {
        fflush(stderr);
        int result = _dup2(shSavedDupStderrFD, _fileno(stderr));
        _close(shSavedDupStderrFD);
        if(result == -1)
        {
            printf("Unable to close redirected output.\n");
            pauseAndExit();
        }
        shSavedDupStderrFD = -1;
    }
}

void toggleStdout(BOOL bOn)
{
    static BOOL sbIsOn=TRUE;
    assert(bOn != sbIsOn);
    if(bOn)
    {
        closeRedirectedOutput();
    }
    else
    {
        redirectOutput("nul", TRUE);
    }
    sbIsOn=bOn;
}

void trimFinalWhiteSpace(char *str)
{
    int i=strlen(str)-1;
    while(i>=0 && ((str[i]==' ') || (str[i]=='\n')))
    {
        str[i--]='\0'; //erase final newline/whitespace
    }
}

void lowerCaseAndTrimFinalWhiteSpace(char *str)
{
    trimFinalWhiteSpace(str);
    int i=strlen(str)-1;
    while(i>=0)
    {
        if(ISUPPER(str[i]))
        {
            str[i]=(char)tolower((uchar)str[i]);
        }
        i--;
    }
}

void convertListLineToFileName(char *str)
{
    if(gbAllowMixedCaseNames)
    {
        trimFinalWhiteSpace(str);
    }
    else
    {
        lowerCaseAndTrimFinalWhiteSpace(str);
    }
}

void truncateAfterFirstSpaceOrTab(char *str)
{
    char *pSpace=strchr(str, ' ');
    if(pSpace!=NULL)
    {
        pSpace[0]='\0';
    }
    char *pTab=strchr(str, '\t');
    if(pTab!=NULL)
    {
        pTab[0]='\0';
    }
}

int firstCharDiffIndex(const char *pStr1, const char *pStr2,
                       BOOL bInsensitive, BOOL bOnlyAtStartOrAfterSlash)
{
    int i=0;
    int j=0;
    while(TRUE)
    {
        char c1=pStr1[i];
        char c2=pStr2[i];
        if(c1=='\0' || c2=='\0')
        {
            // They may both be '\0', but we'll call that the first diff
            // anyway.
            return j;
        }
        if(bInsensitive)
        {
            if(ISUPPER(c1))
            {
                c1=(char)tolower(c1);
            }
            if(ISUPPER(c2))
            {
                c2=(char)tolower(c2);
            }
        }
        if(c1!=c2)
        {
            return j;
        }
        i++;
        if(!bOnlyAtStartOrAfterSlash || c1=='\\')
        {
            j=i;
        }
    }
}
        

BOOL isPrefix(const char *prefix, const char *string)
{
    return !strncmp(prefix, string, strlen(prefix));
}

BOOL isInsensitivePrefix(const char *prefix, const char *string)
{
    return !_strnicmp(prefix, string, strlen(prefix));
}

// return NULL if it doesn't have the prefix; else return a pointer to the
// next char.
char * getSuffixOfPrefix(const char *prefix, const char *string)
{
    if(isPrefix(prefix, string))
    {   // We have to cast because C++ doesn't allow us to return an item of
        // "the same" arbitrary constness as the one passed in.
        return ((char *) string + strlen(prefix));
    }
    else
    {
        return NULL;
    }
}

char * getSuffixOfInsensitivePrefix(const char *prefix,
                                    const char *string)
{
    if(isInsensitivePrefix(prefix, string))
    {   // We have to cast because C++ doesn't allow us to return an item of
        // "the same" arbitrary constness as the one passed in.
        return ((char *) string + strlen(prefix));
    }
    else
    {
        return NULL;
    }
}

void reportLastErrorAndExit(const char *err)
{
    PrintWrapped0(err);
    char errBuf[TL_MAXSTRSIZE+1]="";
    DgnSprintf(errBuf, sizeof(errBuf),
               "GetLastError returned %d.", GetLastError());
    PrintWrapped0(errBuf);
    pauseAndExit();
}

// Wrappers for file operations.

int MyFindFirstFile(HANDLE *phandle, const char *path, WIN32_FIND_DATA *pdata)
{
    return((*phandle = (FindFirstFile(path, pdata))) !=
           INVALID_HANDLE_VALUE);
}

int MyFindNextFile(HANDLE handle, WIN32_FIND_DATA *pdata)
{
    return(FindNextFile(handle, pdata));
}

void MyFindClose(HANDLE handle)
{
// It appears that calling FindClose eats an enormous amount of time, and
// not calling it harms nothing (?); so I occasionally think about
// disabling it.
#if 1
    if(handle!=INVALID_HANDLE_VALUE)
    {
        // On some machines (e.g., some Win95 machines), FindClose sometimes
        // returns FALSE, with GetLastError()==6==ERROR_INVALID_HANDLE, for
        // no perceptible reason (the handle is perfectly valid).  So we no
        // longer check the return value.
#if 1
        FindClose(handle);
#else
        BOOL bClosed=FindClose(handle);
        if(!bClosed)
        {
            reportLastErrorAndExit("Couldn't close find handle.");
        }
#endif
    }
#endif
}

int MyGetFileAttr(const char *name, DWORD *pattrib)
{
    return((*pattrib = GetFileAttributes(name)) == 0xFFFFFFFF);
}

void fillDateTime(WIN32_FIND_DATA finddata, char *pDateTime, int lDateTime)
{
    FILETIME ft;
    SYSTEMTIME systime;
    FileTimeToLocalFileTime(&finddata.ftLastWriteTime, &ft);
    FileTimeToSystemTime(&ft, &systime);
    DgnSprintf(pDateTime, lDateTime,
               "%04u-%02u-%02u %02u:%02u:%02u",
               systime.wYear,
               systime.wMonth,
               systime.wDay,
               systime.wHour,
               systime.wMinute,
               systime.wSecond);
}

BOOL saferFindFileAndAttribInternal(BOOL bAllowMismatchedCase,
                                    const char *fileName, BOOL *pbReadWrite,
                                    char *pDateTime, int lDateTime)
{
    WIN32_FIND_DATA tempfinddata;
    int tempfound=0;
#if 1
    HANDLE temphFindFile;
    tempfound = MyFindFirstFile(&temphFindFile, fileName, &tempfinddata);
    MyFindClose(temphFindFile);
#else
    // Note: the below try didn't speed things up in the slightest.  I'm
    // leaving it here to make sure I don't forget myself and try again.
    
    // Try to make this a little faster by avoiding
    // FindFirstFile/FindClose, since we know we're just looking for
    // the one file.
    tempfinddata.dwFileAttributes = GetFileAttributes(fileName);

    // If it's 0xFFFFFFFF, the file either doesn't exist or we
    // aren't allowed to see its attributes; same difference.
    tempfound=(tempfinddata.dwFileAttributes != 0xFFFFFFFF);
#endif
    if(tempfound!=0 && pbReadWrite!=NULL)
    {
        *pbReadWrite=!(tempfinddata.dwFileAttributes &
                       FILE_ATTRIBUTE_READONLY);
    }
    if(tempfound!=0 && pDateTime!=NULL)
    {
        fillDateTime(tempfinddata, pDateTime, lDateTime);
    }
    if(tempfound!=0)
    {
        const char *lastSlash=strrchr(fileName, '\\');
        const char *lastColon=strrchr(fileName, ':');
        const char *fileNoDir=(lastSlash!=NULL ? lastSlash+1 :
                               (lastColon!=NULL ? lastColon+1 :
                                fileName));
        if(_stricmp(fileNoDir, tempfinddata.cFileName) != 0)
        {
            PrintWrapped2("Was looking for file '%s' "
                          "and found file '%s' "
                          "instead.  This may indicate that a "
                          "special character like '?' or '*' slipped "
                          "through somehow.",
                          fileName, tempfinddata.cFileName);
            pauseAndExit();
        }
        if(gbAllowMixedCaseNames &&
           !bAllowMismatchedCase &&
           strcmp(fileNoDir, tempfinddata.cFileName))
        {
            PrintWrapped2("Was looking for file '%s' "
                          "and found alternatively-cased file '%s' "
                          "instead.  This is a serious inconsistency in a "
                          "project that supports mixed-case filenames, "
                          "and must be rectified.",
                          fileName, tempfinddata.cFileName);
            pauseAndExit();
        }
    }
    return ((tempfound!=0) &&
            !(tempfinddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY));
}

BOOL saferFindFileAndAttrib(const char *fileName, BOOL *pbReadWrite)
{
    return saferFindFileAndAttribInternal(FALSE, fileName, pbReadWrite,
                                          NULL, 0);
}

BOOL saferFindFileAndAttribAndDate(const char *fileName, BOOL *pbReadWrite,
                                   char *pDateTime, int lDateTime)
{
    return saferFindFileAndAttribInternal(FALSE, fileName, pbReadWrite,
                                          pDateTime, lDateTime);
}

BOOL saferFindFile(const char *fileName)
{
    return saferFindFileAndAttribInternal(FALSE, fileName, NULL, NULL, 0);
}

BOOL saferFindFileAllowMismatchedCase(const char *fileName)
{
    return saferFindFileAndAttribInternal(TRUE, fileName, NULL, NULL, 0);
}

BOOL fileExistsAndIsWritable(const char *fileName)
{
    BOOL bWritable=FALSE;
    if(!saferFindFileAndAttrib(fileName, &bWritable))
    {
        return FALSE;
    }
    return bWritable;
}
        
BOOL saferFindDir(const char *dirName)
{
    WIN32_FIND_DATA tempfinddata;
    HANDLE temphFindFile;
    int tempfound=0;
    tempfound = MyFindFirstFile(&temphFindFile, dirName, &tempfinddata);
    MyFindClose(temphFindFile);
    return ((tempfound!=0) &&
            (tempfinddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY));
}

void saferCopyModTimes(const char *fromFileName, const char *toFileName)
{
    FILETIME creationTime;
    FILETIME lastAccessTime;
    FILETIME lastWriteTime;
    HANDLE fromHandle;
    HANDLE toHandle;
    fromHandle=CreateFile(fromFileName, GENERIC_READ, 0, NULL,
                          OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(fromHandle==INVALID_HANDLE_VALUE)
    {
        reportLastErrorAndExit("Couldn't open from file.");
    }
    toHandle=CreateFile(toFileName, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(toHandle==INVALID_HANDLE_VALUE)
    {
        reportLastErrorAndExit("Couldn't open to file.");
    }
    if(!GetFileTime(fromHandle, &creationTime, &lastAccessTime,
                    &lastWriteTime))
    {
        reportLastErrorAndExit("Couldn't get file time.");
    }
    if(!SetFileTime(toHandle, &creationTime, &lastAccessTime,
                    &lastWriteTime))
    {
        reportLastErrorAndExit("Couldn't set file time.");
    }
    if(!CloseHandle(fromHandle) || !CloseHandle(toHandle))
    {
        reportLastErrorAndExit("Couldn't close file handle.");
    }
}

void saferTmpnam(char *pFileName, int lFileName)
{
    assert(gbEnvironmentInitialized);

    int fd=-1;
    for(int i=0; fd==-1 && i<1000; i++)
    {
        int len=strlen(gTempPath);
        DgnSprintf(pFileName, lFileName, "%s%stlm%d.$$$",
                   gTempPath,
                   (len > 0 && gTempPath[len-1] != '\\' ? "\\" : ""),
                   i);
        DgnOpen(&fd, pFileName, _O_CREAT | _O_EXCL | _O_RDWR);
    }

    if(fd == -1)
    {
        PrintWrapped0("Can't get temporary file name.");
        pauseAndExit();
    }

    _close(fd);
}

typedef enum VolumeType
{
    normal,
    silent,
    loud
} VolumeType;

typedef enum CheckRetType
{
    eCheckRetNone,
    eCheckRetZeroToTwo,
    eCheckRetNoneAndNoCheckValidExe
} CheckRetType;

int saferSpawn(VolumeType volume, CheckRetType checkRet,
               const char *spawnArgv[])
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";
    myCmdLine[0]='\0';
    for(int i=0; spawnArgv[i]!=NULL; i++)
    {
        if(i>0)
        {
            DgnStrcat(myCmdLine, sizeof(myCmdLine), " ");
        }
        DgnStrcat(myCmdLine, sizeof(myCmdLine), spawnArgv[i]);
    }
    if(gbVerbose || gbAlwaysVerbose || volume==loud)
    {
        printf("Executing: ");
        puts(myCmdLine);
    }
    if(checkRet != eCheckRetNoneAndNoCheckValidExe &&
       !saferFindFileAllowMismatchedCase(spawnArgv[0]))
    {
        PrintWrapped1("Couldn't execute %s as it doesn't exist.",
                      spawnArgv[0]);
        pauseAndExit();
    }
    if(volume==silent)
    {
        toggleStdout(FALSE);
    }
    int ret=_spawnvp(_P_WAIT, spawnArgv[0], spawnArgv);
    if(volume==silent)
    {
        toggleStdout(TRUE);
    }
    if(ret==-1)
    {
        switch(errno)
        {
         case E2BIG:
            PrintWrapped1("Error: Arguments too long in command %s.",
                          myCmdLine);
            break;
         case EINVAL:
            PrintWrapped1("Error: Executable not found or invalid executable "
                          "in command %s.", myCmdLine);
            break;
         case ENOENT:
            PrintWrapped1("Error: Executable not found in command %s.",
                          myCmdLine);
            break;
         case ENOEXEC:
            PrintWrapped1("Error: File not executable in command %s.",
                          myCmdLine);
            break;
         case ENOMEM:
            PrintWrapped1("Error: Out of memory in command %s.", myCmdLine);
            break;
         default:
            PrintWrapped1("Unknown errno in command %s.", myCmdLine);
            PrintErrno();
            break;
        }
        pauseAndExit();
    }
    switch(checkRet)
    {
     case eCheckRetNone:
     case eCheckRetNoneAndNoCheckValidExe:
        break;
     case eCheckRetZeroToTwo:
        {
            if(ret<0 || ret>2)
            {
                char errBuf[TL_MAXSTRSIZE+1]="";
                DgnSprintf(errBuf, sizeof(errBuf),
                           "Error: unexpected return value %d from %s",
                           ret, myCmdLine);
                PrintWrapped0(errBuf);
                pauseAndExit();
            }
            break;
        }
     default:
        assert(!"Bad CheckRetType");
    }
    
    return ret;
}

int saferSpawn0(VolumeType volume, CheckRetType checkRet,
                const char *pExeName, const char *pArgFormatStr)
{
    char myArgs[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myArgs, sizeof(myArgs), pArgFormatStr); // for the sake of
                                                       // %-consistency

    const char *spawnArgv[]={ pExeName, myArgs, NULL };

    return saferSpawn(volume, checkRet, spawnArgv);
}

int saferSpawn1(VolumeType volume, CheckRetType checkRet,
                const char *pExeName, const char *pArgFormatStr,
                const char *arg1)
{
    char myArgs[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myArgs, sizeof(myArgs), pArgFormatStr, arg1);
    
    const char *spawnArgv[]={ pExeName, myArgs, NULL };

    return saferSpawn(volume, checkRet, spawnArgv);
}

int saferSpawn2(VolumeType volume, CheckRetType checkRet,
                const char *pExeName, const char *pArgFormatStr,
                const char *arg1, const char *arg2)
{
    char myArgs[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myArgs, sizeof(myArgs), pArgFormatStr, arg1, arg2);
    
    const char *spawnArgv[]={ pExeName, myArgs, NULL };

    return saferSpawn(volume, checkRet, spawnArgv);
}

int saferSpawn3(VolumeType volume, CheckRetType checkRet,
                const char *pExeName, const char *pArgFormatStr,
                const char *arg1, const char *arg2, const char *arg3)
{
    char myArgs[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myArgs, sizeof(myArgs), pArgFormatStr, arg1, arg2, arg3);
    
    const char *spawnArgv[]={ pExeName, myArgs, NULL };

    return saferSpawn(volume, checkRet, spawnArgv);
}

void saferMarkWritable(const char * name, BOOL writable)
{
    int pmode;
    if(writable)
    {
        pmode=_S_IWRITE;
    }
    else
    {
        pmode=_S_IREAD;
    }
    int ret = _chmod(name, pmode);
    if(ret != 0)
    {
        BOOL readWrite;
        if(saferFindFileAndAttrib(name, &readWrite))
        {
            if(readWrite == writable)
            {
                ret = 0;
            }
        }
        if(ret != 0)
        {
            printf("Couldn't _chmod %s; it returned %d.\n", name, ret);
            if(ret == -1)
            {
                PrintErrno();
            }
            pauseAndExit();
        }
    }
}

void saferMarkReadOnly(const char * name)
{
    saferMarkWritable(name, FALSE);
}

void saferMarkReadWrite(const char * name)
{
    saferMarkWritable(name, TRUE);
}

void saferRemove(const char * name, BOOL bMustExist)
{
    if(saferFindFile(name))
    {
        saferMarkReadWrite(name);
        int ret=remove(name);
        if(saferFindFile(name))
        {
            //printf("Couldn't remove %s; it returned %d (retrying...)\n",
            //       name, ret);
            if(ret==-1)
            {
                PrintErrno();
            }
            Sleep(1000);
            int ret2=remove(name);
            if(saferFindFile(name))
            {
                printf("Failed to remove %s; it returned %d.\n",
                       name, ret2);
                if(ret2==-1)
                {
                    PrintErrno();
                }
                pauseAndExit();
            }
        }
    }
    else if(bMustExist)
    {
        PrintWrapped1("Couldn't remove %s as it doesn't exist.", name);
        pauseAndExit();
    }
}

void saferMove(const char * oldname, const char * newname,
               BOOL bOldFileMayNotExist)
{
    if(!saferFindFile(oldname))
    {
        if(bOldFileMayNotExist)
        {
            return;
        }
        PrintWrapped2("Couldn't move %s to %s as it doesn't exist.", oldname,
                      newname);
        pauseAndExit();
    }

    if(saferFindFile(newname))
    {
        PrintWrapped3("Couldn't move %s to %s as %s already exists",
                     oldname, newname, newname);
        pauseAndExit();
    }
    
    if(saferFindFile(oldname))
    {
        int ret=rename(oldname, newname);
        if(ret!=0)
        {
            printf("Couldn't rename %s to %s; it returned %d.\n",
                   oldname, newname, ret);
            if(ret==-1)
            {
                PrintErrno();
            }
            pauseAndExit();
        }
    }
    if(saferFindFile(oldname))
    {
        PrintWrapped1("Couldn't move %s.", oldname);
        pauseAndExit();
    }
}

// Screw DOS.  For some routines, there's no OS-independent version, so
// I'll use the Windows one.

void saferCopy(const char * oldname, const char * newname,
               BOOL bNewCopyWritable)
{
    if(!CopyFile(oldname, newname, FALSE))
    {
        char myErrMsg[TL_MAXSTRSIZE+1]="";

        DgnSprintf(myErrMsg, sizeof(myErrMsg), "Couldn't copy %s to %s.",
                   oldname, newname);
        reportLastErrorAndExit(myErrMsg);
    }
    saferMarkWritable(newname, bNewCopyWritable);
}

void saferMkdir(const char * dirname)
{
    int ret=_mkdir(dirname);
    if(ret!=0)
    {
        printf("Couldn't _mkdir %s; it returned %d.\n", dirname, ret);
        if(ret==-1)
        {
            PrintErrno();
        }
        pauseAndExit();
    }
}

void saferRmdir(const char * dirname)
{
    int ret=_rmdir(dirname);
    if(ret!=0)
    {
        printf("Couldn't _rmdir %s; it returned %d.\n", dirname, ret);
        if(ret==-1)
        {
            PrintErrno();
        }
        pauseAndExit();
    }
}

void saferEnsureDirectoryTreeExists(const char *newFileName,
                                    int offsetOfUncheckedDirs)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), newFileName);
    char *currDir=buffer+offsetOfUncheckedDirs;
    while(TRUE)
    {
        char *nextSlash=strchr(currDir, '\\');
        if(nextSlash==NULL)
        {
            break;
        }
        else
        {
            nextSlash[0]='\0';
            if(!saferFindDir(buffer))
            {
                saferMkdir(buffer);
            }
            nextSlash[0]='\\';
            currDir=nextSlash+1;
        }
    }
}

void saferEnsureDirectoryTreePlusSlashExists(const char *dirName)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), dirName);
    DgnStrcat(buffer, sizeof(buffer), "\\");
    saferEnsureDirectoryTreeExists(buffer, (strchr(buffer, '\\')-buffer)+1);
}

void saferCopyWithDirs(const char *oldpath, const char *newdir,
                       BOOL bNewCopyWritable)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), newdir);
    int currIndex=strlen(buffer);
    buffer[currIndex]='\\';
    buffer[currIndex+1]='\0';
    DgnStrcat(buffer, sizeof(buffer), oldpath);
    saferEnsureDirectoryTreeExists(buffer, currIndex+1);
    saferCopy(oldpath, buffer, bNewCopyWritable);
}

void saferChdir(const char *newDir)
{
    if(_chdir(newDir))
    {
        PrintWrapped1("Couldn't set current directory to %s.", newDir);
        PrintErrno();
        pauseAndExit();
    }
}

void saferGetcwd(char *pCurrDir, int lCurrDir)
{
    char temp1[TL_MAXSTRSIZE+1]="";
    char *junk;
    if(GetCurrentDirectory(TL_MAXSTRSIZE, temp1) == 0 ||
       GetFullPathName(temp1, TL_MAXSTRSIZE, pCurrDir, &junk) == 0)
    {
        reportLastErrorAndExit("Couldn't get current directory.");
    }
    _strlwr_s(pCurrDir, lCurrDir);
}

typedef enum FopenMode
{
    eFopenRead,
    eFopenWrite,
    eFopenWriteBinary,
    eFopenAppend
} FopenMode;

BOOL saferFopen(FILE **fppFile, const char *fileName, FopenMode fopenMode)
{
    const char *modeStr=NULL;
    const char *modeDesc=NULL;
    switch(fopenMode)
    {
     case eFopenRead:         modeStr="rt"; modeDesc="read";            break;
     case eFopenWrite:        modeStr="wt"; modeDesc="write";           break;
     case eFopenWriteBinary:  modeStr="wb"; modeDesc="binary write";    break;
     case eFopenAppend:       modeStr="at"; modeDesc="append";          break;
     default: assert(FALSE);
    }

    if(fopenMode==eFopenRead || fopenMode==eFopenAppend)
    {
        // Make a preliminary call to saferFindFile to get the benefit of
        // its case-validity verification.
        *fppFile=NULL;
        if(saferFindFile(fileName))
        {
            DgnFopen(fppFile, fileName, modeStr);
        }
    }
    else
    {
        DgnFopen(fppFile, fileName, modeStr);
    }
    
    if (*fppFile==NULL)
    {
        PrintWrapped2("Couldn't open file \"%s\" in %s mode.",
                      fileName, modeDesc);
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

void exitIfFailed(BOOL bFailed)
{
    if(bFailed)
    {
        pauseAndExit();
    }
}

FILE *saferFopenOrExit(const char *fileName, FopenMode fopenMode)
{
    FILE *fpFile;
    exitIfFailed(!saferFopen(&fpFile, fileName, fopenMode));
    return fpFile;
}

BOOL pathIsUNC(const char *filePath)
{
    return (filePath[0] == '\\' && filePath[1] == '\\');
}

BOOL pathIsAbsoluteNonUNC(const char *filePath)
{
    return ISALPHA(filePath[0]) && filePath[1] == ':' && filePath[2] == '\\';
}

BOOL pathIsNonRootNonUNC(const char *filePath)
{
    return pathIsAbsoluteNonUNC(filePath) && filePath[3]!='\0';
}

BOOL pathIsAbsolute(const char *filePath)
{
    return (pathIsUNC(filePath) ||
            pathIsAbsoluteNonUNC(filePath));
}

int getFileExtensionOffset(const char *filePath)
{
    const char *lastSlash=strrchr(filePath,'\\');
    const char *lastDot=strrchr(filePath,'.');
    if((lastDot==NULL) || (lastDot < lastSlash))
    {
        return strlen(filePath);
    }
    else
    {
        return lastDot-filePath;
    }
}

char *getFileExtensionAfterDot(char *filePathBuffer)
{
    int offset = getFileExtensionOffset(filePathBuffer);
    char *pDot = filePathBuffer + offset;
    // If there's no dot, add one. This is ugly, but to do
    // things right, I'd have to make a more encompassing change.
    // TODO: Do it!
    if(*pDot != '.')
    {
        assert(*pDot == '\0');
        *pDot = '.';
        *(pDot+1) = '\0';
    }
    return pDot + 1;
}

BOOL errBadVersion(const char *str, const char *pLine, const char *pSource)
{
    PrintWrapped3(
        "Error parsing version information '%s' in line '%s' in %s.",
        str, pLine, pSource);
    return FALSE;
}

// Doesn't parse _every_ tlib-valid version, since those can be really nasty
// (e.g. 1.(3)5.1.(7)1... blech.)  Just parse the ones we've actually seen
// happen. 
BOOL reallyParseVersion(const char *ver,
                        int *pMajorVersion, int *pMinorVersion,
                        const char *pLine, const char *pSource)
{
    char str[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(str, sizeof(str), ver);

    *pMajorVersion=0;
    *pMinorVersion=0;
    int j=0;
    while(j < TL_MAXSTRSIZE)
    {
        if(!ISDIGIT(str[j]))
        {
            if((ISSPACE(str[j]) || str[j]=='\0') && (j!=0))
            {
                str[j]='\0';
                *pMajorVersion=atoi(str);
                break;
            }
            else if(str[j]=='.')
            {
                str[j]='\0';
                *pMajorVersion=atoi(str);
                int k=j+1;
                int minorLoc=j+1;
                while(k < TL_MAXSTRSIZE)
                {
                    if(str[k]=='(' && ISDIGIT(str[k+1]) && str[k+2]==')')
                    {
                        // just ignore these abominations, since they've
                        // happened before.
                        k+=3;
                        minorLoc=k;
                    }
                    if(!ISDIGIT(str[k]))
                    {
                        if((ISSPACE(str[k]) || str[k]=='\0') &&
                           (k!=minorLoc))
                        {
                            str[k]='\0';
                            *pMinorVersion=atoi(str+minorLoc);
                            break;
                        }
                        else
                        {
                            return errBadVersion(ver, pLine, pSource);
                        }
                    }
                    k++;
                }
                break;
            }
            else
            {
                return errBadVersion(ver, pLine, pSource);
            }
        }
        j++;
    }
    return TRUE;
}

BOOL parseVersion(char *str, int *pMajorVersion, int *pMinorVersion,
                  const char *pLine, const char *pSource)
{
    while(str[0]!='v' && str[0]!='\0')
    {
        str++;
    }
    if(str[0]!='v' || str[1]!='=')
    {
        return errBadVersion(str, pLine, pSource);
    }
    return reallyParseVersion(str+2, pMajorVersion, pMinorVersion,
                              pLine, pSource);
}

typedef enum FileListType
{
    eSrcLst,
    eTlibworkTrk,
    eSnapshotTxt
} FileListType;

// FileListReader assumes a list (probably sorted) of files of the specified
// type. As a convenience, if the base file is NULL, it's simply treated as
// an empty list.
class FileListReader
{
 protected:
    FILE *mpBaseFile;
    const char *mpBaseFileIdentifier;
    FileListType mFileListType;
    BOOL mbAssumeListSorted;
    char mListBuffer[TL_MAXSTRSIZE+1];
    int mCurrentMajorVersion;
    int mCurrentMinorVersion;
    BOOL mbDone;
    BOOL mbStarted;
    
 public:
    FileListReader(FILE *pBaseFile, const char *pBaseFileIdentifier,
                   FileListType fileListType, BOOL bAssumeListSorted);

    // Gets the next file.
    void next();

    // Keeps getting the next file until it finds the specified file, or (if
    // the list is sorted) it reads a file after where the specified file
    // should have appeared.  Returns true if it actually found the file it
    // was looking for.
    BOOL seekSpecifiedFile(const char *pSpecName);

    // Ditto, but look for the first file in the specified directory.
    BOOL seekSpecifiedDir(const char *pSpecDir);
    
    // Returns true when there are no more files, and no current file.
    BOOL done();
    
    const char *currentFile();
    BOOL readerSupportsVersions();
    int currentMajorVersion();
    int currentMinorVersion();
};

FileListReader::FileListReader(FILE *pBaseFile,
                               const char *pBaseFileIdentifier,
                               FileListType fileListType,
                               BOOL bAssumeListSorted)
{
    mpBaseFile=pBaseFile;
    mpBaseFileIdentifier=pBaseFileIdentifier;
    mFileListType=fileListType;
    mbAssumeListSorted=bAssumeListSorted;
    mbDone=FALSE;
    mbStarted=FALSE;
    
    if(mpBaseFile==NULL)
    {
        mbDone=TRUE;
    }
    else if(mFileListType==eTlibworkTrk)
    {
        if(!fgets(mListBuffer, TL_MAXSTRSIZE, mpBaseFile))
        {
            PrintWrapped1("Unable to read initial line from %s.",
                          mpBaseFileIdentifier);
            pauseAndExit();
        }
        if(strncmp(mListBuffer, "!!* ", 4))
        {
            PrintWrapped2("Incorrect initial line '%s' in %s.",
                          mListBuffer, mpBaseFileIdentifier);
            pauseAndExit();
        }
    }
}

BOOL stringIsLower(const char *str)
{
    int len=strlen(str);
    for(int i=0; i<len; i++)
    {
        if(ISUPPER(str[i]))
        {
            return FALSE;
        }
    }
    return TRUE;
}

void FileListReader::next()
{
    mbStarted=TRUE;
    assert(!done());
    
    if(!fgets(mListBuffer, TL_MAXSTRSIZE, mpBaseFile))
    {
        mListBuffer[0]='\0'; // not strictly necessary (being done should
                             // protect it), but it gives me peace of mind.
        mbDone=TRUE;
        //PrintWrapped2("finished %s.",
        //              mListBuffer, mpBaseFileIdentifier);
    }
    else
    {
        //PrintWrapped2("next read %s in %s.",
        //              mListBuffer, mpBaseFileIdentifier);
        if(mFileListType==eTlibworkTrk || mFileListType==eSnapshotTxt)
        {
            char *pSpace=strchr(mListBuffer, ' ');
            if(pSpace==NULL)
            {
                PrintWrapped2("Inappropriate line '%s' encountered "
                              "in %s.",
                              mListBuffer, mpBaseFileIdentifier);
                pauseAndExit();
            }
            if(!parseVersion(pSpace+1, &mCurrentMajorVersion,
                             &mCurrentMinorVersion, mListBuffer,
                             mpBaseFileIdentifier))
            {
                pauseAndExit();
            }
            pSpace[0]='\0';
        }
        trimFinalWhiteSpace(mListBuffer);
        if(!gbAllowMixedCaseNames && !stringIsLower(mListBuffer))
        {
            PrintWrapped2(
                "Warning: file name '%s' in %s is not all lower-case.",
                mListBuffer, mpBaseFileIdentifier);
        }
        convertListLineToFileName(mListBuffer);
        //PrintWrapped2("Found filename '%s' in %s.",
        //              mListBuffer, mpBaseFileIdentifier);
    }
}

BOOL FileListReader::seekSpecifiedFile(const char *pSpecName)
{
    assert(!done());
    
    while(TRUE)
    {
        //PrintWrapped0("Next.");
        if(mbStarted)
        {
            int cmpRet=_stricmp(currentFile(), pSpecName);
            //PrintWrapped3("Seeking %s, found %s in %s.", pSpecName,
            //              currentFile(), mpBaseFileIdentifier);
            if(cmpRet==0)
            {
                if(gbAllowMixedCaseNames &&
                   strcmp(currentFile(), pSpecName))
                {
                    PrintWrapped2(
                        "Was looking for file '%s' "
                        "and found alternatively-cased file '%s' "
                        "instead.  This is a serious inconsistency in a "
                        "project that supports mixed-case filenames, "
                        "and must be rectified.",
                        pSpecName, currentFile());
                    pauseAndExit();
                }
                return TRUE;
            }
            else if(mbAssumeListSorted && cmpRet > 0)
            {
                return FALSE;
            }
        }
        next();
        if(done())
        {
            return FALSE;
        }
    }
}

BOOL FileListReader::seekSpecifiedDir(const char *pSpecDir)
{
    assert(!done());
    int specDirLen=strlen(pSpecDir);
    
    while(TRUE)
    {
        //PrintWrapped0("Next.");
        next();
        if(done())
        {
            return FALSE;
        }
        int cmpRet=_strnicmp(currentFile(), pSpecDir, specDirLen);
        //PrintWrapped3("Seeking %s, found %s in %s.", pSpecDir,
        //              currentFile(), mpBaseFileIdentifier);
        if(cmpRet==0)
        {
            return TRUE;
        }
        else if(mbAssumeListSorted && cmpRet > 0)
        {
            return FALSE;
        }
    }
}

BOOL FileListReader::done()
{
    return mbDone;
}

const char *FileListReader::currentFile()
{
    assert(mbStarted);
    assert(!done());
    return mListBuffer;
}

BOOL FileListReader::readerSupportsVersions()
{
    return (mFileListType != eSrcLst);
}

int FileListReader::currentMajorVersion()
{
    assert(readerSupportsVersions());
    assert(mbStarted);
    assert(!done());
    return mCurrentMajorVersion;
}

int FileListReader::currentMinorVersion()
{
    assert(readerSupportsVersions());
    assert(mbStarted);
    assert(!done());
    return mCurrentMinorVersion;
}

void FileIOFailure(const char *pFuncName)
{
    PrintWrapped1("An error has occurred while calling %s on a file.  "
                  "Maybe you're low on disk space; try freeing "
                  "up some space before trying again.",
                  pFuncName);
    PrintErrno();
    pauseAndExit();
}

void saferFputs(const char *buffer, FILE *fpFile)
{
    if(fputs(buffer, fpFile) == EOF)
    {
        FileIOFailure("fputs");
    }
}

void saferFclose(FILE *fpFile)
{
    if(fclose(fpFile) != 0)
    {
        FileIOFailure("fclose");
    }
}

#define saferFprintf(pFile, pFmt, ...) \
    if(fprintf(pFile, pFmt, __VA_ARGS__) < 0) { FileIOFailure("fprintf"); }

// Check if an item is in src.lst.
BOOL srcLstFindItem(const char *name, BOOL bOnlyDir)
{
    char newName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(newName, sizeof(newName), name);
    
    if(bOnlyDir)
    {
        char *lastSlash=strrchr(newName, '\\');
        if(lastSlash!=NULL)
        {
            lastSlash[1]='\0';
        }
        else
        {
            return TRUE;
        }
    }

    // open src.lst, look for item.
    FILE *fpSrcLst=saferFopenOrExit("src.lst", eFopenRead);

    BOOL bFoundName=FALSE;
    FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
    if(bOnlyDir)
    {
        bFoundName=srcLstReader.seekSpecifiedDir(newName);
    }
    else
    {
        bFoundName=srcLstReader.seekSpecifiedFile(newName);
    }
    saferFclose(fpSrcLst);
    return bFoundName;
}

// Take an item out of src.lst.
void srcLstRemove(const char *name)
{
    char tempSrcLst[TL_MAXSTRSIZE+1]="";
    
    // open src.lst, save out copy while looking for item.
    FILE *fpSrcLst=saferFopenOrExit("src.lst", eFopenRead);
    saferTmpnam(tempSrcLst, sizeof(tempSrcLst));
    FILE *fpTempOutSrcLst=saferFopenOrExit(tempSrcLst, eFopenWrite);

    BOOL bFoundName=FALSE;

    FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
    while(!srcLstReader.done())
    {
        srcLstReader.next();
        if(srcLstReader.done())
        {
            break;
        }
        if(!_stricmp(name, srcLstReader.currentFile()))
        {
            if(bFoundName)
            {
                PrintWrapped1("Found more than one occurrence "
                              "of '%s' in src.lst.",
                              name);
                pauseAndExit();
            }
            if(gbAllowMixedCaseNames &&
               strcmp(srcLstReader.currentFile(), name))
            {
                PrintWrapped2(
                    "Was looking for file '%s' "
                    "and found alternatively-cased file '%s' "
                    "instead.  This is a serious inconsistency in a "
                    "project that supports mixed-case filenames, "
                    "and must be rectified.",
                    name, srcLstReader.currentFile());
                pauseAndExit();
            }
            bFoundName=TRUE;
        }
        else
        {
            saferFprintf(fpTempOutSrcLst, "%s\n", srcLstReader.currentFile());
        }
    }
    saferFclose(fpSrcLst);
    saferFclose(fpTempOutSrcLst);
    if (!bFoundName)
    {
        PrintWrapped1("Couldn't find %s in src.lst.", name);
        saferRemove(tempSrcLst, TRUE);
        pauseAndExit();
    }

    // move copy onto src.lst
    saferRemove("src.lst", TRUE);
    saferMove(tempSrcLst, "src.lst", FALSE);
}

// Put an item in src.lst, maintaining its sortedness.
BOOL srcLstAdd(const char *name)
{
    char tempSrcLst[TL_MAXSTRSIZE+1]="";

    // open src.lst, save out copy while looking for source.
    FILE *fpSrcLst=saferFopenOrExit("src.lst", eFopenRead);
    saferTmpnam(tempSrcLst, sizeof(tempSrcLst));
    FILE *fpTempOutSrcLst=saferFopenOrExit(tempSrcLst, eFopenWrite);

    BOOL bFoundName=FALSE;

    FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
    while(!srcLstReader.done())
    {
        srcLstReader.next();
        if(srcLstReader.done())
        {
            break;
        }
        if(!_stricmp(name, srcLstReader.currentFile()))
        {
            PrintWrapped1("File %s already in src.lst.",
                          srcLstReader.currentFile());
            return FALSE;
        }
        if((!bFoundName) &&
           (srcLstReader.currentFile()[0]!='\0') &&
           (srcLstReader.currentFile()[0]!=' ') &&
           (_stricmp(name, srcLstReader.currentFile()) < 0))
        {
            saferFprintf(fpTempOutSrcLst, "%s\n", name);
            bFoundName=TRUE;
        }
        saferFprintf(fpTempOutSrcLst, "%s\n", srcLstReader.currentFile());
    }
    if (!bFoundName)
    {
        saferFprintf(fpTempOutSrcLst, "%s\n", name);
    }

    saferFclose(fpSrcLst);
    saferFclose(fpTempOutSrcLst);

    // move copy onto src.lst
    saferRemove("src.lst", TRUE);
    saferMove(tempSrcLst, "src.lst", FALSE);
    return TRUE;
}

// Take a filename and mangle it into the name of the tlib library or lock
// file for that file.
void tlibMangle(char *pBuffer, int lBuffer, MangleTypeEnum mangleType)
{
    const char *pDir = NULL;
    const char *pExtn = NULL;
    char buffer2[TL_MAXSTRSIZE+1]="";

    switch(mangleType)
    {
     case EMangleForLibrary:
        pDir = gLibDirSlash;
        pExtn = gLibExt;
        break;
     case EMangleForLock:
        pDir = gLokDirSlash;
        pExtn = gLokExt;
        break;
     case ENoMangle:
     default:
        assert(!"Invalid MangleTypeEnum passed to tlibMangle");
        return;
    }
    // insert "tlib\"
    char *lastSlash=strrchr(pBuffer, '\\');
    if(lastSlash==NULL)
    {
        // file is in root directory, use dir\buffer
        DgnStrcpy(buffer2, sizeof(buffer2), pDir);
        DgnStrcat(buffer2, sizeof(buffer2), pBuffer);
    }
    else
    {
        // file not in rootdir, insert dir\ before name
        DgnStrcpy(buffer2, sizeof(buffer2), pBuffer);
        char *insertLoc=strrchr(buffer2,'\\')+1;
        DgnStrcpy(insertLoc, sizeof(buffer2) - int(insertLoc - buffer2), pDir);
        DgnStrcat(buffer2, sizeof(buffer2), lastSlash+1);
    }
    DgnStrcpy(pBuffer, lBuffer, buffer2);

    if(!gbMangleExtensions)
    {
        return; // all done
    }

    // change extension
    char *pExt=getFileExtensionAfterDot(pBuffer);
    // algorithm is as follows:
    // Let's say the file's extension is "xyz" and the extension pattern
    // is "abc".
    // For every non-'?' u  in abc, replace the corresponding character in
    // "xyz" by u. If there are no characters in "xyz" to the left of the
    // position, use '_'.

    int extLen=strlen(pExt);
    assert(extLen <= gMaxExtLen);

    // Count the number of non-?s in "abc"
    int nFixedChars=0;
    int index;
    for(index=0; index < gMaxExtLen; index++)
    {
        if(pExtn[index] != '?') {
            nFixedChars++;
        }
    }

    // Substitute each fixed character into the extension.
    for(index=0; nFixedChars > 0; index++)
    {
        assert(index < gMaxExtLen);
        if(pExtn[index] != '?')
        {
            nFixedChars--;
            pExt[index] = pExtn[index];
        }
        else
        {
            // keep the char the same, unless it's beyond the end,
            // in which case use '_'.
            if(index >= extLen)
            {
                pExt[index] = '_';
            }
        }
    }
    // Make sure string is nul-terminated properly:
    if(index >= extLen)
    {
        pExt[index] = '\0';
    }
}

BOOL gbInsensitive=FALSE;
BOOL gbIgnoreAfterFinalBackslashExceptToTiebreak=FALSE;
int gStartColumn=0;
int gStartOfBackslashesColumn=0;
BOOL gbFirstCompareAfterFirstWhitespace=FALSE;

const char *getNextWhitespace(const char *pStr)
{
    while(!ISSPACE(*pStr))
    {
        pStr++;
    }
    return pStr;
}

const char *getNextNonWhitespace(const char *pStr)
{
    while(ISSPACE(*pStr))
    {
        pStr++;
    }
    return pStr;
}

int cmpStrings(char * const *p1, char * const *p2)
{
    int ret = 0;
    if(gbFirstCompareAfterFirstWhitespace)
    {
        const char *pAfter1=getNextNonWhitespace(getNextWhitespace(*p1));
        const char *pAfter2=getNextNonWhitespace(getNextWhitespace(*p2));
        if(gbInsensitive)
        {
            ret=_stricmp(pAfter1, pAfter2);
        }
        else
        {
            ret=strcmp(pAfter1, pAfter2);
        }
    }
    if(ret == 0)
    {
        // This is a hack and I will pay for mutilating my sort data (and
        // then fixing it, I promise!) while sorting, but it's so tempting I
        // can't resist.
        char *pLastSlash1=NULL;
        char *pLastSlash2=NULL;
        char savedChar1='\\';
        char savedChar2='\\';
        BOOL bRoot1=FALSE;
        BOOL bRoot2=FALSE;
        if(gbIgnoreAfterFinalBackslashExceptToTiebreak)
        {
            pLastSlash1=strrchr((*p1)+gStartOfBackslashesColumn, '\\');
            pLastSlash2=strrchr((*p2)+gStartOfBackslashesColumn, '\\');
            if(pLastSlash1==NULL)
            {
                pLastSlash1=(*p1)+gStartOfBackslashesColumn;
                savedChar1=pLastSlash1[0];
                bRoot1=TRUE;
            }
            pLastSlash1[0]='\0';
            if(pLastSlash2==NULL)
            {
                pLastSlash2=(*p2)+gStartOfBackslashesColumn;
                savedChar2=pLastSlash2[0];
                bRoot2=TRUE;
            }
            pLastSlash2[0]='\0';
        }
        if(gbIgnoreAfterFinalBackslashExceptToTiebreak &&
           gStartColumn == 0 && gStartOfBackslashesColumn == 0 &&
           ((bRoot1 && !bRoot2) || (!bRoot1 && bRoot2)))
        {
            // Put root files at the end in this case, specifically so "tlm
            // prep" will have project-global files like tlmproj.cfg and
            // src.lst at the bottom of the list of files being checked in.
            ret=bRoot1 ? 1 : -1;
        }
        if(ret==0)
        {
            if(gbInsensitive)
            {
                ret=_stricmp((*p1)+gStartColumn, (*p2)+gStartColumn);
            }
            else
            {
                ret=strcmp((*p1)+gStartColumn, (*p2)+gStartColumn);
            }
        }
        if(pLastSlash1)
        {
            pLastSlash1[0]=savedChar1;
        }
        if(pLastSlash2)
        {
            pLastSlash2[0]=savedChar2;
        }
        if(ret==0)
        {
            if(gbInsensitive)
            {
                ret=_stricmp((*p1)+gStartColumn, (*p2)+gStartColumn);
            }
            else
            {
                ret=strcmp((*p1)+gStartColumn, (*p2)+gStartColumn);
            }
        }
    }
    return ret;
}

typedef int (*VoidSortFunction)(const void *, const void *);
typedef int (*StringSortFunction)(char * const *, char * const *);

void saferSort(BOOL caseInsensitive,
               BOOL ignoreAfterFinalBackslashExceptToTiebreak,
               BOOL bFixSrcLstAndSnapshotBugs,
               int startColumn, int startOfBackslashesColumn,
               BOOL bFirstCompareAfterFirstWhitespace,
               const char *fromFile, const char *toFile)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    FILE *fpFromFile=saferFopenOrExit(fromFile, eFopenRead);

    int nLines=0;
    while(!feof(fpFromFile))
    {
        if(fgets(buffer, TL_MAXSTRSIZE, fpFromFile)==NULL)
        {
            break;
        }
        char *p;
        trimFinalWhiteSpace(buffer);
        if(bFixSrcLstAndSnapshotBugs &&
           (buffer[0]=='\0' ||
            strchr(buffer, '?') != NULL ||
            strchr(buffer, '*') != NULL ||
            ((p = strchr(buffer, ' ')) != NULL &&
             (p[1] != 'v' || p[2] != '='))))
        {
            continue;
        }
        nLines++;
    }
    saferFclose(fpFromFile);
    fpFromFile=saferFopenOrExit(fromFile, eFopenRead);

    char **lineArray=(char**)malloc(nLines*sizeof(char*));
    int curLine=0;
    while(!feof(fpFromFile))
    {
        if(fgets(buffer, TL_MAXSTRSIZE, fpFromFile)==NULL)
        {
            break;
        }
        char *realBuffer=buffer;
        char *p;
        if(bFixSrcLstAndSnapshotBugs)
        {
            trimFinalWhiteSpace(buffer);
            if(buffer[0]=='\0' ||
               strchr(buffer, '?') != NULL ||
               strchr(buffer, '*') != NULL ||
               ((p = strchr(buffer, ' ')) != NULL &&
                (p[1] != 'v' || p[2] != '=')))
            {
                continue;
            }
            if(!gbAllowMixedCaseNames)
            {
                _strlwr_s(buffer, sizeof(buffer));
            }
            if(buffer[0]=='.' && buffer[1]=='\\')
            {
                realBuffer=buffer+2;
            }
            int x=strlen(realBuffer);
            realBuffer[x]='\n';
            realBuffer[x+1]='\0';
        }
        int len=strlen(realBuffer);
        lineArray[curLine]=(char*)malloc((len+1)*sizeof(char));
        DgnStrcpy(lineArray[curLine], len+1, realBuffer);
        curLine++;
        if(curLine>nLines)
        {
            PrintWrapped1("%s changed size.", fromFile);
            pauseAndExit();
        }
    }
    saferFclose(fpFromFile);
    if(curLine<nLines)
    {
        PrintWrapped1("%s changed size.", fromFile);
        pauseAndExit();
    }
    gbInsensitive=caseInsensitive;
    gbIgnoreAfterFinalBackslashExceptToTiebreak=(
        ignoreAfterFinalBackslashExceptToTiebreak);
    gStartColumn=startColumn;
    gStartOfBackslashesColumn=startOfBackslashesColumn;
    gbFirstCompareAfterFirstWhitespace=bFirstCompareAfterFirstWhitespace;
    VoidSortFunction voidSortFunction=(VoidSortFunction)(cmpStrings);
    //StringSortFunction stringSortFunction=cmpStrings;
    qsort(lineArray, nLines, sizeof(lineArray[0]), voidSortFunction);
    FILE *fpToFile=saferFopenOrExit(toFile, eFopenWrite);

    for(int i=0; i<nLines; i++)
    {
        // Couldn't figure out how to make this work, but did get it sorted
        // right.
        //if(i!=0)
        //{
        //    int order=(*stringSortFunction)(&(lineArray[i-1]),
        //                                    &(lineArray[i]));
        //    assert(order <= 0);
        //}
        saferFputs(lineArray[i], fpToFile);
        free(lineArray[i]);
    }
    saferFclose(fpToFile);
    free(lineArray);
}

BOOL saferSortAndFopen(FILE **fppFile, BOOL bFixSrcLstAndSnapshotBugs,
                       const char *fileName, const char *sortedFileName)
{
    saferSort(TRUE, FALSE, bFixSrcLstAndSnapshotBugs, 0, 0,
              FALSE, fileName, sortedFileName);
    return saferFopen(fppFile, sortedFileName, eFopenRead);
}

// For more information about of the hashing algorithm used here, see
// doc/hashacc.txt

#define HASH_ROL_NBITS 9
#define HASH_ROL(x) _rotl(x, HASH_ROL_NBITS)

uint hashString(const char *str)
{
    uint hash=0;
    for (int i=0; str[i]!='\0'; i++)
    {
        uchar ch = (uchar)(str[i]);
        if (ISUPPER(ch))
        {
            ch = (uchar)tolower(ch);
        }
        hash = ((uint)HASH_ROL(hash)) + ((uint)ch);
    }
    // Actual hashing happens here....
    const uint cFibonacciMultiplier = 0x9E436CB9UL;
    return hash * cFibonacciMultiplier;
}

#define HASH_MAX_NAMES (2*40000) // should be as big as 2*the length of the
                                 // largest src.lst around.
#define HASH_MAX_CHARS 2000000   // should be maximum concatenated length of
                                 // all names including terminators

class NameListHash
{
 protected:
    BOOL mbCheckNameRestrictions;
    char *mpNamePool;
    char *mpNextPool;
    char **mNames;
    char mSpecialSubDirs[TL_MAXSTRSIZE+1];

    uint hashName(const char *name) const;

 public:
    NameListHash(BOOL bCheckNameRestrictions);
    ~NameListHash();
    void hashInsert(const char *name, BOOL bOkayIfAlreadyPresent);
    int hashFind(const char *name) const;

    char const * const * getAllNames() { return mNames; }
    char const * getNamePool() { return mpNamePool; }
    char const * getNextPool() { return mpNextPool; }
};

uint NameListHash::hashName(const char *name) const
{
    return hashString(name) % HASH_MAX_NAMES;
}

BOOL readConfigOption(const char *configFilePath,
                      const char *configFileName,
                      const char *variableEquals,
                      char *pValue,
                      int lValue,
                      BOOL bErrorIfFileAbsent,
                      BOOL bForceValueLowercase,
                      BOOL bAllowTlibLineContinuation);

BOOL checkFileMeetsNameRestrictions(const char *fileName,
                                    const char *pSpecialSubDirs,
                                    const char *pDesc1,
                                    const char *pDesc2);

NameListHash::NameListHash(BOOL bCheckNameRestrictions)
{
    mbCheckNameRestrictions=bCheckNameRestrictions;
    mpNamePool=new char[HASH_MAX_CHARS];
    mpNextPool=mpNamePool;
    mNames=new char*[HASH_MAX_NAMES];
    for(int i=0; i < HASH_MAX_NAMES; i++)
    {
        mNames[i]=NULL;
    }
    if(!readConfigOption(gWorkDirectory, "tlmproj.cfg",
                         "UPDATE_SPECIAL_SUBDIRS_STARSTAR=",
                         mSpecialSubDirs, sizeof(mSpecialSubDirs),
                         TRUE, TRUE, FALSE))
    {
        mSpecialSubDirs[0]='\0';
    }
}

NameListHash::~NameListHash()
{
    delete mpNamePool;
    delete mNames;
}

void NameListHash::hashInsert(const char *name, BOOL bOkayIfAlreadyPresent)
{
    if(mbCheckNameRestrictions &&
       !checkFileMeetsNameRestrictions(name, mSpecialSubDirs,
                                       "Warning: file name ",
                                       ""))
    {
        //pauseAndWarn();
    }
    int nameLen=strlen(name);
    if((nameLen+1)+(mpNextPool-mpNamePool+1) >= HASH_MAX_CHARS)
    {
        PrintWrapped0("ERROR: Can't add to hash: out of memory.");
        pauseAndExit();
    }
    uint probe, endprobe;
    for(endprobe=(((probe=hashName(name))+HASH_MAX_NAMES-1) %
                  HASH_MAX_NAMES);
        probe!=endprobe;
        probe=((probe + 1) % HASH_MAX_NAMES))
    {
        if(mNames[probe]==NULL)
        {
            mNames[probe]=mpNextPool;
            DgnStrcpy(mNames[probe], nameLen + 1, name);
            mpNextPool = mpNextPool + nameLen + 1;
            return;
        }
        else if(!_stricmp(mNames[probe], name))
        {
            if(bOkayIfAlreadyPresent)
            {
                if(gbAllowMixedCaseNames &&
                   strcmp(mNames[probe], name))
                {
                    PrintWrapped2("Filename hash table (generated from "
                                  "src.lst or another list of files) "
                                  "contains file '%s', but TLM wants to add "
                                  "alternatively-cased file '%s' "
                                  "instead.  This is a serious "
                                  "inconsistency in a "
                                  "project that supports "
                                  "mixed-case filenames, "
                                  "and must be rectified.",
                                  mNames[probe], name);
                    pauseAndExit();
                }
                return;
            }
            else
            {
                PrintWrapped2("Filename hash table (generated from "
                              "src.lst or another list of files) "
                              "already contains file '%s', where "
                              "TLM wants to add the duplicate file '%s'.  "
                              "This is a serious "
                              "inconsistency, "
                              "and must be rectified.",
                              mNames[probe], name);
                pauseAndExit();
            }
        }
    }
    PrintWrapped0("ERROR: Can't add to hash: out of slots.");
    pauseAndExit();
}

int NameListHash::hashFind(const char *name) const
{
    uint probe, endprobe;
    for(endprobe=(((probe=hashName(name))+HASH_MAX_NAMES-1) %
                  HASH_MAX_NAMES);
        (probe!=endprobe) && (mNames[probe]!=NULL);
        probe=((probe + 1) % HASH_MAX_NAMES))
    {
        if(!_stricmp(mNames[probe], name))
        {
            if(gbAllowMixedCaseNames &&
               strcmp(mNames[probe], name))
            {
                PrintWrapped2("Filename hash table (generated from "
                              "src.lst or another list of files) "
                              "contains file '%s', but TLM is looking for "
                              "alternatively-cased file '%s' "
                              "instead.  This is a serious inconsistency in a "
                              "project that supports mixed-case filenames, "
                              "and must be rectified.",
                              mNames[probe], name);
                pauseAndExit();
            }
            return probe;
        }
    }
    return -1;
}

void saferHash(const char *fromFile, const char *toFile)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    FILE *fpFromFile=saferFopenOrExit(fromFile, eFopenRead);

    int nLines=0;
    while(!feof(fpFromFile))
    {
        if(fgets(buffer, TL_MAXSTRSIZE, fpFromFile)==NULL)
        {
            break;
        }
        nLines++;
    }
    saferFclose(fpFromFile);
    fpFromFile=saferFopenOrExit(fromFile, eFopenRead);

    char **lineArray=(char**)malloc(nLines*sizeof(char*));
    int curLine=0;
    while(!feof(fpFromFile))
    {
        if(fgets(buffer, TL_MAXSTRSIZE, fpFromFile)==NULL)
        {
            break;
        }
        int len=strlen(buffer);
        lineArray[curLine]=(char*)malloc((len+1)*sizeof(char));
        DgnStrcpy(lineArray[curLine], len+1, buffer);
        curLine++;
        if(curLine>nLines)
        {
            PrintWrapped1("%s changed size.", fromFile);
            pauseAndExit();
        }
    }
    saferFclose(fpFromFile);
    if(curLine<nLines)
    {
        PrintWrapped1("%s changed size.", fromFile);
        pauseAndExit();
    }
    FILE *fpToFile=saferFopenOrExit(toFile, eFopenWrite);

    char outBuffer[TL_MAXSTRSIZE+1]="";
    for(int i=0; i<nLines; i++)
    {
        uint x=hashString(lineArray[i]);
        DgnSprintf(outBuffer, sizeof(outBuffer), "%u\n", x);
        saferFputs(outBuffer, fpToFile);
        free(lineArray[i]);
    }
    saferFclose(fpToFile);
    free(lineArray);
}

void saferSystem(VolumeType volume, char *cmdLine)
{
    assert(gbEnvironmentInitialized);
    const char *spawnArgv[]={ gComSpecPath, "/c", cmdLine, NULL };

    saferSpawn(volume, eCheckRetNone, spawnArgv);
}

void saferSystem0(VolumeType volume, const char *cmdLine)
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myCmdLine, sizeof(myCmdLine), cmdLine); // for the sake of
                                                       // %-consistency
    saferSystem(volume, myCmdLine);
}

void saferSystem1(VolumeType volume, const char *cmdLine, const char *arg1)
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myCmdLine, sizeof(myCmdLine), cmdLine, arg1);
    saferSystem(volume, myCmdLine);
}

void saferSystem2(VolumeType volume, const char *cmdLine,
                  const char *arg1, const char *arg2)
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myCmdLine, sizeof(myCmdLine), cmdLine, arg1, arg2);
    saferSystem(volume, myCmdLine);
}

void saferSystem3(VolumeType volume, const char *cmdLine,
                  const char *arg1, const char *arg2, const char *arg3)
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myCmdLine, sizeof(myCmdLine), cmdLine, arg1, arg2, arg3);
    saferSystem(volume, myCmdLine);
}

void saferSystem4(VolumeType volume, const char *cmdLine,
                  const char *arg1, const char *arg2, const char *arg3,
                  const char *arg4)
{
    char myCmdLine[TL_MAXSTRSIZE+1]="";

    DgnSprintf(myCmdLine, sizeof(myCmdLine), cmdLine, arg1, arg2, arg3, arg4);
    saferSystem(volume, myCmdLine);
}

int saferTlibbs0(VolumeType volume, const char *cmdLine)
{
    return saferSpawn0(volume, eCheckRetZeroToTwo, gTlibbsPath,
                       cmdLine);
}

int saferTlibbs1(VolumeType volume, const char *cmdLine, const char *arg1)
{
    return saferSpawn1(volume, eCheckRetZeroToTwo, gTlibbsPath,
                       cmdLine, arg1);
}

int saferTlibbs2(VolumeType volume, const char *cmdLine,
                  const char *arg1, const char *arg2)
{
    return saferSpawn2(volume, eCheckRetZeroToTwo, gTlibbsPath,
                       cmdLine, arg1, arg2);
}

int saferTlibbs3(VolumeType volume, const char *cmdLine,
                  const char *arg1, const char *arg2, const char *arg3)
{
    return saferSpawn3(volume, eCheckRetZeroToTwo, gTlibbsPath,
                       cmdLine, arg1, arg2, arg3);
}

BOOL saferFindOrExtractFile(const char *fileName)
{
    return (
        saferFindFile(fileName) ||
        ((saferTlibbs1(silent, "c \"errorpaus 0\" -q ebf %s", fileName) == 0 &&
          saferFindFile(fileName))));
}

#define TLIBWORK_TRK (gbAllowMixedCaseNames ? "TLIBWORK.TRK" : "tlibwork.trk")

BOOL saferCheckReadWriteAccess(const char *netDir)
{
    char trackName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(trackName, sizeof(trackName), netDir);
    DgnStrcat(trackName, sizeof(trackName), "\\");
    DgnStrcat(trackName, sizeof(trackName), TLIBWORK_TRK);
    
    BOOL bWasReadOnly=FALSE;
    BOOL bSuccess=TRUE;
    DWORD dwAttr = GetFileAttributes(trackName);
    if(dwAttr == (DWORD)-1)
    {
        PrintWrapped2("You appear not to have read/write access to "
                      "the specified network directory %s, which you need "
                      "in order to install from it.  (Failed to get "
                      "the attributes on %s.)",
                      netDir, trackName);
        return FALSE;
    }
    else if((dwAttr & FILE_ATTRIBUTE_READONLY) != 0)
    {
        bWasReadOnly=TRUE;
        if(!SetFileAttributes(trackName, dwAttr ^ FILE_ATTRIBUTE_READONLY))
        {
            PrintWrapped2("You appear not to have read/write access to "
                          "the specified network directory %s, which you need "
                          "in order to install from it.  (Failed to set "
                          "the attributes on %s so it would be read/write.)",
                          netDir, trackName);
            return FALSE;
        }
    }

    HANDLE myHandle=CreateFile(trackName, GENERIC_READ | GENERIC_WRITE,
                               FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(myHandle==INVALID_HANDLE_VALUE)
    {
        PrintWrapped2("You appear not to have read/write access to "
                      "the specified network directory %s, which you need "
                      "in order to install from it.  (Failed to set "
                      "the attributes on %s so it would be read/write.)",
                      netDir, trackName);
        bSuccess=FALSE;
    }
    else
    {
        CloseHandle(myHandle);
    }
    
    if(bWasReadOnly)
    {
        if(!SetFileAttributes(trackName, dwAttr))
        {
            if(bSuccess)
            {
                PrintWrapped2("You appear not to have read/write access to "
                              "the specified network directory %s, "
                              "which you need "
                              "in order to install from it.  (Failed to "
                              "the attributes back on %s so it would be "
                              "read-only again.)",
                              netDir, trackName);
            }
            return FALSE;
        }
    }

    return bSuccess;
}

void saferCopyAndTouch(const char * oldname, const char * newname,
                       BOOL bNewCopyWritable)
{
    saferCopy(oldname, newname, TRUE);

    SYSTEMTIME currentSystemTime;
    GetSystemTime(&currentSystemTime);
    FILETIME currentFileTime;
    SystemTimeToFileTime(&currentSystemTime, &currentFileTime);

    HANDLE myHandle=CreateFile(newname, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(myHandle==INVALID_HANDLE_VALUE)
    {
        reportLastErrorAndExit("Couldn't open file.");
    }
    
    FILETIME creationTime;
    FILETIME lastAccessTime;
    FILETIME lastWriteTime;
    if(!GetFileTime(myHandle, &creationTime, &lastAccessTime,
                    &lastWriteTime))
    {
        reportLastErrorAndExit("Couldn't get file time.");
    }
    lastWriteTime = currentFileTime;
    if(!SetFileTime(myHandle, &creationTime, &lastAccessTime,
                    &lastWriteTime))
    {
        reportLastErrorAndExit("Couldn't set file time.");
    }
    if(!CloseHandle(myHandle))
    {
        reportLastErrorAndExit("Couldn't close file handle.");
    }
    
    saferMarkWritable(newname, bNewCopyWritable);
}

void getRelPathInternal(BOOL bReverseDirection, char *pRelPath, int lRelPath)
{
    char origDir[TL_MAXSTRSIZE+1]="";
    char workDir[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(workDir, sizeof(workDir), gWorkDirectory);
    if(workDir[strlen(workDir)-1]=='\\')
    {
        workDir[strlen(workDir)-1]='\0';
    }

    saferGetcwd(origDir, sizeof(origDir));

    if(pRelPath != NULL)
    {
        pRelPath[0] = '\0';
    }
    if(!isPrefix(workDir, origDir))
    {
        PrintWrapped2("%s doesn't look like a subdirectory of %s",
                      workDir, origDir);
        pauseAndExit();
    }
    else
    {
        if(pRelPath != NULL && origDir[strlen(workDir)]=='\\')
        {
            const char *startRelPath=origDir+strlen(workDir)+1;
            if(bReverseDirection && startRelPath[0] != '\0')
            {
                while(TRUE)
                {
                    DgnStrcat(pRelPath, lRelPath, "..\\");
                    const char *nextSlash=strchr(startRelPath, '\\');
                    if(nextSlash != NULL)
                    {
                        startRelPath = nextSlash+1;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            else
            {
                DgnStrcat(pRelPath, lRelPath, startRelPath);
                DgnStrcat(pRelPath, lRelPath, "\\");
            }
            assert(stringIsLower(pRelPath));
        }
    }
}

// Fill relPath with the offset to the current directory if any, e.g. "alien\"
void getRelPath(char *pRelPath, int lRelPath)
{
    getRelPathInternal(FALSE, pRelPath, lRelPath);
}

// Fill relPath with the offset from the current directory if any, e.g. "..\"
void getReverseRelPath(char *pRelPath, int lRelPath)
{
    getRelPathInternal(TRUE, pRelPath, lRelPath);
}

void fullMangle(char *pBuffer, int lBuffer,
                const char *dirName, const char *fileName,
                MangleTypeEnum mangleType)
{
    DgnStrcpy(pBuffer, lBuffer, dirName);
    DgnStrcat(pBuffer, lBuffer, fileName);
    if(mangleType != ENoMangle)
    {
        tlibMangle(pBuffer, lBuffer, mangleType);
    }
}

// Note that this always returns 1 for files that have weak locking enabled
// (e.g. updating.lck).
//
// 0 = Checked out to you
// 1 = Not checked out
// 2 = Checked out to someone else
int checkLock(const char *fileName, BOOL bStrong = FALSE)
{
    return saferTlibbs2(silent, "-q -e1 c \"errorpaus 0\" %st %s",
                       (bStrong ? "c \"LOCKING Y\" " : ""), fileName);
}

// This should always work, even for weak locking files.
BOOL isLocked(const char *netdir, const char *fileName, char *lockingUser,
              BOOL *pbStrongLocked)
{
    assert(pbStrongLocked != NULL);
    assert(lockingUser != NULL);
    *pbStrongLocked=TRUE;
    
    char buffer[TL_MAXSTRSIZE+1]="";

    fullMangle(buffer, sizeof(buffer), netdir, fileName, EMangleForLock);
    BOOL ret=saferFindFile(buffer);

    if(ret)
    {
        FILE *fpLock=saferFopenOrExit(buffer, eFopenRead);
        if(fgets(lockingUser, TL_MAXSTRSIZE, fpLock) != NULL)
        {
            trimFinalWhiteSpace(lockingUser);
            char *pSpace=strchr(lockingUser, ' ');
            if(pSpace!=NULL)
            {
                pSpace[0]='\0';
                char *pNextSpace=strchr(pSpace+1, ' ');
                if(pNextSpace!=NULL)
                {
                    if(!_stricmp(pNextSpace+1, "w=1"))
                    {
                        *pbStrongLocked=FALSE;
                    }
                }
            }
        }
        else
        {
            // TLIB treats an empty lock file as "not locked".
            ret = FALSE;
        }
        saferFclose(fpLock);
    }
    return ret;
}

void incrementVersion(int *pMajor, int *pMinor)
{   // A best guess at what the next version will be.
    if((*pMinor)!=0)
    {
        (*pMinor)++;
    }
    else
    {
        (*pMajor)++;
    }
}

// returns > 0 if ver1 > ver2, < 0 if ver1 < ver2, = 0 if ver1 == ver2.
int compareVersions(int ver1Major, int ver1Minor, int ver2Major, int ver2Minor)
{
    if(ver1Major > ver2Major)
    {
        return 1;
    }
    else if(ver1Major < ver2Major)
    {
        return -1;
    }
    else if(ver1Minor > ver2Minor)
    {
        return 1;
    }
    else if(ver1Minor < ver2Minor)
    {
        return -1;
    }
    else
    {
        return 0;
    }
}

void fillVersionString(char *pVer, int lVer, int major, int minor)
{
    if(minor!=0)
    {
        DgnSprintf(pVer, lVer, "%d.%d", major, minor);
    }
    else
    {
        DgnSprintf(pVer, lVer, "%d", major);
    }
}

void printVersion(FILE *fpOut, int major, int minor)
{
    char ver[TL_MAXSTRSIZE+1]="";
    fillVersionString(ver, sizeof(ver), major, minor);
    saferFprintf(fpOut, "%s", ver);
}

BOOL getNetworkVersionFromHistory(const char *historyFileName,
                                  int *pMajorVersion, int *pMinorVersion,
                                  int *pnVersionsFound)
{
    char verBuffer[TL_MAXSTRSIZE+1]="";

    FILE *fpVer=saferFopenOrExit(historyFileName, eFopenRead);

    *pnVersionsFound=0;
    *pMajorVersion=0;
    *pMinorVersion=0;
    while(fgets(verBuffer, TL_MAXSTRSIZE, fpVer))
    {
        trimFinalWhiteSpace(verBuffer);
        if(ISDIGIT(verBuffer[0]))
        {
            if(!reallyParseVersion(verBuffer, pMajorVersion, pMinorVersion,
                                   verBuffer, historyFileName))
            {
                return FALSE;
            }
            (*pnVersionsFound)++;
        }
        else if(ISSPACE(verBuffer[0]) && ISDIGIT(verBuffer[1]))
        {
            if(!reallyParseVersion(verBuffer+1, pMajorVersion, pMinorVersion,
                                   verBuffer, historyFileName))
            {
                return FALSE;
            }
            (*pnVersionsFound)++;
        }
    }

    saferFclose(fpVer);

    if(*pMajorVersion == 0)
    {
        PrintWrapped1("Couldn't find any version numbers in %s.",
                      historyFileName);
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

BOOL getNetworkVersionAndCount(const char *fileName,
                               int *pMajorVersion, int *pMinorVersion,
                               int *pnVersionsFound)
{
    char tempHistFile[TL_MAXSTRSIZE+1]="";
    saferTmpnam(tempHistFile, sizeof(tempHistFile));
    redirectOutput(tempHistFile, FALSE);
    int ret=saferTlibbs1(normal, "-q l %s", fileName);
    closeRedirectedOutput();
    if(ret != 0)
    {
        PrintWrapped1("Couldn't successfully execute TLIB to "
                      "find %s's history.",
                      fileName);
        return FALSE;
    }
    if(!getNetworkVersionFromHistory(tempHistFile,
                                     pMajorVersion, pMinorVersion,
                                     pnVersionsFound))
    {
        return FALSE;
    }
    saferRemove(tempHistFile, TRUE);
    return TRUE;
}

BOOL getNetworkVersion(const char *fileName,
                       int *pMajorVersion, int *pMinorVersion)
{
    int dummyNumVersionsFound;
    return getNetworkVersionAndCount(fileName, pMajorVersion, pMinorVersion,
                                     &dummyNumVersionsFound);
}

BOOL getNetworkVersionCount(const char *fileName,
                            int *pnVersionsFound)
{
    int dummyMajorVersion;
    int dummyMinorVersion;
    return getNetworkVersionAndCount(fileName,
                                     &dummyMajorVersion, &dummyMinorVersion,
                                     pnVersionsFound);
}

BOOL getVerFromTrack(const char *trackName, const char *fileName,
                     int *pMajorVersion, int *pMinorVersion)
{
    FILE *fpTrack;
    if(!saferFopen(&fpTrack, trackName, eFopenRead))
    {
        return FALSE;
    }

    FileListReader trackReader(fpTrack, TLIBWORK_TRK, eTlibworkTrk, FALSE);
    BOOL bFoundName=trackReader.seekSpecifiedFile(fileName);
    if(bFoundName)
    {
        *pMajorVersion=trackReader.currentMajorVersion();
        *pMinorVersion=trackReader.currentMinorVersion();
    }
    else
    {
        PrintWrapped2("Couldn't find %s in %s.", fileName, trackName);
    }
    saferFclose(fpTrack);
    return bFoundName;
}

BOOL removeDotDotComponents(const char *pSource, char *pDest, int lDest)
{
    int sourceIndex=0;
    int nextDestIndex=0;
    while(pSource[sourceIndex] != '\0')
    {
        if(pSource[sourceIndex] == '\\' &&
           pSource[sourceIndex+1] == '.' &&
           pSource[sourceIndex+2] == '.' &&
           pSource[sourceIndex+3] == '\\')
        {
            if(nextDestIndex==0)
            {
                PrintWrapped1("Too many '..' path components in path '%s'.",
                              pSource);
                return FALSE;
            }
            assert(nextDestIndex < lDest);
            pDest[nextDestIndex]='\0';
            char *pLastSlash=strrchr(pDest, '\\');
            if(pLastSlash == NULL)
            {
                nextDestIndex=0;
                sourceIndex+=4;
            }
            else
            {
                nextDestIndex=(pLastSlash-pDest+1);
                sourceIndex+=3;
            }
        }
        else
        {
            assert(nextDestIndex < lDest);
            pDest[nextDestIndex]=pSource[sourceIndex];
            nextDestIndex++;
            sourceIndex++;
        }
    }
    assert(nextDestIndex < lDest);
    pDest[nextDestIndex]='\0';
    return TRUE;
}

void showHistoryTail(const char *fileName)
{
    // find the history of the file and pipe the last 12 lines; 12
    // lines should be enough to get the latest version and any
    // comments.
    PrintWrapped1("*** The latest official versions of %s are... ***",
                  fileName);
    char tempHistFile[TL_MAXSTRSIZE+1]="";
    saferTmpnam(tempHistFile, sizeof(tempHistFile));
    redirectOutput(tempHistFile, FALSE);
    int ret=saferTlibbs1(normal, "-q l %s", fileName);
    closeRedirectedOutput();
    if(ret != 0)
    {
        PrintWrapped1("Couldn't successfully execute TLIB to "
                      "find %s's history.",
                      fileName);
        pauseAndExit();
    }
    saferSpawn1(normal, eCheckRetNoneAndNoCheckValidExe,
                gTailPath, "-12 %s", tempHistFile);
    saferRemove(tempHistFile, TRUE);
}

BOOL getFileVersionFromTrack(const char *fileName,
                             BOOL bShow, BOOL bRemoteTrack,
                             BOOL bShowHistoryTail,
                             int *pMajor, int *pMinor)
{
    char fullName[TL_MAXSTRSIZE+1]="";
    char fullStrippedName[TL_MAXSTRSIZE+1]="";
    char relPath[TL_MAXSTRSIZE+1]="";
    char trackName[TL_MAXSTRSIZE+1]="";

    getRelPath(relPath, sizeof(relPath));
    DgnStrcpy(fullName, sizeof(fullName), relPath);
    DgnStrcat(fullName, sizeof(fullName), fileName);
    if(!removeDotDotComponents(fullName, fullStrippedName,
                               sizeof(fullStrippedName)))
    {
        return FALSE;
    }
    
    if(bRemoteTrack)
    {
        DgnStrcpy(trackName, sizeof(trackName), gNetworkDirectory);
    }
    else
    {
        DgnStrcpy(trackName, sizeof(trackName), gWorkDirectory);
    }
    DgnStrcat(trackName, sizeof(trackName), TLIBWORK_TRK);
    
    int major;
    int minor;
    if(!getVerFromTrack(trackName, fullStrippedName, &major, &minor))
    {
        return FALSE;
    }
    if(bShowHistoryTail)
    {
        showHistoryTail(fileName);
        PrintWrapped0("\n");
    }
    if(bShow)
    {
        PrintWrapped0(
            "*** Version information from your local track file ***");
        printf("%s v=", fullStrippedName);
        printVersion(stdout, major, minor);
        printf("\n");
    }
    if(pMajor != NULL && pMinor != NULL)
    {
        *pMajor = major;
        *pMinor = minor;
    }
    return TRUE;
}

BOOL isPointerFile(const char *fileName)
{
    return !_stricmp(fileName+getFileExtensionOffset(fileName), ".ptr");
}

// For alien\libc.ptr, major=1, minor=0, fills pRemotePath with something
// like "g:\work\mrec\alien\ptrlib\libc\001\".  *pBegSubdirOffset points to
// the a in alien in the above example, *pEndSubdirOffset points to the p in
// ptrlib.
void getFullRemotePointedPath(char *pRemotePath, int lRemotePath,
                              const char *fileName,
                              int major, int minor, int *pBegSubdirOffset,
                              int *pEndSubdirOffset)
{
    char temp[TL_MAXSTRSIZE+1]="";

    getRelPath(temp, sizeof(temp));
    DgnStrcpy(pRemotePath, lRemotePath, gNetworkDirectory);
    *pBegSubdirOffset=strlen(pRemotePath);
    DgnStrcat(pRemotePath, lRemotePath, temp);
    DgnStrcat(pRemotePath, lRemotePath, fileName);
    pRemotePath[getFileExtensionOffset(pRemotePath)]='\0';
    int lastSlashIndex=strrchr(pRemotePath, '\\') - pRemotePath;
    DgnStrcpy(temp, sizeof(temp), pRemotePath + lastSlashIndex);
    pRemotePath[lastSlashIndex+1]='\0';
    *pEndSubdirOffset=strlen(pRemotePath);
    DgnStrcat(pRemotePath, lRemotePath, "ptrlib");
    DgnStrcat(pRemotePath, lRemotePath, temp);
    DgnSprintf(pRemotePath+strlen(pRemotePath),
               lRemotePath-strlen(pRemotePath), "\\%03d", major);
    if(minor!=0)
    {
        DgnSprintf(pRemotePath+strlen(pRemotePath),
                   lRemotePath-strlen(pRemotePath), ".%03d", minor);
    }
    DgnStrcat(pRemotePath, lRemotePath, "\\");
}

BOOL readConfigOption(const char *configFilePath,
                      const char *configFileName,
                      const char *variableEquals,
                      char *pValue,
                      int lValue,
                      BOOL bErrorIfFileAbsent,
                      BOOL bForceValueLowercase,
                      BOOL bAllowTlibLineContinuation)
{
    BOOL ret=FALSE;

    char configFullFileName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(configFullFileName, sizeof(configFullFileName), configFilePath);
    DgnStrcat(configFullFileName, sizeof(configFullFileName), configFileName);
    
    if(saferFindFile(configFullFileName))
    {
        FILE *fpCfg=saferFopenOrExit(configFullFileName, eFopenRead);

        char buffer[TL_MAXSTRSIZE+1]="";
        while(fgets(buffer, TL_MAXSTRSIZE, fpCfg))
        {
            trimFinalWhiteSpace(buffer);
            const char *suffix=getSuffixOfPrefix(variableEquals, buffer);
            if(suffix!=NULL)
            {
                DgnStrcpy(pValue, lValue, suffix);
                if(bAllowTlibLineContinuation)
                {
                    while(pValue[strlen(pValue)-1] == '\\')
                    {
                        pValue[strlen(pValue)-1]='\0';
                        if(!fgets(buffer, TL_MAXSTRSIZE, fpCfg))
                        {
                            break;
                        }
                        trimFinalWhiteSpace(buffer);
                        char *appendBuf=buffer;
                        while(ISSPACE(*appendBuf))
                        {
                            appendBuf++;
                        }
                        DgnStrcat(pValue, lValue, appendBuf);
                    }
                }
                ret=TRUE;
            }
            if(ret)
            {
                if(bForceValueLowercase)
                {
                    _strlwr_s(pValue, lValue);
                }
                break;
            }
        }
        saferFclose(fpCfg);
    }
    else if(bErrorIfFileAbsent)
    {
        PrintWrapped2("Unable to find configuration file %s when "
                      "attempting to read config option '%s'.",
                      configFullFileName, variableEquals);
        pauseAndExit();
    }
    return ret;
}

// preserves pExtensions, but changes it back and forth for speed
BOOL extensionIsInCommaSet(const char *pExt, const char *pExtensions)
{
    while(TRUE)
    {
        char *pComma=(char *)strchr(pExtensions, ',');
        if(pComma!=NULL)
        {
            *pComma='\0';
        }
        if((pExt[0]=='\0' && pExtensions[0]=='\0') ||
           !_stricmp(pExt+1, pExtensions))
        {
            if(pComma!=NULL)
            {
                *pComma=',';
            }
            return TRUE;
        }
        if(pComma!=NULL)
        {
            *pComma=',';
            pExtensions=pComma+1;
        }
        else
        {
            return FALSE;
        }
    }
}

const char *getNextFieldByWhitespace(const char *pStr)
{
    pStr=strchr(pStr, ' ');
    if(pStr!=NULL)
    {
        pStr++;
    }
    return pStr;
}

BOOL isMemberByWhitespace(const char *pElement, const char *pSet)
{
    while(pSet!=NULL)
    {
        const char *suffix=getSuffixOfInsensitivePrefix(
            pElement, pSet);
        if(suffix!=NULL && (suffix[0]==' ' || suffix[0]=='\0'))
        {
            return TRUE;
        }
        pSet=getNextFieldByWhitespace(pSet);
    }
    return FALSE;
}

BOOL isUserConfiguredFile(const char *fileName)
{
    if(!_stricmp(fileName, "tlibuser.cfg") ||
       !_stricmp(fileName, "tlmuser.cfg") ||
       !_stricmp(fileName, "rootdir.mak"))
    {
        return TRUE;
    }
    char configValue[TL_MAXSTRSIZE+1]="";
    if(!readConfigOption(gWorkDirectory,
                         "tlmproj.cfg", "EXTRA_USER_CONFIGURED_FILES=",
                         configValue, sizeof(configValue),
                         TRUE, FALSE, FALSE))
    {
        configValue[0] = '\0';
    }
    return isMemberByWhitespace(fileName, configValue);
}

BOOL isFileCheckinAllowed(const char *fileName)
{
    char fullName[TL_MAXSTRSIZE+1]="";
    char fullStrippedName[TL_MAXSTRSIZE+1]="";
    getRelPath(fullName, sizeof(fullName));
    DgnStrcat(fullName, sizeof(fullName), fileName);
    if(!removeDotDotComponents(fullName, fullStrippedName,
                               sizeof(fullStrippedName)))
    {
        pauseAndExit();
    }
    char *pSlash=strchr(fullStrippedName, '\\');
    if(pSlash == NULL)
    {
        return TRUE;
    }
    pSlash[0]='\0';
    if(isMemberByWhitespace(fullStrippedName, gNoCheckinTopDirs))
    {
        return FALSE;
    }
    return TRUE;
}

BOOL checkFileCheckinAllowed(const char *fileName)
{
    if(!isFileCheckinAllowed(fileName))
    {
        PrintWrapped1("The file %s is in a directory where checkins "
                      "aren't allowed, only creations and removals.",
                      fileName);
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

typedef enum PointerAction
{
    eCopyTo,
    eCopyFrom,
    eRemoveLocal,
    eXcheck,
    eMarkWritable,
    eMarkReadonly,
    eCheckWritable,
    eCheckMissing,
    eVerifyLocalPresent,
    eVerifyLocalPresentAndWritable,
    eVerifyLegalNames
} PointerAction;

// The numbers are to allow us to sort on the digit character first and the
// name second, to make xchecks appropriately grouped in order of
// importance.
#define TRACKED_BY_PTR " (tracked by pointer file)."
const char *gpLibMissing="[A] NETWORK LIBRARY FILE MISSING.";
const char *gpLibNotReadOnly="[A] NETWORK LIBRARY FILE NOT READ-ONLY.";
const char *gpLockNotReadOnly="[A] NETWORK LOCK FILE NOT READ-ONLY.";
#define REF_MISSING "[A] NETWORK REFERENCE COPY MISSING"
const char *gpRefMissing=REF_MISSING ".";
const char *gpRefMissingTracked=REF_MISSING TRACKED_BY_PTR;
#define REF_RW "[A] NETWORK REFERENCE COPY NOT READ-ONLY"
const char *gpRefNotReadOnly=REF_RW ".";
const char *gpRefNotReadOnlyTracked=REF_RW TRACKED_BY_PTR;
const char *gpTlibCfgThatShouldExist=(
    "[B] should exist, but is not in src.lst.");
const char *gpExtensionThatShouldBeConfigured=(
    "[C] extension not set up in tlibproj.cfg.");
#define LOCAL_MISSING "[D] missing"
const char *gpLocalMissing=LOCAL_MISSING ".";
const char *gpLocalMissingTracked=LOCAL_MISSING TRACKED_BY_PTR;
#define LOCAL_PRESENT "[E] present"
const char *gpLocalPresent=LOCAL_PRESENT ".";
const char *gpLocalPresentTracked=LOCAL_PRESENT TRACKED_BY_PTR;
const char *gpLocalNotReadOnlyNoCheckinAllowed=(
    "[F] not read-only (checkin-disallowed file).");
const char *gpLocalNotReadOnlyUserConfig=(
    "[G] not read-only (user-configured file).");
const char *gpLocalNotReadOnlyCheckedOutToYouInCkinall=(
    "[H] not read-only (++ ckinall.txt %s).");
const char *gpLocalNotReadOnlyCheckedOutToYou=(
    "[I] not read-only (-- ckinall.txt %s).");
#define LOCAL_RW "[J] not read-only"
const char *gpLocalNotReadOnly=LOCAL_RW ".";
const char *gpLocalNotReadOnlyTracked=LOCAL_RW TRACKED_BY_PTR;
const char *gpLocalNotReadOnlyCheckedOut=LOCAL_RW " (checked out to %s).";
const char *gpLocalNotReadOnlyWeakLocked=LOCAL_RW " (weak locked by %s).";
const char *gpLocalReadOnlyNotInSrcLst="[K] read-only, not in src.lst.";
const char *gpLocalNotReadOnlyNotInSrcLst="[L] not read-only, not in src.lst.";
const char *gpLocalNotReadOnlyNotInSrcLstFromExtra=(
    "[M] (extra) not read-only, not in src.lst.");
const char *gpLocalNotReadOnlyNotInSrcLstFromFull=(
    "[N] (full) not read-only, not in src.lst.");
const char *gpUntrackedNonEmptyDirectory=(
    "[O] (full) untracked non-empty directory.");
const char *gpUntrackedEmptyDirectory=(
    "[P] (full) untracked empty directory.");

void printOneTrackInfo(const char *fileName, FILE *pPlainFile, FILE *pTlxFile,
                       const char *desc)
{
    char realFileName[TL_MAXSTRSIZE+1]="";

    if(strchr(fileName, ' ') != NULL)
    {
        int ret=GetShortPathName(fileName, realFileName, TL_MAXSTRSIZE);
        if(ret==0 || ret >= TL_MAXSTRSIZE)
        {
            DgnStrcpy(realFileName, sizeof(realFileName), fileName);
        }
    }
    else
    {
        DgnStrcpy(realFileName, sizeof(realFileName), fileName);
    }
    
    if(pPlainFile)
    {
        saferFprintf(pPlainFile, "%-34s %s\n", realFileName, desc);
    }
    if(pTlxFile)
    {
        saferFprintf(pTlxFile, "%s is modified on your machine\n",
                     realFileName);
    }
}

BOOL handlePointedFiles(PointerAction action, const char *fileName,
                        int copyMajor, int copyMinor,
                        const char *xcheckNetDir, const char *xcheckWorkDir,
                        FILE *pXcheckPlainFile, FILE *pXcheckTlxFile,
                        NameListHash *pXcheckTrackedHash, BOOL xcheckListOnly,
                        FILE *fpCheckWritableList, BOOL *pbAnyWithProperty,
                        BOOL bCheckReferenceCopy);

void xcheckTrackedFile(BOOL bListOnly,
                       NameListHash *pTrackedHash,
                       NameListHash *pCheckinHash,
                       const char *netDir, const char *workDir,
                       const char *fileName,
                       BOOL bIsFromPointerFile,
                       FILE *pPlainFile, FILE *pTlxFile, BOOL bShouldBeHere,
                       BOOL bCheckReferenceCopy)
{
    if(bListOnly && bShouldBeHere)
    {
        if(pPlainFile)
        {
            saferFprintf(pPlainFile, "%s\n", fileName);
        }
    }

    // Check local copy
    {
        char localName[TL_MAXSTRSIZE+1]="";

        DgnStrcpy(localName, sizeof(localName), workDir);
        DgnStrcat(localName, sizeof(localName), fileName);
        BOOL readWrite;
        if(saferFindFileAndAttrib(localName, &readWrite))
        {
            if(bShouldBeHere)
            {
                // Found tracked file in local copy
                if(!bListOnly && readWrite)
                {
                    // Check if checked-out
                    char lockingUser[TL_MAXSTRSIZE+1]="";
                    BOOL bStrongLocked;
                    if(bIsFromPointerFile)
                    {
                        printOneTrackInfo(fileName, pPlainFile, pTlxFile,
                                          gpLocalNotReadOnlyTracked);
                    }
                    else if (isLocked(netDir, fileName, lockingUser,
                                      &bStrongLocked))
                    {
                        char descWithUser[TL_MAXSTRSIZE+1]="";
                        DgnSprintf(descWithUser, sizeof(descWithUser),
                                (bStrongLocked ?
                                 (!_stricmp(lockingUser, gUserName) ?
                                  (pCheckinHash->hashFind(fileName) != -1 ?
                                   gpLocalNotReadOnlyCheckedOutToYouInCkinall :
                                   gpLocalNotReadOnlyCheckedOutToYou) :
                                  gpLocalNotReadOnlyCheckedOut) :
                                 gpLocalNotReadOnlyWeakLocked),
                                lockingUser);
                        printOneTrackInfo(fileName, pPlainFile, pTlxFile,
                                          descWithUser);
                    }
                    else
                    {
                        printOneTrackInfo(
                            fileName, pPlainFile, pTlxFile,
                            (isUserConfiguredFile(fileName) ?
                             gpLocalNotReadOnlyUserConfig :
                             (isFileCheckinAllowed(fileName) ?
                              gpLocalNotReadOnly :
                              gpLocalNotReadOnlyNoCheckinAllowed)));
                    }
                }
                if(!bIsFromPointerFile && isPointerFile(fileName))
                {
                    if(!handlePointedFiles(eXcheck, fileName, 0, 0,
                                           netDir, workDir,
                                           pPlainFile, pTlxFile, pTrackedHash,
                                           bListOnly, NULL, NULL,
                                           bCheckReferenceCopy))
                    {
                        pauseAndExit();
                    }
                }
            }
            else if(!bListOnly)
            {
                // Tracked file should be missing from local copy
                printOneTrackInfo(fileName, pPlainFile, pTlxFile,
                                  (bIsFromPointerFile ?
                                   gpLocalPresentTracked :
                                   gpLocalPresent));
            }
        }
        else if(!bListOnly && bShouldBeHere)
        {
            // Tracked file missing from local copy
            printOneTrackInfo(fileName, pPlainFile, NULL,
                              (bIsFromPointerFile ?
                               gpLocalMissingTracked :
                               gpLocalMissing));
        }
    }

    // Check reference copy
    if(!bListOnly && bCheckReferenceCopy)
    {
        char refName[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(refName, sizeof(refName), netDir);
        DgnStrcat(refName, sizeof(refName), fileName);
        BOOL readWrite;
        if(saferFindFileAndAttrib(refName, &readWrite))
        {
            // Found tracked file in reference copy
            if(readWrite)
            {
                printOneTrackInfo(fileName, pPlainFile, NULL,
                                  (bIsFromPointerFile ?
                                   gpRefNotReadOnlyTracked :
                                   gpRefNotReadOnly));
            }
        }
        else
        {
            // Tracked file missing from reference copy
            printOneTrackInfo(fileName, pPlainFile, NULL,
                              (bIsFromPointerFile ?
                               gpRefMissingTracked :
                               gpRefMissing));
        }

        if(!bIsFromPointerFile)
        {
            char libName[TL_MAXSTRSIZE+1]="";
            fullMangle(libName, sizeof(libName),
                       netDir, fileName, EMangleForLibrary);
            if(saferFindFileAndAttrib(libName, &readWrite))
            {
                // Found library file for tracked file
                if(readWrite)
                {
                    printOneTrackInfo(fileName, pPlainFile, NULL,
                                      gpLibNotReadOnly);
                }
            }
            else
            {
                // Missing library file for tracked file
                printOneTrackInfo(fileName, pPlainFile, NULL,
                                  gpLibMissing);
            }
        }

        if(!bIsFromPointerFile)
        {
            char lockName[TL_MAXSTRSIZE+1]="";
            fullMangle(lockName, sizeof(lockName),
                       netDir, fileName, EMangleForLock);
            if(saferFindFileAndAttrib(lockName, &readWrite))
            {
                // Found lock file for tracked file
                if(readWrite)
                {
                    printOneTrackInfo(fileName, pPlainFile, NULL,
                                      gpLockNotReadOnly);
                }
            }
        }
    }
}

BOOL verifyGoodExtension(const char *fileName)
{
    if(!extensionIsInCommaSet(fileName + getFileExtensionOffset(fileName),
                              gGoodExtensions))
    {
        PrintWrapped1("The extension for the file %s has not been configured "
                      "in tlibproj.cfg.  Please configure it before "
                      "proceeding.", fileName);
        return FALSE;
    }
    return TRUE;
}

BOOL verifyGoodFileNameCase(const char *fileName)
{
    char fileDir[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(fileDir, sizeof(fileDir), fileName);
    char *lastSlash=strrchr(fileDir, '\\');
    if(lastSlash==NULL)
    {
        fileDir[0]='\0';
    }
    else
    {
        lastSlash[1]='\0';
    }

    const char *fileLastDot=strrchr(fileName, '.');
    const char *fileLastSlash=strrchr(fileName, '\\');

    if(fileLastDot != NULL &&
       (fileLastSlash == NULL || fileLastDot > fileLastSlash) &&
       !stringIsLower(fileLastDot))
    {
        PrintWrapped1("The extension of file '%s' is not all "
                      "lower-case.  TLM does not support mixed-case "
                      "file extensions.", fileName);
        return FALSE;
    }
    
    if(!stringIsLower(fileDir))
    {
        PrintWrapped1("The directory component of file '%s' is not all "
                      "lower-case.  TLM does not support mixed-case "
                      "directory components.", fileName);
        return FALSE;
    }

    if(!gbAllowMixedCaseNames && !stringIsLower(fileName))
    {
        PrintWrapped1("The filename component of file '%s' is not all "
                      "lower-case.  Your project does not "
                      "support mixed-case filename components.",
                      fileName);
        return FALSE;
    }

    return TRUE;
}

BOOL handlePointedFiles(PointerAction action, const char *fileName,
                        int copyMajor, int copyMinor,
                        const char *xcheckNetDir, const char *xcheckWorkDir,
                        FILE *pXcheckPlainFile, FILE *pXcheckTlxFile,
                        NameListHash *pXcheckTrackedHash, BOOL xcheckListOnly,
                        FILE *fpCheckWritableList, BOOL *pbAnyWithProperty,
                        BOOL bCheckReferenceCopy)
{
    char remotePtrlibPath[TL_MAXSTRSIZE+1]="";
    char remotePlainPath[TL_MAXSTRSIZE+1]="";
    char localPath[TL_MAXSTRSIZE+1]="";

    int begSubdirOffset;
    int endSubdirOffset;
    getFullRemotePointedPath(remotePtrlibPath, sizeof(remotePtrlibPath),
                             fileName,
                             copyMajor, copyMinor,
                             &begSubdirOffset, &endSubdirOffset);
    DgnStrcpy(remotePlainPath, sizeof(remotePlainPath), remotePtrlibPath);
    int remotePtrlibPathLen = strlen(remotePtrlibPath);

    DgnStrcpy(localPath, sizeof(localPath), fileName);
    char *lastSlash=strrchr(localPath, '\\');
    if(lastSlash!=NULL)
    {
        lastSlash[1]='\0';
    }
    else
    {
        localPath[0]='\0';
    }
    int partLocalPathLen=strlen(localPath);
    FILE *fpTempFile=saferFopenOrExit(fileName, eFopenRead);

    char buffer[TL_MAXSTRSIZE+1]="";
    BOOL ret=TRUE;
    while(fgets(buffer, TL_MAXSTRSIZE, fpTempFile))
    {
        BOOL foundOne=FALSE;
        char *localFile=NULL;
        char *tempPtr;
        if((tempPtr=getSuffixOfInsensitivePrefix("binary=",buffer)) != NULL)
        {
            localFile=tempPtr;
            foundOne=TRUE;
        }
        if(foundOne)
        {
            int i=strlen(localFile)-1;
            while((localFile[i]==' ') || (localFile[i]=='\n'))
            {
                localFile[i--]='\0'; //erase final newline/whitespace
            }
            DgnStrcpy(remotePtrlibPath + remotePtrlibPathLen,
                      sizeof(remotePtrlibPath) - remotePtrlibPathLen,
                      localFile);
            DgnStrcpy(localPath + partLocalPathLen,
                      sizeof(localPath) - partLocalPathLen,
                      localFile);
            switch(action)
            {
             case eCopyTo:
                {
                    PrintWrapped2("Copying %s to %s...",
                                  localPath, remotePtrlibPath);
                    saferEnsureDirectoryTreeExists(remotePtrlibPath,
                                                   begSubdirOffset);
                    saferCopy(localPath, remotePtrlibPath, FALSE);
                    // "extract" the network version
                    DgnStrcpy(remotePlainPath + endSubdirOffset,
                              sizeof(remotePlainPath) - endSubdirOffset,
                              localFile);
                    PrintWrapped2("Copying %s to %s...",
                                  localPath, remotePlainPath);
                    saferEnsureDirectoryTreeExists(remotePlainPath,
                                                   endSubdirOffset);
                    saferRemove(remotePlainPath, FALSE);
                    saferCopy(localPath, remotePlainPath, FALSE);
                    saferMarkWritable(localPath, FALSE);
                    break;
                }
             case eCopyFrom:
                {
                    PrintWrapped2("Copying %s to %s...",
                                  remotePtrlibPath, localPath);
                    saferEnsureDirectoryTreeExists(localPath,
                                                   partLocalPathLen);
                    BOOL localReadWrite;
                    if(saferFindFileAndAttrib(localPath, &localReadWrite) &&
                       localReadWrite)
                    {
                        PrintWrapped2("While extracting the files referenced "
                                      "by %s, couldn't extract %s because the "
                                      "local version is not read-only.",
                                      fileName, localPath);
                        pauseAndWarn();
                    }
                    else
                    {
                        saferRemove(localPath, FALSE);
                        saferCopyAndTouch(remotePtrlibPath, localPath, FALSE);
                    }
                    break;
                }
             case eRemoveLocal:
                {
                    BOOL localReadWrite;
                    if(saferFindFileAndAttrib(localPath, &localReadWrite) &&
                       localReadWrite)
                    {
                        PrintWrapped2("While removing the files referenced by "
                                      "%s, couldn't remove %s because the "
                                      "local version is not read-only.",
                                      fileName, localPath);
                        pauseAndWarn();
                    }
                    else
                    {
                        saferRemove(localPath, FALSE);
                    }
                    break;
                }
             case eXcheck:
                {
                    if(!gbAllowMixedCaseNames)
                    {
                        int len=strlen(localPath);
                        for(int i=0; i<len; i++)
                        {
                            if(localPath[i] >= 'A' && localPath[i] <= 'Z')
                            {
                                PrintWrapped1("Warning: file name '%s' "
                                              "contains an uppercase "
                                              "character.", localPath);
                                //pauseAndWarn();
                                break;
                            }
                        }
                    }
                    pXcheckTrackedHash->hashInsert(localPath, FALSE);
                    
                    xcheckTrackedFile(xcheckListOnly,
                                      pXcheckTrackedHash,
                                      NULL,
                                      xcheckNetDir, xcheckWorkDir, localPath,
                                      TRUE, pXcheckPlainFile,
                                      pXcheckTlxFile, TRUE,
                                      bCheckReferenceCopy);
                    break;
                }
             case eMarkWritable:
                {
                    PrintWrapped1("Marking %s read/write...", localPath);
                    saferMarkWritable(localPath, TRUE);
                    break;
                }
             case eMarkReadonly:
                {
                    PrintWrapped1("Marking %s read-only...", localPath);
                    saferMarkWritable(localPath, FALSE);
                    break;
                }
             case eCheckWritable:
                {
                    if(fileExistsAndIsWritable(localPath))
                    {
                        if(fpCheckWritableList != NULL)
                        {
                            saferFprintf(fpCheckWritableList,
                                         "%s (pointed to by %s)\n",
                                         localPath, fileName);
                        }
                        *pbAnyWithProperty=TRUE;
                    }
                    break;
                }
             case eCheckMissing:
                {
                    if(!saferFindFile(localPath))
                    {
                        *pbAnyWithProperty=TRUE;
                    }
                    break;
                }
             case eVerifyLocalPresent:
                {
                    if(!saferFindFile(localPath))
                    {
                        PrintWrapped2("Can't find %s (pointed to by %s)",
                                      localPath, fileName);
                        ret=FALSE;
                    }
                    break;
                }
             case eVerifyLocalPresentAndWritable:
                {
                    if(!fileExistsAndIsWritable(localPath))
                    {
                        PrintWrapped2("%s (pointed to by %s) "
                                      "does not exist or "
                                      "is not writable.\n",
                                      localPath, fileName);
                        ret=FALSE;
                    }
                    break;
                }
             case eVerifyLegalNames:
                {
                    if(!verifyGoodFileNameCase(localPath) ||
                       !checkFileMeetsNameRestrictions(localPath, "",
                                                       "Can't point to ",
                                                       ", as it "))
                    {
                        ret=FALSE;
                    }
                    break;
                }
             default:
                {
                    PrintWrapped0("Bad action in handlePointedFiles.");
                    return FALSE;
                }
            }
        }
    }
    saferFclose(fpTempFile);
    return ret;
}

BOOL configOptionExistsAndIsOne(const char *configFileName,
                                const char *variableEquals,
                                BOOL bErrorIfFileAbsent)
{
    char configValue[TL_MAXSTRSIZE+1]="";
    if(readConfigOption(gWorkDirectory, configFileName, variableEquals,
                        configValue, sizeof(configValue),
                        bErrorIfFileAbsent, FALSE, FALSE) &&
       atoi(configValue)==1)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL configOptionExistsAndIsZero(const char *configFileName,
                                 const char *variableEquals,
                                 BOOL bErrorIfFileAbsent)
{
    char configValue[TL_MAXSTRSIZE+1]="";
    if(readConfigOption(gWorkDirectory, configFileName, variableEquals,
                        configValue, sizeof(configValue),
                        bErrorIfFileAbsent, FALSE, FALSE) &&
       atoi(configValue)==0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL configMaintainEngStyleVersion()
{
    return configOptionExistsAndIsOne(
        "tlmproj.cfg", "MAINTAIN_ENG_STYLE_PROJECT_VERSION=", TRUE);
}

BOOL configUseUpdtstrc()
{
    return !configOptionExistsAndIsZero(
        "tlmproj.cfg", "USE_UPDTSTRC_BAT=", TRUE);
}

BOOL configUseRootdirMak()
{
    return configOptionExistsAndIsOne(
        "tlmproj.cfg", "USE_ROOTDIR_MAK=", TRUE);
}

BOOL tlibInfo(const char *arg)
{
    saferTlibbs1(normal, "-q -e1 t %s", arg);
    return TRUE;
}

BOOL addItemToSet(char *pSet, int lSet, const char *pAddItem)
{
    char item[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(item, sizeof(item), pAddItem);
    char *pSpace=strchr(item, ' ');
    if(pSpace != NULL)
    {
        pSpace[0]='\0';
    }
    if(isMemberByWhitespace(item, pSet))
    {
        return FALSE;
    }
    if(pSet[0]!='\0')
    {
        DgnStrcat(pSet, lSet, " ");
    }
    DgnStrcat(pSet, lSet, item);
    return TRUE;
}

BOOL addSetToSet(char *pSet, int lSet, const char *pAddSet)
{
    while(pAddSet!=NULL)
    {
        if(!addItemToSet(pSet, lSet, pAddSet))
        {
            return FALSE;
        }
        pAddSet=getNextFieldByWhitespace(pAddSet);
    }
    return TRUE;
}

BOOL subtractItemFromSet(char *pSet, int lSet, const char *pSubItem)
{
    char item[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(item, sizeof(item), pSubItem);
    char *pSpace=strchr(item, ' ');
    if(pSpace != NULL)
    {
        pSpace[0]='\0';
    }
    char resultSet[TL_MAXSTRSIZE+1]="";
    resultSet[0]='\0';
    int nextResultIndex=0;
    BOOL foundItem=FALSE;
    const char *pSetTemp=pSet;
    while(pSetTemp!=NULL)
    {
        const char *suffix=getSuffixOfInsensitivePrefix(
            item, pSetTemp);
        if(suffix!=NULL && (suffix[0]==' ' || suffix[0]=='\0'))
        {
            if(!foundItem)
            {
                foundItem=TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        else
        {
            if(resultSet[0]!='\0')
            {
                resultSet[nextResultIndex++]=' ';
            }
            DgnStrcpy(resultSet + nextResultIndex,
                      sizeof(resultSet) - nextResultIndex,
                      pSetTemp);
            char *pSpace=strchr(resultSet + nextResultIndex, ' ');
            if(pSpace==NULL)
            {
                nextResultIndex=strlen(resultSet);
            }
            else
            {
                nextResultIndex=int(pSpace - resultSet);
            }
        }
        pSetTemp=getNextFieldByWhitespace(pSetTemp);
    }
    if(!foundItem)
    {
        return FALSE;
    }
    resultSet[nextResultIndex]='\0';
    DgnStrcpy(pSet, lSet, resultSet);
    return TRUE;
}

BOOL subtractSetFromSet(char *pSet, int lSet, const char *pSubtractSet)
{
    if(pSubtractSet[0]!='\0')
    {
        while(pSubtractSet!=NULL)
        {
            if(!subtractItemFromSet(pSet, lSet, pSubtractSet))
            {
                return FALSE;
            }
            pSubtractSet=getNextFieldByWhitespace(pSubtractSet);
        }
    }
    return TRUE;
}

typedef enum UnconfiguredDefaultMeaning
{
    eNone,
    eStar,
    eStarStar
} UnconfiguredDefaultMeaning;

// Get the expanded set of items in the first file/variable.  If the first
// file/variable is not found, assume either "", "*", or "**", depending on
// udm.  If the starFile/variable is not found, assume "*" means "".
void readSetAndSubstituteSingleStars(
    char *pSet, int lSet, UnconfiguredDefaultMeaning udm,
    const char *fileName, const char *variableEq,
    const char *starFileName, const char *starVariableEq)
{
    pSet[0]='\0';
    char configValue[TL_MAXSTRSIZE+1]="";
    if(!readConfigOption("", fileName, variableEq,
                         configValue, sizeof(configValue),
                         TRUE, TRUE, FALSE))
    {
        switch(udm)
        {
         case eNone:
            DgnStrcpy(configValue, sizeof(configValue), "");
            break;
         case eStar:
            DgnStrcpy(configValue, sizeof(configValue), "*");
            break;
         case eStarStar:
            DgnStrcpy(configValue, sizeof(configValue), "**");
            break;
         default:
            assert(!"Bad UnconfiguredDefaultMeaning");
            break;
        }
    }

    BOOL foundADirTwice=FALSE;
    const char *pTopDir=(configValue[0]=='\0' ? NULL : configValue);
    while(pTopDir!=NULL)
    {
        if(pTopDir[0]=='*' && (pTopDir[1]=='\0' || pTopDir[1]==' '))
        {
            char configValue2[TL_MAXSTRSIZE+1]="";
            if(readConfigOption("", starFileName, starVariableEq,
                                configValue2, sizeof(configValue2),
                                TRUE, TRUE, FALSE) &&
               configValue2[0]!='\0')
            {
                if(!addSetToSet(pSet, lSet, configValue2))
                {
                    foundADirTwice=TRUE;
                    break;
                }
            }
        }
        else
        {
            if(!addItemToSet(pSet, lSet, pTopDir))
            {
                foundADirTwice=TRUE;
                break;
            }
        }
        pTopDir=getNextFieldByWhitespace(pTopDir);
    }
    if(strstr(pSet, "**") && (strlen(pSet) != 2))
    {
        foundADirTwice=TRUE;
    }
    if(foundADirTwice)
    {
        PrintWrapped2("Error: The same item occurs twice in update "
                      "topdirs in %s and %s.", fileName, starFileName);
        pauseAndExit();
    }
}

void checkNetworkDirectoryPresent()
{
    char netDir[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(netDir, sizeof(netDir), gNetworkDirectory);
    int netDirLen=strlen(netDir);
    BOOL bNetIsRoot=FALSE;
    if(netDirLen > 0 && netDir[netDirLen-1]=='\\')
    {
        if(netDirLen > 1 && netDir[netDirLen-2]==':')
        {
            bNetIsRoot=TRUE;
        }
        else
        {
            netDir[netDirLen-1]='\0';
        }
    }
    if((bNetIsRoot && GetDriveType(netDir) == DRIVE_NO_ROOT_DIR) ||
       (!bNetIsRoot && !saferFindDir(netDir)))
    {
        PrintWrapped1("The network directory for this project, %s, cannot "
                      "be found.  Perhaps your network is down.", netDir);
        pauseForYes();
    }
}

void replaceForwardSlashesWithBackslashes(char *psz)
{
    while(*psz != '\0')
    {
        if(*psz == '/')
        {
            *psz = '\\';
        }
        psz++;
    }
}

BOOL isInDirectorySet(char *buffer, const char *dirs)
{
    char *pLastSlash=strrchr(buffer, '\\');
    if(pLastSlash==NULL)
    {
        return FALSE;
    }
    pLastSlash[0]='\0';
    if(isMemberByWhitespace(buffer, dirs))
    {
        pLastSlash[0]='\\';
        return TRUE;
    }
    else
    {
        BOOL bCheckNested=isInDirectorySet(buffer, dirs);
        pLastSlash[0]='\\';
        return bCheckNested;
    }
}

class UpdateCriteria
{
 protected:
    char mUpdateTopDirs[TL_MAXSTRSIZE+1];
    char mNoUpdateSubDirs[TL_MAXSTRSIZE+1];
    char mFullUpdateTopDirs[TL_MAXSTRSIZE+1];
    char mNoUpdateFullDirs[TL_MAXSTRSIZE+1];
    char mRestrictToExtensions[TL_MAXSTRSIZE+1];
    BOOL mbAllFilesAreUpdated;

 public:
    UpdateCriteria();
    ~UpdateCriteria();

    BOOL fileMeetsUpdateCriteria(const char *fileName) const;
    BOOL allFilesAreUpdated() const { return mbAllFilesAreUpdated; }
};

UpdateCriteria::UpdateCriteria()
{
    readSetAndSubstituteSingleStars(
        mUpdateTopDirs, sizeof(mUpdateTopDirs), eStarStar,
        "tlmuser.cfg", "UPDATE_TOPDIRS=",
        "tlmproj.cfg", "UPDATE_TOPDIRS_STAR=");
    readSetAndSubstituteSingleStars(
        mFullUpdateTopDirs, sizeof(mFullUpdateTopDirs), eStar,
        "tlmuser.cfg", "FULL_UPDATE_TOPDIRS=",
        "tlmproj.cfg", "FULL_UPDATE_TOPDIRS_STAR=");
    char updateSubDirs[TL_MAXSTRSIZE+1]="";
    readSetAndSubstituteSingleStars(
        updateSubDirs, sizeof(updateSubDirs), eStarStar,
        "tlmuser.cfg", "UPDATE_SPECIAL_SUBDIRS=",
        "tlmproj.cfg", "UPDATE_SPECIAL_SUBDIRS_STAR=");
    if(!strcmp(updateSubDirs, "**"))
    {
        mNoUpdateSubDirs[0]='\0';
    }
    else
    {
        char specialSubDirs[TL_MAXSTRSIZE+1]="";
        if(!readConfigOption(gWorkDirectory, "tlmproj.cfg",
                             "UPDATE_SPECIAL_SUBDIRS_STARSTAR=",
                             specialSubDirs, sizeof(specialSubDirs),
                             TRUE, TRUE, FALSE))
        {
            specialSubDirs[0]='\0';
        }
        if(!subtractSetFromSet(specialSubDirs, sizeof(specialSubDirs),
                               updateSubDirs))
        {
            PrintWrapped2("Cannot subtract subdir set '%s' from set '%s'.  "
                          "Check to make sure the UPDATE_SPECIAL_SUBDIRS "
                          "in your tlmuser.cfg are listed in "
                          "UPDATE_SPECIAL_SUBDIRS_STARSTAR in tlmproj.cfg.",
                          updateSubDirs, specialSubDirs);
            pauseAndExit();
        }
        DgnStrcpy(mNoUpdateSubDirs, sizeof(mNoUpdateSubDirs), specialSubDirs);
    }
    assert(stringIsLower(mUpdateTopDirs));
    assert(stringIsLower(mNoUpdateSubDirs));
    assert(stringIsLower(mFullUpdateTopDirs));

    if(!readConfigOption(gWorkDirectory,
                         "tlmuser.cfg", "NO_UPDATE_FULLDIRS=",
                         mNoUpdateFullDirs, sizeof(mNoUpdateFullDirs),
                         TRUE, TRUE, FALSE))
    {
        mNoUpdateFullDirs[0]='\0';
    }
    assert(stringIsLower(mNoUpdateFullDirs));
    replaceForwardSlashesWithBackslashes(mNoUpdateFullDirs);
    
    if(!readConfigOption(gWorkDirectory,
                         "tlmuser.cfg", "UPDATE_RESTRICT_TO_EXTENSIONS=",
                         mRestrictToExtensions, sizeof(mRestrictToExtensions),
                         TRUE, TRUE, FALSE))
    {
        mRestrictToExtensions[0]='\0';
    }
    assert(stringIsLower(mRestrictToExtensions));
    
    mbAllFilesAreUpdated=(!strcmp(mUpdateTopDirs, "**") &&
                          (!strcmp(mNoUpdateSubDirs, "") ||
                           !strcmp(mFullUpdateTopDirs, "**")) &&
                          !strcmp(mNoUpdateFullDirs, "") &&
                          !strcmp(mRestrictToExtensions, ""));
}

UpdateCriteria::~UpdateCriteria()
{
}

BOOL UpdateCriteria::fileMeetsUpdateCriteria(const char *fileName) const
{
    char buffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), fileName);
    {
        char *pSlash=strchr(buffer, '\\');
        if(pSlash!=NULL)
        {
            if(strcmp(mNoUpdateFullDirs, ""))
            {
                if(isInDirectorySet(buffer, mNoUpdateFullDirs))
                {
                    return FALSE;
                }
            }
            if(strcmp(mRestrictToExtensions, "") &&
               !extensionIsInCommaSet(buffer + getFileExtensionOffset(buffer),
                                      mRestrictToExtensions))
            {
                return FALSE;
            }
            if(strcmp(mUpdateTopDirs, "**"))
            {
                pSlash[0]='\0';
                if(!isMemberByWhitespace(buffer, mUpdateTopDirs))
                {
                    return FALSE;
                }
                pSlash[0]='\\';
            }
        }
    }
    
    if(!strcmp(mFullUpdateTopDirs, "**"))
    {
        return TRUE;
    }
    else
    {
        char *pSlash=strchr(buffer, '\\');
        if(pSlash!=NULL)
        {
            pSlash[0]='\0';
            if(isMemberByWhitespace(buffer, mFullUpdateTopDirs))
            {
                return TRUE;
            }
            pSlash[0]='\\';
        }
    }

    char *pTemp=buffer;
    while(TRUE)
    {
        char *pSlash=strchr(pTemp, '\\');
        if(pSlash==NULL)
        {
            return TRUE;
        }
        else
        {
            pSlash[0]='\0';
            if(isMemberByWhitespace(pTemp, mNoUpdateSubDirs))
            {
                return FALSE;
            }
            pSlash[0]='\\';
            pTemp=pSlash+1;
        }
    }
}

void addToUpdateList(const char *fileName, const char *snapVer,
                     char *pLastDir, int lLastDir, const char *workDir,
                     FILE *fpUpdateList, FILE *fpPtrUpdateList)
{
    {
        char nameAndMaybeVer[TL_MAXSTRSIZE+1]="";
        if(snapVer!=NULL && snapVer[0] != '\0')
        {
            DgnSprintf(nameAndMaybeVer, sizeof(nameAndMaybeVer),
                       "%s v=%s", fileName, snapVer);
        }
        else
        {
            DgnSprintf(nameAndMaybeVer, sizeof(nameAndMaybeVer),
                       "%s", fileName);
        }
        saferFprintf(fpUpdateList, "%s\n", nameAndMaybeVer);
        if(isPointerFile(fileName))
        {
            saferFprintf(fpPtrUpdateList, "%s\n", nameAndMaybeVer);
        }
    }
    const char *lastSlash=strrchr(fileName, '\\');
    if(lastSlash != NULL)
    {
        int lenToSlash=(int)(lastSlash-fileName);
        if((lenToSlash!=((int)strlen(pLastDir))) ||
           !isPrefix(pLastDir, fileName))
        {
            char fullPathName[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(fullPathName, sizeof(fullPathName), workDir);
            DgnStrcat(fullPathName, sizeof(fullPathName), fileName);
            saferEnsureDirectoryTreeExists(fullPathName, strlen(workDir));
            DgnStrcpy(pLastDir, lLastDir, fileName);
            pLastDir[lenToSlash]='\0';
        }
    }
}

void maybeAddToUpdateList(const char *fileName, const char *snapVer,
                          char *pLastDir, int lLastDir, const char *workDir,
                          FILE *fpUpdateList, FILE *fpPtrUpdateList,
                          FILE *fpUnupdatedList,
                          BOOL verboseUpdate, BOOL readWrite, char reasonChar,
                          BOOL *pUpdateListNonEmpty, BOOL *pbSomeUnupdated)
{
    if(!readWrite)
    {
        BOOL bIsPresentPointerFile=(isPointerFile(fileName) &&
                                    saferFindFile(fileName));
        BOOL bAnyWritable=FALSE;
        if(bIsPresentPointerFile)
        {
            handlePointedFiles(eCheckWritable, fileName, 0, 0,
                               NULL, NULL, NULL, NULL, NULL,
                               FALSE, fpUnupdatedList, &bAnyWritable, TRUE);
        }
        if(!bAnyWritable)
        {
            if(bIsPresentPointerFile)
            {
                // Remove the pointed files and the pointer file, on the
                // theory that they're going to be extracted anyway (so it's
                // no loss), and removing them now will mean that when the
                // pointer is reextracted, if the list of pointed files has
                // been changed, items that were on the first list but not
                // the second will have been removed.
                handlePointedFiles(eRemoveLocal, fileName, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL,
                                   FALSE, NULL, NULL, TRUE);
                saferRemove(fileName, FALSE);
            }
            addToUpdateList(fileName, snapVer, pLastDir, lLastDir, workDir,
                            fpUpdateList, fpPtrUpdateList);
            *pUpdateListNonEmpty=TRUE;
        }
        else
        {
            *pbSomeUnupdated=TRUE;
        }
    }
    else
    {
        saferFprintf(fpUnupdatedList, "%s\n", fileName);
        *pbSomeUnupdated=TRUE;
    }
    putchar('!');
    if(verboseUpdate)
    {
        putchar(reasonChar);
        PrintWrapped1(" %s", fileName);
    }
}

void updateMaybeRemoveFile(BOOL checkFileExists, BOOL verboseUpdate,
                           const char *fileName,
                           FILE *fpUnremovedList, BOOL *pbSomeUnremoved)
{
    BOOL readWrite;
    if(checkFileExists &&
       saferFindFileAndAttrib(fileName, &readWrite))
    {
        if(!readWrite && isPointerFile(fileName))
        {
            handlePointedFiles(eCheckWritable, fileName, 0, 0,
                               NULL, NULL, NULL, NULL, NULL,
                               FALSE, NULL, &readWrite,
                               TRUE);
        }
        if(readWrite)
        {
            putchar('*');
            saferFprintf(fpUnremovedList, "%s\n", fileName);
            *pbSomeUnremoved=TRUE;
        }
        else
        {
            if(isPointerFile(fileName))
            {
                handlePointedFiles(eRemoveLocal, fileName, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL,
                                   FALSE, NULL, NULL, TRUE);
            }
            saferRemove(fileName, FALSE);
            putchar('x');
        }
    }
    else
    {
        putchar(',');
    }
    if(verboseUpdate)
    {
        putchar(' ');
        PrintWrapped1(" %s", fileName);
    }
}

BOOL showUnupdatedAndUnremoved(BOOL bSomeUnupdated, BOOL bSomeUnremoved,
                               BOOL bSomeBadlyUnremoved,
                               BOOL bPauseAndWarnOnProblem)
{
    char outFileBuffer[TL_MAXSTRSIZE+1]="";

    if(bSomeBadlyUnremoved)
    {
        PrintWrapped0("\n");
        PrintWrapped0("Warning: these files have been removed from the "
                      "project and need to be removed; please read the "
                      "instructions after the list carefully:");
        FILE *fp;
        if(!saferFopen(&fp, "tlupdate.012", eFopenRead))
        {
            return FALSE;
        }
        while(fgets(outFileBuffer, TL_MAXSTRSIZE, fp))
        {
            printf("        %s", outFileBuffer);
        }
        saferFclose(fp);
        PrintWrapped0("\n");
        PrintWrapped0("Warning: the above files, which have been "
                      "removed from the project, are marked "
                      "read/write in your local installation, "
                      "or point to read/write files, "
                      "and thus cannot safely be removed by " TLM_NAME
                      ".  You should remove these files (and their "
                      "pointed files) yourself after making sure "
                      "you have everything you need from them.  This "
                      "will be your only notification!  These files are "
                      "also listed in tlupdate.012.");
        PrintWrapped0("\n");
        pauseAndWarn();
    }
    else
    {
        saferRemove("tlupdate.012", TRUE);
    }
    
    if(bSomeUnupdated)
    {
        PrintWrapped0("\n");
        PrintWrapped0("These files need to be updated, but are read/write; "
                      "please rectify the situation and update again:");
        FILE *fp;
        if(!saferFopen(&fp, "tlupdate.010", eFopenRead))
        {
            return FALSE;
        }
        while(fgets(outFileBuffer, TL_MAXSTRSIZE, fp))
        {
            printf("        %s", outFileBuffer);
        }
        saferFclose(fp);
    }

    if(bSomeUnremoved)
    {
        PrintWrapped0("\n");
        PrintWrapped0("These files need to be removed, but are read/write; "
                      "please rectify the situation and update again:");
        FILE *fp;
        if(!saferFopen(&fp, "tlupdate.009", eFopenRead))
        {
            return FALSE;
        }
        while(fgets(outFileBuffer, TL_MAXSTRSIZE, fp))
        {
            printf("        %s", outFileBuffer);
        }
        saferFclose(fp);
    }

    if((bSomeUnupdated || bSomeUnremoved) && bPauseAndWarnOnProblem)
    {
        PrintWrapped0("\n");
        if(bSomeUnupdated)
        {
            PrintWrapped0("The files which need to be updated "
                          "are also listed in tlupdate.010.");
        }
        else
        {
            saferRemove("tlupdate.010", TRUE);
        }
        if(bSomeUnremoved)
        {
            PrintWrapped0("The files which need to be removed "
                          "are also listed in tlupdate.009.");
        }
        else
        {
            saferRemove("tlupdate.009", TRUE);
        }
        PrintWrapped0("\n");
        pauseForComprehensionOfUpdate();
    }
    else
    {
        saferRemove("tlupdate.009", TRUE);
        saferRemove("tlupdate.010", TRUE);
    }

    return TRUE;
}

typedef enum UpdateFileType
{
    eUFTSrcLst,
    eUFTLastSrcLst,
    eUFTDesiredSnapshot
} UpdateFileType;

const char *getUFTName(UpdateFileType uft,
                       FileListReader *pSrcLstReader,
                       FileListReader *pLastSrcLstReader,
                       FileListReader *pDesiredSnapshotReader)
{
    switch(uft)
    {
     case eUFTSrcLst:
        return pSrcLstReader->currentFile();
     case eUFTLastSrcLst:
        return pLastSrcLstReader->currentFile();
     case eUFTDesiredSnapshot:
        return pDesiredSnapshotReader->currentFile();
     default:
        assert(!"Bad UpdateFileType");
        return NULL;
    }
}

FileListReader *gpSrcLstReader=NULL;
FileListReader *gpLastSrcLstReader=NULL;
FileListReader *gpDesiredSnapshotReader=NULL;

int cmpUpdateFiles(UpdateFileType const *p1, UpdateFileType const *p2)
{
    const char *pName1=getUFTName(*p1, gpSrcLstReader, gpLastSrcLstReader,
                                  gpDesiredSnapshotReader);
    const char *pName2=getUFTName(*p2, gpSrcLstReader, gpLastSrcLstReader,
                                  gpDesiredSnapshotReader);

    return _stricmp(pName1, pName2);
}

void getSortedUpdateFileTypes(FileListReader &srcLstReader,
                              FileListReader &lastSrcLstReader,
                              FileListReader &desiredSnapshotReader,
                              UpdateFileType *pUFTs,
                              int *pnUFTs)
{
    int nUFTs=0;
    if(!srcLstReader.done())
    {
        pUFTs[nUFTs++]=eUFTSrcLst;
    }
    if(!lastSrcLstReader.done())
    {
        pUFTs[nUFTs++]=eUFTLastSrcLst;
    }
    if(!desiredSnapshotReader.done())
    {
        pUFTs[nUFTs++]=eUFTDesiredSnapshot;
    }
    *pnUFTs=nUFTs;
    gpSrcLstReader=&srcLstReader;
    gpLastSrcLstReader=&lastSrcLstReader;
    gpDesiredSnapshotReader=&desiredSnapshotReader;
    VoidSortFunction voidSortFunction=(VoidSortFunction)(cmpUpdateFiles);
    qsort(pUFTs, nUFTs, sizeof(pUFTs[0]), voidSortFunction);
}

typedef enum ListFileTraversalType
{
    eTraverseUpdate,
    eTraverseShowSrcLstAdditions,
    eTraverseShowSrcLstRemovals
} ListFileTraversalType;

typedef struct RealUpdateArgs
{
    BOOL verboseUpdate;
    BOOL checkFileExists;
    BOOL bForceExtractEvenIfAlreadyUpdated;
    BOOL bOnlyGetFilesInSourceList;
    BOOL bOnlyAcceptNewerSnapshotVersions;
    BOOL bCheckLibraries;
    BOOL *pbSomeUnupdated;
    BOOL *pbSomeUnremoved;
    BOOL *pbSomeBadlyUnremoved;
} RealUpdateArgs;

typedef struct RealUpdateHandleArgs
{
    BOOL bUpdatingToSnapshot;
    BOOL *pbUpdateListNonEmpty;
    FILE *fpUpdateList;
    FILE *fpPtrUpdateList;
    FILE *fpUnupdatedList;
    FILE *fpUnremovedList;
    FILE *fpBadlyUnremovedList;
    UpdateCriteria *pUpCrit;
    FileListReader *pLocalTrackReader;
    FileListReader *pRemoteTrackReader;
    const char *workDir;
} RealUpdateHandleArgs;

void realUpdateHandleFile(const char *handleFile,
                          BOOL bInSrcLst,
                          BOOL bInLastSrcLst,
                          BOOL bInDesiredSnapshot,
                          int desiredSnapshotMajor,
                          int desiredSnapshotMinor,
                          const RealUpdateArgs &realUpdateArgs,
                          const RealUpdateHandleArgs &realUpdateHandleArgs,
                          char *pLastDir, int lLastDir)
{
    if(bInLastSrcLst && !bInSrcLst &&
       (!realUpdateHandleArgs.bUpdatingToSnapshot ||
        realUpdateArgs.bOnlyGetFilesInSourceList ||
        !bInDesiredSnapshot))
    {
        updateMaybeRemoveFile(TRUE, realUpdateArgs.verboseUpdate,
                              handleFile,
                              realUpdateHandleArgs.fpBadlyUnremovedList,
                              realUpdateArgs.pbSomeBadlyUnremoved);
        return;
    }
    else if(!realUpdateHandleArgs.pUpCrit->fileMeetsUpdateCriteria(handleFile))
    {
        updateMaybeRemoveFile(realUpdateArgs.checkFileExists,
                              realUpdateArgs.verboseUpdate,
                              handleFile,
                              realUpdateHandleArgs.fpUnremovedList,
                              realUpdateArgs.pbSomeUnremoved);
        return;
    }

    char ver[TL_MAXSTRSIZE+1]="";
    if(realUpdateHandleArgs.bUpdatingToSnapshot)
    {
        if(bInDesiredSnapshot)
        {
            if(realUpdateArgs.bOnlyGetFilesInSourceList && !bInSrcLst)
            {
                return;
            }
            fillVersionString(ver, sizeof(ver), desiredSnapshotMajor,
                              desiredSnapshotMinor);
        }
        else
        {
            return;
        }
    }
    else
    {
        ver[0]='\0';
    }

    BOOL readWrite=FALSE;
    BOOL bUpdateFile=FALSE;
    BOOL bSkipFileWithNoLibrary=FALSE;
    char updateType='?';
    if(realUpdateHandleArgs.bUpdatingToSnapshot &&
       realUpdateArgs.bCheckLibraries)
    {
        char libName[TL_MAXSTRSIZE+1]="";
        fullMangle(libName, sizeof(libName), gNetworkDirectory,
                   handleFile, EMangleForLibrary);
        if(!saferFindFile(libName))
        {
            bSkipFileWithNoLibrary=TRUE;
        }
    }
    if(bSkipFileWithNoLibrary)
    {
    }
    else if(realUpdateArgs.checkFileExists &&
            !saferFindFileAndAttrib(handleFile, &readWrite))
    {   // The src.lst file didn't exist locally, so update it.
        readWrite=FALSE;
        bUpdateFile=TRUE;
        updateType='e';
    }
    else if(realUpdateArgs.bForceExtractEvenIfAlreadyUpdated)
    {
        // We're supposed to extract everything we can (except
        // read/write files), regardless of whether they're present
        // or what version they're at.  We're really doing more of a
        // "get" than an "update" in this case.
        bUpdateFile=TRUE;
        updateType='f';
    }
    else if(realUpdateHandleArgs.pLocalTrackReader->done() ||
            !realUpdateHandleArgs.pLocalTrackReader->seekSpecifiedFile(
                handleFile))
    {   // The src.lst file wasn't in the local tlibwork.trk, so
        // update it.
        bUpdateFile=TRUE;
        updateType='l';
    }
    else if(realUpdateHandleArgs.bUpdatingToSnapshot)
    {
        int cmpRes=compareVersions(
            desiredSnapshotMajor,
            desiredSnapshotMinor,
            realUpdateHandleArgs.pLocalTrackReader->currentMajorVersion(),
            realUpdateHandleArgs.pLocalTrackReader->currentMinorVersion());
        if(cmpRes > 0 ||
           (cmpRes < 0 && !realUpdateArgs.bOnlyAcceptNewerSnapshotVersions))
        {   // the desired snapshot was different, so update it.
            bUpdateFile=TRUE;
            updateType='s';
        }
        else if(isPointerFile(handleFile))
        {
            BOOL bAnyMissing=FALSE;
            handlePointedFiles(eCheckMissing, handleFile, 0, 0,
                               NULL, NULL, NULL, NULL, NULL,
                               FALSE, NULL, &bAnyMissing,
                               TRUE);
            if(bAnyMissing)
            {
                bUpdateFile=TRUE;
                updateType='p';
            }
        }
    }
    else if(realUpdateHandleArgs.pRemoteTrackReader->done() ||
            !realUpdateHandleArgs.pRemoteTrackReader->seekSpecifiedFile(
                handleFile))
    {
        bUpdateFile=TRUE;
        updateType='r';
        PrintWrapped0("\n");
        PrintWrapped2("Warning: %s does not occur in the "
                      "network tlibwork.trk.  "
                      "This is a serious inconsistency, and "
                      "should be rectified.  You may want to "
                      "consider executing a '" TLM_NAME " track %s' "
                      "command, manually reextracting this file "
                      "in the network directory, or asking for help.",
                      handleFile, handleFile);
        pauseAndWarn();
    }
    else
    {
        int cmpRet=compareVersions(
            realUpdateHandleArgs.pRemoteTrackReader->currentMajorVersion(),
            realUpdateHandleArgs.pRemoteTrackReader->currentMinorVersion(),
            realUpdateHandleArgs.pLocalTrackReader->currentMajorVersion(),
            realUpdateHandleArgs.pLocalTrackReader->currentMinorVersion());
        if(cmpRet > 0)
        {   // the remote version was greater, so update it.
            bUpdateFile=TRUE;
            updateType='v';
        }
        else if(cmpRet < 0)
        {
            PrintWrapped0("\n");
            PrintWrapped2("Warning: %s has a greater version in your "
                          "local tlibwork.trk than it does in the "
                          "network tlibwork.trk.  "
                          "This is a serious inconsistency, and "
                          "should be rectified.  You may want to "
                          "consider executing a '" TLM_NAME " track -f %s' "
                          "command, manually reextracting this file "
                          "in the network directory, or asking for help.",
                          handleFile, handleFile);
            pauseAndWarn();
        }
        else if(isPointerFile(handleFile))
        {
            BOOL bAnyMissing=FALSE;
            handlePointedFiles(eCheckMissing, handleFile, 0, 0,
                               NULL, NULL, NULL, NULL, NULL,
                               FALSE, NULL, &bAnyMissing,
                               TRUE);
            if(bAnyMissing)
            {
                bUpdateFile=TRUE;
                updateType='p';
            }
        }
    }

    if(bUpdateFile)
    {
        maybeAddToUpdateList(handleFile, ver,
                             pLastDir, lLastDir,
                             realUpdateHandleArgs.workDir,
                             realUpdateHandleArgs.fpUpdateList,
                             realUpdateHandleArgs.fpPtrUpdateList,
                             realUpdateHandleArgs.fpUnupdatedList,
                             realUpdateArgs.verboseUpdate, readWrite,
                             updateType,
                             realUpdateHandleArgs.pbUpdateListNonEmpty,
                             realUpdateArgs.pbSomeUnupdated);
    }
    else
    {
        putchar('.');
        if(realUpdateArgs.verboseUpdate)
        {
            putchar(' ');
            PrintWrapped1(" %s",
                          handleFile);
        }
    }
}

void traverseListFiles(FileListReader &srcLstReader,
                       FileListReader &lastSrcLstReader,
                       FileListReader &desiredSnapshotReader,
                       ListFileTraversalType traversalType,
                       const RealUpdateArgs &realUpdateArgs,
                       const RealUpdateHandleArgs &realUpdateHandleArgs,
                       char *pLastDir, int lLastDir,
                       FILE *fpComments)
{
    if(!srcLstReader.done())
    {
        srcLstReader.next();
    }
    if(!lastSrcLstReader.done())
    {
        lastSrcLstReader.next();
    }
    if(!desiredSnapshotReader.done())
    {
        desiredSnapshotReader.next();
    }

    BOOL bFoundFirstSrcLstChange=FALSE;
    
    char lastHandledFile[TL_MAXSTRSIZE+1]="";
    while(TRUE)
    {
        UpdateFileType ufts[3];
        int nUFTs=3;
        getSortedUpdateFileTypes(srcLstReader, lastSrcLstReader,
                                 desiredSnapshotReader, ufts, &nUFTs);
        if(nUFTs==0)
        {
            break;
        }
        UpdateFileType mainUFT=ufts[0];
        const char *handleFile=getUFTName(mainUFT, &srcLstReader,
                                          &lastSrcLstReader,
                                          &desiredSnapshotReader);
        if(_stricmp(handleFile, lastHandledFile) != 0)
        {
            DgnStrcpy(lastHandledFile, sizeof(lastHandledFile), handleFile);
            BOOL bInSrcLst=FALSE;
            BOOL bInLastSrcLst=FALSE;
            BOOL bInDesiredSnapshot=FALSE;
            int desiredSnapshotMinor=0;
            int desiredSnapshotMajor=0;
            for(int i=0; i<nUFTs; i++)
            {
                if(!_stricmp(handleFile, getUFTName(ufts[i], &srcLstReader,
                                                   &lastSrcLstReader,
                                                   &desiredSnapshotReader)))
                {
                    switch(ufts[i])
                    {
                     case eUFTSrcLst:
                        bInSrcLst=TRUE;
                        break;
                     case eUFTLastSrcLst:
                        bInLastSrcLst=TRUE;
                        break;
                     case eUFTDesiredSnapshot:
                        bInDesiredSnapshot=TRUE;
                        desiredSnapshotMinor=(
                            desiredSnapshotReader.currentMinorVersion());
                        desiredSnapshotMajor=(
                            desiredSnapshotReader.currentMajorVersion());
                        break;
                    }
                }
            }

            //printf("%s %d %d\n", handleFile, bInSrcLst, bInLastSrcLst);
            if(traversalType==eTraverseUpdate)
            {
                realUpdateHandleFile(handleFile,
                                     bInSrcLst,
                                     bInLastSrcLst,
                                     bInDesiredSnapshot,
                                     desiredSnapshotMajor,
                                     desiredSnapshotMinor,
                                     realUpdateArgs,
                                     realUpdateHandleArgs,
                                     pLastDir, lLastDir);
            }
            else if(traversalType==eTraverseShowSrcLstAdditions &&
                    bInSrcLst && !bInLastSrcLst)
            {
                //printf("Added %s\n", handleFile);
                if(!bFoundFirstSrcLstChange)
                {
                    bFoundFirstSrcLstChange=TRUE;
                    saferFprintf(fpComments, "    Added files:\n");
                }
                saferFprintf(fpComments, "        %s\n", handleFile);
            }
            else if(traversalType==eTraverseShowSrcLstRemovals &&
                    !bInSrcLst && bInLastSrcLst)
            {
                //printf("Removed %s\n", handleFile);
                if(!bFoundFirstSrcLstChange)
                {
                    bFoundFirstSrcLstChange=TRUE;
                    saferFprintf(fpComments, "    Removed files:\n");
                }
                saferFprintf(fpComments, "        %s\n", handleFile);
            }
        }

        switch(mainUFT)
        {
         case eUFTSrcLst:
            srcLstReader.next();
            break;
         case eUFTLastSrcLst:
            lastSrcLstReader.next();
            break;
         case eUFTDesiredSnapshot:
            desiredSnapshotReader.next();
            break;
        }
    }
}

void markLockReadOnlyForTlibBug(const char *fileName)
{
    // work around tlib bug -- it can sometimes leave the lock file
    // read/write.
    char fullFileName[TL_MAXSTRSIZE+1]="";
    getRelPath(fullFileName, sizeof(fullFileName));
    DgnStrcat(fullFileName, sizeof(fullFileName), fileName);

    char lockName[TL_MAXSTRSIZE+1]="";
    fullMangle(lockName, sizeof(lockName), gNetworkDirectory,
               fullFileName, EMangleForLock);
    BOOL readWrite;
    if(saferFindFileAndAttrib(lockName, &readWrite))
    {
        if(readWrite)
        {
            saferMarkReadOnly(lockName);
        }
    }
}

void updateUnlock(BOOL *pbNeedToUnlock)
{
    if(pbNeedToUnlock == NULL || *pbNeedToUnlock)
    {
        // now release updating.lck so others can checkin
        if(saferTlibbs0(normal, "-q ud updating.lck") != 0)
        {
            // work around tlib bug -- it can leave the lock file read/write
            // in this case.
            markLockReadOnlyForTlibBug("updating.lck");
        }
        if(pbNeedToUnlock != NULL)
        {
            *pbNeedToUnlock = FALSE;
        }
    }
}

BOOL realUpdate(const char *sourceList, const char *lastSourceList,
                const char *remoteTrack, const char *desiredSnapshot,
                BOOL bJustShow, int *pExtractRet,
                const RealUpdateArgs &realUpdateArgs,
                BOOL *pbNeedToUnlock,
                BOOL bIsLastRealUpdate)
{
    BOOL bUpdatingToSnapshot=(desiredSnapshot!=NULL);

    char workDir[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(workDir, sizeof(workDir), gWorkDirectory);

    FILE *fpSrcLst = NULL;
    FILE *fpLastSrcLst = NULL;
    FILE *fpLocalTrack = NULL;
    FILE *fpRemoteTrack = NULL;
    FILE *fpDesiredSnapshot = NULL;
    FILE *fpUpdateList = NULL;
    FILE *fpPtrUpdateList = NULL;
    FILE *fpPtrUpdateList2 = NULL;
    FILE *fpUnupdatedList = NULL;
    FILE *fpUnremovedList = NULL;
    FILE *fpBadlyUnremovedList = NULL;

    // It's time to look out for #1.  Update simply can't afford to have an
    // unsorted sourceList or lastSourceList, as comparing these two files
    // if either were unsorted would either lead to rampant inappropriate
    // file deletion, or, optimistically, an error condition during the
    // middle of an update being reported.  The latter is tempting, but
    // since a little bit of state is lost in such an aborted update (we'd
    // no longer know which files had gone missing from src.lst, since it
    // was made current at the beginning of the update), it really isn't
    // desirable. So we're off to make a few more temp files.  And we won't
    // even notice if we've cleaned up after an inappropriately-unsorted
    // file.  Oh, the humanity.
    if(!saferSortAndFopen(&fpSrcLst, TRUE, sourceList, "tlupdate.007") ||
       (lastSourceList != NULL &&
        !saferSortAndFopen(&fpLastSrcLst, TRUE,
                           lastSourceList, "tlupdate.008")) ||
       !saferSortAndFopen(&fpLocalTrack, FALSE,
                          TLIBWORK_TRK, "tlupdate.001") ||
       !saferSortAndFopen(&fpRemoteTrack, FALSE,
                          remoteTrack, "tlupdate.002") ||
       (bUpdatingToSnapshot &&
        !saferSortAndFopen(&fpDesiredSnapshot, TRUE,
                           desiredSnapshot, "tlupdate.011")) ||
       !saferFopen(&fpUpdateList, "tlupdate.003", eFopenWrite) ||
       !saferFopen(&fpPtrUpdateList, "tlupdate.004", eFopenWrite) ||
       (!bUpdatingToSnapshot &&
        !saferFopen(&fpPtrUpdateList2, "tlupdate.013", eFopenWrite)) ||
       !saferFopen(&fpUnupdatedList, "tlupdate.010", eFopenWrite) ||
       !saferFopen(&fpUnremovedList, "tlupdate.009", eFopenWrite) ||
       !saferFopen(&fpBadlyUnremovedList, "tlupdate.012", eFopenWrite))
    {
        return FALSE;
    }

    FileListReader localTrackReader(fpLocalTrack, "local tlibwork.trk",
                                    eTlibworkTrk, TRUE);
    FileListReader remoteTrackReader(fpRemoteTrack, "remote tlibwork.trk",
                                     eTlibworkTrk, TRUE);
    FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
    FileListReader lastSrcLstReader(fpLastSrcLst, "last src.lst", eSrcLst,
                                    TRUE);
    FileListReader desiredSnapshotReader(fpDesiredSnapshot,
                                         "desired snapshot.txt", eSnapshotTxt,
                                         TRUE);

    UpdateCriteria upCrit;

    char lastDir[TL_MAXSTRSIZE+1]="";
    lastDir[0]='\0';
    BOOL updateListNonEmpty=FALSE;
    *(realUpdateArgs.pbSomeUnupdated)=FALSE;
    *(realUpdateArgs.pbSomeUnremoved)=FALSE;
    *(realUpdateArgs.pbSomeBadlyUnremoved)=FALSE;

    RealUpdateHandleArgs realUpdateHandleArgs;
    realUpdateHandleArgs.bUpdatingToSnapshot = bUpdatingToSnapshot;
    realUpdateHandleArgs.pbUpdateListNonEmpty = &updateListNonEmpty;
    realUpdateHandleArgs.fpUpdateList = fpUpdateList;
    realUpdateHandleArgs.fpPtrUpdateList = fpPtrUpdateList;
    realUpdateHandleArgs.fpUnupdatedList = fpUnupdatedList;
    realUpdateHandleArgs.fpUnremovedList = fpUnremovedList;
    realUpdateHandleArgs.fpBadlyUnremovedList = fpBadlyUnremovedList;
    realUpdateHandleArgs.pUpCrit = &upCrit;
    realUpdateHandleArgs.pLocalTrackReader = &localTrackReader;
    realUpdateHandleArgs.pRemoteTrackReader = &remoteTrackReader;
    realUpdateHandleArgs.workDir = workDir;
    
    traverseListFiles(srcLstReader, lastSrcLstReader, desiredSnapshotReader,
                      eTraverseUpdate, realUpdateArgs, realUpdateHandleArgs,
                      lastDir, sizeof(lastDir), NULL);

    putchar('\n');

    saferFclose(fpLocalTrack);
    saferFclose(fpRemoteTrack);
    if(fpDesiredSnapshot != NULL)
    {
        saferFclose(fpDesiredSnapshot);
    }
    saferFclose(fpUpdateList);
    saferFclose(fpPtrUpdateList);
    saferFclose(fpUnupdatedList);
    saferFclose(fpUnremovedList);
    saferFclose(fpBadlyUnremovedList);
    saferFclose(fpSrcLst);
    if(fpLastSrcLst != NULL)
    {
        saferFclose(fpLastSrcLst);
    }

    if(updateListNonEmpty)
    {
        if (bJustShow)
        {
            printf("*** Main update list - tlupdate.003 ***\n");
            FILE *fp3;
            if(!saferFopen(&fp3, "tlupdate.003", eFopenRead))
            {
                return FALSE;
            }
            FileListReader up3Reader(fp3, "tlupdate.003", eSrcLst, TRUE);
            up3Reader.next();
            while(!up3Reader.done())
            {
                printf("%s\n", up3Reader.currentFile());
                up3Reader.next();
            }
            saferFclose(fp3);
            *pExtractRet=0;
        }
        else
        {
            if(gbUsingDave)
            {
                waitSeconds("Waiting 50 seconds to work around bug in "
                            "DAVE/TLIB interaction...\n",
                            FALSE, 50);
            }
            *pExtractRet=saferTlibbs1(
                normal, "-q %s @tlupdate.003",
                ((bUpdatingToSnapshot ||
                  realUpdateArgs.bForceExtractEvenIfAlreadyUpdated) ?
                 "eb" : "ebf"));
        }
    }
    else
    {
        *pExtractRet=0;
    }

    {
        if(!bUpdatingToSnapshot)
        {
            FILE *fp4;
            if(!saferFopen(&fp4, "tlupdate.004", eFopenRead))
            {
                return FALSE;
            }
            FileListReader up4Reader(fp4, "tlupdate.004", eSrcLst, TRUE);
            up4Reader.next();
            while(!up4Reader.done())
            {
                if (bJustShow)
                {
                    printf("%s\n", up4Reader.currentFile());
                }
                else
                {
                    int postMajor;
                    int postMinor;
                    if(getNetworkVersion(up4Reader.currentFile(),
                                         &postMajor, &postMinor))
                    {
                        saferFprintf(fpPtrUpdateList2, "%s v=",
                                     up4Reader.currentFile());
                        printVersion(fpPtrUpdateList2, postMajor, postMinor);
                        saferFprintf(fpPtrUpdateList2, "\n");
                    }
                    else
                    {
                        PrintWrapped1("Couldn't find %s's version after "
                                      "attempting to update it.",
                                      up4Reader.currentFile());
                        return FALSE;
                    }
                }
                up4Reader.next();
            }
            saferFclose(fpPtrUpdateList2);
            saferFclose(fp4);
        }

        // All of that was to manage to get the current versions of files so
        // we can unlock updating.lck before starting to copy down
        // pointed-to files.
        if(bIsLastRealUpdate)
        {
            updateUnlock(pbNeedToUnlock);
        }
        
        FILE *fp5;
        const char *up5FileName=(bUpdatingToSnapshot ?
                                 "tlupdate.004" : "tlupdate.013");
        if(!saferFopen(&fp5, up5FileName, eFopenRead))
        {
            return FALSE;
        }
        FileListReader up5Reader(fp5, up5FileName, eSnapshotTxt, TRUE);
        up5Reader.next();
        while(!up5Reader.done())
        {
            if (bJustShow)
            {
                printf("%s\n", up5Reader.currentFile());
            }
            else
            {
                if(!handlePointedFiles(
                    eCopyFrom, up5Reader.currentFile(),
                    up5Reader.currentMajorVersion(),
                    up5Reader.currentMinorVersion(),
                    NULL, NULL, NULL, NULL, NULL, FALSE, NULL, NULL, TRUE))
                {
                    return FALSE;
                }
            }
            up5Reader.next();
        }
        saferFclose(fp5);
    }

    saferRemove("tlupdate.001", TRUE);
    saferRemove("tlupdate.002", TRUE);
    if (!bJustShow)
    {
        saferRemove("tlupdate.003", TRUE);
        saferRemove("tlupdate.004", TRUE);
    }
    saferRemove("tlupdate.013", FALSE);
    saferRemove("tlupdate.007", TRUE);
    if(lastSourceList != NULL)
    {
        saferRemove("tlupdate.008", TRUE);
    }
    if(desiredSnapshot != NULL)
    {
        saferRemove("tlupdate.011", TRUE);
    }

    return TRUE;
}

BOOL reserveFileShared(VolumeType volume,
                       const char * fileName, BOOL bForceStrong,
                       const char * surrogateIdPrefix)
{
    char surrogateArg[TL_MAXSTRSIZE+1]="";
    if(surrogateIdPrefix != NULL)
    {
        DgnSprintf(surrogateArg, sizeof(surrogateArg), "cw %s%s ",
                   surrogateIdPrefix, gUserName);
    }
    int ret=saferTlibbs3(volume, "-q %s%ser %s", surrogateArg,
                         (bForceStrong ? "c \"LOCKING Y\" " : ""), fileName);

    // work around tlib bug -- it can leave the lock file read/write in
    // this case, if the file was already locked by the user that's now
    // reserving it, and they don't have their local version
    // writable, and also if the reserve fails.
    markLockReadOnlyForTlibBug(fileName);
    
    if(ret == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL reserveFile(const char * fileName, BOOL bForceStrong)
{
    return reserveFileShared(normal, fileName, bForceStrong, NULL);
}

BOOL reserveFileToSurrogate(const char * fileName, const char *pIdPrefix)
{
    return reserveFileShared(loud, fileName, FALSE, pIdPrefix);
}

BOOL updateLock(BOOL bIgnoreRequest, BOOL bStrong)
{
    if(bIgnoreRequest)
    {
        return TRUE;
    }
    int lockRes=checkLock("changes.txt");
    if(lockRes==0)
    {   // We already have the lock on changes.txt, but we should get the
        // one on updating.lck too.
    }
    else if (lockRes==2)
    {
        PrintWrapped0("Someone else is currently checking in.  "
                      "Try again later.");
        tlibInfo("changes.txt");
        return FALSE;
    }
    if (bStrong)
    {
        BOOL success = FALSE;
        BOOL done = FALSE;
        {
            int ret=saferTlibbs0(normal,
                                 "-q -e1 c \"LOCKING Y\" t updating.lck");
            switch(ret)
            {
             case 0:
                // Is this right?  What happens if user has this file weak
                // locked and then asks for the lock status?
                done = TRUE;
                success = TRUE;
                break;
             case 1:
                // not checked out to anyone
                break;
             case 2:
                done = TRUE;
                success = FALSE;
                break;
            }
        }
        if (!done)
        {
            // now grab updating.lck - strong locking on this file
            success = reserveFile("updating.lck", TRUE);
        }
        if (!success)
        {
            PrintWrapped0("Unable to full lock updating.lck.");
            return FALSE;
        }
        return TRUE;
    }
    else
    {
        // now grab updating.lck - weak locking on this file
        if(!reserveFile("updating.lck", FALSE))
        {
            PrintWrapped0("Unable to reserve updating.lck.");
            return FALSE;
        }
        return TRUE;
    }
}

// tlibXXX commands return TRUE for success, FALSE for failure.
BOOL tlibUpdateFile(const char *fileName)
{
    PrintWrapped0("Updating file");
    BOOL bAnyWritable=FALSE;
    handlePointedFiles(eCheckWritable, fileName, 0, 0,
                       NULL, NULL, NULL, NULL, NULL,
                       FALSE, NULL, &bAnyWritable, TRUE);
    if(bAnyWritable)
    {
        PrintWrapped1("Can't update %s, as it has a pointed-to file "
                      "marked read/write in your local installation.",
                      fileName);
        return FALSE;
    }
    if(saferTlibbs1(normal, "-q ebf %s", fileName) != 0)
    {
        return FALSE;
    }
    if(isPointerFile(fileName))
    {
        int postMajor;
        int postMinor;
        if(!getFileVersionFromTrack(fileName, FALSE, FALSE, FALSE,
                                    &postMajor, &postMinor))
        {
            return FALSE;
        }
        return handlePointedFiles(eCopyFrom, fileName,
                                  postMajor, postMinor,
                                  NULL, NULL, NULL, NULL, NULL, FALSE,
                                  NULL, NULL, TRUE);
    }
    return TRUE;
}

BOOL importantUpdate(const char *importantGetList, BOOL *pbNeedToUnlock,
                     const char *remoteTrack,
                     BOOL checkFileExists, BOOL verboseUpdate,
                     BOOL bShowOnly, BOOL bForceExtractEvenIfAlreadyUpdated,
                     BOOL bOnlyAcceptNewerSnapshotVersions,
                     BOOL bCheckLibraries,
                     const char *desiredSnapshot)
{
    if((desiredSnapshot!=NULL) || gbUsingDave)
    {
        // in this case, do a realUpdate on these files to avoid
        // hitting the track file with ebf.  We would do this
        // all the time, except that it causes unnecessary
        // traffic in sorting and scanning files.
        int extractRet;
        BOOL bSomeUnupdated, bSomeUnremoved, bSomeBadlyUnremoved;
        RealUpdateArgs realUpdateArgs;
        realUpdateArgs.verboseUpdate = verboseUpdate;
        realUpdateArgs.checkFileExists = checkFileExists;
        realUpdateArgs.bForceExtractEvenIfAlreadyUpdated = (
            bForceExtractEvenIfAlreadyUpdated);
        realUpdateArgs.bOnlyGetFilesInSourceList = TRUE;
        realUpdateArgs.bOnlyAcceptNewerSnapshotVersions = (
            bOnlyAcceptNewerSnapshotVersions);
        realUpdateArgs.bCheckLibraries = bCheckLibraries;
        realUpdateArgs.pbSomeUnupdated = &bSomeUnupdated;
        realUpdateArgs.pbSomeUnremoved = &bSomeUnremoved;
        realUpdateArgs.pbSomeBadlyUnremoved = &bSomeBadlyUnremoved;

        if(!realUpdate(importantGetList, importantGetList, remoteTrack,
                       desiredSnapshot,
                       bShowOnly, &extractRet,
                       realUpdateArgs, pbNeedToUnlock, FALSE))
        {
            updateUnlock(pbNeedToUnlock);
            return FALSE;
        }
        if(!showUnupdatedAndUnremoved(bSomeUnupdated,
                                      bSomeUnremoved,
                                      bSomeBadlyUnremoved,
                                      FALSE))
        {
            return FALSE;
        }
        if(extractRet!=0)
        {
            PrintWrapped0("Warning: some critical files "
                          "failed to update.  "
                          "Update again to see which "
                          "ones they were.");
            updateUnlock(pbNeedToUnlock);
            return FALSE;
        }
    }
    else
    {
        saferTlibbs1(
            ((gbVerbose || verboseUpdate) ? normal : silent),
            "-q c \"errorpaus 0\" ebf @%s", importantGetList);
    }
    return TRUE;
}

BOOL tlibUpdateProject(BOOL checkFileExists, BOOL verboseUpdate,
                       BOOL bShowOnly, BOOL bForceExtractEvenIfAlreadyUpdated,
                       BOOL bOnlyAcceptNewerSnapshotVersions,
                       BOOL bCheckLibraries,
                       const char *desiredSnapshot,
                       const char *desiredLastSourceList)
{
    PrintWrapped0("Updating project");

    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    BOOL bUpdateAlreadyStrongLocked=FALSE;
    {
        char lockingUser[TL_MAXSTRSIZE+1]="";
        BOOL bStrongLocked;
        if(checkLock("updating.lck", TRUE) != 1 &&
           isLocked(gNetworkDirectory, "updating.lck",
                    lockingUser, &bStrongLocked) &&
           bStrongLocked && !_stricmp(lockingUser, gUserName))
        {
            bUpdateAlreadyStrongLocked=TRUE;
            PrintWrapped0("Warning: updating.lck is already locked by you "
                          "with a strong lock, indicating that you're "
                          "in the middle of checking in.  "
                          "Updating in the middle of a checkin is "
                          "not normal; if you can't explain "
                          "why you're doing this, you should "
                          "choose not to continue.");
            if(!pauseForYesOrNo("Are you _sure_ you want to continue?"))
            {
                return FALSE;
            }
        }
    }
    if(!updateLock(bUpdateAlreadyStrongLocked, FALSE))
    {
        return FALSE;
    }
    BOOL bNeedToUnlock=!bUpdateAlreadyStrongLocked;
    char remoteTrack[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(remoteTrack, sizeof(remoteTrack), gNetworkDirectory);
    DgnStrcat(remoteTrack, sizeof(remoteTrack), TLIBWORK_TRK);

    saferRemove("tlupdate.005", FALSE);
    saferRemove("tlupdate.006", FALSE);
    saferRemove("tlupdate.014", FALSE);
    
    if(!saferFindOrExtractFile("changes.txt"))
    {
        PrintWrapped0("Couldn't find or extract changes.txt.");
        updateUnlock(&bNeedToUnlock);
        return FALSE;
    }
    if(!saferFindOrExtractFile("src.lst"))
    {
        PrintWrapped0("Couldn't find or extract src.lst.");
        updateUnlock(&bNeedToUnlock);
        return FALSE;
    }
    
    {
        int ret=checkLock("changes.txt");
        if(ret==0)
        {
            PrintWrapped0("Warning: changes.txt is checked out to you.");
        }
        switch(ret)
        {
         case 2:
            PrintWrapped0("Warning: changes.txt is checked out to "
                          "someone else.  Files are in an "
                          "inconsistent state!  Please try again later.");
            tlibInfo("changes.txt");
            updateUnlock(&bNeedToUnlock);
            return FALSE;
         case 0:
         case 1:
            {
                // Stash away the last version of src.lst for comparison
                // to know which previously version-controlled files
                // should be removed.
                if(desiredLastSourceList != NULL)
                {
                    saferCopy(desiredLastSourceList, "tlupdate.006", TRUE);
                }
                else
                {
                    saferCopy("src.lst", "tlupdate.006", TRUE);
                }
                FILE *fpImportantGetList;
                if(!saferFopen(&fpImportantGetList, "tlupdate.005",
                               eFopenWrite))
                {
                    updateUnlock(&bNeedToUnlock);
                    return FALSE;
                }
                // maintain these in sorted order so a realUpdate will
                // work.
                saferFprintf(fpImportantGetList, "src.lst\n");
                saferFprintf(fpImportantGetList, "tlib.cfg\n");
                saferFprintf(fpImportantGetList, "tlibproj.cfg\n");
                saferFprintf(fpImportantGetList, "tlibuser.cfg\n");
                saferFprintf(fpImportantGetList, "tlmproj.cfg\n");
                saferFprintf(fpImportantGetList, "tlmuser.cfg\n");
                saferFclose(fpImportantGetList);
                if(!importantUpdate(
                    "tlupdate.005", &bNeedToUnlock, remoteTrack,
                    checkFileExists, verboseUpdate, bShowOnly,
                    bForceExtractEvenIfAlreadyUpdated,
                    bOnlyAcceptNewerSnapshotVersions, bCheckLibraries,
                    desiredSnapshot))
                {
                    return FALSE;
                }
                // Begin the full update
                if(saferFindFile("tlib.cfg") &&
                   saferFindFile("tlibproj.cfg") &&
                   saferFindFile("tlibuser.cfg") &&
                   saferFindFile("tlmproj.cfg") &&
                   saferFindFile("tlmuser.cfg") &&
                   saferFindFile("src.lst"))
                {
                    if(configUseUpdtstrc())
                    {
                        FILE *fpImportantGetList2;
                        if(!saferFopen(&fpImportantGetList2, "tlupdate.014",
                                       eFopenWrite))
                        {
                            updateUnlock(&bNeedToUnlock);
                            return FALSE;
                        }
                        saferFprintf(fpImportantGetList, "updtstrc.bat\n");
                        saferFclose(fpImportantGetList);
                        if(!importantUpdate(
                            "tlupdate.014", &bNeedToUnlock, remoteTrack,
                            checkFileExists, verboseUpdate, bShowOnly,
                            bForceExtractEvenIfAlreadyUpdated,
                            bOnlyAcceptNewerSnapshotVersions, bCheckLibraries,
                            desiredSnapshot))
                        {
                            return FALSE;
                        }
                        if(desiredSnapshot==NULL)
                        {
                            // The updtstrc mechanism doesn't work for
                            // incremental unsnaps, so don't bother with it
                            // then.
                            if(!saferFindFile("updtstrc.bat"))
                            {
                                PrintWrapped0(
                                    "Couldn't extract update-critical "
                                    "file updtstrc.bat.");
                                updateUnlock(&bNeedToUnlock);
                                return FALSE;
                            }
                            if(!saferFindFile("updthelp.bat"))
                            {
                                saferSystem0(silent, "call updtstrc 1");
                            }
                            else
                            {
                                saferMarkReadWrite("updthelp.bat");
                                saferSystem0(silent, "call updthelp");
                            }
                        }
                    }
                    int extractRet;
                    BOOL bSomeUnupdated, bSomeUnremoved, bSomeBadlyUnremoved;
                    RealUpdateArgs realUpdateArgs;
                    realUpdateArgs.verboseUpdate = verboseUpdate;
                    realUpdateArgs.checkFileExists = checkFileExists;
                    realUpdateArgs.bForceExtractEvenIfAlreadyUpdated = (
                        bForceExtractEvenIfAlreadyUpdated);
                    realUpdateArgs.bOnlyGetFilesInSourceList = TRUE;
                    realUpdateArgs.bOnlyAcceptNewerSnapshotVersions = (
                        bOnlyAcceptNewerSnapshotVersions);
                    realUpdateArgs.bCheckLibraries = bCheckLibraries;
                    realUpdateArgs.pbSomeUnupdated = &bSomeUnupdated;
                    realUpdateArgs.pbSomeUnremoved = &bSomeUnremoved;
                    realUpdateArgs.pbSomeBadlyUnremoved = &bSomeBadlyUnremoved;

                    if(!realUpdate("src.lst", "tlupdate.006", remoteTrack,
                                   desiredSnapshot,
                                   bShowOnly, &extractRet,
                                   realUpdateArgs, &bNeedToUnlock,
                                   TRUE))
                    {
                        updateUnlock(&bNeedToUnlock);
                        return FALSE;
                    }

                    if(!showUnupdatedAndUnremoved(bSomeUnupdated,
                                                  bSomeUnremoved,
                                                  bSomeBadlyUnremoved,
                                                  TRUE))
                    {
                        return FALSE;
                    }
                    if(configUseUpdtstrc() && saferFindFile("updtpost.bat"))
                    {
                        saferSystem0(silent, "call updtpost");
                        saferRemove("updtpost.bat", TRUE);
                    }
                    if(saferFindFile("changes.txt") &&
                       checkLock("changes.txt")==0)
                    {
                        // repeat warning
                        PrintWrapped0("Warning: changes.txt is "
                                      "checked out to you.");
                    }
                    if(extractRet!=0)
                    {
                        PrintWrapped0("Warning: some files failed to "
                                      "update.  Update again to see which "
                                      "ones they were.");
                    }
                }
                else
                {
                    PrintWrapped0("Couldn't extract update-critical files.");
                    updateUnlock(&bNeedToUnlock);
                    return FALSE;
                }
                // don't remove tlupdate.005 unless succeeded
                saferRemove("tlupdate.005", TRUE);
                saferRemove("tlupdate.006", TRUE);
                saferRemove("tlupdate.014", FALSE);
                break;
            }
        }
    }
    updateUnlock(&bNeedToUnlock);
    saferChdir(currDir);
    return TRUE;
}

BOOL tlibUpdate(BOOL checkFileExists, BOOL verboseUpdate, BOOL bShowOnly,
                BOOL bForceExtractEvenIfAlreadyUpdated, const char *arg)
{
    if(arg[0]!='\0')
    {
        return tlibUpdateFile(arg);
    }
    else
    {
        return tlibUpdateProject(checkFileExists, verboseUpdate, bShowOnly,
                                 bForceExtractEvenIfAlreadyUpdated,
                                 FALSE, FALSE, NULL, NULL);
    }
}

BOOL getVerFromSnap(char *pVer, int lVer,
                    const char *fileName, const char *snapName)
{
    if(fileName[0]=='.' && fileName[1]=='\\')
    {   // An allowance for old snapshots.
        fileName+=2;
    }

    FILE *fp;
    if (!saferFopen(&fp, snapName, eFopenRead))
    {
        return FALSE;
    }
    FileListReader snapReader(fp, snapName, eSnapshotTxt, FALSE);
    BOOL bFoundName=snapReader.seekSpecifiedFile(fileName);
    if(bFoundName)
    {
        fillVersionString(pVer, lVer,
                          snapReader.currentMajorVersion(),
                          snapReader.currentMinorVersion());
    }
    else
    {
        PrintWrapped2("Couldn't find %s in %s", fileName, snapName);
    }
    saferFclose(fp);
    return bFoundName;
}

BOOL tlibGet(const char *fileName, BOOL interpretVersionsAsSnapshotVersions,
             const char *revNum, const char *destName);

BOOL fillWithActualDesiredFileVersion(const char *fileName,
                                      BOOL interpretVersionsAsSnapshotVersions,
                                      const char *revNum, char *pRealRevNum,
                                      int lRealRevNum)
{
    char firstFileName[TL_MAXSTRSIZE+1]="";
    if(interpretVersionsAsSnapshotVersions)
    {
        getReverseRelPath(firstFileName, sizeof(firstFileName));
        DgnStrcat(firstFileName, sizeof(firstFileName), "snapshot.txt");
    }
    else
    {
        DgnStrcpy(firstFileName, sizeof(firstFileName), fileName);
    }
        
    char firstRevNum[TL_MAXSTRSIZE+1]="";
    
    int localBaseMajor;
    int localBaseMinor;
    if (!strcmp(revNum, "-"))
    {
        if(!getFileVersionFromTrack(firstFileName, FALSE, FALSE, FALSE,
                                    &localBaseMajor, &localBaseMinor))
        {
            return FALSE;
        }
        fillVersionString(firstRevNum, sizeof(firstRevNum),
                          localBaseMajor, localBaseMinor);
    }
    else
    {
        DgnStrcpy(firstRevNum, sizeof(firstRevNum), revNum);
    }

    if(interpretVersionsAsSnapshotVersions)
    {
        saferRemove("tlgetsn.000", FALSE);
        tlibGet(firstFileName, FALSE, firstRevNum, "tlgetsn.000");
        if(!getVerFromSnap(pRealRevNum, lRealRevNum, fileName, "tlgetsn.000"))
        {
            PrintWrapped2("Unable to get version of %s from "
                          "snapshot.txt version %s", fileName,
                          firstRevNum);
            return FALSE;
        }
        saferRemove("tlgetsn.000", TRUE);
    }
    else
    {
        DgnStrcpy(pRealRevNum, lRealRevNum, firstRevNum);
    }
    return TRUE;
}

BOOL tlibGet(const char *fileName, BOOL interpretVersionsAsSnapshotVersions,
             const char *revNum, const char *destName)
{
    PrintWrapped0("Get a file...");
    char realRevNum[TL_MAXSTRSIZE+1]="";

    if(!fillWithActualDesiredFileVersion(
        fileName, interpretVersionsAsSnapshotVersions, revNum, realRevNum,
        sizeof(realRevNum)))
    {
        return FALSE;
    }

    if(destName==NULL)
    {
        BOOL bAnyWritable=FALSE;
        if(isPointerFile(fileName) && saferFindFile(fileName))
        {
            handlePointedFiles(eCheckWritable, fileName, 0, 0,
                               NULL, NULL, NULL, NULL, NULL,
                               FALSE, NULL, &bAnyWritable, TRUE);
        }
        if(bAnyWritable)
        {
            PrintWrapped1("Can't extract %s, as it has a pointed-to file "
                          "marked read/write in your local installation.",
                          fileName);
            return FALSE;
        }
        if(saferTlibbs2(loud, "-q ebs %s %s", fileName, realRevNum) != 0)
        {
            return FALSE;
        }
        if(isPointerFile(fileName))
        {
            int postMajor;
            int postMinor;
            if(!getFileVersionFromTrack(fileName, FALSE, FALSE, FALSE,
                                        &postMajor, &postMinor))
            {
                return FALSE;
            }
            return handlePointedFiles(eCopyFrom, fileName,
                                      postMajor, postMinor,
                                      NULL, NULL, NULL, NULL, NULL, FALSE,
                                      NULL, NULL, TRUE);
        }
        return TRUE;
    }
    else
    {
        if(isPointerFile(fileName))
        {
            PrintWrapped1("Warning: get won't copy %s's pointed-to "
                          "files when extracting to a non-default location, "
                          "as there's no logical place to put them.",
                          fileName);
        }
        if(saferFindFile(destName))
        {
            PrintWrapped1("Can't extract to %s, as it already exists.",
                          destName);
            return FALSE;
        }
        if(saferTlibbs3(loud, "-q c \"track n\" -n%s ebs %s %s",
                        destName, fileName, realRevNum) != 0)
        {
            return FALSE;
        }
        // make it writable for easy deletion
        saferMarkReadWrite(destName);
        return TRUE;
    }
}

BOOL checkFileIsUpToDateEnough(const char *fileName)
{
    int localMajor, localMinor, remoteMajor, remoteMinor;
    if(!getFileVersionFromTrack(fileName, FALSE, FALSE, FALSE,
                                &localMajor, &localMinor) ||
       !getFileVersionFromTrack(fileName, FALSE, TRUE, FALSE,
                                &remoteMajor, &remoteMinor))
    {
        return FALSE;
    }
    if(compareVersions(localMajor, localMinor, remoteMajor, remoteMinor) != 0)
    {
        char localVerStr[TL_MAXSTRSIZE+1]="";
        char remoteVerStr[TL_MAXSTRSIZE+1]="";
        fillVersionString(localVerStr, sizeof(localVerStr),
                          localMajor, localMinor);
        fillVersionString(remoteVerStr, sizeof(remoteVerStr),
                          remoteMajor, remoteMinor);
        PrintWrapped3("The file %s has a different version in the network "
                      "track file (%s) than it does in the local track "
                      "file (%s).", fileName, remoteVerStr, localVerStr);
        return FALSE;
    }
    return TRUE;
}

BOOL tlibEdit(const char *fileName, BOOL bPauseOnWarning,
              BOOL bCheckForCurrentVersion)
{
    PrintWrapped0("Edit a file...");
    if(!checkFileCheckinAllowed(fileName))
    {
        return FALSE;
    }
    
    if(bCheckForCurrentVersion)
    {
        if(!checkFileIsUpToDateEnough(fileName))
        {
            return FALSE;
        }
    }
    
    if(isPointerFile(fileName))
    {
        int retx=checkLock(fileName);
        if(retx==2 || retx==0)
        {
            PrintWrapped1("The pointer file %s is already checked out.",
                          fileName);
            tlibInfo(fileName);
            return FALSE;
        }
        if(!tlibGet(fileName, FALSE, "*", NULL))
        {
            return FALSE;
        }
    }

    int ret=saferTlibbs2(loud, "-q %se %s",
                         bPauseOnWarning ? "" : "c \"errorpaus 0\" ",
                         fileName);

    // work around tlib bug -- it can leave the lock file read/write in
    // this case, if the file was already locked by the user that's now
    // checking it out, and they don't have their local version
    // writable.
    markLockReadOnlyForTlibBug(fileName);
        
    if(ret != 0)
    {
        return FALSE;
    }
    else
    {
        if(isPointerFile(fileName))
        {
            return handlePointedFiles(eMarkWritable, fileName, 0, 0,
                                      NULL, NULL, NULL, NULL, NULL, FALSE,
                                      NULL, NULL, TRUE);
        }
        else
        {
            return TRUE;
        }
    }
}

BOOL tlibReserve(const char *fileName, BOOL bForceStrong,
                 BOOL bCheckForCurrentVersion, BOOL bMarkLocalReadWrite)
{
    PrintWrapped0("Reserve a file...");
    if(!checkFileCheckinAllowed(fileName))
    {
        return FALSE;
    }
    
    if(bCheckForCurrentVersion)
    {
        if(!checkFileIsUpToDateEnough(fileName))
        {
            return FALSE;
        }
    }

    if(bMarkLocalReadWrite)
    {
        if(!saferFindFile(fileName))
        {
            PrintWrapped1("Couldn't find %s.", fileName);
            return FALSE;
        }
    }

    if(!reserveFile(fileName, bForceStrong))
    {
        return FALSE;
    }
    if(bMarkLocalReadWrite)
    {
        saferMarkWritable(fileName, TRUE);
        if(isPointerFile(fileName))
        {
            return handlePointedFiles(eMarkWritable, fileName, 0, 0,
                                      NULL, NULL, NULL, NULL, NULL, FALSE,
                                      NULL, NULL, TRUE);
        }
    }
    return TRUE;
}

BOOL tlibBackout(const char *fileName, const char *revNum)
{
    PrintWrapped0("Back out a file...");
    if(!checkFileCheckinAllowed(fileName))
    {
        return FALSE;
    }
    int revNumMajor, revNumMinor;
    if(!reallyParseVersion(revNum, &revNumMajor, &revNumMinor,
                           revNum, "command-line argument") ||
       !tlibGet(fileName, FALSE, "*", NULL) ||
       !tlibReserve(fileName, FALSE, TRUE, FALSE))
    {
        return FALSE;
    }
    if(saferTlibbs2(loud, "-q c \"track n\" ebs %s %s",
                    fileName, revNum) != 0)
    {
        return FALSE;
    }
    saferMarkReadWrite(fileName);
    if(isPointerFile(fileName))
    {
        if(!handlePointedFiles(eCopyFrom, fileName,
                               revNumMajor, revNumMinor,
                               NULL, NULL, NULL, NULL, NULL, FALSE,
                               NULL, NULL, TRUE))
        {
            return FALSE;
        }
        if(!handlePointedFiles(eMarkWritable, fileName,
                               revNumMajor, revNumMinor,
                               NULL, NULL, NULL, NULL, NULL, FALSE,
                               NULL, NULL, TRUE))
        {
            return FALSE;
        }
    }
    return TRUE;
}

BOOL tlibTrack(const char *fileName, BOOL bFirstUntrack)
{
    BOOL bSuccess=TRUE;
    if(bFirstUntrack)
    {
        PrintWrapped0("Untrack a file...");
        int ret=saferTlibbs1(loud, "-q ad %s", fileName);
        bSuccess=(ret==0);
    }
    if(bSuccess)
    {
        PrintWrapped0("Track a file...");
        int ret=saferTlibbs1(loud, "-q a %s", fileName);
        bSuccess=(ret==0);
    }
    return bSuccess;
}

BOOL saferEnsureExistsAndReadWrite(const char *fileName)
{
    if(saferFindOrExtractFile(fileName))
    {
        BOOL readWrite;
        if(!saferFindFileAndAttrib(fileName, &readWrite) || !readWrite)
        {
            // First test the lock status of the file
            if(checkLock(fileName)!=0)
            {
                tlibEdit(fileName, TRUE, TRUE);
                if(checkLock(fileName)!=0)
                {
                    PrintWrapped1("The file %s cannot be checked "
                                  "out to you.", fileName);
                    tlibInfo(fileName);
                    return FALSE;
                }
            }
        }
    }
    return TRUE;
}

BOOL tlibUncheck(const char *fileName)
{
    PrintWrapped0("Uncheck a file...");
    if(isPointerFile(fileName))
    {
        PrintWrapped0("You are about to uncheck a .ptr file; if you do so, "
                      "your current versions of its pointed-to files will "
                      "be assumed to be the same as the checked-in ones, "
                      "and will accordingly be marked read-only without "
                      "being re-retrieved from the network.");
        pauseForYes();
    }
    int ret=saferTlibbs1(loud, "-q ud %s", fileName);
    if(ret != 0)
    {
        // work around tlib bug -- it can leave the lock file read/write in
        // this case.
        markLockReadOnlyForTlibBug(fileName);
        return FALSE;
    }
    else
    {
        if(isPointerFile(fileName))
        {
            return handlePointedFiles(eMarkReadonly, fileName, 0, 0,
                                      NULL, NULL, NULL, NULL, NULL, FALSE,
                                      NULL, NULL, TRUE);
        }
        else
        {
            return TRUE;
        }
    }
}

BOOL tlibBreak(const char *fileName, BOOL bQuiet)
{
    PrintWrapped0("Break lock on a file...");
    int ret=saferTlibbs1((bQuiet ? silent : normal), "-q t %s", fileName);
    if(ret==1)
    {
        PrintWrapped1("The file %s does not appear to be checked out.",
                      fileName);
        pauseForYes();
    }

    char buffer[TL_MAXSTRSIZE+1]="";
    char fullFileName[TL_MAXSTRSIZE+1]="";
    getRelPath(fullFileName, sizeof(fullFileName));
    DgnStrcat(fullFileName, sizeof(fullFileName), fileName);

    if(!saferFindFile(fileName))
    {
        PrintWrapped1("Couldn't find %s.", fileName);
        return FALSE;
    }
    else
    {
        fullMangle(buffer, sizeof(buffer), gNetworkDirectory,
                   fullFileName, EMangleForLock);
        saferRemove(buffer, TRUE);
        if(!bQuiet)
        {
            PrintWrapped1("Successfully broke lock on %s.", fileName);
        }
        return TRUE;
    }
}

BOOL fileAlwaysStoredInCRLFMode(const char *fileName)
{
    return (!strcmp(fileName, "updating.lck") ||
            !strcmp(fileName, "tlib.cfg") ||
            !strcmp(fileName, "tlibproj.cfg") ||
            !strcmp(fileName, "tlibuser.cfg") ||
            !strcmp(fileName, "tlmproj.cfg") ||
            !strcmp(fileName, "tlmuser.cfg") ||
            !strcmp(fileName, "src.lst") ||
            !strcmp(fileName, "snapshot.txt") ||
            !strcmp(fileName, "changes.txt") ||
            !strcmp(fileName, "updtstrc.bat"));
}

BOOL tlibMerge(BOOL editFile, const char *fileName, const char *revNum)
{
    if(!checkFileCheckinAllowed(fileName))
    {
        return FALSE;
    }
    
    if(!fileExistsAndIsWritable(fileName))
    {
        PrintWrapped1("File %s must exist and be writable.", fileName);
        return FALSE;
    }

    // First test the lock status of the file
    int ret=checkLock(fileName);
    char autoMergeRevision[TL_MAXSTRSIZE+1]="";
    if(editFile && ret==2)
    {
        PrintWrapped1("The file %s is checked out to someone else; "
                      "consider " TLM_NAME " mergened.", fileName);
        tlibInfo(fileName);
        return FALSE;
    }
    else if(ret==0)
    {
        PrintWrapped1("The file %s is already checked out to you!  "
                      "Can't merge.", fileName);
        return FALSE;
    }
    else if(isPointerFile(fileName))
    {
        PrintWrapped1("Can't merge %s as it is a pointer file, and "
                      "there's no logical way to handle its pointed-to "
                      "files.", fileName);
        return FALSE;
    }
    else
    {
        PrintWrapped0("\n");
        {
            int localMajor, localMinor;
            int revNumMajor, revNumMinor;
            BOOL bAuto = FALSE;
            if (!strcmp(revNum, "auto"))
            {
                revNumMinor = -1;
                revNumMajor = -1;
                bAuto = TRUE;
            }
            else
            {
                if(!reallyParseVersion(revNum, &revNumMajor, &revNumMinor,
                                       revNum, "command-line argument"))
                {
                    return FALSE;
                }
            }
            if(!getFileVersionFromTrack(fileName, bAuto, FALSE, bAuto,
                                        &localMajor, &localMinor))
            {
                return FALSE;
                // Either the track file couldn't opened, or this file
                // couldn't be found in it; this should never happen, and
                // continuing would only short circuit the checking that we
                // do below.  Better to fail completely in this case.
            }
            else if(compareVersions(localMajor, localMinor,
                                    revNumMajor, revNumMinor) != 0)
            {
                char localVer[TL_MAXSTRSIZE+1]="";
                fillVersionString(localVer, sizeof(localVer),
                                  localMajor, localMinor);
                if (bAuto)
                {
                    PrintWrapped0("\n");
                    PrintWrapped0("Are you _really_ sure you want to "
                                  "continue?");
                    PrintWrapped0("If you answer yes, I will use "
                                  "the track file version.");
                    DgnStrcpy(autoMergeRevision, sizeof(autoMergeRevision),
                              localVer);
                    revNum = autoMergeRevision;
                }
                else
                {
                    PrintWrapped3("I just checked up on your story, "
                                  "and it sure "
                                  "doesn't look to me like the "
                                  "version you're starting from is right: "
                                  "the local track file has %s at "
                                  "version %s, while you claim it is "
                                  "version %s.  Are you _really_ sure "
                                  "you want to "
                                  "continue?", fileName, localVer, revNum);
                }
                pauseForYes();
            }
        }
        saferRemove("tlmerge.000", FALSE);
        saferRemove("tlmerge.001", FALSE);
        saferRemove("tlmerge.002", FALSE);
        saferRemove("tlmerge.003", FALSE);
        saferRemove("tlmerge.004", FALSE);
        saferRemove("tlmerge.005", FALSE);
        saferRemove("tlmerge.006", FALSE);
        saferRemove("tlmerge.007", FALSE);

        // your revision in tlmerge.000
        saferCopy(fileName, "tlmerge.000", TRUE);
        // base revision in tlmerge.001
        // latest revision in tlmerge.002
        if(tlibGet(fileName, FALSE, revNum, "tlmerge.001") &&
           tlibGet(fileName, FALSE, "*", "tlmerge.002") &&
           saferFindFile("tlmerge.000") &&
           saferFindFile("tlmerge.001") &&
           saferFindFile("tlmerge.002"))
        {
            // merged version in tlmerge.003
            const char *outputNewLineType=(
                gNewLineType == E_CR ? "CR" : (
                    gNewLineType == E_LF ? "LF" : "CRLF"));
            if(gbExecutedFromRoot && fileAlwaysStoredInCRLFMode(fileName))
            {
                outputNewLineType = "CRLF";
            }
            int tlmergeRet=saferSpawn1(
                normal, eCheckRetZeroToTwo, gTlmergePath,
                "tlmerge.001 tlmerge.002 tlmerge.000 tlmerge.003 %s",
                outputNewLineType);
            if(tlmergeRet==1)
            {
                PrintWrapped0("Note: merge was trivial because there "
                              "were no changes in either of the branches "
                              "being merged.");
            }
            if(tlmergeRet==0 || tlmergeRet==1)
            {
                // can't remove as it might be a configuration file for tlib
                saferMarkReadOnly(fileName);
                if(editFile)
                {
                    tlibEdit(fileName, TRUE, FALSE);
                }
                else
                {
                    tlibGet(fileName, FALSE, "*", NULL);
                    saferRemove(fileName, TRUE);
                }
                saferCopy("tlmerge.003", fileName, TRUE);
                if(gbExecutedFromRoot && !strcmp(fileName, "src.lst"))
                {
                    PrintWrapped0("You've just merged src.lst, which "
                                  "means you may lose the benefit "
                                  "of local removal of files that "
                                  "have been removed from the project "
                                  "in the src.lst changes you've just "
                                  "merged.  It is recommended that "
                                  "you do a special update against the "
                                  "old src.lst now, so the appropriate "
                                  "local files will be removed.  "
                                  "(Note that if your merge had "
                                  "collisions, it is recommended that "
                                  "you fix them before continuing.)");
                    if(pauseForYesOrNo("Do you want to do a special update?"))
                    {
                        while(!tlibUpdateProject(TRUE, FALSE, FALSE, FALSE,
                                                 FALSE, FALSE, NULL,
                                                 "tlmerge.001"))
                        {
                            if(!pauseForYesOrNo(
                                "Special update failed.  Try again?"))
                            {
                                break;
                            }
                        }
                    }
                    
                }
                saferRemove("tlmerge.001", TRUE);
                saferRemove("tlmerge.002", TRUE);
                saferRemove("tlmerge.003", TRUE);
                return TRUE;
            }
            else
            {
                PrintWrapped0("tlmerge failed.");
                return FALSE;
            }
        }
        else
        {
            PrintWrapped1("Failed to get intermediate versions of %s.",
                          fileName);
            return FALSE;
        }
    }
}

BOOL mergeOneCommentArg(const char *arg,
                        int numSkipLinesInFileArg, FILE *fpComment,
                        BOOL *pbJustDidNewLine, BOOL *pbWroteFirstLine)
{
    if(arg[0]=='@')
    {
        FILE *fpInput;
        if(!saferFopen(&fpInput, arg+1, eFopenRead))
        {
            return FALSE;
        }
        char buffer[TL_MAXSTRSIZE+1]="";
        int lineNum=0;
        while(fgets(buffer, TL_MAXSTRSIZE, fpInput))
        {
            lineNum++;
            if(lineNum <= numSkipLinesInFileArg)
            {
                continue;
            }
            trimFinalWhiteSpace(buffer);
            if(buffer[0]!='\0')
            {
                if(!(*pbJustDidNewLine))
                {
                    saferFprintf(fpComment, "\n");
                }
                saferFprintf(fpComment, "%s\n", buffer);
                *pbJustDidNewLine=TRUE;
                *pbWroteFirstLine=TRUE;
            }
        }
        saferFclose(fpInput);
    }
    else
    {
        char arg2[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(arg2, sizeof(arg2), arg);
        trimFinalWhiteSpace(arg2);
        if(arg2[0]!='\0')
        {
            if(strchr(arg2, ' ')!=NULL)
            {
                if(!(*pbJustDidNewLine))
                {
                    saferFprintf(fpComment, "\n");
                }
                saferFprintf(fpComment, "%s\n", arg2);
                *pbJustDidNewLine=TRUE;
                *pbWroteFirstLine=TRUE;
            }
            else
            {
                if(!(*pbJustDidNewLine))
                {
                    saferFprintf(fpComment, " ");
                }
                saferFprintf(fpComment, "%s", arg2);
                *pbJustDidNewLine=FALSE;
                *pbWroteFirstLine=TRUE;
            }
        }
    }
    return TRUE;
}

BOOL mergeComments(const char *outFile, const char *extraEarlyCommentArg,
                   int commentsArgc, const char *commentsArgv[],
                   const char *extraLateCommentArg,
                   const char *forkedFromHistoryArg)
{
    FILE *fpComment;
    if(!saferFopen(&fpComment, outFile, eFopenWrite))
    {
        return FALSE;
    }

    BOOL bJustDidNewLine=TRUE;
    BOOL bWroteFirstLine=FALSE;
    if(!mergeOneCommentArg(extraEarlyCommentArg, 0, fpComment,
                           &bJustDidNewLine, &bWroteFirstLine))
    {
        return FALSE;
    }
    for(int i=0; i<commentsArgc; i++)
    {
        if(!mergeOneCommentArg(commentsArgv[i], 0, fpComment,
                               &bJustDidNewLine, &bWroteFirstLine))
        {
            return FALSE;
        }
    }
    if(!mergeOneCommentArg(extraLateCommentArg, 0, fpComment,
                           &bJustDidNewLine, &bWroteFirstLine))
    {
        return FALSE;
    }
    if(forkedFromHistoryArg[0] != '\0')
    {
        if(!mergeOneCommentArg("Source history:", 0, fpComment,
                               &bJustDidNewLine, &bWroteFirstLine))
        {
            return FALSE;
        }
        if(!mergeOneCommentArg(forkedFromHistoryArg, 2, fpComment,
                               &bJustDidNewLine, &bWroteFirstLine))
        {
            return FALSE;
        }
    }
    if(!bJustDidNewLine)
    {
        saferFprintf(fpComment, "\n");
    }
    saferFclose(fpComment);
    if(!bWroteFirstLine)
    {
        PrintWrapped0("There are no actual comments in the "
                      "locations specified on the command line.");
        return FALSE;
    }
    return TRUE;
}

//----------------------------------------------------------------------
//
// Open the file and scan the beginning of the file for the
// TLM_NEXT_CHECKIN_COMMENTS string.  If a line which is too long is found
// or if the TLM_NEXT_CHECKIN_COMMENTS string is not found then nothing is
// changed.
//
// Otherwise, we copy the input file to a temporary file, extract the
// comments from between the TLM_NEXT_CHECKIN_COMMENTS lines, and rename the
// temporary file to be the original file.
//

BOOL extractAndMergeComments(const char *fileName,
                             const char *extraEarlyCommentArg,
                             int commentsArgc, const char *commentsArgv[],
                             const char *forkedFromHistoryArg)
{
    FILE *fpIn;
    if(!saferFopen(&fpIn, fileName, eFopenRead))
    {
        return FALSE;
    }

    FILE *fpOut;
    if(!saferFopen(&fpOut, "tlcomm.002", eFopenWrite))
    {
        return FALSE;
    }

    FILE *fpExtractedComments;
    if(!saferFopen(&fpExtractedComments, "tlcomm.003", eFopenWrite))
    {
        return FALSE;
    }

    char prefix[256];
    char abbrevPrefix[256];
    int revCol=0;
    BOOL bExtractedComments=FALSE;

    // phase one, look for first TLM_NEXT_CHECKIN_COMMENTS string
    char fileBuffer[TL_MAXSTRSIZE+1]="";
    BOOL foundFirst=FALSE;
    if (strcmp(fileName, "changes.txt") &&
        strcmp(fileName, "snapshot.txt"))
    {
        for (;;)
        {
            if (!fgets(fileBuffer, TL_MAXSTRSIZE, fpIn))
            {
                break;
            }
            else if(strlen(fileBuffer) == TL_MAXSTRSIZE)
            {
                PrintWrapped0("Line too long:");
                PrintWrapped0(fileBuffer);
                return FALSE;
                break;
            }
            saferFputs(fileBuffer, fpOut);
            for(revCol=0; revCol<=TLM_MAX_REV_COL; revCol++)
            {
                if (isPrefix(TLM_NEXT_CHECKIN_COMMENTS, fileBuffer + revCol))
                {
                    foundFirst=TRUE;
                    break;
                }
            }
            if(foundFirst)
            {
                break;
            }
        } // for ;;
    }

    if(foundFirst)
    {
        // Let's get the prefix from this line
        DgnStrncpy(prefix, sizeof(prefix), fileBuffer, revCol);
        prefix[revCol] = '\0';
        DgnStrcpy(abbrevPrefix, sizeof(abbrevPrefix), prefix);
        trimFinalWhiteSpace(abbrevPrefix);

        // when we get here we have just copied the first revision line.
        // Now in phase two, for each line processed, extract it for checkin
        // comments.
        BOOL foundSecond=FALSE;
        for (;;)
        {
            if (!fgets(fileBuffer, TL_MAXSTRSIZE, fpIn))
            {
                break;
            }
            else if(strlen(fileBuffer) == TL_MAXSTRSIZE)
            {
                PrintWrapped0("Line too long:");
                PrintWrapped0(fileBuffer);
                return FALSE;
                break;
            }
            if (isPrefix(prefix, fileBuffer) &&
                isPrefix(TLM_NEXT_CHECKIN_COMMENTS, fileBuffer + revCol))
            {
                saferFputs(fileBuffer, fpOut);
                foundSecond=TRUE;
                break;
            }
            else if(!isPrefix(abbrevPrefix, fileBuffer))
            {
                break;
            }
            else
            {
                char *lineWriteStart=fileBuffer+strlen(abbrevPrefix);
                while(ISSPACE(lineWriteStart[0]))
                {
                    lineWriteStart++;
                }
                saferFputs(lineWriteStart, fpExtractedComments);
            }
        } // for ;;

        if(foundSecond)
        {
            while(fgets(fileBuffer, TL_MAXSTRSIZE, fpIn))
            {
                if (strlen(fileBuffer) == TL_MAXSTRSIZE)
                {
                    PrintWrapped0("Line too long:");
                    PrintWrapped0(fileBuffer);
                    return FALSE;
                    break;
                }
                saferFputs(fileBuffer, fpOut);
            }
            bExtractedComments = TRUE;
        }
    }

    saferFclose(fpIn);
    saferFclose(fpOut);
    saferFclose(fpExtractedComments);

    if(bExtractedComments)
    {
        saferCopyModTimes(fileName, "tlcomm.002");
        saferRemove(fileName, TRUE);
        saferCopy("tlcomm.002", fileName, TRUE);
        if(!mergeComments("tlcomm.001", extraEarlyCommentArg,
                          commentsArgc, commentsArgv, "@tlcomm.003",
                          forkedFromHistoryArg))
        {
            return FALSE;
        }
        saferRemove("tlcomm.002", TRUE);
        saferRemove("tlcomm.003", TRUE);
    }
    else
    {
        if(!mergeComments("tlcomm.001", extraEarlyCommentArg,
                          commentsArgc, commentsArgv, "",
                          forkedFromHistoryArg))
        {
            return FALSE;
        }
        saferRemove("tlcomm.002", TRUE);
        saferRemove("tlcomm.003", TRUE);
    }
    return TRUE;
}

// This verifies that the file name meets applicable constraints.  In
// particular, if tlibproj.cfg says "longnames n", it means standard 8.3. If
// tlibproj.cfg has "longnames y", it means a path component may have at
// most one dot, and may not have any spaces. Other restrictions may be
// added if necessary.
//
// See gMaxFileNameLen commentary above for an explanation of the file and
// directory length restrictions.
//
// Also, if "longnames y" is the case, we require that "path" be configured
// with separate "tlib" and "tlok" directories, and that "libext" and
// "lokext" each consist of all question marks, for simplicity.  (This is
// good for everyone, it's just that migrating the installed base of
// non-longnames projects may take time.)
//
// If it has an extension, a file's extension may be at most N characters,
// where N is the number of characters in libext/lokext.  Note that TLIB
// doesn't allow libext/lokext greater than 7 characters.

BOOL isBadNodeLength(int nodeLength)
{
    return (nodeLength > gMaxFileNodeLen);
}

BOOL isBadBodyLength(int bodyLength)
{
    if(gbAllowLongNames)
    {
        return (bodyLength == 0);
    }
    else
    {
        return (bodyLength == 0 || bodyLength > 8);
    }
}

BOOL isBadExtLength(int extLength)
{
    return extLength > gMaxExtLen;
}

BOOL fileMeetsComponentBodyExtRestrictions(const char *fileName,
                                           const char *specialSubDirs,
                                           int *pnSpecialSubDirs)
{
    *pnSpecialSubDirs=0;
    const char *nullChar=fileName+strlen(fileName);
    while(TRUE)
    {
        const char *nextSlash=strchr(fileName, '\\');
        const char *nextDot=strchr(fileName, '.');
        BOOL bLastComponent=FALSE;
        if(nextSlash==NULL)
        {
            nextSlash=nullChar;
            bLastComponent=TRUE;
        }
        if(nextDot==NULL || nextDot > nextSlash)
        {
            if(isBadBodyLength(nextSlash - fileName) ||
               isBadNodeLength(nextSlash - fileName))
            {
                return FALSE;
            }
        }
        else
        {
            const char *nextNextDot=strchr(nextDot+1, '.');
            if(nextNextDot != NULL && nextNextDot < nextSlash)
            {
                return FALSE;
            }
            if(isBadExtLength(nextSlash - nextDot - 1) ||
               isBadBodyLength(nextDot - fileName) ||
               isBadNodeLength(nextSlash - fileName))
            {
                return FALSE;
            }
        }
        char component[TL_MAXSTRSIZE+1]="";
        DgnStrncpy(component, sizeof(component), fileName,
                   nextSlash - fileName);
        component[nextSlash - fileName] = '\0';
        if(isMemberByWhitespace(component, specialSubDirs))
        {
            (*pnSpecialSubDirs)++;
        }
        if(bLastComponent)
        {
            return TRUE;
        }
        fileName=nextSlash+1;
    }
}

BOOL checkFileMeetsNameRestrictions(const char *fileName,
                                    const char *pSpecialSubDirs,
                                    const char *pDesc1,
                                    const char *pDesc2)
{
    const char *pBadChar;
    int nSpecialSubDirs;
    if(strlen(fileName) > gMaxFileNameLen)
    {
        char maxLen[10];
        DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxFileNameLen);
        PrintWrapped4("%s'%s'%s has more than "
                      "%s characters.",
                      pDesc1, fileName, pDesc2, maxLen);
        return FALSE;
    }
    else if((pBadChar=strpbrk(fileName, " \t*?@/:&#~!$%^()=|[]{};`'\",<>")) !=
            NULL)
    {
        char badStr[2];
        badStr[0]=*pBadChar;
        badStr[1]='\0';
        PrintWrapped4("%s'%s'%s contains a '%s' "
                      "character.", pDesc1, fileName, pDesc2, badStr);
        return FALSE;
    }
    else if(!gbAllowMixedCaseNames && !stringIsLower(fileName))
    {
        PrintWrapped3("%s'%s'%s is not all lower-case.",
                      pDesc1, fileName, pDesc2);
        return FALSE;
    }
    else if(fileName[strlen(fileName)-1] == '.')
    {
        PrintWrapped3("%s'%s'%s ends in a dot.", pDesc1, fileName, pDesc2);
        return FALSE;
    }
    else if(!fileMeetsComponentBodyExtRestrictions(fileName,
                                                   pSpecialSubDirs,
                                                   &nSpecialSubDirs))
    {
        if(gbAllowLongNames)
        {
            char maxLen[10];
            DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxFileNodeLen);
            PrintWrapped4("%s'%s'%s has a path component "
                          "that is empty, that has more than one dot, "
                          "that has more than %s characters, or that "
                          "has an extension that is over "
                          "your project's extension length limit.",
                          pDesc1, fileName, pDesc2, maxLen);
        }
        else
        {
            PrintWrapped3("%s'%s'%s has a path component "
                          "that is not 8.3-compliant.",
                          pDesc1, fileName, pDesc2);
        }
        return FALSE;
    }
    else if(nSpecialSubDirs > 1)
    {
        PrintWrapped3("%s'%s'%s has more than one path "
                      "component found in UPDATE_SPECIAL_SUBDIRS_STARSTAR "
                      "in tlmproj.cfg.",
                      pDesc1, fileName, pDesc2);
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

typedef enum VerifyReadyForCommand
{
    eCheckin,
    eCreate,
    eUnremove,
    eMove
} VerifyReadyForCommand;

BOOL verifyFileReadyToBeCheckedIn(const char *fileName,
                                  VerifyReadyForCommand verifyReadyForCommand,
                                  const char *pType)
{
    char specialSubDirs[TL_MAXSTRSIZE+1]="";
    if(!readConfigOption(gWorkDirectory, "tlmproj.cfg",
                         "UPDATE_SPECIAL_SUBDIRS_STARSTAR=",
                         specialSubDirs, sizeof(specialSubDirs),
                         TRUE, TRUE, FALSE))
    {
        specialSubDirs[0]='\0';
    }

    if((verifyReadyForCommand == eCheckin ||
        verifyReadyForCommand == eMove) &&
       !checkFileCheckinAllowed(fileName))
    {
        return FALSE;
    }

    char cantDo[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(cantDo, sizeof(cantDo), "Can't ");
    DgnStrcat(cantDo, sizeof(cantDo), pType);
    if(!verifyGoodFileNameCase(fileName) ||
       !verifyGoodExtension(fileName) ||
       !checkFileMeetsNameRestrictions(fileName, specialSubDirs,
                                       cantDo,
                                       ", as it "))
    {
        return FALSE;
    }
    
    if(verifyReadyForCommand == eUnremove ||
       verifyReadyForCommand == eMove)
    {
        if(saferFindFile(fileName))
        {
            PrintWrapped1("File %s must not exist.", fileName);
            return FALSE;
        }
    }
    else
    {
        if(!fileExistsAndIsWritable(fileName))
        {
            PrintWrapped1("File %s must exist and be writable.", fileName);
            return FALSE;
        }
    }

    UpdateCriteria upCrit;

    if(!upCrit.fileMeetsUpdateCriteria(fileName))
    {
        PrintWrapped2("Can't %s %s because it's in a directory that "
                      "doesn't meet your updatability criteria.",
                      pType, fileName);
        return FALSE;
    }
    
    if(isPointerFile(fileName))
    {
        if(verifyReadyForCommand != eUnremove)
        {
            if(!handlePointedFiles(eVerifyLocalPresentAndWritable,
                                   fileName, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL, FALSE,
                                   NULL, NULL, TRUE))
            {
                PrintWrapped2("Can't %s %s because one or more of "
                              "its pointed-to files is missing or "
                              "not writable.",
                              pType, fileName);
                return FALSE;
            }
            if(!handlePointedFiles(eVerifyLegalNames,
                                   fileName, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL, FALSE,
                                   NULL, NULL, TRUE))
            {
                PrintWrapped2("Can't %s %s because one or more of "
                              "its pointed-to files has a bad filename.",
                              pType, fileName);
                return FALSE;
            }
        }
    }

    if(verifyReadyForCommand == eCheckin &&
       checkLock(fileName) != 0)
    {
        PrintWrapped1("File %s must be checked out to you.", fileName);
        return FALSE;
    }

    return TRUE;
}

BOOL tlibCreate(BOOL bActuallyUnremove, const char *fileName,
                BOOL bAddToSrcLst, BOOL bEditFile,
                BOOL bPromptForStructureIssues, const char *fileVersion,
                const char *pForkedFromNetDir, const char *pForkedFromDir,
                const char *extraEarlyCommentArg,
                int commentsArgc, const char *commentsArgv[])
{
    const char *actualCommandStr=bActuallyUnremove ? "unremove" : "create";
    const char *actualDoingStr=bActuallyUnremove ? "unremoving" : "creating";
    const char *actualDidStr=bActuallyUnremove ? "unremoved" : "created";
    const char *capActualCommandStr=bActuallyUnremove ? "Unremove" : "Create";
    PrintWrapped1("%s a file...", capActualCommandStr);

    if(fileVersion != NULL)
    {
        uint fileVersionLen=strlen(fileVersion);
        BOOL bGoodVersion=(fileVersionLen>0);
        for(uint i=0; i<fileVersionLen; i++)
        {
            if(!ISDIGIT(fileVersion[i]))
            {
                bGoodVersion=FALSE;
                break;
            }
        }
        if(!bGoodVersion)
        {
            PrintWrapped1("Can't create file with version '%s'.", fileVersion);
            return FALSE;
        }
    }
    
    char relPath[TL_MAXSTRSIZE+1]="";
    getRelPath(relPath, sizeof(relPath));
    assert(pForkedFromNetDir == NULL || pForkedFromDir == NULL);
    if((pForkedFromNetDir != NULL || pForkedFromDir != NULL) &&
       relPath[0] != '\0')
    {
        PrintWrapped0("Can only create a forked file from the "
                      "project root.");
        return FALSE;
    }
    if(pForkedFromNetDir != NULL)
    {
        assert(pForkedFromNetDir[strlen(pForkedFromNetDir)-1] == '\\');
    }
    else if(pForkedFromDir != NULL)
    {
        if(pForkedFromDir[strlen(pForkedFromDir)-1] == '\\')
        {
            PrintWrapped1("The specified forked-from directory %s ends in a "
                          "backslash.",
                          pForkedFromDir);
            return FALSE;
        }
    }
    
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    char fullFileName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(fullFileName, sizeof(fullFileName), relPath);
    DgnStrcat(fullFileName, sizeof(fullFileName), fileName);

    if(!verifyFileReadyToBeCheckedIn(fullFileName,
                                     bActuallyUnremove ? eUnremove : eCreate,
                                     actualCommandStr))
    {
        return FALSE;
    }
    
    if(!saferEnsureExistsAndReadWrite("src.lst"))
    {
        PrintWrapped0("Couldn't find/edit src.lst.");
        return FALSE;
    }

    if(bPromptForStructureIssues && isPointerFile(fullFileName))
    {
        PrintWrapped1("You are about to %s a .ptr file, which will "
                      "be handled specially as indicated by " TLM_NAME
                      " doc.", actualCommandStr);
        pauseForYes();
    }

    if(bPromptForStructureIssues && !srcLstFindItem(fullFileName, TRUE))
    {
        PrintWrapped1("You are about to %s a file in a directory "
                      "which currently has no source-controlled files, "
                      "thus creating the directory.", actualCommandStr);
        pauseForYes();
        {
            char *firstSlash=strchr(fullFileName, '\\');
            assert(firstSlash != NULL);
            char *secondSlash=strchr(firstSlash+1, '\\');
            if(secondSlash==NULL)
            {
                PrintWrapped0("Note also that you may want to add the "
                              "new directory to your project's "
                              "UPDATE_TOPDIRS_STAR setting in "
                              "tlmproj.cfg.");
                pauseForKey(TRUE);
            }
        }
    }

    if (bAddToSrcLst && srcLstFindItem(fullFileName, FALSE))
    {
        PrintWrapped1("File %s already in src.lst.", fullFileName);
        return FALSE;
    }

    if(bActuallyUnremove)
    {
        if(!tlibGet(fullFileName, FALSE, "*", NULL) ||
           (checkLock(fullFileName) != 1 &&
            !tlibBreak(fullFileName, TRUE)) ||
           !tlibTrack(fullFileName, TRUE))
        {
            return FALSE;
        }
    }
    else
    {
        char forkVer[TL_MAXSTRSIZE+1]="";
        char forkedFromHistoryArg[TL_MAXSTRSIZE+1]="";
        char tempHistFile[TL_MAXSTRSIZE+1]="";
        char *configWideHist=" c \"swidth 150\" c \"logwidth 200\"";
        if(pForkedFromNetDir != NULL || pForkedFromDir != NULL)
        {
            char forkRootDir[TL_MAXSTRSIZE+1]="";
            if(pForkedFromDir != NULL)
            {
                saferGetcwd(forkRootDir, sizeof(forkRootDir));
                saferChdir(pForkedFromDir);
            }
            
            saferTmpnam(tempHistFile, sizeof(tempHistFile));
            redirectOutput(tempHistFile, FALSE);
            int ret;
            if(pForkedFromDir != NULL)
            {
                ret=saferTlibbs2(normal, "-q%s l %s",
                                 configWideHist, fullFileName);
            }
            else
            {
                ret=saferTlibbs3(normal, "-q%s cp %s*\\tlib l %s",
                                 configWideHist, pForkedFromNetDir,
                                 fullFileName);
            }
            closeRedirectedOutput();

            if(ret != 0)
            {
                PrintWrapped1("Couldn't successfully execute TLIB to "
                              "find %s's forked-from version "
                              "when attempting to create it.",
                              fullFileName);
                return FALSE;
            }

            if(pForkedFromDir != NULL)
            {
                saferChdir(forkRootDir);
            }

            int forkMajor;
            int forkMinor;
            int dummyNumVersionsFound;
            if(!getNetworkVersionFromHistory(tempHistFile,
                                             &forkMajor, &forkMinor,
                                             &dummyNumVersionsFound))
            {
                PrintWrapped1("Couldn't find %s's forked-from version "
                              "when attempting to create it.",
                              fullFileName);
                return FALSE;
            }
            incrementVersion(&forkMajor, &forkMinor);
            fillVersionString(forkVer, sizeof(forkVer), forkMajor, forkMinor);
            fileVersion = forkVer;
            DgnStrcpy(forkedFromHistoryArg, sizeof(forkedFromHistoryArg), "@");
            DgnStrcat(forkedFromHistoryArg, sizeof(forkedFromHistoryArg),
                      tempHistFile);
        }
        if(!extractAndMergeComments(fullFileName, extraEarlyCommentArg,
                                    commentsArgc, commentsArgv,
                                    forkedFromHistoryArg))
        {
            return FALSE;
        }
        if(pForkedFromNetDir != NULL || pForkedFromDir != NULL)
        {
            saferRemove(tempHistFile, TRUE);
        }
        // Note: we set errorpaus 1 to avoid pausing for user input on
        // warnings about "Tiny file not analyzed." and "Homogeneous file
        // not analyzed."  We hope there aren't other warnings of this same
        // class that we actually want to leave enabled.
        int ret=saferTlibbs3(normal,
                             "-q%s c \"errorpaus 1\" ns %s %s @tlcomm.001",
                             configWideHist, fullFileName, fileVersion);
        if(ret != 0)
        {
            PrintWrapped0("Create failed.");
            return FALSE;
        }
        saferRemove("tlcomm.001", TRUE);
        int postMajor;
        int postMinor;
        if(getNetworkVersion(fullFileName, &postMajor, &postMinor))
        {
            if(isPointerFile(fullFileName) &&
               !handlePointedFiles(eCopyTo, fullFileName,
                                   postMajor, postMinor,
                                   NULL, NULL, NULL, NULL,
                                   NULL, FALSE, NULL, NULL, TRUE))
            {
                return FALSE;
            }
        }
        else
        {
            PrintWrapped1("Couldn't find %s after attempting to "
                          "create it.", fullFileName);
            return FALSE;
        }
    }
    if(bAddToSrcLst && !srcLstAdd(fullFileName))
    {
        return FALSE;
    }
    if(bEditFile)
    {
        if(isFileCheckinAllowed(fullFileName))
        {
            if(!tlibEdit(fullFileName, TRUE, FALSE))
            {
                PrintWrapped2("Couldn't check out %s after %s it.",
                              fullFileName, actualDoingStr);
                return FALSE;
            }
            PrintWrapped2("%s has been %s and checked back out to you.",
                          fullFileName, actualDidStr);
        }
        else
        {
            PrintWrapped2("%s has been %s.",
                          fullFileName, actualDidStr);
        }
    }
    saferChdir(currDir);
    return TRUE;
}

BOOL tlibRemove(const char *fileName)
{
    PrintWrapped0("Remove a file...");

    char currDir[TL_MAXSTRSIZE+1]="";
    char relPath[TL_MAXSTRSIZE+1]="";
    getRelPath(relPath, sizeof(relPath));
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    char fullFileName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(fullFileName, sizeof(fullFileName), relPath);
    DgnStrcat(fullFileName, sizeof(fullFileName), fileName);
    if(!verifyGoodFileNameCase(fullFileName))
    {
        return FALSE;
    }

    if(fileExistsAndIsWritable(fullFileName))
    {
        PrintWrapped1("The file %s is writable.  Can't remove.",
                      fullFileName);
        return FALSE;
    }
    if(saferTlibbs1(normal, "-q t %s", fullFileName) != 1)
    {
        PrintWrapped1("The file %s is checked out.  Can't remove.",
                      fullFileName);
        return FALSE;
    }
    if(!saferEnsureExistsAndReadWrite("src.lst"))
    {
        PrintWrapped0("Couldn't find/edit src.lst in this directory.");
        return FALSE;
    }
    if(!srcLstFindItem(fullFileName, FALSE))
    {
        PrintWrapped1("Couldn't find %s in src.lst.", fullFileName);
        return FALSE;
    }
    if(isPointerFile(fullFileName))
    {
        PrintWrapped0("You are about to remove a .ptr file, which "
                      "will be handled specially as indicated by "
                      TLM_NAME " doc.");
        pauseForYes();
        handlePointedFiles(eRemoveLocal, fullFileName, 0, 0,
                           NULL, NULL, NULL, NULL, NULL, FALSE,
                           NULL, NULL, TRUE);
    }

    if(!reserveFileToSurrogate(fullFileName, "DELETED_BY_"))
    {
        return FALSE;
    }

    saferRemove(fullFileName, FALSE);

    // Update src.lst
    srcLstRemove(fullFileName);

    saferChdir(currDir);
    return TRUE;
}

BOOL tlibMove(const char *srcName, const char *destName)
{
    PrintWrapped0("Move a file...");

    char currDir[TL_MAXSTRSIZE+1]="";
    char relPath[TL_MAXSTRSIZE+1]="";
    getRelPath(relPath, sizeof(relPath));
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    char fullSrcName[TL_MAXSTRSIZE+1]="";
    char fullDestName[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(fullSrcName, sizeof(fullSrcName), relPath);
    DgnStrcat(fullSrcName, sizeof(fullSrcName), srcName);
    DgnStrcpy(fullDestName, sizeof(fullDestName), relPath);
    DgnStrcat(fullDestName, sizeof(fullDestName), destName);
    if(!verifyGoodFileNameCase(fullSrcName))
    {
        return FALSE;
    }
    
    if(isPointerFile(fullSrcName))
    {
        PrintWrapped1("Can't move %s as it is a pointer file, and "
                      "there's no logical way to handle its pointed-to "
                      "files.", fullSrcName);
        return FALSE;
    }
    else if(isPointerFile(fullDestName))
    {
        PrintWrapped1("Can't move to %s as that would make it a pointer "
                      "file, and there's no logical way to handle its "
                      "pointed-to files.", fullDestName);
        return FALSE;
    }

    if(!verifyFileReadyToBeCheckedIn(fullDestName, eMove, "move to"))
    {
        return FALSE;
    }

    if(!srcLstFindItem(fullDestName, TRUE))
    {
        PrintWrapped0("You cannot move a file into a directory "
                      "which currently has no source-controlled files; "
                      "you should create a file in the destination "
                      "directory first (for example, a tlib.cfg file.)");
        return FALSE;
    }
    
    // First test the lock status of the file
    int ret=checkLock(fullSrcName);
    if (ret != 0)
    {
        // try to check it out
        tlibEdit(fullSrcName, TRUE, TRUE);
        ret = checkLock(fullSrcName);
    }
    if(ret!=0)
    {
        PrintWrapped1("The file %s is not checked out to you.  "
                      "Can't move.", fullSrcName);
        tlibInfo(fullSrcName);
        return FALSE;
    }
    else
    {
        if(saferEnsureExistsAndReadWrite("src.lst"))
        {
            char buffer[TL_MAXSTRSIZE+1]="";
            char buffer2[TL_MAXSTRSIZE+1]="";

            if(!saferFindFile(fullSrcName))
            {
                PrintWrapped1("Couldn't find %s.", fullSrcName);
                return FALSE;
            }
            else if(saferFindFile(fullDestName))
            {
                PrintWrapped1("%s already exists.", fullDestName);
                return FALSE;
            }
            else
            {
                // copy source network library file to dest network library
                // file
                fullMangle(buffer, sizeof(buffer), gNetworkDirectory,
                           fullSrcName, EMangleForLibrary);
                fullMangle(buffer2, sizeof(buffer2), gNetworkDirectory,
                           fullDestName, EMangleForLibrary);
                saferCopy(buffer, buffer2, FALSE);

                // copy source network file to dest network file
                fullMangle(buffer, sizeof(buffer), gNetworkDirectory,
                           fullSrcName, ENoMangle);
                fullMangle(buffer2, sizeof(buffer2), gNetworkDirectory,
                           fullDestName, ENoMangle);
                saferCopy(buffer, buffer2, FALSE);

                if(!tlibTrack(fullDestName, FALSE))
                {
                    PrintWrapped0("Couldn't track dest; move failed!");
                    return FALSE;
                }

                if(!tlibEdit(fullDestName, TRUE, FALSE))
                {
                    PrintWrapped0("Couldn't check out dest; move failed!");
                    return FALSE;
                }

                // copy source local file to dest local file
                saferCopy(fullSrcName, fullDestName, TRUE);

                // Add fullDestName to src.lst
                if (!srcLstFindItem(fullDestName, FALSE) &&
                    tlibUncheck(fullSrcName) &&
                    tlibRemove(fullSrcName) &&
                    srcLstAdd(fullDestName))
                {
                    PrintWrapped0("If your project uses non-automatic "
                                  "dependencies, remember to update them!");
                    saferChdir(currDir);
                    return TRUE;
                }
                else
                {
                    PrintWrapped0("Move failed!");
                    return FALSE;
                }
            }
        }
        else
        {
            PrintWrapped0("Couldn't find/edit src.lst in this directory.");
            return FALSE;
        }
    }
}

void outputOneTlibInfo(FILE *plainFile, FILE *tlckFile,
                       const char *dateTime, const char *userName,
                       const char *fileType, const char *fileName)
{
    char outLine[TL_MAXSTRSIZE+1]="";
    DgnSprintf(outLine, sizeof(outLine), "%19s %-12s %-11s %s\n",
            dateTime, userName, fileType, fileName);
    if (plainFile)
    {
        saferFprintf(plainFile, outLine);
    }
    if (tlckFile)
    {
        saferFprintf(tlckFile, "%s is checked out to you\n", fileName);
    }
}

// helper routine
void replaceTrailingQMsByStar(char *psz)
{
    char *pszEnd = psz + strlen(psz) - 1; // point pszEnd to last char.
    while(*pszEnd == '?')
    {
        *pszEnd = '*';
        *(pszEnd + 1) = '\0';
        if(pszEnd == psz) {
            break;
        }
        pszEnd--;
    }
}

void outputOneLockFileInfo(const char *lockFileName,
                           const char *lockDateTime,
                           const char *trackedFileName,
                           BOOL bRefFileExists,
                           FILE *tlckFile, FILE *plainFile,
                           BOOL bTrackedFileInTrackedHash,
                           BOOL bFull, const char *restrictName)
{
    char userName[TL_MAXSTRSIZE+1]="";
    BOOL hadALock=FALSE;
    FILE *fpLock=saferFopenOrExit(lockFileName, eFopenRead);
    while(fgets(userName, TL_MAXSTRSIZE, fpLock) != NULL)
    {
        hadALock=TRUE;
        trimFinalWhiteSpace(userName);
        BOOL bStrongLocked=TRUE;
        char *pSpace=strchr(userName, ' ');
        if(pSpace!=NULL && pSpace > userName)
        {
            const char *nRefStr = "n=REF";
            char *pTheoreticalNextSpace = pSpace+1+strlen(nRefStr);
            if(strncmp(pSpace+1, nRefStr, strlen(nRefStr)) ||
               (pTheoreticalNextSpace[0] != '\0' &&
                pTheoreticalNextSpace[0] != ' '))
            {
                saferFprintf(stdout, "Lock file '%s' has corrupt line:\n",
                             lockFileName);
                saferFprintf(stdout, "%s\n", userName);
                pauseAndExit();
            }
            pSpace[0]='\0';
            if(pTheoreticalNextSpace[0] == ' ')
            {
                if(!_stricmp(pTheoreticalNextSpace+1, "w=1"))
                {
                    bStrongLocked=FALSE;
                }
                else
                {
                    saferFprintf(stdout,
                                 "Lock file '%s' has corrupt line:\n",
                                 lockFileName);
                    saferFprintf(stdout, "%s\n", userName);
                    pauseAndExit();
                }
            }
        }
        else
        {
            saferFprintf(stdout, "Lock file '%s' has corrupt line:\n",
                         lockFileName);
            saferFprintf(stdout, "%s\n", userName);
            pauseAndExit();
        }

        if (!bRefFileExists)
        {
            if (bFull)
            {
                outputOneTlibInfo(
                    plainFile, NULL, lockDateTime, userName,
                    "Deleted", trackedFileName);
            }
        }
        else
        {
            if (!bTrackedFileInTrackedHash)
            {
                if (bFull)
                {
                    outputOneTlibInfo(
                        plainFile, NULL, lockDateTime, userName,
                        "CHECKED-OUT", trackedFileName);
                }
            }
            else
            {
                if ((restrictName == NULL) ||
                    !_stricmp(restrictName, userName))
                {
                    outputOneTlibInfo(
                        plainFile, tlckFile, lockDateTime, userName,
                        (bStrongLocked ? "Checked-out" : "Weak-locked"),
                        trackedFileName);
                }
            }
        }
    } // while (TRUE)
    saferFclose(fpLock);
    if(!hadALock)
    {
        PrintWrapped1("Lock file '%s' is empty.", lockFileName);
        pauseAndExit();
    }
}

// netPath is the directory being recursively checked, terminated by a
// backslash.  relPath is the relative path from there to the current
// directory to check the tlib directory of, terminated by a backslash,
// if non-empty.
void outputOneTlokDirInfo(FILE *tlckFile, FILE *plainFile,
                          const char *netPath, const char *relPath,
                          const NameListHash *pTrackedHash,
                          BOOL bFull, const char *restrictName)
{
    WIN32_FIND_DATA finddata;
    HANDLE hFindFile;
    BOOL found;

    char lockNameBuffer[TL_MAXSTRSIZE+1]="";
    char refNameBuffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(lockNameBuffer, sizeof(lockNameBuffer), netPath);
    DgnStrcpy(refNameBuffer, sizeof(refNameBuffer), netPath);
    int netLen=strlen(lockNameBuffer);
    DgnStrcat(lockNameBuffer, sizeof(lockNameBuffer), relPath);
    DgnStrcat(refNameBuffer, sizeof(refNameBuffer), relPath);
    int netRelLen=strlen(lockNameBuffer);

    // For search patterns, replace trailing ?'s by *
    {
        char extPattern[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(extPattern, sizeof(extPattern), gLokExt);
        replaceTrailingQMsByStar(extPattern);
        DgnSprintf(lockNameBuffer + netRelLen,
                   sizeof(lockNameBuffer) - netRelLen, "%s*.%s",
                   gLokDirSlash, extPattern);
        //PrintWrapped1("Searching for files matching %s", lockNameBuffer);
    }

    for (found = MyFindFirstFile(&hFindFile, lockNameBuffer, &finddata);
         found;
         found = MyFindNextFile(hFindFile, &finddata))
    {
        if(finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {   // directories can't be lock files.  If we're using *.* as our
            // pattern, this keeps us from using "." or "..".
            continue;
        }

        // We've got a lock file. Open it up.
        DgnStrcpy(lockNameBuffer+netRelLen,
                  sizeof(lockNameBuffer)-netRelLen, gLokDirSlash);
        DgnStrcat(lockNameBuffer, sizeof(lockNameBuffer), finddata.cFileName);
        //PrintWrapped1("Found file %s", lockNameBuffer);

        // Now try to locate the file that it's locking. Go back to relative
        // dir and translate the extension of the lock file into a search
        // pattern. Here we're going to make an assumption that underscores
        // in the extension were filled in to extend a short extension.

        // Here's the algorithm. For each character in the lock file's
        // extension:
        //  1. Replace '_' by '\0'
        //  2. Replace a char at position of a non-? in gLokExt with a ?.
        //  3. Anything else, leave alone.

        // Now things get a little tricky if the last character is a '?'. We
        // need to query the os for the file both using the ? and not.
        // For example, a pattern that looks like 'r?' could either match
        // 'r' or 'rc'.

        DgnStrcpy(refNameBuffer + netRelLen,
                  sizeof(refNameBuffer) - netRelLen, finddata.cFileName);
        BOOL bRefFileExists;
        if(gbMangleExtensions)
        {
            char *pExt=getFileExtensionAfterDot(refNameBuffer);

            int extlen = strlen(pExt);
            for(int i=0; i<extlen;i++)
            {
                if(pExt[i] == '_') {
                    pExt[i] = '\0';
                    break;
                }
                if(gLokExt[i] != '?') {
                    pExt[i] = '?';
                }
            }

            WIN32_FIND_DATA tempdata;
            HANDLE tempFindFile;

            bRefFileExists = MyFindFirstFile(&tempFindFile, refNameBuffer,
                                             &tempdata);
            MyFindClose(tempFindFile);

            if(!bRefFileExists &&
               refNameBuffer[strlen(refNameBuffer)-1] == '?')
            {
                // Try again without the ?
                refNameBuffer[strlen(refNameBuffer)-1] = '\0';
                bRefFileExists = MyFindFirstFile(&tempFindFile, refNameBuffer,
                                                 &tempdata);
                MyFindClose(tempFindFile);
            }
            if(bRefFileExists)
            {
                DgnStrcpy(refNameBuffer + netRelLen,
                          sizeof(refNameBuffer) - netRelLen,
                          tempdata.cFileName);
            }
        }
        else
        {
            bRefFileExists=saferFindFile(refNameBuffer);
        }

        if(!bRefFileExists ||
           pTrackedHash->hashFind(refNameBuffer+netLen) == -1)
        {   // Ignore regular tracked files -- they've already been covered
            // earlier.
            if(!gbAllowMixedCaseNames)
            {
                _strlwr_s(refNameBuffer + netLen,
                          sizeof(refNameBuffer) - netLen);
            }

            char lockDateTime[20];
            fillDateTime(finddata, lockDateTime, sizeof(lockDateTime));

            outputOneLockFileInfo(lockNameBuffer, lockDateTime,
                                  refNameBuffer+netLen, bRefFileExists,
                                  tlckFile, plainFile, FALSE, bFull,
                                  restrictName);
            putchar('.');
        }
    } // for (found ... )
    MyFindClose(hFindFile);
} // outputOneTlokDirInfo

// netPath is the directory being recursively checked, terminated by a
// backslash.  relPath is the relative path from there to the current
// directory being recursively checked, terminated by a backslash if
// non-empty.
void outputAllTlibSubdirsInfo(FILE *tlckFile, FILE *plainFile,
                              const char *netPath, const char *relPath,
                              const NameListHash *pTrackedHash,
                              BOOL bFull, const char *restrictName)
{
    WIN32_FIND_DATA finddata;
    HANDLE hFindFile;
    BOOL found;

    char buffer[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), netPath);
    DgnStrcat(buffer, sizeof(buffer), relPath);
    DgnStrcat(buffer, sizeof(buffer), "*.*");
    for (found = MyFindFirstFile(&hFindFile, buffer, &finddata);
         found;
         found = MyFindNextFile(hFindFile, &finddata))
    {
        if ((finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
            strcmp(finddata.cFileName, ".") &&
            strcmp(finddata.cFileName, "..") &&
            _stricmp(finddata.cFileName, "ptrlib")) // Don't look for TLIB
                                                   // dirs in PTRLIB dirs
        {
            char newRelPath[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(newRelPath, sizeof(newRelPath), relPath);
            DgnStrcat(newRelPath, sizeof(newRelPath), finddata.cFileName);
            DgnStrcat(newRelPath, sizeof(newRelPath), "\\");
            if (_stricmp(gLokDir, finddata.cFileName) == 0)
            {
                //PrintWrapped1("Starting lock dir %s.", newRelPath);
                outputOneTlokDirInfo(tlckFile, plainFile, netPath, relPath,
                                     pTrackedHash, bFull, restrictName);
                //PrintWrapped1("Finishing lock dir %s.", newRelPath);
            }
            else
            {   // Don't look for lock dirs in TLIB dirs
                if(_stricmp(gLibDir, finddata.cFileName) != 0)
                {
                    //PrintWrapped1("Starting dir %s.", newRelPath);
                    outputAllTlibSubdirsInfo(tlckFile, plainFile,
                                             netPath, newRelPath,
                                             pTrackedHash, bFull,
                                             restrictName);
                    //PrintWrapped1("Finishing dir %s.", newRelPath);
                }
            }
        }
    }
    MyFindClose(hFindFile);
}

BOOL processSrcLstIntoHash(const char *srcLstName, NameListHash *pSrcLstHash,
                           BOOL bOkayIfAlreadyPresent)
{
    FILE *fpSrcLst=NULL;
    if (!saferFopen(&fpSrcLst, srcLstName, eFopenRead))
    {
        return FALSE;
    }

    // Process reference src.lst into a hash table.
    FileListReader srcLstReader(fpSrcLst, srcLstName, eSrcLst, TRUE);
    while(!srcLstReader.done())
    {
        srcLstReader.next();
        if(srcLstReader.done())
        {
            break;
        }
        pSrcLstHash->hashInsert(srcLstReader.currentFile(),
                                bOkayIfAlreadyPresent);
    }
    saferFclose(fpSrcLst);
    return TRUE;
}

void checkSrcLstMissingFile(int &ct, BOOL bCheckForFile, const char *fileName,
                            const NameListHash *pSrcLstHash)
{
    if (bCheckForFile && pSrcLstHash->hashFind(fileName) == -1)
    {
        PrintWrapped1("Important file '%s' is missing from src.lst.",
                      fileName);
        ct++;
    }
}

void warnOnSrcLstMissingImportantFiles(const NameListHash *pSrcLstHash)
{
    int ct=0;
    checkSrcLstMissingFile(ct, TRUE, "updating.lck", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "tlib.cfg", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "tlibproj.cfg", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "tlibuser.cfg", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "tlmproj.cfg", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "tlmuser.cfg", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "src.lst", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "snapshot.txt", pSrcLstHash);
    checkSrcLstMissingFile(ct, TRUE, "changes.txt", pSrcLstHash);
    checkSrcLstMissingFile(ct, configUseUpdtstrc(),
                           "updtstrc.bat", pSrcLstHash);
    checkSrcLstMissingFile(ct, configUseRootdirMak(),
                           "rootdir.mak", pSrcLstHash);
    if (ct > 0)
    {
        char buffer[10];
        DgnSprintf(buffer, sizeof(buffer), "%d", ct);
        PrintWrapped3("Warning: there %s %s important file%s missing "
                      "from src.lst.",
                      ct > 1 ? "are" : "is", buffer, ct > 1 ? "s" : "");
        pauseAndWarn();
    }
}

BOOL tlibTlinfo(BOOL bFull, const char *tlibName, const char *tlckOutFile,
                const char *plainOutFile)
{
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);

    FILE *tlckFile=NULL;
    FILE *plainFile=NULL;

    NameListHash srcLstHash(TRUE);
    if ((tlckOutFile && !saferFopen(&tlckFile, tlckOutFile, eFopenWrite)) ||
        (plainOutFile && !saferFopen(&plainFile, plainOutFile, eFopenWrite)) ||
        !processSrcLstIntoHash("src.lst", &srcLstHash, FALSE))
    {
        return FALSE;
    }
    warnOnSrcLstMissingImportantFiles(&srcLstHash);

    const char *pNamePool=srcLstHash.getNamePool();
    const char *pNextPool=srcLstHash.getNextPool();
    const char *pCurrentName=pNamePool;
    const char *numStagesStr=bFull ? "4" : "3";
    // Maybe this could be a handy option, but it's just too ugly to turn on
    // right now.
    BOOL bShowAlphaChars=FALSE;
    char lastInitialChar='\0';
    PrintWrapped1("Checking network reference files (stage 1 of %s)",
                  numStagesStr);
    while(pCurrentName != pNextPool)
    {
        {
            // Report if not read-only or if missing
            char refName[TL_MAXSTRSIZE+1]="";

            DgnStrcpy(refName, sizeof(refName), gNetworkDirectory);
            DgnStrcat(refName, sizeof(refName), pCurrentName);
            BOOL readWrite;
            if(saferFindFileAndAttrib(refName, &readWrite))
            {
                if (readWrite)
                {
                    saferFprintf(stdout, "\n%s not read-only.\n", refName);
                    if(plainFile)
                    {
                        saferFprintf(plainFile, "%s not read-only.\n",
                                     refName);
                    }
                }
            }
            else
            {
                PrintWrapped1("Warning: %s, the reference copy of a "
                              "source-controlled file, is missing.  "
                              "This is a serious inconsistency, and "
                              "should be rectified.", refName);
                pauseAndWarn();
                saferFprintf(stdout, "%s missing.\n", refName);
                if(plainFile)
                {
                    saferFprintf(plainFile, "%s missing.\n", refName);
                }
            }
        }
        if(bShowAlphaChars && *pCurrentName != lastInitialChar)
        {
            lastInitialChar = *pCurrentName;
            putchar(lastInitialChar);
        }
        else
        {
            putchar('.');
        }
        pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
    }
    putchar('\n');

    pCurrentName=pNamePool;
    lastInitialChar='\0';
    PrintWrapped1("Checking network library files (stage 2 of %s)",
                  numStagesStr);
    while(pCurrentName != pNextPool)
    {
        {
            char libName[TL_MAXSTRSIZE+1]="";
            fullMangle(libName, sizeof(libName), gNetworkDirectory,
                       pCurrentName, EMangleForLibrary);
            BOOL readWrite;
            if(saferFindFileAndAttrib(libName, &readWrite))
            {
                if (readWrite)
                {
                    saferFprintf(stdout, "\n%s not read-only.\n", libName);
                    if(plainFile)
                    {
                        saferFprintf(plainFile, "%s not read-only.\n",
                                     libName);
                    }
                }
            }
            else
            {
                PrintWrapped1("Warning: %s, the library file for a "
                              "source-controlled file, is missing.  "
                              "This is a serious corruption, and "
                              "should be rectified.", libName);
                pauseAndWarn();
                saferFprintf(stdout, "%s missing.\n", libName);
                if(plainFile)
                {
                    saferFprintf(plainFile, "%s missing.\n", libName);
                }
            }
        }
        if(bShowAlphaChars && *pCurrentName != lastInitialChar)
        {
            lastInitialChar = *pCurrentName;
            putchar(lastInitialChar);
        }
        else
        {
            putchar('.');
        }
        pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
    }
    putchar('\n');

    pCurrentName=pNamePool;
    lastInitialChar='\0';
    PrintWrapped1("Checking network lock files (stage 3 of %s)",
                  numStagesStr);
    while(pCurrentName != pNextPool)
    {
        {
            char lockName[TL_MAXSTRSIZE+1]="";
            fullMangle(lockName, sizeof(lockName), gNetworkDirectory,
                       pCurrentName, EMangleForLock);
            BOOL readWrite;
            char lockDateTime[20];
            if(saferFindFileAndAttribAndDate(
                lockName, &readWrite,
                lockDateTime, sizeof(lockDateTime)))
            {
                if (readWrite)
                {
                    saferFprintf(stdout, "\n%s not read-only.\n", lockName);
                    if(plainFile)
                    {
                        saferFprintf(plainFile, "%s not read-only.\n",
                                     lockName);
                    }
                }
                outputOneLockFileInfo(lockName, lockDateTime,
                                      pCurrentName, TRUE,
                                      tlckFile, plainFile, TRUE, bFull,
                                      tlibName);
            }
        }
        if(bShowAlphaChars && *pCurrentName != lastInitialChar)
        {
            lastInitialChar = *pCurrentName;
            putchar(lastInitialChar);
        }
        else
        {
            putchar('.');
        }
        pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
    }
    putchar('\n');

    if(bFull)
    {
        PrintWrapped1(
            "Checking non-src.lst network lock files (stage 4 of %s)",
            numStagesStr);
        // Check all lock files for files not in reference src.lst
        outputAllTlibSubdirsInfo(tlckFile, plainFile,
                                 gNetworkDirectory,
                                 "", &srcLstHash,
                                 bFull, tlibName);
        putchar('\n');
    }

    // Close output file
    if (tlckFile != NULL)
    {
        saferFclose(tlckFile);
    }

    // Close output file
    if (plainFile != NULL)
    {
        saferFclose(plainFile);
    }

    return TRUE;
}

BOOL tlibYou(const char *tlibName)
{
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    saferRemove("tlck.001", FALSE);
    saferRemove("tlck.002", FALSE);
    saferRemove("tlck.003", FALSE);
    saferRemove("tlck.004", FALSE);
    if(tlibTlinfo(FALSE, tlibName, "tlck.002", NULL))
    {
        saferSort(TRUE, TRUE, FALSE, 0, 0, FALSE, "tlck.002", "tlck.004");
        saferRemove("tlck.002", FALSE);
        saferSystem0(normal, "type tlck.004");
        PrintWrapped0("\n");
        PrintWrapped0("A list of the checked out files is in tlck.004\n\n");
        return TRUE;
    }
    else
    {
        PrintWrapped0("Unable to get tlinfo.");
        return FALSE;
    }
}

BOOL tlibMe()
{
    return tlibYou(gUserName);
}

void xcheckDirectory(
    BOOL bFull, BOOL bDirectoryHasTlibCfg,
    FILE *pTlxFile, FILE *pPlainFile, NameListHash *pTrackedHash,
    const char *workPath, const char *relPath)
{
    char checkPath[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(checkPath, sizeof(checkPath), workPath);
    int workLen=strlen(checkPath);
    DgnStrcat(checkPath, sizeof(checkPath), relPath);
    int workRelLen = strlen(checkPath);
    DgnStrcat(checkPath, sizeof(checkPath), "*.*");

    WIN32_FIND_DATA finddata;
    HANDLE hFindFile;
    BOOL bFoundAFile=FALSE;

    for (int found = MyFindFirstFile(&hFindFile, checkPath, &finddata);
         found;
         found = MyFindNextFile(hFindFile, &finddata))
    {
        if (finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            if(strcmp(finddata.cFileName, ".") &&
               strcmp(finddata.cFileName, ".."))
            {
                bFoundAFile=TRUE;
                if(!bDirectoryHasTlibCfg)
                {
                    break;
                }
                
                char newRelPath[TL_MAXSTRSIZE+1]="";
                DgnStrcpy(newRelPath, sizeof(newRelPath), relPath);
                DgnStrcat(newRelPath, sizeof(newRelPath), finddata.cFileName);
                DgnStrcat(newRelPath, sizeof(newRelPath), "\\");

                // now check if a tlib.cfg exists in the subdirectory
                char tlibCfgName[TL_MAXSTRSIZE+1]="";
                DgnStrcpy(tlibCfgName, sizeof(tlibCfgName), newRelPath);
                DgnStrcat(tlibCfgName, sizeof(tlibCfgName), "tlib.cfg");

                BOOL bSubdirHasTlibCfg=saferFindFile(tlibCfgName);

                if(bSubdirHasTlibCfg || bFull)
                {
                    xcheckDirectory(
                        bFull, bSubdirHasTlibCfg,
                        pTlxFile, pPlainFile, pTrackedHash,
                        workPath, newRelPath);
                }
            }
        }
        else
        {
            putchar('.');
            bFoundAFile=TRUE;
            if(!bDirectoryHasTlibCfg)
            {
                break;
            }
            
            DgnStrcpy(checkPath + workRelLen,
                      sizeof(checkPath) - workRelLen,
                      finddata.cFileName);
            // Skip files in src.lst, as we've already checked them.
            if (pTrackedHash->hashFind(checkPath+workLen) == -1)
            {
                const char *pDesc;
                BOOL bPrint=FALSE;
                if (finddata.dwFileAttributes & FILE_ATTRIBUTE_READONLY)
                {
                    pDesc=gpLocalReadOnlyNotInSrcLst;
                    // File is read-only
                    // tlibwork.trk should be read-only
                    if (_stricmp(checkPath+workLen, TLIBWORK_TRK))
                    {
                        bPrint=TRUE;
                    }
                }
                else
                {
                    pDesc=NULL;
                    // Specific name exceptions and requirements
                    int extOff=getFileExtensionOffset(finddata.cFileName);
                    if ((_stricmp(finddata.cFileName, "updthelp.bat") &&
                         _stricmp(finddata.cFileName, "version.txt") &&
                         extensionIsInCommaSet(finddata.cFileName + extOff,
                                               gGoodExtensions) &&
                         (finddata.cFileName[extOff] != '\0' ||
                          !_stricmp(finddata.cFileName, "makefile"))))
                    {
                        pDesc=gpLocalNotReadOnlyNotInSrcLst;
                        bPrint=TRUE;
                    }
                    else if(finddata.cFileName[extOff] == '.' &&
                            isMemberByWhitespace(
                                finddata.cFileName + extOff + 1,
                                gExtraTrackedExtensions))
                    {
                        pDesc=gpLocalNotReadOnlyNotInSrcLstFromExtra;
                        bPrint=TRUE;
                    }
                    else if(bFull)
                    {
                        pDesc=gpLocalNotReadOnlyNotInSrcLstFromFull;
                        bPrint=TRUE;
                    }
                }
                if(bPrint)
                {
                    assert(pDesc != NULL);
                    printOneTrackInfo(checkPath+workLen, pPlainFile, pTlxFile,
                                      pDesc);
                }
            } // file not in src.lst
        }
    } // for (ret ... )
    if(!bDirectoryHasTlibCfg)
    {
        printOneTrackInfo(relPath, pPlainFile, NULL,
                          (bFoundAFile ? gpUntrackedNonEmptyDirectory :
                           gpUntrackedEmptyDirectory));
    }
    MyFindClose(hFindFile);
} // xcheckDirectory

BOOL processCkinallIntoHash(const char *ckinallName,
                            NameListHash *pCheckinHash,
                            NameListHash *pAddcommHash)
{
    FILE *fpCheckinScript;
    if(!saferFopen(&fpCheckinScript, ckinallName, eFopenRead))
    {
        return FALSE;
    }
    char buffer[TL_MAXSTRSIZE+1]="";
    char modcommGeneratedFile[TL_MAXSTRSIZE+1]="";
    while(fgets(buffer, TL_MAXSTRSIZE, fpCheckinScript))
    {
        if(isPrefix("checkin ", buffer))
        {
            char *pFileName=buffer+strlen("checkin ");
            char *pNextSpace=strchr(pFileName, ' ');
            if(pNextSpace == NULL)
            {
                trimFinalWhiteSpace(pFileName);
            }
            else
            {
                pNextSpace[0] = '\0';
            }
            replaceForwardSlashesWithBackslashes(pFileName);
            if(pCheckinHash != NULL)
            {
                pCheckinHash->hashInsert(pFileName, FALSE);
            }
        }
        else if(isPrefix("modcomm ", buffer))
        {
            char *pFileName=buffer+strlen("modcomm ");
            char *pNextSpace=strchr(pFileName, ' ');
            if(pNextSpace == NULL)
            {
                trimFinalWhiteSpace(pFileName);
            }
            else
            {
                pNextSpace[0] = '\0';
                char *pFileName2 = pNextSpace + 1;
                char *pNextSpace2 = strchr(pFileName2, ' ');
                if(pNextSpace2 == NULL)
                {
                    trimFinalWhiteSpace(pFileName2);
                }
                else
                {
                    pNextSpace2[0] = '\0';
                }
                DgnStrcpy(modcommGeneratedFile, sizeof(modcommGeneratedFile),
                          pFileName2);
            }
            replaceForwardSlashesWithBackslashes(pFileName);
            if(pAddcommHash != NULL)
            {
                pAddcommHash->hashInsert(pFileName, FALSE);
            }
        }
        else if(isPrefix("addcomm ", buffer))
        {
            char *pFileName=buffer+strlen("addcomm ");
            char *pNextSpace=strchr(pFileName, ' ');
            if(pNextSpace == NULL)
            {
                trimFinalWhiteSpace(pFileName);
            }
            else
            {
                pNextSpace[0] = '\0';
            }
            replaceForwardSlashesWithBackslashes(pFileName);
            if(pAddcommHash != NULL &&
               strcmp(pFileName, modcommGeneratedFile))
            {
                pAddcommHash->hashInsert(pFileName, FALSE);
            }
        }
    }
    saferFclose(fpCheckinScript);
    return TRUE;
}

BOOL tlibXcheck(BOOL bFull, BOOL bShort, BOOL bListOnly,
                const char *tlxFile, const char *plainFile,
                BOOL bCheckReferenceCopy)
{
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);

    FILE *pTlxFile=NULL;
    FILE *pPlainFile=NULL;
    NameListHash trackedHash(TRUE);
    if ((tlxFile && !saferFopen(&pTlxFile, tlxFile, eFopenWrite)) ||
        (plainFile && !saferFopen(&pPlainFile, plainFile, eFopenWrite)) ||
        !processSrcLstIntoHash("src.lst", &trackedHash, FALSE))
    {
        return FALSE;
    }
    warnOnSrcLstMissingImportantFiles(&trackedHash);

    NameListHash checkinHash(TRUE);
    if(saferFindFile("ckinall.txt"))
    {
        if(!processCkinallIntoHash("ckinall.txt", &checkinHash, NULL))
        {
            return FALSE;
        }
    }

    UpdateCriteria upCrit;

    // Process reference src.lst and pointer-tracked files, outputting info
    // about each, and inserting the latter into trackedHash.
    const char *numStagesStr=(!bListOnly && !bShort) ? "2" : "1";
    {
        const char *pNamePool=trackedHash.getNamePool();
        const char *pNextPool=trackedHash.getNextPool();
        const char *pCurrentName=pNamePool;
        PrintWrapped1("Checking tracked files (stage 1 of %s)",
                      numStagesStr);
        while(pCurrentName != pNextPool)
        {
            BOOL bShouldBeHere=upCrit.fileMeetsUpdateCriteria(pCurrentName);
            xcheckTrackedFile(bListOnly, &trackedHash, &checkinHash,
                              gNetworkDirectory,
                              gWorkDirectory,
                              pCurrentName,
                              FALSE, pPlainFile, pTlxFile, bShouldBeHere,
                              bCheckReferenceCopy);
            putchar('.');
            pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
        }
    }
    putchar('\n');

    {
        char const * const *pAllFiles=trackedHash.getAllNames();
        char tlibCfg[TL_MAXSTRSIZE+1]="";
        NameListHash necessaryTlibCfgsHash(TRUE);
        NameListHash necessaryExtensionsHash(FALSE);
        for(int i=0; i<HASH_MAX_NAMES; i++)
        {
            if(pAllFiles[i] != NULL)
            {
                const char *pExt=(pAllFiles[i] +
                                  getFileExtensionOffset(pAllFiles[i]));
                if(necessaryExtensionsHash.hashFind(pExt) == -1)
                {
                    if(!extensionIsInCommaSet(pExt, gGoodExtensions))
                    {
                        // Unconfigured extension should be configured.
                        printOneTrackInfo(
                            pExt, pPlainFile, NULL,
                            gpExtensionThatShouldBeConfigured);
                    }
                    necessaryExtensionsHash.hashInsert(pExt, FALSE);
                }
                
                DgnStrcpy(tlibCfg, sizeof(tlibCfg), pAllFiles[i]);
                BOOL bCheckedAll=FALSE;
                while(!bCheckedAll)
                {
                    char *lastSlash=strrchr(tlibCfg, '\\');
                    if(lastSlash==NULL)
                    {
                        DgnStrcpy(tlibCfg, sizeof(tlibCfg), "tlib.cfg");
                        bCheckedAll=TRUE;
                    }
                    else
                    {
                        *lastSlash='\0';
                        DgnStrcat(tlibCfg, sizeof(tlibCfg), "\\tlib.cfg");
                    }
                    if(necessaryTlibCfgsHash.hashFind(tlibCfg) == -1)
                    {
                        if(trackedHash.hashFind(tlibCfg) == -1)
                        {
                            // Untracked tlib.cfg file should exist and be
                            // tracked.
                            printOneTrackInfo(tlibCfg, pPlainFile, NULL,
                                              gpTlibCfgThatShouldExist);
                        }
                        necessaryTlibCfgsHash.hashInsert(tlibCfg, FALSE);
                    }
                    if(!bCheckedAll)
                    {
                        lastSlash[0]='\0';
                    }
                }
            }
        }
    }

    if(!bListOnly && !bShort)
    {
        PrintWrapped1("Checking untracked files (stage 2 of %s)",
                      numStagesStr);
        xcheckDirectory(bFull, TRUE, pTlxFile, pPlainFile,
                        &trackedHash, gWorkDirectory, "");
        putchar('\n');
    }

    if (pTlxFile != NULL)
    {
        saferFclose(pTlxFile);
    }

    if (pPlainFile != NULL)
    {
        saferFclose(pPlainFile);
    }

    return TRUE;
}

BOOL createTlibuser(const char *pTlibuserFileName,
                    const char *netDir, const char *localDir,
                    NewLineTypeEnum newLineType,
                    BOOL bSetColorizeN)
{
    FILE *fpTlibuser;
    if (!saferFopen(&fpTlibuser, pTlibuserFileName, eFopenWrite))
    {
        return FALSE;
    }
    saferFprintf(fpTlibuser,
                 "REM this file tells where to find the libraries for your\n");
    saferFprintf(fpTlibuser, "REM project.  Personalize it!\n");
    saferFprintf(fpTlibuser, "SET NETDIR=%s\\\n", netDir);
    saferFprintf(fpTlibuser, "workdir %s\\\n", localDir);
    if (newLineType == E_LF)
    {
        saferFprintf(fpTlibuser, "newline LF\n");
    }
    else if (newLineType == E_CR)
    {
        saferFprintf(fpTlibuser, "newline CR\n");
    }
    else if (newLineType == E_CRLF)
    {
        saferFprintf(fpTlibuser, "newline CRLF\n");
    }
    else
    {
        assert(!"bad newLineType value");
    }
    if(bSetColorizeN)
    {
        saferFprintf(fpTlibuser, "colorize N\n");
    }
    saferFclose(fpTlibuser);
    return TRUE;
}

BOOL createDummyTlmuser(const char *pTlmuserFileName)
{
    FILE *fpTlmuser;
    if (!saferFopen(&fpTlmuser, pTlmuserFileName, eFopenWrite))
    {
        return FALSE;
    }
    saferFprintf(fpTlmuser, "PREVENT_CHANGES=1\n");
    saferFclose(fpTlmuser);
    return TRUE;
}

BOOL tlibXbackup(BOOL bFull, BOOL bShort, const char *dirName,
                 BOOL bCheckReferenceCopy)
{
    char subDirName[TL_MAXSTRSIZE+1]="";
    {
        DgnStrcpy(subDirName, sizeof(subDirName), dirName);
        if(!saferFindDir(subDirName))
        {
            PrintWrapped1("Couldn't find directory %s.", subDirName);
            return FALSE;
        }
        else
        {
            int subDirNameLen=strlen(subDirName);
            BOOL success=FALSE;
            for(int i=1; i<1000; i++)
            {
                DgnSprintf(subDirName + subDirNameLen,
                           sizeof(subDirName) - subDirNameLen, "\\%03d", i);
                if(!saferFindDir(subDirName))
                {
                    saferMkdir(subDirName);
                    if(!saferFindDir(subDirName))
                    {
                        PrintWrapped1("Couldn't make directory %s.",
                                      subDirName);
                        return FALSE;
                    }
                    success=TRUE;
                    break;
                }
            }
            if(!success)
            {
                PrintWrapped1("Couldn't find an unused directory in %s.",
                              dirName);
                return FALSE;
            }
        }
    }
    BOOL tlRet=tlibXcheck(bFull, bShort, FALSE, "xbackup.001", NULL,
                          bCheckReferenceCopy);
    if(tlRet)
    {
        saferSort(TRUE, TRUE, FALSE, 0, 0, FALSE,
                  "xbackup.001", "xbackup.002");
        saferSystem0(normal, "type xbackup.002");
        saferSystem0(normal, "echo changes.txt >> xbackup.002");
        saferSystem0(normal, "echo tlibwork.trk >> xbackup.002");
        saferSystem0(normal, "echo tlib.cfg >> xbackup.002");
        saferSystem0(normal, "echo tlibproj.cfg >> xbackup.002");
        saferSystem0(normal, "echo tlibuser.cfg >> xbackup.002");
        saferSystem0(normal, "echo tlmproj.cfg >> xbackup.002");
        saferSystem0(normal, "echo tlmuser.cfg >> xbackup.002");
        FILE *fpBigListFiles = NULL;
        FILE *fpListFiles = NULL;
        NameListHash skipFiles(TRUE);
        char skippedFiles[TL_MAXSTRSIZE+1]="";
        if (readConfigOption(gWorkDirectory,
                             "tlmuser.cfg", "XBACKUP_SKIPPED_FILES=",
                             skippedFiles, sizeof(skippedFiles),
                             FALSE, FALSE, FALSE))
        {
            char *pSkipFile = skippedFiles;
            while(TRUE)
            {
                while(*pSkipFile == '\t' || *pSkipFile == ' ')
                {
                    pSkipFile++;
                }
                char *p = pSkipFile;
                while(*p != '\t' && *p != ' ' && *p != '\0')
                {
                    p++;
                }
                if(*p == '\0')
                {
                    skipFiles.hashInsert(pSkipFile, TRUE);
                    break;
                }
                else
                {
                    *p = '\0';
                    skipFiles.hashInsert(pSkipFile, TRUE);
                    pSkipFile = p + 1;
                }
            }
        }
        if (!saferFopen(&fpBigListFiles, "xbackup.002", eFopenRead))
        {
            return FALSE;
        }
        if (!saferFopen(&fpListFiles, "xbackup.res", eFopenWrite))
        {
            return FALSE;
        }
        char buffer[TL_MAXSTRSIZE+1]="";
        char buffer1[TL_MAXSTRSIZE+1]="";
        while(fgets(buffer, TL_MAXSTRSIZE, fpBigListFiles))
        {
            DgnStrcpy(buffer1, sizeof(buffer1), (const char *)buffer);
            convertListLineToFileName(buffer);
            truncateAfterFirstSpaceOrTab(buffer);
            if (skipFiles.hashFind(buffer) == -1)
            {
                saferCopyWithDirs(buffer, subDirName, TRUE);
                saferFprintf(fpListFiles, "%s", buffer1);
            }
            else
            {
                PrintWrapped1("Skipping %s (XBACKUP_SKIPPED_FILES)\n",
                              buffer);
            }
        }
        saferFclose(fpListFiles);
        saferFclose(fpBigListFiles);
        {
            char tempName[TL_MAXSTRSIZE+1]="";
            char tempNetDir[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(tempName, sizeof(tempName), subDirName);
            DgnStrcat(tempName, sizeof(tempName), "\\tlibuser.cfg");
            DgnStrcpy(tempNetDir, sizeof(tempNetDir), gNetworkDirectory);
            if(tempNetDir[strlen(tempNetDir)-1] == '\\')
            {
                tempNetDir[strlen(tempNetDir)-1]='\0';
            }
            if(!createTlibuser(tempName, tempNetDir, subDirName,
                               gNewLineType, !gbWinNT))
            {
                return FALSE;
            }
            DgnStrcpy(tempName, sizeof(tempName), subDirName);
            DgnStrcat(tempName, sizeof(tempName), "\\tlmuser.cfg");
            if(!createDummyTlmuser(tempName))
            {
                return FALSE;
            }
        }
        saferRemove("xbackup.001", TRUE);
        saferRemove("xbackup.002", TRUE);
        saferCopyWithDirs("xbackup.res", subDirName, TRUE);
        PrintWrapped0("\n");
        PrintWrapped1("A list of files that have been backed up "
                      "is in %s\\xbackup.res\n\n", subDirName);
    }
    return tlRet;
}

BOOL tlibHistory(const char *fileName)
{
    PrintWrapped0("Finding history...");
    return (saferTlibbs1(loud, "-q l %s", fileName) == 0);
}

BOOL tlibInfohist(const char *fileName)
{
    PrintWrapped0("Finding info and recent history...");
    if(tlibInfo(fileName))
    {
        showHistoryTail(fileName);
        return TRUE;
    }
    return FALSE;
}

#define DIFF_SEPARATOR \
"+++++++++++++++++++++++++++++++++++++++++++++++++++++++"

typedef enum DiffType
{
    eDiffStandard,
    eDiffStandardIgnoringWhitespace,
    eDiffWinDiff,
    eDiffWinMerge,
    eDiffTlibcomp,
    eDiffCustom
} DiffType;

BOOL tlibDiff(const char *fileName, const char *revNum, const char *revNum2,
              BOOL interpretVersionsAsSnapshotVersions,
              DiffType diffType, BOOL displayDiff, BOOL announceDiffDotRes)
{
    PrintWrapped0("Examine differences...");
    BOOL bOutputsToDiffRes=(diffType == eDiffStandard ||
                            diffType == eDiffStandardIgnoringWhitespace ||
                            (diffType == eDiffCustom &&
                             !gbCustomDiffExecutableIsInteractive));
    if(bOutputsToDiffRes)
    {
        saferRemove("diff.res", FALSE);
    }

    if(saferFindFile(fileName) || revNum2 != NULL)
    {
        char leftFile[TL_MAXSTRSIZE+1]="";
        char rightFile[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(leftFile, sizeof(leftFile), fileName);
        const char *pLastSlash=strrchr(leftFile, '\\');
        {
            char *pDot;
            while((pDot=strrchr(leftFile, '.')) != NULL &&
                  (pLastSlash == NULL || pDot > pLastSlash))
            {
                *pDot='_';
            }
        }
        DgnStrcat(leftFile, sizeof(leftFile), "_");
        DgnStrcpy(rightFile, sizeof(rightFile), leftFile);

        if(!strcmp(revNum, "*"))
        {
            DgnStrcat(leftFile, sizeof(leftFile), "curr");
        }
        else if(!strcmp(revNum, "*-1"))
        {
            DgnStrcat(leftFile, sizeof(leftFile), "prev");
        }
        else if(!strcmp(revNum, "-"))
        {
            DgnStrcat(leftFile, sizeof(leftFile), "ltrack");
        }
        else
        {
            DgnStrcat(leftFile, sizeof(leftFile), revNum);
        }

        if(revNum2 == NULL)
        {
            DgnStrcat(rightFile, sizeof(rightFile), "local");
        }
        else if(!strcmp(revNum2, "*"))
        {
            DgnStrcat(rightFile, sizeof(rightFile), "curr");
        }
        else if(!strcmp(revNum2, "*-1"))
        {
            DgnStrcat(rightFile, sizeof(rightFile), "prev");
        }
        else if(!strcmp(revNum2, "-"))
        {
            DgnStrcat(rightFile, sizeof(rightFile), "ltrack");
        }
        else
        {
            DgnStrcat(rightFile, sizeof(rightFile), revNum2);
        }
        DgnStrcat(leftFile, sizeof(leftFile), ".000");
        DgnStrcat(rightFile, sizeof(rightFile), ".001");
        saferRemove(leftFile, FALSE);
        saferRemove(rightFile, FALSE);
        tlibGet(fileName, interpretVersionsAsSnapshotVersions,
                revNum, leftFile);
        // extract the files
        if(revNum2 != NULL)
        {
            tlibGet(fileName, interpretVersionsAsSnapshotVersions,
                    revNum2, rightFile);
        }
        else
        {
            saferCopy(fileName, rightFile, TRUE);
        }
        if(!saferFindFile(leftFile) || !saferFindFile(rightFile))
        {
            PrintWrapped1("Error - Unable to extract file %s.", fileName);
            return FALSE;
        }
        else
        {
            if(!bOutputsToDiffRes)
            {
                switch(diffType)
                {
                 case eDiffStandard:
                 case eDiffStandardIgnoringWhitespace:
                    assert(!"no it's not!");
                    break;

                 case eDiffWinDiff:
                    saferSpawn2(loud, eCheckRetNoneAndNoCheckValidExe,
                                "windiff.exe", "%s %s", leftFile, rightFile);
                    break;

                 case eDiffWinMerge:
                    saferSpawn2(loud, eCheckRetNoneAndNoCheckValidExe,
                                gWinMergePath, "-ub -wl -wr %s %s",
                                leftFile, rightFile);
                    break;

                 case eDiffTlibcomp:
                    saferSpawn2(loud, eCheckRetNone,
                                gTlibcompPath, "%s %s", leftFile, rightFile);
                    break;

                 case eDiffCustom:
                    if(gCustomDiffExecutablePath[0] == '\0')
                    {
                        PrintWrapped0("Must specify custom diff "
                                      "executable in tlmuser.cfg.");
                        return FALSE;
                    }
                    else
                    {
                        saferSystem3(normal, "%s %s %s",
                                     gCustomDiffExecutablePath,
                                     leftFile, rightFile);
                    }
                    break;
                }

                // delete the temporary files
                saferRemove(leftFile, TRUE);
                saferRemove(rightFile, TRUE);
            }
            else
            {
                FILE *fp;
                if (!saferFopen(&fp, "diff.res", eFopenWrite))
                {
                    return FALSE;
                }
                saferFprintf(fp, DIFF_SEPARATOR "\n");
                if(revNum2==NULL)
                {
                    saferFprintf(fp, "Difference in %s between version %s [<] "
                                 "and local version [>]\n", fileName, revNum);
                }
                else
                {
                    saferFprintf(fp, "Difference in %s between version %s [<] "
                                 "and version %s [>]\n", fileName,
                                 revNum, revNum2);
                }
                saferFprintf(fp, "\n");
                saferFclose(fp);
                switch(diffType)
                {
                 case eDiffStandard:
                 case eDiffStandardIgnoringWhitespace:
                    saferSystem4(normal, "%s -v %s%s %s >> diff.res",
                                 gDiffPath,
                                 (diffType == eDiffStandardIgnoringWhitespace ?
                                  "-bi " : ""),
                                 leftFile, rightFile);
                    break;
                    
                 case eDiffWinDiff:
                 case eDiffWinMerge:
                 case eDiffTlibcomp:
                    assert(!"no it's not!");
                    break;

                 case eDiffCustom:
                    saferSystem3(normal, "%s -v %s %s >> diff.res",
                                 gCustomDiffExecutablePath,
                                 leftFile, rightFile);
                    break;
                }
                
                // delete the temporary files
                saferRemove(leftFile, TRUE);
                saferRemove(rightFile, TRUE);
                if(displayDiff)
                {
                    PrintWrapped0("\n");
                    saferSpawn0(normal, eCheckRetNoneAndNoCheckValidExe,
                                gMorePath, "diff.res");
                }
                if(announceDiffDotRes)
                {
                    PrintWrapped0("\n");
                    PrintWrapped0("Differences are stored in the file "
                                  "diff.res\n\n");
                }
            }
            return TRUE;
        }
    }
    else
    {
        PrintWrapped1("No such file as %s.", fileName);
        return FALSE;
    }
}

void appendItem(char *pMergedList, size_t lMergedList,
                const char *pItem, int itemLen)
{
    if(pMergedList[0]!='\0')
    {
        DgnStrcat(pMergedList, lMergedList, ", ");
    }
    DgnStrncat(pMergedList, lMergedList, pItem, itemLen);
}

typedef enum MergeLineStatus
{
    eNoBaseFile,
    eJustBaseFile,
    eBaseFileAndDiffComponent,
    eBaseFileAndDiffDir
} MergeLineStatus;

// Contract: mergedList maintains a list of all the merged components, e.g.
// "file1, file2, file3".  If newFile can be merged with baseFile, it is
// accumulated onto the list and TRUE is returned.  Otherwise, FALSE is
// returned.  mergeLineStatus tells us whether or not a merge is already in
// progress, and if it's eBaseFileAndDiffComponent, *pBaseDiffComponentStart
// determines and is maintained as the index of that in-progress merge.
MergeLineStatus tryMergeLines(
    const char *baseFile, const char *baseSpace,
    const char *newFile, const char *newSpace,
    char *pMergedList, size_t lMergedList,
    MergeLineStatus mergeLineStatus,
    int *pBaseDiffComponentStart)
{
    assert(mergeLineStatus != eNoBaseFile);
    if(strcmp(baseSpace, newSpace))
    {
        return eNoBaseFile;
    }
    if(mergeLineStatus == eBaseFileAndDiffComponent)
    {
        if(strncmp(baseFile, newFile, *pBaseDiffComponentStart))
        {
            return eNoBaseFile;
        }
    }
    else if(mergeLineStatus == eJustBaseFile)
    {
        int firstDiff=firstCharDiffIndex(baseFile, newFile, TRUE, TRUE);
        *pBaseDiffComponentStart = firstDiff;
        pMergedList[0]='\0';
    }

    const char *diffStartBase=baseFile + *pBaseDiffComponentStart;
    const char *diffStartNew=newFile + *pBaseDiffComponentStart;
    const char *nextSlashBase=strchr(diffStartBase, '\\');
    const char *nextSlashNew=strchr(diffStartNew, '\\');
    const char *lastSlashBase=strrchr(baseFile, '\\');
    const char *lastSlashNew=strrchr(newFile, '\\');

    if(mergeLineStatus == eBaseFileAndDiffDir)
    {
        if((lastSlashBase==NULL || lastSlashNew==NULL) ||
           (strcmp(lastSlashBase, lastSlashNew)))
        {
            return eNoBaseFile;
        }
        else
        {
            appendItem(pMergedList, lMergedList, newFile,
                       lastSlashNew-newFile);
            return eBaseFileAndDiffDir;
        }
    }
    else if(nextSlashBase==NULL && nextSlashNew==NULL)
    {
        if(mergeLineStatus == eJustBaseFile)
        {
            appendItem(pMergedList, lMergedList, diffStartBase,
                       strlen(diffStartBase));
        }
        appendItem(pMergedList, lMergedList, diffStartNew,
                   strlen(diffStartNew));
        return eBaseFileAndDiffComponent;
    }
    else if((nextSlashBase==NULL || nextSlashNew==NULL) ||
            (strcmp(nextSlashBase, nextSlashNew)))
    {
        // back off to trying to have the same file name but different
        // complete directories.
        if(mergeLineStatus == eBaseFileAndDiffComponent ||
           (lastSlashBase==NULL || lastSlashNew==NULL) ||
           (strcmp(lastSlashBase, lastSlashNew)))
        {
            return eNoBaseFile;
        }
        else
        {
            assert(mergeLineStatus == eJustBaseFile);
            appendItem(pMergedList, lMergedList,
                       baseFile, lastSlashBase-baseFile);
            appendItem(pMergedList, lMergedList,
                       newFile, lastSlashNew-newFile);
            return eBaseFileAndDiffDir;
        }
    }
    else
    {
        if(mergeLineStatus == eJustBaseFile)
        {
            appendItem(pMergedList, lMergedList,
                       diffStartBase, nextSlashBase-diffStartBase);
        }
        appendItem(pMergedList, lMergedList,
                   diffStartNew, nextSlashNew-diffStartNew);
        return eBaseFileAndDiffComponent;
    }
}

void flushMergedOutput(FILE *fpNewComm,
                       const char *baseFile, const char *baseSpace,
                       const char *mergedList,
                       MergeLineStatus mergeLineStatus,
                       int baseDiffComponentStart)
{
    assert(mergeLineStatus != eNoBaseFile);
    if(mergeLineStatus == eJustBaseFile)
    {
        saferFprintf(fpNewComm, "%s%s\n", baseSpace, baseFile);
    }
    else
    {
        int nBaseSpace=0;
        {
            for(int i=0; baseSpace[i] != '\0'; i++)
            {
                if(baseSpace[i]=='\t')
                {
                    nBaseSpace += 8;
                }
                else
                {
                    nBaseSpace += 1;
                }
            }
        }
        const char *pLeft=baseFile;
        int nLeft;
        const char *pRight="";
        int nRight=0;
        if(mergeLineStatus==eBaseFileAndDiffComponent)
        {
            nLeft=baseDiffComponentStart;
            const char *diffStartBase=pLeft + nLeft;
            const char *nextSlashBase=strchr(diffStartBase, '\\');
            if(nextSlashBase!=NULL)
            {
                pRight=nextSlashBase;
                nRight=strlen(nextSlashBase);
            }
        }
        else
        {
            assert(mergeLineStatus==eBaseFileAndDiffDir);
            nLeft=0;
            const char *lastSlashBase=strrchr(baseFile, '\\');
            assert(lastSlashBase!=NULL);
            pRight=lastSlashBase;
            nRight=strlen(lastSlashBase);
        }
        while(mergedList[0]!='\0')
        {
            int nBraces=0;
            int nMiddle=0;
            const char *pTemp=mergedList;
            while(TRUE)
            {
                const char *pTemp2=strchr(pTemp, ',');
                int nMore;
                if(pTemp2==NULL)
                {
                    nMore=strlen(pTemp);
                }
                else
                {
                    nMore=pTemp2-pTemp;
                }
                if(nMiddle != 0 && // Always allow at least one middle entry
                   nBaseSpace+nLeft+nRight+2+nMiddle+2+nMore > 75)
                {   // The first 2 is the hypothetical (or actual) nBraces
                    // if we end up with more than one item.  The second 2
                    // is the room for the last comma.
                    break;
                }
                else
                {
                    if(nMiddle != 0)
                    {   // more than one, so put in braces
                        nBraces=2;
                        // and room for the last comma
                        nMiddle+=2;
                    }
                    nMiddle+=nMore;
                    if(pTemp2==NULL)
                    {
                        break;
                    }
                    pTemp=pTemp2;
                    assert(pTemp[0]==',');
                    assert(pTemp[1]==' ');
                    pTemp += 2;
                }
            }
            char output[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(output, sizeof(output), baseSpace);
            DgnStrncat(output, sizeof(output), pLeft, nLeft);
            if(nBraces != 0)
            {
                DgnStrcat(output, sizeof(output), "{");
            }
            DgnStrncat(output, sizeof(output), mergedList, nMiddle);
            if(nBraces != 0)
            {
                DgnStrcat(output, sizeof(output), "}");
            }
            DgnStrncat(output, sizeof(output), pRight, nRight);
            saferFprintf(fpNewComm, "%s\n", output);
            mergedList += nMiddle;
            if(mergedList[0] != '\0')
            {
                assert(mergedList[0]==',');
                assert(mergedList[1]==' ');
                mergedList += 2;
            }
        }
    }
}

BOOL tlibModcomm(const char *commentFileName, const char *outputFileName)
{
    PrintWrapped0("Create a modified version of the specified "
                  "comment file...");
    FILE *fpNewComm;
    FILE *fpOldComm;
    if(!saferFopen(&fpOldComm, commentFileName, eFopenRead) ||
       !saferFopen(&fpNewComm, "tlmodcom.001", eFopenWrite))
    {
        return FALSE;
    }

    // We'll consider a file to be mergeable even if it's in the checked-in
    // src.lst (or the previous checked-in src.lst, in case we've checked in
    // src.lst during a ckinall.bat where modcomm happens later) and not the
    // local one.  That way, a list of "tlm remove"d files will be
    // mergeable.
    NameListHash srcLstHash(TRUE);
    saferRemove("tlmodcom.002", FALSE);
    saferRemove("tlmodcom.003", FALSE);
    int srcNumVersionsFound;
    if(!getNetworkVersionCount("src.lst", &srcNumVersionsFound) ||
       srcNumVersionsFound < 1 ||
       !tlibGet("src.lst", FALSE, "*", "tlmodcom.002") ||
       (srcNumVersionsFound > 1 &&
        !tlibGet("src.lst", FALSE, "*-1", "tlmodcom.003")) ||
       !processSrcLstIntoHash("src.lst", &srcLstHash, FALSE) ||
       !processSrcLstIntoHash("tlmodcom.002", &srcLstHash, TRUE) ||
       (srcNumVersionsFound > 1 &&
        !processSrcLstIntoHash("tlmodcom.003", &srcLstHash, TRUE)))
    {
        return FALSE;
    }

    MergeLineStatus mergeLineStatus=eNoBaseFile;
    char baseFile[TL_MAXSTRSIZE+1]="";
    char baseSpace[TL_MAXSTRSIZE+1]="";
    int baseDiffComponentStart = 0;
    char mergedList[TL_BIGMAXSTRSIZE]="";
    char buffer[TL_MAXSTRSIZE+1]="";
    char bufferSpace[TL_MAXSTRSIZE+1]="";
    while(fgets(buffer, TL_MAXSTRSIZE, fpOldComm))
    {
        trimFinalWhiteSpace(buffer);
        char *firstNonSpace=buffer;
        // We now allow identical whitespace prefixes before files, and will
        // output merged lines with that whitespace prefix.
        while(ISSPACE(firstNonSpace[0]))
        {
            firstNonSpace++;
        }
        DgnStrncpy(bufferSpace, sizeof(bufferSpace),
                   buffer, firstNonSpace-buffer);
        bufferSpace[firstNonSpace-buffer]='\0';
        if((srcLstHash.hashFind(firstNonSpace) == -1))
        {
            if(mergeLineStatus != eNoBaseFile)
            {
                flushMergedOutput(
                    fpNewComm, baseFile, baseSpace, mergedList,
                    mergeLineStatus,
                    baseDiffComponentStart);
                mergedList[0]='\0';
            }
            saferFprintf(fpNewComm, "%s\n", buffer);
            mergeLineStatus = eNoBaseFile;
        }
        else
        {
            if(mergeLineStatus == eNoBaseFile)
            {
                DgnStrcpy(baseFile, sizeof(baseFile), firstNonSpace);
                DgnStrcpy(baseSpace, sizeof(baseSpace), bufferSpace);
                mergeLineStatus = eJustBaseFile;
            }
            else
            {
                MergeLineStatus newMergeLineStatus=tryMergeLines(
                    baseFile, baseSpace, firstNonSpace, bufferSpace,
                    mergedList, sizeof(mergedList),
                    mergeLineStatus, &baseDiffComponentStart);
                if(newMergeLineStatus == eNoBaseFile)
                {
                    flushMergedOutput(
                        fpNewComm, baseFile, baseSpace, mergedList,
                        mergeLineStatus,
                        baseDiffComponentStart);
                    mergedList[0]='\0';
                    DgnStrcpy(baseFile, sizeof(baseFile), firstNonSpace);
                    DgnStrcpy(baseSpace, sizeof(baseSpace), bufferSpace);
                    mergeLineStatus = eJustBaseFile;
                }
                else
                {
                    assert(newMergeLineStatus != eJustBaseFile);
                    mergeLineStatus = newMergeLineStatus;
                }
            }
        }
    }
    if(mergeLineStatus != eNoBaseFile)
    {
        flushMergedOutput(
            fpNewComm, baseFile, baseSpace, mergedList,
            mergeLineStatus,
            baseDiffComponentStart);
        mergedList[0]='\0';
    }
    saferFclose(fpNewComm);
    saferFclose(fpOldComm);
    if(_stricmp("tlmodcom.001", outputFileName))
    {
        saferRemove(outputFileName, FALSE);
        saferMove("tlmodcom.001", outputFileName, FALSE);
    }
    saferRemove("tlmodcom.002", TRUE);
    saferRemove("tlmodcom.003", FALSE);
    PrintWrapped2("Successfully modified %s into %s.",
                  commentFileName, outputFileName);
    return TRUE;
}

BOOL tlibDiffall(const char *fileName, const char *snapver1,
                 const char *snapver2, DiffType diffType)
{
    PrintWrapped0("Examine differences for all specified files...");
    NameListHash srcLstHash(TRUE);
    BOOL bInProjectRoot;
    {
        char relSrcLst[TL_MAXSTRSIZE+1]="";
        getReverseRelPath(relSrcLst, sizeof(relSrcLst));
        bInProjectRoot = (relSrcLst[0] == '\0');
        if((snapver1 || snapver2) && !bInProjectRoot)
        {
            PrintWrapped0("Can only do a snapshot-based diffall from "
                          "the project root.");
            return FALSE;
        }
        DgnStrcat(relSrcLst, sizeof(relSrcLst), "src.lst");
        if(!processSrcLstIntoHash(relSrcLst, &srcLstHash, FALSE))
        {
            return FALSE;
        }
    }

    BOOL bOutputsToDiffallRes=(diffType == eDiffStandard ||
                               diffType == eDiffStandardIgnoringWhitespace ||
                               (diffType == eDiffCustom &&
                                !gbCustomDiffExecutableIsInteractive));
    if(bOutputsToDiffallRes)
    {
        saferRemove("diffall.res", FALSE);
    }
    saferRemove("tldiffal.000", FALSE);
    saferCopy(fileName, "tldiffal.000", FALSE); // In case the list changes
                                                // while we're diffing.
    saferRemove("tldiffal.001", FALSE);
    saferRemove("tldiffal.002", FALSE);
    if(snapver1)
    {
        tlibGet("snapshot.txt", FALSE, snapver1, "tldiffal.001");
    }
    if(snapver2)
    {
        tlibGet("snapshot.txt", FALSE, snapver2, "tldiffal.002");
    }

    char buffer[TL_MAXSTRSIZE+1]="";

    FILE *fpListFiles;
    if (!saferFopen(&fpListFiles, "tldiffal.000", eFopenRead))
    {
        return FALSE;
    }
    while(fgets(buffer, TL_MAXSTRSIZE, fpListFiles))
    {
        convertListLineToFileName(buffer);
        truncateAfterFirstSpaceOrTab(buffer);
        // if only spaces, then continue
        if(buffer[0]=='\0')
        {
            continue;
        }

        if((!snapver1 || !snapver2) && bInProjectRoot &&
           (srcLstHash.hashFind(buffer) == -1))
        {
            PrintWrapped1(
                "Warning: not diffing file %s, as it is not in src.lst.",
                buffer);
            if(bOutputsToDiffallRes)
            {
                saferSystem0(normal, "echo " DIFF_SEPARATOR " >> diffall.res");
                saferSystem1(normal,
                             "echo No difference generated for %s, as it is "
                             "not in src.lst. >> diffall.res", buffer);
                saferSystem0(normal, "echo. >> diffall.res");
            }
            continue;
        }
        
        char ver1[100];
        if(snapver1)
        {
            if(!getVerFromSnap(ver1, sizeof(ver1), buffer, "tldiffal.001"))
            {
                PrintWrapped2(
                    "Warning: not diffing file %s, as it is not in "
                    "snapshot.txt version %s.",
                    buffer, snapver1);
                if(bOutputsToDiffallRes)
                {
                    saferSystem0(normal,
                                 "echo " DIFF_SEPARATOR " >> diffall.res");
                    saferSystem2(normal,
                                 "echo No difference generated for %s, "
                                 "as it is not in snapshot.txt "
                                 "version %s. >> diffall.res",
                                 buffer, snapver1);
                    saferSystem0(normal, "echo. >> diffall.res");
                }
                continue;
            }
        }
        else
        {
            DgnStrcpy(ver1, sizeof(ver1), "*");
        }
        const char *ver2;
        char tempver2[100];
        if(snapver2)
        {
            if(!getVerFromSnap(tempver2, sizeof(tempver2),
                               buffer, "tldiffal.002"))
            {
                PrintWrapped2(
                    "Warning: not diffing file %s, as it is not in "
                    "snapshot.txt version %s.",
                    buffer, snapver2);
                if(bOutputsToDiffallRes)
                {
                    saferSystem0(normal,
                                 "echo " DIFF_SEPARATOR " >> diffall.res");
                    saferSystem2(normal,
                                 "echo No difference generated for %s, "
                                 "as it is not in snapshot.txt "
                                 "version %s. >> diffall.res",
                                 buffer, snapver2);
                    saferSystem0(normal, "echo. >> diffall.res");
                }
                continue;
            }
            ver2=tempver2;
        }
        else
        {
            if(!saferFindFile(buffer))
            {
                PrintWrapped1(
                    "Warning: not diffing file %s, as it is not "
                    "present locally.",
                    buffer);
                if(bOutputsToDiffallRes)
                {
                    saferSystem0(normal,
                                 "echo " DIFF_SEPARATOR " >> diffall.res");
                    saferSystem1(normal,
                                 "echo No difference generated for %s, as it "
                                 "is not present locally. >> diffall.res",
                                 buffer);
                    saferSystem0(normal, "echo. >> diffall.res");
                }
                continue;
            }
            ver2=NULL;
        }
        if(!ver2 || strcmp(ver1, ver2))
        {
            if(!tlibDiff(buffer, ver1, ver2, FALSE, diffType, FALSE, FALSE))
            {
                return FALSE;
            }
            if(bOutputsToDiffallRes)
            {
                saferSystem0(normal, "type diff.res >> diffall.res");
            }
        }
    }
    saferFclose(fpListFiles);
    PrintWrapped0("\n");
    if(bOutputsToDiffallRes)
    {
        PrintWrapped0("All Differences are stored in the file "
                      "diffall.res\n\n");
    }
    saferRemove("tldiffal.000", FALSE);
    saferRemove("tldiffal.001", FALSE);
    saferRemove("tldiffal.002", FALSE);
    return TRUE;
}

BOOL createUpdthelp()
{
    FILE *fpUpdthelp;
    if (!saferFopen(&fpUpdthelp, "updthelp.bat", eFopenWrite))
    {
        return FALSE;
    }
    saferFprintf(fpUpdthelp, "call updtstrc 1\n");
    saferFclose(fpUpdthelp);
    return TRUE;
}

BOOL createRootdir(const char *rootDir, NewLineTypeEnum newLineType)
{
    // Make rootdir.mak to tell where the root dir really is.
    FILE *fpRootdir;
    if (!saferFopen(&fpRootdir, "rootdir.mak", eFopenWriteBinary))
    {
        return FALSE;
    }
    const char *newLineStr=NULL;
    switch(newLineType)
    {
     case E_CRLF: newLineStr="\r\n"; break;
     case E_LF: newLineStr="\n"; break;
     case E_CR: newLineStr="\r"; break;
     default: assert(!"bad newLineType"); break;
    }

    saferFprintf(fpRootdir,
                 "# this file tells where to find the root directory for%s",
                 newLineStr);
    saferFprintf(fpRootdir, "# your project.  Personalize it!%s", newLineStr);
    saferFprintf(fpRootdir, "ifndef ROOT_DIR%s", newLineStr);
    saferFprintf(fpRootdir, "ROOT_DIR = %s$(SLASH)%s", rootDir, newLineStr);
    saferFprintf(fpRootdir, "endif%s", newLineStr);
    saferFclose(fpRootdir);
    return TRUE;
}

BOOL tlibUnsnap(const char *fileName,
                BOOL bIncremental, BOOL bNewer, BOOL bCheckLibraries,
                BOOL bVerbose)
{
    PrintWrapped0("Unsnapshot a project...");
    return tlibUpdateProject(TRUE, bVerbose,
                             FALSE, !bIncremental, bNewer, bCheckLibraries,
                             fileName, NULL);
}

BOOL tlibUnsnapv(const char *snapshotTxtName, const char *revNum,
                 BOOL bIncremental, BOOL bNewer, BOOL bCheckLibraries,
                 BOOL bVerbose)
{
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    saferRemove("tlunsnap.000", FALSE);
    if(!tlibGet(snapshotTxtName, FALSE, revNum, "tlunsnap.000") ||
       !tlibUnsnap("tlunsnap.000", bIncremental, bNewer, bCheckLibraries,
                   bVerbose))
    {
        PrintWrapped2("Couldn't unsnap version %s of %s", revNum,
                      snapshotTxtName);
        return FALSE;
    }
    else
    {
        saferRemove("tlunsnap.000", FALSE);
        saferChdir(currDir);
        return TRUE;
    }
}

BOOL saferCheckDirectoryEmpty(const char *dir)
{
    char pattern[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(pattern, sizeof(pattern), dir);
    DgnStrcat(pattern, sizeof(pattern), "\\*.*");

    WIN32_FIND_DATA finddata;
    HANDLE hFindFile;

    for (BOOL bFound = MyFindFirstFile(&hFindFile, pattern, &finddata);
         bFound;
         bFound = MyFindNextFile(hFindFile, &finddata))
    {
        if(!(finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
           (strcmp(finddata.cFileName, ".") &&
            strcmp(finddata.cFileName, "..")))
        {
            return FALSE;
        }
    }
    return TRUE;
}

BOOL readTlibConfiguration()
{
    static const char cfgname[] = "tlibproj.cfg";

    // path must be of the form %!!NETDIR%*\tlib or
    // %!!NETDIR%*\tlib/%!!NETDIR%*\tlok
    char path[TL_MAXSTRSIZE+1]="";
    if(!readConfigOption(gWorkDirectory, cfgname, "path ",
                         path, sizeof(path),
                         TRUE, FALSE, FALSE))
    {
        PrintWrapped2("Error: %s has no '%s' specification",
                      cfgname, "path ");
        return FALSE;
    }
    
    const char prefix1[] = "%!!NETDIR%*\\";
    const char prefix2[] = "%!!NETDIR%\\";
    char pathPrefix[TL_MAXSTRSIZE];
    DgnStrcpy(pathPrefix, sizeof(pathPrefix), (const char *)prefix1);
    if(strncmp(path, prefix1, strlen(prefix1)) != 0)
    {
        DgnStrcpy(pathPrefix, sizeof(pathPrefix), (const char *)prefix2);
        if(strncmp(path, prefix2, strlen(prefix2)) != 0)
        {
            PrintWrapped2("Error: 'path %s' in %s not valid for TLM",
                          path, cfgname);
            return FALSE;
        }
    }
    // look for forward slash
    char *pchForwardSlash = strchr(path, '/');
    if(pchForwardSlash != NULL)
    {
        // replace slash by nul
        *pchForwardSlash = '\0';
    }
    DgnStrcpy(gLibDir, sizeof(gLibDir), path + strlen(pathPrefix));
    if(pchForwardSlash == NULL)
    {
        // No slash, lib and lok directories same
        DgnStrcpy(gLokDir, sizeof(gLokDir), gLibDir);
    }
    else
    {
        if (strncmp(pchForwardSlash+1, pathPrefix, strlen(pathPrefix)) != 0)
        {
            PrintWrapped3("Error: 'path %s/%s' in %s not valid for TLM",
                          path, pchForwardSlash+1, cfgname);
            return FALSE;
        }
        DgnStrcpy(gLokDir, sizeof(gLokDir),
               pchForwardSlash + 1 + strlen(pathPrefix));
    }

    if(!stringIsLower(gLibDir) || !stringIsLower(gLokDir))
    {
        PrintWrapped1("Error: 'path' configuration in %s not valid for TLM "
                      "(library and lock directories must be all lower-case.)",
                      cfgname);
        return FALSE;
    }
    
    gbLibDirIsLokDir=!strcmp(gLibDir, gLokDir);

    // postpend '\\' to get Slashed versions.
    DgnStrcpy(gLibDirSlash, sizeof(gLibDirSlash), gLibDir);
    DgnStrcat(gLibDirSlash, sizeof(gLibDirSlash), "\\");
    DgnStrcpy(gLokDirSlash, sizeof(gLokDirSlash), gLokDir);
    DgnStrcat(gLokDirSlash, sizeof(gLokDirSlash), "\\");

    {
        char longnames[TL_MAXSTRSIZE+1]="";
        if(!readConfigOption(gWorkDirectory, cfgname, "longnames ",
                             longnames, sizeof(longnames),
                             TRUE, FALSE, FALSE))
        {
            PrintWrapped1("Warning: %s has no 'longnames' specification; "
                          "assuming 'longnames n'.",
                          cfgname);
            gbAllowLongNames=FALSE;
        }
        else
        {
            if(!_stricmp(longnames, "y"))
            {
                gbAllowLongNames=TRUE;
            }
            else if(!_stricmp(longnames, "n"))
            {
                gbAllowLongNames=FALSE;
            }
            else
            {
                PrintWrapped2(
                    "Error: 'longnames %s' in %s is not "
                    "valid for TLM (must be y or n)",
                    longnames, cfgname);
                return FALSE;
            }
        }
    }

    {
        char fnamecase[TL_MAXSTRSIZE+1]="";
        if(!readConfigOption(gWorkDirectory, cfgname, "fnamecase ",
                             fnamecase, sizeof(fnamecase),
                             TRUE, FALSE, FALSE))
        {
            PrintWrapped1("Warning: %s has no 'fnamecase' specification; "
                          "assuming 'fnamecase lower'.",
                          cfgname);
            gbAllowMixedCaseNames=FALSE;
        }
        else
        {
            if(!_stricmp(fnamecase, "auto"))
            {
                gbAllowMixedCaseNames=TRUE;
            }
            else if(!_stricmp(fnamecase, "lower"))
            {
                gbAllowMixedCaseNames=FALSE;
            }
            else
            {
                PrintWrapped2(
                    "Error: 'fnamecase %s' in %s is not "
                    "valid for TLM (must be auto or lower)",
                    fnamecase, cfgname);
                return FALSE;
            }
        }
    }

    // read lib and lok extensions
    if(!readConfigOption(gWorkDirectory, cfgname, "libext ",
                         gLibExt, sizeof(gLibExt),
                         TRUE, FALSE, FALSE))
    {
        PrintWrapped2("Error: %s has no '%s' specification",
                      cfgname, "libext ");
        return FALSE;
    }

    if(!readConfigOption(gWorkDirectory, cfgname, "lokext ",
                         gLokExt, sizeof(gLokExt),
                         TRUE, FALSE, FALSE))
    {
        PrintWrapped2("Error: %s has no '%s' specification",
                      cfgname, "lokext ");
        return FALSE;
    }
    
    if(strlen(gLibExt) != strlen(gLokExt))
    {
        PrintWrapped3(
            "Error: 'libext %s' and 'lokext %s' in %s are not "
            "valid for TLM (must have the same number of characters)",
            gLibExt, gLokExt, cfgname);
        return FALSE;
    }
    gMaxExtLen=strlen(gLibExt);

    gbMangleExtensions=FALSE;
    for(int i=0; i<gMaxExtLen; i++)
    {
        if(gLibExt[i]!='?' || gLokExt[i]!='?')
        {
            gbMangleExtensions=TRUE;
            break;
        }
    }

    if(!gbMangleExtensions && gbLibDirIsLokDir)
    {
        PrintWrapped3(
            "Error: 'libext %s' and 'lokext %s' in %s are not "
            "valid for TLM (cannot have all question marks given that "
            "your lib and lock directories set by 'path' are the same.)",
            gLibExt, gLokExt, cfgname);
    }

    if(gMaxExtLen != 3)
    {
        // For long extensions, we'll make some more onerous restrictions,
        // since we can and they'll reduce the likelihood of confusion.
        if(gbLibDirIsLokDir)
        {
            PrintWrapped3(
                "Error: 'libext %s' and 'lokext %s' in %s are not "
                "valid for TLM (since they're longer than three "
                "characters, we require by fiat that your "
                "lib and lock directories set by 'path' be different.)",
                gLibExt, gLokExt, cfgname);
        }
        if(gbMangleExtensions)
        {
            PrintWrapped3(
                "Error: 'libext %s' and 'lokext %s' in %s are not "
                "valid for TLM (must have all question marks if "
                "longer than three characters)",
                gLibExt, gLokExt, cfgname);
        }
    }

    if(!readConfigOption(gWorkDirectory, cfgname, "extension ",
                         gGoodExtensions, sizeof(gGoodExtensions),
                         TRUE, FALSE, TRUE))
    {
        PrintWrapped2("Error: %s has no '%s' specification",
                      cfgname, "extension ");
        return FALSE;
    }

    // If we're mangling extensions and any extension has an '_', we're
    // hosed.
    if(gbMangleExtensions && strchr(gGoodExtensions, '_') != 0)
    {
        PrintWrapped1(
            "Error: The list of extensions in %s contains "
            "an extension with an '_'.  "
            "This is not supported by TLM.", cfgname);
        return FALSE;
    }

    return TRUE;
}

#define TLM_TLIBBS_PATH_RECOMMENDATION \
"Your TLM_TLIBBS_PATH environment variable " \
"should be the full path to your local version " \
"of TLIB (version %s or greater).  " \
"E.g., for a local installation in " TLIB_EXAMPLE_DIR ", " \
"the suggested configuration is to " \
"'set TLM_TLIBBS_PATH=" TLIB_EXAMPLE_DIR "\\tlib32c.exe'."

void verifyTlibVersionGoodEnough(const char *whoFor)
{
    if(gTlibCurVerMajor < gTlibMinVerMajor ||
       (gTlibCurVerMajor == gTlibMinVerMajor &&
        gTlibCurVerMinor < gTlibMinVerMinor) ||
       (gTlibCurVerMajor == gTlibMinVerMajor &&
        gTlibCurVerMinor == gTlibMinVerMinor &&
        gTlibCurVerCharacter < gTlibMinVerCharacter))
    {
        PrintWrapped4("Your local version of TLIB (%s) identifies itself "
                      "as version '%s', which is too old for %s.  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      gTlibbsPath, gTlibCurVerStr, whoFor, gTlibMinVerStr);
        pauseAndExit();
    }
}

void parseTlibVersion(const char *verStr, int *pMajor,
                      int *pMinor, char *pCharacter,
                      const char *cameFrom1,
                      const char *cameFrom2)
{
    if(DgnSscanf(verStr, "%d.%d%c", pMajor, pMinor,
                 DgnSscanfSizedArgument(pCharacter, 1)) != 3)
    {
        PrintWrapped4("Couldn't parse TLIB version '%s' "
                      "from %s (%s).  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      verStr, cameFrom1, cameFrom2,
                      gTlibMinVerStr);
        pauseAndExit();
    }
}

void saferGetenv(char *pEnvVarValue, int lEnvVarValue, const char *pEnvVarName)
{
    size_t desiredSize;
    int ret = DgnGetenv(&desiredSize, pEnvVarValue, lEnvVarValue, pEnvVarName);
    if(ret != 0)
    {
        PrintWrapped1("getenv(%s) call failed.", pEnvVarName);
        pauseAndExit();
    }
}

void saferPutenv(const char *pEnvVarName, const char *pEnvVarValue)
{
    // Work around an apparent bug in MSDev 7.1 where setting it empty when
    // it's already empty sometimes causes heap corruption.
    BOOL bSettingEmpty=(pEnvVarValue[0] == '\0');
    char currVal[TL_MAXSTRSIZE+1]="";
    saferGetenv(currVal, sizeof(currVal), pEnvVarName);    
    if(!(currVal[0] == '\0' && bSettingEmpty))
    {
        int ret=_putenv_s(pEnvVarName, pEnvVarValue);
        if(ret != 0)
        {
            PrintWrapped2("_putenv_s(%s, %s) call failed.",
                          pEnvVarName, pEnvVarValue);
            pauseAndExit();
        }
    }
}

void readLocalConfig(BOOL bVerifyTlmprojForCheckin)
{
    if(!saferFindFile("tlib.cfg"))
    {
        PrintWrapped0("Error: couldn't find a tlib.cfg file "
                      "in this directory.");
        pauseAndExit();
    }

    {
        char relPathToProjectRoot[TL_MAXSTRSIZE+1]="";

        {
            if(!readConfigOption("", "tlib.cfg", "include ",
                                 relPathToProjectRoot,
                                 sizeof(relPathToProjectRoot),
                                 TRUE, FALSE, FALSE))
            {
                PrintWrapped0("Error: couldn't find a valid 'include' line in "
                              "the tlib.cfg file in this directory.");
                pauseAndExit();
            }
            char *lastSlash=strrchr(relPathToProjectRoot, '\\');
            if(lastSlash != NULL)
            {
                gbExecutedFromRoot = FALSE;
                lastSlash[1] = '\0';
            }
            else
            {
                gbExecutedFromRoot = TRUE;
                relPathToProjectRoot[0] = '\0';
            }
        }

        {
            if(!readConfigOption(relPathToProjectRoot,
                                 "tlibuser.cfg", "SET NETDIR=",
                                 gNetworkDirectory, sizeof(gNetworkDirectory),
                                 TRUE, FALSE, FALSE))
            {
                PrintWrapped0("Error: couldn't find a valid 'SET NETDIR=' "
                              "line in your tlibuser.cfg.");
                pauseAndExit();
            }
            lowerCaseAndTrimFinalWhiteSpace(gNetworkDirectory);
            if(strlen(gNetworkDirectory) > gMaxNetDirLen)
            {
                char maxLen[10];
                DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxNetDirLen);
                PrintWrapped2("Error: your tlibuser.cfg's 'SET NETDIR=' "
                              "value '%s' has more than %s characters.",
                              gNetworkDirectory, maxLen);
                pauseAndExit();
            }

            if(!readConfigOption(relPathToProjectRoot,
                                 "tlibuser.cfg", "workdir ",
                                 gWorkDirectory, sizeof(gWorkDirectory),
                                 TRUE, FALSE, FALSE))
            {
                PrintWrapped0("Error: couldn't find a valid 'workdir ' "
                              "line in your tlibuser.cfg.");
                pauseAndExit();
            }
            lowerCaseAndTrimFinalWhiteSpace(gWorkDirectory);
            if(strlen(gWorkDirectory) > gMaxWorkDirLen)
            {
                char maxLen[10];
                DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxWorkDirLen);
                PrintWrapped2("Error: your tlibuser.cfg's 'workdir' "
                              "value '%s' has more than %s characters.",
                              gWorkDirectory, maxLen);
                pauseAndExit();
            }
            if(!pathIsNonRootNonUNC(gWorkDirectory))
            {
                PrintWrapped1("Error: your tlibuser.cfg's 'workdir' "
                              "value '%s' is not an absolute "
                              "path, is a UNC, or is a root directory.",
                              gWorkDirectory);
                pauseAndExit();
            }
            char workDirectoryNoSlash[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(workDirectoryNoSlash, sizeof(workDirectoryNoSlash),
                      gWorkDirectory);
            {
                int xlen=strlen(workDirectoryNoSlash);
                if(xlen==0 || workDirectoryNoSlash[xlen-1] != '\\')
                {
                    PrintWrapped1("Error: your tlibuser.cfg's 'workdir' "
                                  "value '%s' doesn't end in a backslash.",
                                  gWorkDirectory);
                    pauseAndExit();
                }
                workDirectoryNoSlash[xlen-1]='\0';
            }
            
            {
                char currDir[TL_MAXSTRSIZE+1]="";
                saferGetcwd(currDir, sizeof(currDir));
                if(!isPrefix(workDirectoryNoSlash, currDir))
                {
                    PrintWrapped2("Error: your tlibuser.cfg's 'workdir' "
                                  "value '%s' is not a parent of "
                                  "the current working directory '%s'.",
                                  gWorkDirectory, currDir);
                    pauseAndExit();
                }
                char relWorkFromCwd[TL_MAXSTRSIZE+1]="";
                getReverseRelPath(relWorkFromCwd, sizeof(relWorkFromCwd));
                if(strcmp(relWorkFromCwd, relPathToProjectRoot))
                {
                    PrintWrapped1("Error: your tlibuser.cfg's 'workdir' "
                                  "value '%s' does not accurately reflect "
                                  "where it is.",
                                  gWorkDirectory);
                    pauseAndExit();
                }
            }

            char newLineType[TL_MAXSTRSIZE+1]="";
            if(readConfigOption(relPathToProjectRoot,
                                "tlibuser.cfg", "newline ",
                                newLineType, sizeof(newLineType),
                                TRUE, TRUE, FALSE))
            {
                trimFinalWhiteSpace(newLineType);
                if(!_stricmp(newLineType, "cr"))
                {
                    gNewLineType = E_CR;
                }
                else if(!_stricmp(newLineType, "lf"))
                {
                    gNewLineType = E_LF;
                }
                else if(!_stricmp(newLineType, "crlf"))
                {
                    gNewLineType = E_CRLF;
                }
                else
                {
                    PrintWrapped1("Error: your tlibuser.cfg's 'newline' "
                                  "value '%s' is not cr, lf, or crlf.",
                                  newLineType);
                    pauseAndExit();
                }
            }
        }
    }

    {
        char overrideUserName[TL_MAXSTRSIZE+1]="";
        if(readConfigOption(gWorkDirectory,
                            "tlmuser.cfg", "OVERRIDE_TLIBID=",
                            overrideUserName, sizeof(overrideUserName),
                            TRUE, FALSE, FALSE))
        {
            saferPutenv("TLIBID", overrideUserName);
            DgnStrcpy(gUserName, sizeof(gUserName), overrideUserName);
        }
    }

    gbAlwaysVerbose=configOptionExistsAndIsOne("tlmuser.cfg",
                                               "ALWAYS_VERBOSE=", TRUE);
    gbUsingDave=configOptionExistsAndIsOne("tlmuser.cfg",
                                           "USING_DAVE=", TRUE);
    gbPreventChanges=configOptionExistsAndIsOne("tlmuser.cfg",
                                                "PREVENT_CHANGES=", TRUE);
    gbCustomDiffExecutableIsInteractive=configOptionExistsAndIsOne(
        "tlmuser.cfg", "CUSTOM_DIFF_EXECUTABLE_IS_INTERACTIVE=", TRUE);
    if(!readConfigOption(gWorkDirectory,
                         "tlmuser.cfg", "CUSTOM_DIFF_EXECUTABLE=",
                         gCustomDiffExecutablePath,
                         sizeof(gCustomDiffExecutablePath),
                         TRUE, FALSE, FALSE))
    {
        gCustomDiffExecutablePath[0] = '\0';
    }
    
    if(!readConfigOption(gWorkDirectory, "tlmuser.cfg",
                         "XCHECK_EXTRA_EXTENSIONS=",
                         gExtraTrackedExtensions,
                         sizeof(gExtraTrackedExtensions),
                         TRUE, FALSE, FALSE))
    {
        gExtraTrackedExtensions[0] = '\0';
    }

    {
        char minimumVersionNumber[TL_MAXSTRSIZE+1]="";
        int minVer=0;
        if(readConfigOption(gWorkDirectory,
                            "tlmproj.cfg", "TLM_MINIMUM_VERSION=",
                            minimumVersionNumber, sizeof(minimumVersionNumber),
                            TRUE, FALSE, FALSE))
        {
            minVer = atoi(minimumVersionNumber);
        }
        
        if(atoi(gTlmVersionNumber) < minVer)
        {
            PrintWrapped2("This version of TLM (%s) is not adequate for this "
                          "project.  The minimum version is %s.",
                          gTlmVersionNumber, minimumVersionNumber);
            pauseAndExit();
        }

        // Bump this to the current version if checkin semantics change in
        // such a way that you want to ensure that the first "new-style"
        // checkin will guarantee that there are no more checkins made with
        // an "old-style" TLM.  This was first done when (with version 176)
        // the snapshot.txt semantics were changed to predict snapshot.txt's
        // post-checkin version rather than using its pre-checkin version,
        // since otherwise, the semantics would change back-and-forth from
        // checkin to checkin.  This was next done when (with version 189)
        // using tlib32c.exe of at least version 5.51b started being
        // required, in order to exploit its longer path length limits. This
        // was next done when (with version 228) using tlib32c.exe of at
        // least version 5.53f started being required, in order to use its
        // tlmerge.exe, and also because (with version 228) a new
        // configuration variable, NO_CHECKIN_TOPDIRS, started needing to be
        // respected.
        const char *checkinMinTlibprojTlmMinVerStr="228";
        int checkinMinTlibprojTlmMinVer=atoi(checkinMinTlibprojTlmMinVerStr);

        if(bVerifyTlmprojForCheckin &&
           minVer < checkinMinTlibprojTlmMinVer)
        {
            PrintWrapped3("This version of " TLM_NAME " (%s) "
                          "has new semantics that are different "
                          "from those in " TLM_NAME " versions earlier "
                          "than %s.  For project consistency, it's required "
                          "that the first checkin using this version "
                          "of " TLM_NAME " enforce the new semantics "
                          "by requiring subsequent checkins to use them as "
                          "well.  This means that you must modify the "
                          "TLM_MINIMUM_VERSION= line in your project's "
                          "tlmproj.cfg to have a value of at least %s, and "
                          "check in the new tlmproj.cfg during your first "
                          "checkin using this version of " TLM_NAME ".",
                          gTlmVersionNumber, checkinMinTlibprojTlmMinVerStr,
                          checkinMinTlibprojTlmMinVerStr);
            pauseAndExit();
        }

        if(bVerifyTlmprojForCheckin)
        {
            if(configOptionExistsAndIsOne("tlmproj.cfg",
                                          "MAINTAIN_PROJVER=",
                                          TRUE))
            {
                PrintWrapped1("This version of " TLM_NAME " (%s) "
                              "no longer supports MAINTAIN_PROJVER=1.  "
                              "For project consistency, it's required "
                              "that the first checkin using this version "
                              "of " TLM_NAME " enforce the new semantics "
                              "by requiring subsequent checkins to use them "
                              "as well.  This means that you must modify the "
                              "MAINTAIN_PROJVER=1 line in your project's "
                              "tlmproj.cfg by changing it to "
                              "MAINTAIN_PROJVER=0 or removing it, and "
                              "check in the new tlmproj.cfg during your first "
                              "checkin using this version of " TLM_NAME ".",
                              gTlmVersionNumber);
            }

            if(configOptionExistsAndIsOne(
                "tlmproj.cfg",
                "USE_ENG_STYLE_PROJECT_VERSIONING=",
                TRUE))
            {
                PrintWrapped1("This version of " TLM_NAME " (%s) "
                              "no longer supports "
                              "USE_ENG_STYLE_PROJECT_VERSIONING=1.  "
                              "For project consistency, it's required "
                              "that the first checkin using this version "
                              "of " TLM_NAME " enforce the new semantics "
                              "by requiring subsequent checkins to use them "
                              "as well.  This means that you must modify the "
                              "USE_ENG_STYLE_PROJECT_VERSIONING=1 line "
                              "in your project's "
                              "tlmproj.cfg by changing it to "
                              "MAINTAIN_ENG_STYLE_PROJECT_VERSION=1, and "
                              "check in the new tlmproj.cfg during your first "
                              "checkin using this version of " TLM_NAME ".",
                              gTlmVersionNumber);
            }

            if(configOptionExistsAndIsOne(
                "tlmproj.cfg",
                "USE_ENG_STYLE_PROJECT_VERSIONING_AND_SPECIAL_SUBDIRS=",
                TRUE))
            {
                PrintWrapped1(
                    "This version of " TLM_NAME " (%s) "
                    "no longer supports "
                    "USE_ENG_STYLE_PROJECT_VERSIONING_AND_SPECIAL_SUBDIRS=1.  "
                    "For project consistency, it's required "
                    "that the first checkin using this version "
                    "of " TLM_NAME " enforce the new semantics "
                    "by requiring subsequent checkins to use them "
                    "as well.  This means that you must modify the "
                    "USE_ENG_STYLE_PROJECT_VERSIONING_AND_SPECIAL_SUBDIRS=1 "
                    "line in your project's "
                    "tlmproj.cfg by changing it to "
                    "MAINTAIN_ENG_STYLE_PROJECT_VERSION=1, and "
                    "check in the new tlmproj.cfg during your first "
                    "checkin using this version of " TLM_NAME ".",
                    gTlmVersionNumber);
            }
        }
    }

    char minimumVersionNumber[TL_MAXSTRSIZE+1]="";
    if(readConfigOption(gWorkDirectory,
                        "tlmproj.cfg", "TLIB_MINIMUM_VERSION=",
                        minimumVersionNumber, sizeof(minimumVersionNumber),
                        TRUE, FALSE, FALSE))
    {
        DgnStrcpy(gTlibMinVerStr, sizeof(gTlibMinVerStr),
                  minimumVersionNumber);
        parseTlibVersion(gTlibMinVerStr, &gTlibMinVerMajor,
                         &gTlibMinVerMinor, &gTlibMinVerCharacter,
                         "your project's TLIB_MINIMUM_VERSION",
                         "in tlibproj.cfg");
        verifyTlibVersionGoodEnough(
            "your project, according to its TLIB_MINIMUM_VERSION setting");
    }

    readConfigOption(gWorkDirectory,
                     "tlmproj.cfg", "NO_CHECKIN_TOPDIRS=",
                     gNoCheckinTopDirs, sizeof(gNoCheckinTopDirs),
                     TRUE, TRUE, FALSE);

    if(!readTlibConfiguration())
    {
        PrintWrapped0("An error occurred reading tlibproj.cfg.");
        pauseAndExit();
    }
}

BOOL checkNetAndLocalDirsForInstallOrCloneproj(const char *netDir,
                                               const char *localDir)
{
    if(!pathIsAbsolute(netDir))
    {
        PrintWrapped1("The specified network directory %s is not an absolute "
                      "path.  Please only install from an absolute path.",
                      netDir);
        return FALSE;
    }
    if(netDir[strlen(netDir)-1] == '\\')
    {
        PrintWrapped1("The specified network directory %s ends in a "
                      "backslash.",
                      netDir);
        return FALSE;
    }
    if(strlen(netDir)+1 > gMaxNetDirLen)
    {   // 1 extra for the backslash-to-come.  This makes the message we
        // print slightly off, but making it accurate would just make things
        // more confusing.
        char maxLen[10];
        DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxNetDirLen);
        PrintWrapped2("The specified network directory %s has more "
                      "than %s characters.",
                      netDir, maxLen);
        return FALSE;
    }
    if(!pathIsNonRootNonUNC(localDir))
    {
        PrintWrapped1("The specified local directory %s is not an absolute "
                      "path, is a UNC, or is a root directory.  Please only "
                      "install into an absolute, non-UNC, non-root path.",
                      localDir);
        return FALSE;
    }
    if(localDir[strlen(localDir)-1] == '\\')
    {
        PrintWrapped1("The specified local directory %s ends in a backslash.",
                      localDir);
        return FALSE;
    }
    if(strlen(localDir)+1 > gMaxWorkDirLen)
    {   // 1 extra for the backslash-to-come.  This makes the message we
        // print slightly off, but making it accurate would just make things
        // more confusing.
        char maxLen[10];
        DgnSprintf(maxLen, sizeof(maxLen), "%d", gMaxWorkDirLen);
        PrintWrapped2("The specified local directory %s has more "
                      "than %s characters.",
                      localDir, maxLen);
        return FALSE;
    }
    return TRUE;
}

void rewriteTlmuserWithEmptyUpdateTopdirs(
    FILE *fpInTlmuser, FILE *fpOutTlmuser)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    while(fgets(buffer, TL_MAXSTRSIZE, fpInTlmuser))
    {
        if(isPrefix("UPDATE_TOPDIRS=", buffer))
        {
            saferFprintf(fpOutTlmuser, "UPDATE_TOPDIRS=\n");
        }
        else
        {
            saferFputs(buffer, fpOutTlmuser);
        }
    }
}

typedef enum InstallSubsetType
{
    eInstallPrompt,
    eInstallFull,
    eInstallNoTopdirs
} InstallSubsetType;

BOOL tlibInstall(const char *snapshotTxtName, const char *snapVer,
                 const char *netDir, const char *localDir,
                 const char *rootDir, NewLineTypeEnum newLineType,
                 InstallSubsetType installSubsetType)
{
    if(!checkNetAndLocalDirsForInstallOrCloneproj(netDir, localDir))
    {
        return FALSE;
    }
    if(!saferCheckReadWriteAccess(netDir))
    {
        return FALSE;
    }

    saferEnsureDirectoryTreePlusSlashExists(localDir);

    if(!saferCheckDirectoryEmpty(localDir))
    {
        PrintWrapped1("The directory %s is not empty.  Please "
                      "install only into an empty or "
                      "non-existent directory.", localDir);
        return FALSE;
    }

    saferChdir(localDir);

    // We do the following to avoid the necessity of doing a "tlm get" on a
    // .cfg file that TLIB has to read in the same session, because some
    // local drives (in particular, when the "local" drive is exported from
    // a Mac with DAVE) won't allow such a quick overwrite of the
    // recently-read file (at least in the way TLIB is doing it), claiming
    // that it can't overwrite a read/write file (checking right afterwards,
    // you see the file as actually being read-only.)

    {
        saferSystem0(normal, "echo include tlinst.001 > tlinst.000");
        saferSystem0(normal, "echo include tlinst.002 >> tlinst.000");

        if(!createTlibuser("tlinst.001", netDir, localDir, E_CRLF, !gbWinNT))
        {
            return FALSE;
        }
        char buffer[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(buffer, sizeof(buffer), netDir);
        DgnStrcat(buffer, sizeof(buffer), "\\tlibproj.cfg");
        saferCopy(buffer, "tlinst.002", FALSE);

        saferPutenv("TLIBCFG", "!tlinst.000");

        if(!tlibGet("tlib.cfg", FALSE, "*", NULL) ||
           !tlibGet("tlibproj.cfg", FALSE, "*", NULL) ||
           !tlibGet("tlibuser.cfg", FALSE, "*", NULL) ||
           !tlibGet("tlmproj.cfg", FALSE, "*", NULL) ||
           !tlibGet("tlmuser.cfg", FALSE, "*", NULL))
        {
            return FALSE;
        }

        saferRemove("tlibuser.cfg", TRUE);
        if(!createTlibuser("tlibuser.cfg", netDir, localDir, newLineType,
                           !gbWinNT))
        {
            return FALSE;
        }
        
        saferRemove("tlinst.000", TRUE);
        saferRemove("tlinst.001", TRUE);
        saferRemove("tlinst.002", TRUE);

        saferPutenv("TLIBCFG", "");
    }

    if(configUseUpdtstrc() && !createUpdthelp())
    {
        return FALSE;
    }

    readLocalConfig(FALSE);

    BOOL bUserDecided=FALSE;
    while(!bUserDecided)
    {
        if(installSubsetType==eInstallFull)
        {
            bUserDecided=TRUE;
        }
        else if(installSubsetType==eInstallNoTopdirs)
        {
            // Modify tlmuser.cfg.
            FILE *fpOutTlmuser;
            FILE *fpInTlmuser;
            if(!saferFopen(&fpOutTlmuser, "tlinst.003", eFopenWrite) ||
               !saferFopen(&fpInTlmuser, "tlmuser.cfg", eFopenRead))
            {
                return FALSE;
            }

            rewriteTlmuserWithEmptyUpdateTopdirs(
                fpInTlmuser, fpOutTlmuser);
            saferFclose(fpOutTlmuser);
            saferFclose(fpInTlmuser);
            saferRemove("tlmuser.cfg", TRUE);
            saferCopy("tlinst.003", "tlmuser.cfg", TRUE);
            saferRemove("tlinst.003", TRUE);

            bUserDecided=TRUE;
        }
        else if(installSubsetType==eInstallPrompt)
        {
            if(pauseForYesOrNo(
                "\nDo you want to install the _entire_ project?"))
            {
                bUserDecided=TRUE;
                PrintWrapped0("\n");
                PrintWrapped0("You may still want to "
                              "attrib -r and modify your tlmuser.cfg to have "
                              "an OVERRIDE_TLIBID= line to your tlmuser.cfg "
                              "if you want this installation to use "
                              "a special TLIBID.  Once you've made any "
                              "desired modifications to tlmuser.cfg, "
                              "hit any key to continue.");
                pauseForKey(FALSE);
            }
            else
            {
                PrintWrapped0("\n");
                PrintWrapped0("In that case, please open up another window "
                              "and attrib -r and modify your tlmuser.cfg to "
                              "have the desired settings for what top-level "
                              "directories and special subdirectories to "
                              "install.  You may also want to add an "
                              "OVERRIDE_TLIBID= line to your tlmuser.cfg "
                              "if you want this installation to use "
                              "a special TLIBID.  Once you've made all "
                              "desired modifications to tlmuser.cfg, hit any "
                              "key to continue.");
                pauseForKey(FALSE);
                if(fileExistsAndIsWritable("tlmuser.cfg"))
                {
                    bUserDecided=TRUE;
                }
                else
                {
                    PrintWrapped0("\n");
                    PrintWrapped0("I just checked up on your story, "
                                  "and it doesn't appear that you've even "
                                  "marked tlmuser.cfg writable, which means "
                                  "you're definitely on the road to "
                                  "installing the entire project.  I'm "
                                  "afraid I'm going to have to ask you "
                                  "again....");
                }
            }
        }
    }
    
    readLocalConfig(FALSE);

    if(snapVer==NULL)
    {
        if(!tlibUpdateProject(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE,
                              NULL, NULL))
        {
            return FALSE;
        }
    }
    else
    {
        if(!tlibUnsnapv(snapshotTxtName, snapVer,
                        TRUE, FALSE, FALSE, FALSE))
        {
            return FALSE;
        }
    }

    if(configUseRootdirMak())
    {
        saferMarkReadWrite("rootdir.mak");
        if(!createRootdir(rootDir, newLineType))
        {
            return FALSE;
        }
    }

    // show an xcheck for good measure
    PrintWrapped0("\n");
    PrintWrapped0("Performing an xcheck for the new installation...");
    if(!tlibXcheck(TRUE, FALSE, FALSE, NULL, "xcheck.001", TRUE))
    {
        return FALSE;
    }
    saferSort(TRUE, TRUE, FALSE, 0, 0, TRUE, "xcheck.001", "xcheck.res");
    saferRemove("xcheck.001", TRUE);
    saferSystem0(normal, "type xcheck.res");
    PrintWrapped0("The only differences that should appear in the above "
                  "xcheck are that you may have locally-modified copies "
                  "of tlibuser.cfg, tlmuser.cfg, updthelp.bat, and/or "
                  "rootdir.mak, and xcheck.001/xcheck.res files for the "
                  "xcheck itself.");

    if(snapVer==NULL)
    {
        PrintWrapped0("Installation complete!");
    }
    else
    {
        PrintWrapped1("Installation of version %s complete!", snapVer);
    }
    return TRUE;
}

void cloneFile(const char *fileName, const char *oldNetDir,
               const char *localDir)
{
    char buffer[TL_MAXSTRSIZE+1]="";
    char buffer2[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(buffer, sizeof(buffer), oldNetDir);
    DgnStrcat(buffer, sizeof(buffer), fileName);
    DgnStrcpy(buffer2, sizeof(buffer2), localDir);
    DgnStrcat(buffer2, sizeof(buffer2), "\\");
    DgnStrcat(buffer2, sizeof(buffer2), fileName);
    saferCopy(buffer, buffer2, TRUE);
}

void countMissingFile(int &ct, BOOL bCheckForFile, const char *fileName)
{
    if (bCheckForFile && !saferFindFile(fileName))
    {
        PrintWrapped1("An important file (%s) is missing from "
                      "your current project", fileName);
        ct++;
    }
}

BOOL checkNoImportantMissingFiles()
{
    int ct = 0;
    countMissingFile(ct, TRUE, "updating.lck");
    countMissingFile(ct, TRUE, "tlib.cfg");
    countMissingFile(ct, TRUE, "tlibproj.cfg");
    countMissingFile(ct, TRUE, "tlibuser.cfg");
    countMissingFile(ct, TRUE, "tlmproj.cfg");
    countMissingFile(ct, TRUE, "tlmuser.cfg");
    countMissingFile(ct, TRUE, "src.lst");
    countMissingFile(ct, TRUE, "snapshot.txt");
    countMissingFile(ct, TRUE, "changes.txt");
    countMissingFile(ct, configUseUpdtstrc(), "updtstrc.bat");
    countMissingFile(ct, configUseRootdirMak(), "rootdir.mak");
    countMissingFile(ct, configUseUpdtstrc(), "updthelp.bat");
    if (ct > 0)
    {
        char buffer[10];
        DgnSprintf(buffer, sizeof(buffer), "%d", ct);
        PrintWrapped2("There are %s important file%s missing from your "
                      "current project.", buffer, ct > 1 ? "s" : "");
        return FALSE;
    }
    return TRUE;
}

void writeVerToFile(FILE *fpOutFile, BOOL bEngStyleVersion,
                    int newVerA, int newVerB, int newVerC, int newVerD)
{
    if(bEngStyleVersion)
    {
        saferFprintf(fpOutFile,
                     "%d.%02d.%03d.%03d",
                     newVerA, newVerB, newVerC, newVerD);
    }
    else
    {
        saferFprintf(fpOutFile,
                     "%d.%d.%d",
                     newVerA, newVerB, newVerC);
    }
}

int StrGetVal(const char **ppszStr)
{
    int v = 0;

    if(!ISDIGIT(**ppszStr))
    {
        PrintWrapped0("Couldn't parse specified version successfully.");
        pauseAndExit();
    }

    while(ISDIGIT(**ppszStr))
    {
        v = v * 10 + **ppszStr - '0';
        ++*ppszStr;
    }

    return v;
}

void parseFunkyVersion(const char *ptr, int nExpectedComps,
                       int *pNewVerA, int *pNewVerB,
                       int *pNewVerC, int *pNewVerD)
{
    assert(nExpectedComps>=3 && nExpectedComps<=4);
    *pNewVerA=0;
    *pNewVerB=0;
    *pNewVerC=0;
    *pNewVerD=0;
    int nFoundComps=1;
    *pNewVerA=StrGetVal(&ptr);
    if(ptr[0]=='.')
    {
        ptr++;
        nFoundComps++;
        *pNewVerB=StrGetVal(&ptr);
        if(ptr[0]=='.')
        {
            ptr++;
            nFoundComps++;
            *pNewVerC=StrGetVal(&ptr);
            if(ptr[0]=='.')
            {
                ptr++;
                nFoundComps++;
                *pNewVerD=StrGetVal(&ptr);
            }
        }
    }
    if(nFoundComps!=nExpectedComps)
    {
        PrintWrapped0("Couldn't parse specified version successfully.");
    }
}

BOOL tlibWhatsnew(BOOL displayDiff)
{
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    if(checkLock("changes.txt")==2)
    {
        PrintWrapped0("Note: someone else is currently checking in.");
        tlibInfo("changes.txt");
    }
    if(!tlibDiff("changes.txt", "*", NULL, FALSE, eDiffStandard,
                 displayDiff, TRUE))
    {
        return FALSE;
    }
    saferChdir(currDir);
    return TRUE;
}

// Bump this whenever a non-backwards-compatible change to the syntax used
// by ckinall.bat is made.
#define CURRENT_CKINALL_SYNTAX_VERSION 3

BOOL doPrep(const char *fileName)
{
    saferRemove("tlprep.000", FALSE);
    saferRemove("tlprep.001", FALSE);
    saferRemove("tlprep.002", FALSE);
    
    char checkinBatFileName[TL_MAXSTRSIZE+1]="";
    char checkinTextFileName[TL_MAXSTRSIZE+1]="";
    char commentsFileName[TL_MAXSTRSIZE+1]="";
    char buffer[TL_MAXSTRSIZE+1]="";

    FILE *fpListFiles = NULL;
    FILE *fpCheckinBat = NULL;
    FILE *fpCheckinText = NULL;
    FILE *fpComments = NULL;

    saferTmpnam(checkinBatFileName, sizeof(checkinBatFileName));
    saferTmpnam(checkinTextFileName, sizeof(checkinTextFileName));
    saferTmpnam(commentsFileName, sizeof(commentsFileName));

    if(!saferFopen(&fpListFiles, fileName, eFopenRead) ||
       !saferFopen(&fpCheckinBat, checkinBatFileName, eFopenWrite) ||
       !saferFopen(&fpCheckinText, checkinTextFileName, eFopenWrite) ||
       !saferFopen(&fpComments, commentsFileName, eFopenWrite))
    {
        return FALSE;
    }

    NameListHash srcLstHash(TRUE);
    if(!processSrcLstIntoHash("src.lst", &srcLstHash, FALSE))
    {
        return FALSE;
    }
    warnOnSrcLstMissingImportantFiles(&srcLstHash);

    DgnSprintf(buffer, sizeof(buffer), "%s\n", gUserName);
    saferFputs(buffer, fpComments);

    UpdateCriteria upCrit;

    while(fgets(buffer, TL_MAXSTRSIZE, fpListFiles))
    {
        convertListLineToFileName(buffer);
        truncateAfterFirstSpaceOrTab(buffer);
        if(buffer[0]=='\0')
        {
            continue;
        }
        if(srcLstHash.hashFind(buffer) == -1)
        {
            PrintWrapped2("One of the specified files, %s, is not in src.lst; "
                          "thus, you are not allowed to check it in.  "
                          "Please make appropriate modifications and "
                          "try again.  For example, you could remove the "
                          "pertinent files "
                          "from the list %s and re-prep with that "
                          "argument.", buffer, fileName);
            return FALSE;
        }
        if(!upCrit.fileMeetsUpdateCriteria(buffer))
        {
            PrintWrapped2("One of the specified files, %s, is in a "
                          "directory that you do not keep up-to-date; "
                          "thus, you are not allowed to check it in.  "
                          "Please make appropriate modifications and "
                          "try again.  For example, you could modify "
                          "your tlmuser.cfg to make that directory "
                          "meet the updatability criteria and update, or "
                          "uncheck the "
                          "pertinent files and re-prep, or remove them "
                          "from the list %s and re-prep with that "
                          "argument.", buffer, fileName);
            return FALSE;
        }
        if((strcmp(buffer, "updating.lck") != 0) &&
           !fileExistsAndIsWritable(buffer))
        {
            PrintWrapped1("One of the specified files, %s, either "
                          "doesn't exist or is not writable; "
                          "thus, you are not allowed to check it in.  "
                          "Please make appropriate modifications and "
                          "try again.", buffer);
            return FALSE;
        }
        if(isPointerFile(buffer))
        {
            if(!handlePointedFiles(eVerifyLocalPresentAndWritable,
                                   buffer, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL, FALSE,
                                   NULL, NULL, TRUE))
            {
                PrintWrapped1("One of the specified files, %s, refers to "
                              "one or more pointed-to files which either "
                              "don't exist or are not writable; "
                              "thus, you are not allowed to check it in.  "
                              "Please make appropriate modifications and "
                              "try again.", buffer);
                return FALSE;
            }
            if(!handlePointedFiles(eVerifyLegalNames,
                                   buffer, 0, 0,
                                   NULL, NULL, NULL, NULL, NULL, FALSE,
                                   NULL, NULL, TRUE))
            {
                PrintWrapped1("One of the specified files, %s, refers to "
                              "one or more pointed-to files which has "
                              "a bad filename; "
                              "thus, you are not allowed to check it in.  "
                              "Please make appropriate modifications and "
                              "try again.", buffer);
                return FALSE;
            }
        }
        if(isUserConfiguredFile(buffer))
        {
            PrintWrapped1("One of the specified files, %s, is specified "
                          "by TLM or your project as a user-configured "
                          "file.  This means that users are expected to "
                          "often have locally-modified versions "
                          "of it, which means that checking it in "
                          "is almost invariably a bad idea.  "
                          "Please make appropriate modifications and "
                          "try again.", buffer);
            return FALSE;
        }
    }
    _fseeki64(fpListFiles, 0, SEEK_SET);    // back to the beginning

    saferFprintf(
        fpCheckinBat,
        "\n@rem **** Check in using the commands in ckinall.txt ****\n");
    saferFprintf(fpCheckinBat,
                 "@rem **** Remember to add comments to 'checkin' lines in "
                 "ckinall.txt ****\n");
    saferFprintf(fpCheckinBat,
                 "tlm @ckinall.txt\n");
    
    saferFprintf(fpCheckinText, "\n// **** Beginning of checkin ****\n");
    saferFprintf(fpCheckinText,
                 "ckinbeg -c %d -v version.txt -k ckinall.txt%s\n",
                 CURRENT_CKINALL_SYNTAX_VERSION,
                 configMaintainEngStyleVersion() ? " -b nobump" : "");

    saferFprintf(fpCheckinText,
                 "\n// **** Check in user-modified files ****\n");
    saferFprintf(fpCheckinText,
                 "/////// ADD COMMENTS TO THESE LINES ///////\n");
    while(fgets(buffer, TL_MAXSTRSIZE, fpListFiles))
    {
        convertListLineToFileName(buffer);
        truncateAfterFirstSpaceOrTab(buffer);
        if(buffer[0]=='\0')
        {
            saferFprintf(fpCheckinText, "\n");
            saferFprintf(fpComments, "\n");
            continue;
        }
        // special case files not to check in even if checked out
        if (strcmp(buffer, "changes.txt") != 0 &&
            strcmp(buffer, "snapshot.txt") != 0 &&
            strcmp(buffer, "updating.lck") != 0)
        {
            // Print the checkin string to the bat file
            saferFprintf(fpCheckinText, "checkin %s @version.txt \n", buffer);
        }
        if (strcmp(buffer, "snapshot.txt") != 0 &&
            strcmp(buffer, "updating.lck") != 0)
        {
            saferFprintf(fpComments, "%s\n", buffer);
        }
        if (strcmp(buffer, "src.lst") == 0)
        {
            int srcMajor, srcMinor;
            if(!getNetworkVersion("src.lst", &srcMajor, &srcMinor) ||
               !tlibGet("src.lst", FALSE, "*", "tlprep.000"))
            {
                return FALSE;
            }
            FILE *fpSrcLst = NULL;
            FILE *fpLastSrcLst = NULL;
            RealUpdateArgs realUpdateArgs;
            RealUpdateHandleArgs realUpdateHandleArgs;
            saferSort(TRUE, FALSE, FALSE, 0, 0, FALSE,
                      "tlprep.000", "tlprep.001");
            saferSort(TRUE, FALSE, FALSE, 0, 0, FALSE,
                      "src.lst", "tlprep.002");

            {
                if(!saferFopen(&fpLastSrcLst, "tlprep.001", eFopenRead) ||
                   !saferFopen(&fpSrcLst, "tlprep.002", eFopenRead))
                {
                    return FALSE;
                }
                FileListReader srcLstReader(fpSrcLst, "src.lst",
                                            eSrcLst, TRUE);
                FileListReader lastSrcLstReader(fpLastSrcLst, "last src.lst",
                                                eSrcLst, TRUE);
                FileListReader desiredSnapshotReader(NULL,
                                                     "desired snapshot.txt",
                                                     eSnapshotTxt, TRUE);
                traverseListFiles(srcLstReader, lastSrcLstReader,
                                  desiredSnapshotReader,
                                  eTraverseShowSrcLstAdditions,
                                  realUpdateArgs, realUpdateHandleArgs,
                                  NULL, 0,
                                  fpComments);
                saferFclose(fpSrcLst);
                saferFclose(fpLastSrcLst);
            }
            {
                if(!saferFopen(&fpLastSrcLst, "tlprep.001", eFopenRead) ||
                   !saferFopen(&fpSrcLst, "tlprep.002", eFopenRead))
                {
                    return FALSE;
                }
                FileListReader srcLstReader(fpSrcLst, "src.lst",
                                            eSrcLst, TRUE);
                FileListReader lastSrcLstReader(fpLastSrcLst, "last src.lst",
                                                eSrcLst, TRUE);
                FileListReader desiredSnapshotReader(NULL,
                                                     "desired snapshot.txt",
                                                     eSnapshotTxt, TRUE);
                traverseListFiles(srcLstReader, lastSrcLstReader,
                                  desiredSnapshotReader,
                                  eTraverseShowSrcLstRemovals,
                                  realUpdateArgs, realUpdateHandleArgs,
                                  NULL, 0,
                                  fpComments);
                saferFclose(fpSrcLst);
                saferFclose(fpLastSrcLst);
            }
        }
    }
    saferFprintf(fpCheckinText,
                 "/////////// STOP ADDING COMMENTS //////////\n");

    saferFprintf(fpCheckinText,
                 "\n// **** Update project-control files ****\n");
    saferFprintf(fpCheckinText, "snap -p \n");
    saferFprintf(fpCheckinText, "modcomm comments.txt tlmodcom.001 \n");
    saferFprintf(fpCheckinText, "addcomm tlmodcom.001 version.txt \n");

    saferFprintf(fpCheckinText,
                 "\n// **** Check in project-control files ****\n");
    saferFprintf(fpCheckinText,
                 "/////// ADD COMMENTS TO THESE LINES ///////\n");
    saferFprintf(fpCheckinText, "checkin snapshot.txt @version.txt \n");
    saferFprintf(fpCheckinText, "checkin changes.txt @version.txt \n");
    saferFprintf(fpCheckinText,
                 "/////////// STOP ADDING COMMENTS //////////\n");

    saferFprintf(fpCheckinText, "\n// **** End of checkin ****\n");
    saferFprintf(fpCheckinText, "ckinend\n");

    saferFclose(fpCheckinBat);
    saferFclose(fpCheckinText);
    saferFclose(fpComments);
    saferFclose(fpListFiles);

    saferRemove("ckinall.bat", FALSE);
    saferMove(checkinBatFileName, "ckinall.bat", FALSE);
    saferRemove("ckinall.txt", FALSE);
    saferMove(checkinTextFileName, "ckinall.txt", FALSE);
    saferRemove("comments.txt", FALSE);
    saferMove(commentsFileName, "comments.txt", FALSE);

    saferRemove("tlprep.000", FALSE);
    saferRemove("tlprep.001", FALSE);
    saferRemove("tlprep.002", FALSE);
    saferRemove("tlprep.003", FALSE);
    
    return TRUE;
}

BOOL tlibPrep(const char *fileName)
{
    PrintWrapped0("Create a batch file for checking in all files...");
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);
    saferRemove("ckinall.bat", FALSE);
    saferRemove("ckinall.old", FALSE);
    saferMove("ckinall.txt", "ckinall.old", TRUE);
    saferRemove("comments.old", FALSE);
    saferMove("comments.txt", "comments.old", TRUE);
    if(doPrep(fileName))
    {
        PrintWrapped0("\n");
        PrintWrapped0(
            "*** Now add comments to comments.txt and ckinall.txt ***");
        PrintWrapped0("*** Then run ckinall.bat ***\n\n");
        saferChdir(currDir);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL tlibCheckin(const char *fileName, int commentsArgc,
                 const char *commentsArgv[])
{
    PrintWrapped0("Checkin a file...");
    char remoteTrack[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(remoteTrack, sizeof(remoteTrack), gNetworkDirectory);
    DgnStrcat(remoteTrack, sizeof(remoteTrack), TLIBWORK_TRK);

    {
        char relPath[TL_MAXSTRSIZE+1]="";
        getRelPath(relPath, sizeof(relPath));
        if(relPath[0] != '\0')
        {
            PrintWrapped0("Can only check in a file from the project root.");
            return FALSE;
        }
    }
    
    if(!verifyFileReadyToBeCheckedIn(fileName, eCheckin, "check in"))
    {
        return FALSE;
    }

    if(checkLock("changes.txt") != 0)
    {
        PrintWrapped0("You're trying to check in a file, but changes.txt "
                      "is not presently checked out to you.  "
                      "This is not normal; if you can't explain "
                      "why you're doing this, you should "
                      "choose not to continue.");
        if(!pauseForYesOrNo("Are you _sure_ you want to continue?"))
        {
            return FALSE;
        }
    }

    int preMajor, preMinor;
    if(!getNetworkVersion(fileName, &preMajor, &preMinor))
    {
        PrintWrapped1("Couldn't find %s's version when "
                      "attempting to check it in.", fileName);
        return FALSE;
    }
    if(!extractAndMergeComments(fileName, "", commentsArgc, commentsArgv, ""))
    {
        return FALSE;
    }
    int ret=((saferTlibbs1(loud, "-q u %s @tlcomm.001", fileName) != 0) ? 0 :
             checkLock(fileName));
    switch(ret)
    {
     default:
        assert(!"Bad ret");
        return FALSE;
        
     case 0:
        {
            char errBuf[TL_MAXSTRSIZE+1]="";
            DgnSprintf(errBuf, sizeof(errBuf), "Failed to check in file %s.  "
                    "An error occurred.", fileName);
            PrintWrapped0(errBuf);
            FILE *fp;
            if(!saferFopen(&fp, "tlchkin.err",
                           (saferFindFile("tlchkin.err") ?
                            eFopenAppend :
                            eFopenWrite)))
            {
                return FALSE;
            }
            saferFprintf(fp, "%s\n", errBuf);
            saferFclose(fp);
            pauseForKey(FALSE);
            return FALSE;
        }
        
     case 2:
        PrintWrapped1("Warning: slightly unsure if we managed to "
                      "check in file %s as "
                      "it is now checked out to someone else:", fileName);
        tlibInfo(fileName);
        pauseForKey(FALSE);
        // intentional fall-through
     case 1:
        {
            int postMajor, postMinor;
            if(!getNetworkVersion(fileName, &postMajor, &postMinor))
            {
                PrintWrapped1("Couldn't find %s's version after "
                              "attempting to check it in.",
                              fileName);
                return FALSE;
            }
            int cmpRet=compareVersions(postMajor, postMinor,
                                       preMajor, preMinor);
            if(cmpRet > 0)
            {
                if(isPointerFile(fileName))
                {
                    return handlePointedFiles(eCopyTo, fileName, postMajor,
                                              postMinor, NULL, NULL, NULL,
                                              NULL, NULL, FALSE, NULL, NULL,
                                              TRUE);
                }
            }
            else if(cmpRet < 0)
            {
                PrintWrapped1("%s's version decreased after "
                              "attempting to check it in.",
                              fileName);
                return FALSE;
            }
            else
            {
                PrintWrapped1("%s's version stayed the same after "
                              "attempting to check it in.",
                              fileName);
                return FALSE;
            }
            int trackPostMajor, trackPostMinor;
            if(!getVerFromTrack(remoteTrack, fileName,
                                &trackPostMajor, &trackPostMinor))
            {
                return FALSE;
            }
            if(compareVersions(postMajor, postMinor,
                               trackPostMajor, trackPostMinor) != 0)
            {
                PrintWrapped1("%s's version is different in the network "
                              "track file from what it is in the network "
                              "library after attempting to check it in.",
                              fileName);
                return FALSE;
            }
            if(postMinor != 0)
            {
                PrintWrapped1("%s's version has forked after attempting to "
                              "check it in.", fileName);
                return FALSE;
            }
            saferRemove("tlcomm.001", TRUE);
            return TRUE;
        }
    }
}

BOOL getControlFileNetworkVersions(int *pChanMajor, int *pChanMinor,
                                   int *pSnapMajor, int *pSnapMinor,
                                   BOOL bPredictiveIncrement)
{
    if(!getNetworkVersion("changes.txt", pChanMajor, pChanMinor))
    {
        PrintWrapped0("Couldn't get the version of changes.txt.");
        return FALSE;
    }
    if(!getNetworkVersion("snapshot.txt", pSnapMajor, pSnapMinor))
    {
        PrintWrapped0("Couldn't get the version of snapshot.txt.");
        return FALSE;
    }
    if(bPredictiveIncrement)
    {
        incrementVersion(pChanMajor, pChanMinor);
        incrementVersion(pSnapMajor, pSnapMinor);
    }
    return TRUE;
}

BOOL tlibSnap(const char *pOutputName,
              BOOL bPredictiveIncrementForControlFiles)
{
    PrintWrapped0("Snapshot a project...");
    char currDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(currDir, sizeof(currDir));
    saferChdir(gWorkDirectory);

    int predictedChanMajor;
    int predictedChanMinor;
    int predictedSnapMajor;
    int predictedSnapMinor;
    if(!getControlFileNetworkVersions(&predictedChanMajor,
                                      &predictedChanMinor,
                                      &predictedSnapMajor,
                                      &predictedSnapMinor,
                                      bPredictiveIncrementForControlFiles))
    {
        return FALSE;
    }

    BOOL bOverwritingSnapshotTxt = !strcmp(pOutputName, "snapshot.txt");
    
    if(bOverwritingSnapshotTxt &&
       !fileExistsAndIsWritable("snapshot.txt"))
    {
        PrintWrapped1("File %s must exist and be writable.", "snapshot.txt");
        return FALSE;
    }
    else if(!bOverwritingSnapshotTxt &&
            !saferFindFile("snapshot.txt"))
    {
        PrintWrapped1("File %s must exist.", "snapshot.txt");
        return FALSE;
    }
    else
    {
        FILE *fpSrcLst;
        FILE *fpLocalTrack;
        if (!saferFopen(&fpSrcLst, "src.lst", eFopenRead) ||
            !saferSortAndFopen(&fpLocalTrack, FALSE,
                               TLIBWORK_TRK, "tlsnap.001"))
        {
            return FALSE;
        }

        UpdateCriteria upCrit;

        BOOL incrementalSnapshot=!upCrit.allFilesAreUpdated();
        FILE *fpInSnapshot = NULL;
        FILE *fpOutSnapshot = NULL;
        if((incrementalSnapshot &&
            !saferFopen(&fpInSnapshot, "snapshot.txt", eFopenRead)) ||
           !saferFopen(&fpOutSnapshot, "tlsnap.002", eFopenWrite))
        {
            return FALSE;
        }

        FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
        FileListReader localTrackReader(fpLocalTrack, "local tlibwork.trk",
                                        eTlibworkTrk, TRUE);
        FileListReader inSnapReader(fpInSnapshot, "initial snapshot.txt",
                                    eSnapshotTxt, TRUE);

        while(!srcLstReader.done())
        {
            srcLstReader.next();
            if(srcLstReader.done())
            {
                break;
            }
            if(!upCrit.fileMeetsUpdateCriteria(srcLstReader.currentFile()))
            {
                // have to get it from fpInSnapshot...
                if(inSnapReader.done() ||
                   !inSnapReader.seekSpecifiedFile(
                    srcLstReader.currentFile()))
                {   // The unupdated src.lst file wasn't in the old
                    // snapshot, so we're toast.
                    PrintWrapped1("Unable to generate incremental snapshot "
                                  "as the unupdated file %s was not found "
                                  "in the old snapshot.txt.",
                                  srcLstReader.currentFile());
                    return FALSE;
                }
                else
                {
                    saferFprintf(fpOutSnapshot, "%s v=",
                                 inSnapReader.currentFile());
                    printVersion(fpOutSnapshot,
                                 inSnapReader.currentMajorVersion(),
                                 inSnapReader.currentMinorVersion());
                    saferFprintf(fpOutSnapshot, "\n");
                    putchar(',');
                }
            }
            else
            {
                if(localTrackReader.done() ||
                   !localTrackReader.seekSpecifiedFile(
                    srcLstReader.currentFile()))
                {   // The src.lst file wasn't in the local tlibwork.trk.
                    PrintWrapped1("Couldn't find %s in local tlibwork.trk!  "
                                  "Check src.lst to make sure it's sorted.  "
                                  "Are you sure you're up-to-date?  If "
                                  "updating gives _any_ errors, you're not!",
                                  srcLstReader.currentFile());
                    return FALSE;
                }
                else
                {
                    int currentMajor=localTrackReader.currentMajorVersion();
                    int currentMinor=localTrackReader.currentMinorVersion();
                    if(!strcmp(srcLstReader.currentFile(), "snapshot.txt") ||
                       !strcmp(srcLstReader.currentFile(), "changes.txt"))
                    {
                        // Special cases: try to predict the snapshot.txt
                        // version, so that an unsnap will get us the exact
                        // completely-post-checkin state.  And, as long as
                        // we're predicting the snapshot.txt version, we
                        // might as well do the same for changes.txt,
                        // allowing us to simplify things a bit.
                        if(bPredictiveIncrementForControlFiles)
                        {
                            incrementVersion(&currentMajor, &currentMinor);
                        }

                        int predictedMajor=0;
                        int predictedMinor=0;
                        if(!strcmp(srcLstReader.currentFile(),
                                   "snapshot.txt"))
                        {
                            predictedMajor=predictedSnapMajor;
                            predictedMinor=predictedSnapMinor;
                        }
                        else if(!strcmp(srcLstReader.currentFile(),
                                        "changes.txt"))
                        {
                            predictedMajor=predictedChanMajor;
                            predictedMinor=predictedChanMinor;
                        }

                        // Might as well check it against the version
                        // predicted for use by changes.txt.
                        if(compareVersions(predictedMajor, predictedMinor,
                                           currentMajor, currentMinor) != 0)
                        {
                            PrintWrapped2("The predicted %s "
                                          "version disagrees with "
                                          "the %s version "
                                          "generated while making "
                                          "the new snapshot.",
                                          srcLstReader.currentFile(),
                                          srcLstReader.currentFile());
                            return FALSE;
                        }
                    }

                    saferFprintf(fpOutSnapshot, "%s v=",
                                 srcLstReader.currentFile());
                    printVersion(fpOutSnapshot, currentMajor, currentMinor);
                    saferFprintf(fpOutSnapshot, "\n");
                    putchar('.');
                }
            }
        }
        saferFclose(fpLocalTrack);
        saferFclose(fpOutSnapshot);
        if(incrementalSnapshot)
        {
            saferFclose(fpInSnapshot);
        }
        saferFclose(fpSrcLst);
        putchar('\n');
        saferRemove("tlsnap.001", TRUE);
        saferRemove(pOutputName, bOverwritingSnapshotTxt);
        saferMove("tlsnap.002", pOutputName, FALSE);
        saferChdir(currDir);
        return TRUE;
    }
}

void fillWithCurrentDateTime(char *pTimeString, int lTimeString)
{
    tm localTM;
    tm *pTM = &localTM;
    __time64_t t = _time64(NULL);
    int errnum = _localtime64_s(pTM, &t);
    if(errnum != 0)
    {
        PrintWrapped0("Couldn't obtain current local time successfully.");
        pauseAndExit();
    }
    DgnSprintf(pTimeString, lTimeString,
               "%04ld-%02ld-%02ld %02ld:%02ld:%02ld",
               (long)(pTM->tm_year + 1900),
               (long)(pTM->tm_mon + 1),
               (long)pTM->tm_mday,
               (long)pTM->tm_hour,
               (long)pTM->tm_min,
               (long)pTM->tm_sec);
}

BOOL tlibAddcomm(const char *commFile, const char *verInFile,
                 BOOL bFirstComment)
{
    char newFileName[TL_MAXSTRSIZE+1]="";
    saferTmpnam(newFileName, sizeof(newFileName));

    char relPath[TL_MAXSTRSIZE+1]="";
    getRelPath(relPath, sizeof(relPath));
    if(relPath[0] != '\0')
    {
        PrintWrapped0("Can only add comments in the project root.");
        return FALSE;
    }

    FILE *fpChanges;
    FILE *fpNewChanges;
    FILE *fpComments;
    if(!saferFopen(&fpChanges, "changes.txt", eFopenRead) ||
       !saferFopen(&fpNewChanges, newFileName, eFopenWrite) ||
       !saferFopen(&fpComments, commFile, eFopenRead))
    {
        return FALSE;
    }

    int predictedChanMajor;
    int predictedChanMinor;
    int predictedSnapMajor;
    int predictedSnapMinor;
    if(!getControlFileNetworkVersions(&predictedChanMajor,
                                      &predictedChanMinor,
                                      &predictedSnapMajor,
                                      &predictedSnapMinor,
                                      TRUE))
    {
        return FALSE;
    }
    
    BOOL foundComment=FALSE;
    char buffer[TL_MAXSTRSIZE+1]="";
    while(fgets(buffer, TL_MAXSTRSIZE, fpChanges))
    {
        if(!foundComment && isPrefix(gMarkerForComments, buffer))
        {
            // put comment marker back
            saferFputs(buffer, fpNewChanges);

            // put in the version information
            assert(verInFile != NULL);
            char ver[TL_MAXSTRSIZE+1]="";
            FILE *fpVer;
            if(!saferFopen(&fpVer, verInFile, eFopenRead))
            {
                return FALSE;
            }
            if(!fgets(ver, TL_MAXSTRSIZE, fpVer))
            {
                PrintWrapped1("Couldn't read %s.", verInFile);
                return FALSE;
            }
            saferFclose(fpVer);
            trimFinalWhiteSpace(ver);
            saferFprintf(fpNewChanges, "%s", ver);
            saferFprintf(fpNewChanges, " (changes.txt v. ");
            printVersion(fpNewChanges, predictedChanMajor,
                         predictedChanMinor);
            saferFprintf(fpNewChanges, ", ");
            saferFprintf(fpNewChanges, "snapshot.txt v. ");
            printVersion(fpNewChanges, predictedSnapMajor,
                         predictedSnapMinor);
            saferFprintf(fpNewChanges, ")\n");

            // put in the current date/time
            char timeString[TL_MAXSTRSIZE+1]="";
            fillWithCurrentDateTime(timeString, sizeof(timeString));
            DgnStrcat(timeString, sizeof(timeString), "  ");
            saferFprintf(fpNewChanges, timeString);

            BOOL needFinalNewLine=TRUE;
            // now read in comment file
            while(fgets(buffer, TL_MAXSTRSIZE, fpComments))
            {
                trimFinalWhiteSpace(buffer);
                needFinalNewLine = (buffer[0] != '\0');
                saferFprintf(fpNewChanges, "%s\n", buffer);
                
            }
            if(!bFirstComment && needFinalNewLine)
            {
                saferFprintf(fpNewChanges, "\n");
            }
            foundComment = TRUE;
        }
        else
        {
            saferFputs(buffer, fpNewChanges);
        }
    }
    saferFclose(fpNewChanges);
    saferFclose(fpComments);
    saferFclose(fpChanges);
    if(!foundComment)
    {
        PrintWrapped2("Couldn't find \"%s\" in %s.",
                      gMarkerForComments, "changes.txt");
        return FALSE;
    }

    saferRemove("changes.old", FALSE);
    saferMove("changes.txt", "changes.old", FALSE);
    saferMove(newFileName, "changes.txt", FALSE);
    return TRUE;
}

BOOL bumpVersion(int *pNewVerA, int *pNewVerB, int *pNewVerC, int *pNewVerD,
                 const char *versionBumpOrOverride)
{
    (*pNewVerD)++;
    if(*pNewVerD > 999)
    {
        (*pNewVerC)++;
        *pNewVerD=0;
    }
    if(*pNewVerC > 999)
    {
        (*pNewVerB)++;
        *pNewVerC=0;
        *pNewVerD=0;
    }
    if(*pNewVerB > 99)
    {
        (*pNewVerA)++;
        *pNewVerB=0;
        *pNewVerC=0;
        *pNewVerD=0;
    }
    if(strcmp(versionBumpOrOverride, "nobump") != 0)
    {
        int bumpVerA;
        int bumpVerB;
        int bumpVerC;
        int bumpVerD;
        parseFunkyVersion(
            versionBumpOrOverride, 4,
            &bumpVerA, &bumpVerB, &bumpVerC, &bumpVerD);
        if(bumpVerA < *pNewVerA ||
           (bumpVerA == *pNewVerA && bumpVerB < *pNewVerB) ||
           (bumpVerA == *pNewVerA && bumpVerB == *pNewVerB &&
            bumpVerC < *pNewVerC) ||
           (bumpVerA == *pNewVerA && bumpVerB == *pNewVerB &&
            bumpVerC == *pNewVerC && bumpVerD < *pNewVerD))
        {
            PrintWrapped1("Version %s must be strictly greater than the "
                          "previous version.", versionBumpOrOverride);
            return FALSE;
        }
        *pNewVerA = bumpVerA;
        *pNewVerB = bumpVerB;
        *pNewVerC = bumpVerC;
        *pNewVerD = bumpVerD;
    }
    return TRUE;
}

BOOL checkCkinall(const char *ckinallToVerify, BOOL *pbCheckingInSrcLst)
{
    NameListHash checkinHash(TRUE);
    NameListHash addcommHash(TRUE);
    if(!processCkinallIntoHash(ckinallToVerify, &checkinHash, &addcommHash))
    {
        return FALSE;
    }
    
    {
        const char *pNamePool=checkinHash.getNamePool();
        const char *pNextPool=checkinHash.getNextPool();
        const char *pCurrentName=pNamePool;
        while(pCurrentName != pNextPool)
        {
            if(strcmp(pCurrentName, "changes.txt") &&
               strcmp(pCurrentName, "snapshot.txt"))
            {
                if(!verifyFileReadyToBeCheckedIn(pCurrentName, eCheckin,
                                                 "check in"))
                {
                    return FALSE;
                }
            }
            if(!strcmp(pCurrentName, "src.lst"))
            {
                *pbCheckingInSrcLst = TRUE;
            }
            pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
        }
    }

    {
        const char *pNamePool=addcommHash.getNamePool();
        const char *pNextPool=addcommHash.getNextPool();
        const char *pCurrentName=pNamePool;
        while(pCurrentName != pNextPool)
        {
            if(!fileExistsAndIsWritable(pCurrentName))
            {
                PrintWrapped1("File %s must exist and be writable.",
                              pCurrentName);
                return FALSE;
            }
            pCurrentName = pCurrentName + strlen(pCurrentName) + 1;
        }
    }
    
    return TRUE;
}

BOOL tlibCkinbeg(BOOL bInForkproj, const char *pForkprojForkingFromVersion,
                 const char *versionBumpOrOverride, const char *versOut,
                 const char *ckinallToVerify)
{
    saferRemove("tlchkin.err", FALSE);
    if(checkLock("changes.txt")==2)
    {
        PrintWrapped0("Someone is currently checking in.  Try again later.");
        tlibInfo("changes.txt");
        return FALSE;
    }
    if(checkLock("snapshot.txt")==2)
    {
        PrintWrapped0("Someone is currently checking in.  Try again later.");
        tlibInfo("snapshot.txt");
        return FALSE;
    }

    BOOL maintainEngStyleVersion=configMaintainEngStyleVersion();

    {
        char lockingUser[TL_MAXSTRSIZE+1]="";
        BOOL bStrongLocked;
        if (checkLock("updating.lck", TRUE) == 2 &&
            isLocked(gNetworkDirectory, "updating.lck",
                     lockingUser, &bStrongLocked))
        {
            if(bStrongLocked)
            {
                if(_stricmp(lockingUser, gUserName))
                {
                    PrintWrapped0("Someone is currently checking in.  "
                                  "Try again later.");
                    tlibInfo("updating.lck");
                    return FALSE;
                }
            }
            else
            {
                PrintWrapped0("Note: someone is currently updating.");
                tlibInfo("updating.lck");
                pauseForYes();
                // fall through, to allow the checkin preparations to begin
                // before people are done updating.
            }
        }
    }

    if(!getFileVersionFromTrack("changes.txt", TRUE, FALSE, TRUE,
                                NULL, NULL))
    {
        return FALSE;
    }
    if(!bInForkproj)
    {
        PrintWrapped0("\n");
        PrintWrapped0("Are you up to date?  If not, try " TLM_NAME
                      " update, rebuild and test.");
        pauseForYes();
    }
    
    if(!checkFileIsUpToDateEnough("changes.txt") ||
       !checkFileIsUpToDateEnough("src.lst"))
    {
        PrintWrapped0("Try updating and rebuilding.");
        return FALSE;
    }

    // Now grab updating.lck, after checking on person's story
    // Is updating.lck available?
    // Don't grab the lock on updating.lck until after deciding to continue
    // with the checkin...
    {
        char lockingUser[TL_MAXSTRSIZE+1]="";
        BOOL bStrongLocked;
        if (checkLock("updating.lck", TRUE) == 2 &&
            isLocked(gNetworkDirectory, "updating.lck",
                     lockingUser, &bStrongLocked))
        {
            if(bStrongLocked)
            {
                PrintWrapped0("Someone is currently checking in.  "
                              "Try again later.");
                tlibInfo("updating.lck");
                return FALSE;
            }
            else
            {
                PrintWrapped0("Someone is currently updating.  "
                              "[Note that it is possible that they aborted "
                              "their update without cleaning up "
                              "after themselves; "
                              "if you know this to be the case, you can "
                              "\"" TLM_NAME " break updating.lck\".]");
                tlibInfo("updating.lck");
                PrintWrapped0("\n");
                PrintWrapped0("Since there is someone updating, you "
                              "can't start your checkin yet.  "
                              "But " TLM_NAME " can reserve changes.txt "
                              "for you for five minutes, in hopes that "
                              "people's updates will finish in "
                              "that interval (and no "
                              "new ones will start, since you'll "
                              "have changes.txt locked), then continue "
                              "your checkin once the pending updates "
                              "are finished.");
                PrintWrapped0("\n");
                if(!pauseForYesOrNo("Do you want to reserve changes.txt?"))
                {
                    return FALSE;
                }
                PrintWrapped0("\n");
                PrintWrapped0("Warning: this will temporarily keep people "
                              "from starting new updates, and you must be "
                              "very careful not to leave the project in "
                              "this state.");
                PrintWrapped0("\n");
                if(!pauseForYesOrNo("Are you _sure_ you want to continue?"))
                {
                    return FALSE;
                }
                if(!checkFileIsUpToDateEnough("changes.txt"))
                {
                    PrintWrapped0("Try updating and rebuilding.");
                    return FALSE;
                }
                if(!reserveFileToSurrogate("changes.txt", "RESERVED_BY_"))
                {
                    return FALSE;
                }
                BOOL bSuccess=FALSE;
                for(int i=0; i<30; i++)
                {
                    BOOL bStrongLocked;
                    printf("Checking for pending updates: attempt %d of %d\n",
                           i+1, 30);
                    if (checkLock("updating.lck", TRUE) == 2 &&
                        isLocked(gNetworkDirectory, "updating.lck",
                                 lockingUser, &bStrongLocked))
                    {
                        if(bStrongLocked)
                        {
                            PrintWrapped0("Somebody has strong-locked "
                                          "updating.lck:");
                            tlibInfo("updating.lck");
                            break;
                        }
                        else
                        {
                            tlibInfo("updating.lck");
                            printf("\n");
                            if(waitSeconds("Press any key to back out...",
                                           TRUE, 10))
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        // now grab updating.lck - strong locking on this
                        // file
                        if(!reserveFile("updating.lck", TRUE))
                        {
                            PrintWrapped0(
                                "Failed to lock updating.lck, even though "
                                "it didn't look like it was locked.");
                            tlibInfo("updating.lck");
                            break;
                        }
                        else
                        {
                            bSuccess=TRUE;
                            break;
                        }
                    }
                }
                if(!bSuccess)
                {
                    PrintWrapped0("Backing out....");
                }
                if(!tlibBreak("changes.txt", TRUE))
                {
                    if(bSuccess)
                    {
                        updateUnlock(NULL);
                    }
                    PrintWrapped1("Failed to break the "
                                  "RESERVED_BY_%s lock on "
                                  "changes.txt.", gUserName);
                    return FALSE;
                }
                else if(!bSuccess)
                {
                    PrintWrapped1("Successfully broke the "
                                  "RESERVED_BY_%s lock on "
                                  "changes.txt.", gUserName);
                    return FALSE;
                }
                // Okay, we've now got updating.lck strong-locked, and
                // that's all; let's continue.
                PrintWrapped0("The pending updates are all "
                              "finished -- continuing checkin.");
            }
        }
        else if(!updateLock(FALSE, TRUE))
        {
            PrintWrapped0("Failed to lock updating.lck, even though "
                          "it didn't look like it was locked.");
            tlibInfo("updating.lck");
            return FALSE;
        }
    }

    // Now that we have updating.lck, do our best to see if snapshot
    // generation is eventually going to fail, in which case we should
    // gracefully abort the checkin.
    BOOL bBackout=FALSE;
    if(!bInForkproj)
    {
        BOOL bCheckingInSrcLst=FALSE;
        if(!bBackout &&
           !checkCkinall(ckinallToVerify, &bCheckingInSrcLst))
        {
            bBackout=TRUE;
        }
        if(!bBackout)
        {
            PrintWrapped0("Generating pre-checkin test snapshot...");
            saferRemove("tlckbeg.002", FALSE);
            saferRemove("tlckbeg.003", FALSE);
            if(!tlibSnap("tlckbeg.002", FALSE))
            {
                PrintWrapped0("Since your pre-checkin test snapshot failed, "
                              "you're definitely not up-to-date; try "
                              "updating and rebuilding.");
                bBackout=TRUE;
            }
        }
        if(!bBackout &&
           saferSpawn0(
            silent, eCheckRetNoneAndNoCheckValidExe, gDiffPath,
            "-v snapshot.txt tlckbeg.002") != 0)
        {
            saferSystem1(normal,
                         "%s -v snapshot.txt tlckbeg.002 > tlckbeg.003",
                         gDiffPath);
            PrintWrapped0("Your pre-checkin test snapshot (tlckbeg.002) "
                          "succeeded, but it's different from the "
                          "currently checked-in snapshot (snapshot.txt), "
                          "with the following differences (also stored "
                          "in tlckbeg.003): ");
            saferSpawn0(normal, eCheckRetNoneAndNoCheckValidExe,
                        gMorePath, "tlckbeg.003");
            PrintWrapped0("\n");
            PrintWrapped1("A difference like this is unusual, "
                          "but may be appropriate if you're "
                          "creating/removing/moving files "
                          "in this checkin, you're "
                          "cleaning up after a broken snapshot, "
                          "or if this is the first checkin with "
                          "a new version of " TLM_NAME " that has "
                          "new checkin semantics.  You should "
                          "double-check these differences, and "
                          "if you can't explain them, you should "
                          "choose not to continue.  Note "
                          "that you %s checking in src.lst.",
                          bCheckingInSrcLst ? "are" : "aren't");
            if(!pauseForYesOrNo("Do you want to continue?"))
            {
                bBackout=TRUE;
            }
            else if(!bCheckingInSrcLst)
            {
                PrintWrapped0("Note that you aren't checking "
                              "in src.lst, changes to which are "
                              "the most frequent reason for "
                              "pre-checkin test snapshot "
                              "differences.");
                if(!pauseForYesOrNo(
                    "Are you _sure_ you want to continue?"))
                {
                    bBackout=TRUE;
                }
                else
                {
                    saferRemove("tlckbeg.003", TRUE);
                }
            }
            else
            {
                saferRemove("tlckbeg.003", TRUE);
            }
        }
        if(!bBackout)
        {
            saferRemove("tlckbeg.002", TRUE);
        }
    }

    FILE *fpVersOut;
    if(!bBackout && !saferFopen(&fpVersOut, versOut, eFopenWrite))
    {
        return FALSE;
    }

    int newVerA=0, newVerB=0, newVerC=0, newVerD=0;
    if(!bBackout)
    {
        if(maintainEngStyleVersion)
        {
            if(bInForkproj)
            {
                parseFunkyVersion(pForkprojForkingFromVersion, 4,
                                  &newVerA, &newVerB, &newVerC, &newVerD);
            }
            else
            {
                // Get the old version number from changes.txt and bump it.
                FILE *fpChanges;
                if (!saferFopen(&fpChanges, "changes.txt", eFopenRead))
                {
                    return FALSE;
                }

                char chanBuffer[TL_MAXSTRSIZE+1]="";
                while(fgets(chanBuffer, TL_MAXSTRSIZE, fpChanges))
                {
                    if(isPrefix(gMarkerForComments, chanBuffer))
                    {
                        if(fgets(chanBuffer, TL_MAXSTRSIZE, fpChanges) &&
                           !ISSPACE(chanBuffer[0]))
                        {
                            // There's another line -- it has to have a
                            // valid version number in it.
                            char *pNextSpace;
                            if((pNextSpace=strchr(chanBuffer, ' ')) == NULL ||
                               (pNextSpace=strchr(pNextSpace+1, ' ')) == NULL)
                            {
                                PrintWrapped1("Couldn't find version number "
                                              "in line '%s'.",
                                              chanBuffer);
                                return FALSE;
                            }
                            parseFunkyVersion(pNextSpace+1, 4,
                                              &newVerA, &newVerB,
                                              &newVerC, &newVerD);
                        }
                        else
                        {
                            // There's no next line -- this is probably a
                            // new project, for which a version of
                            // 0.00.000.001 is appropriate and will now
                            // result.
                        }
                        break;
                    }
                }
                saferFclose(fpChanges);
            }
            if(!bumpVersion(&newVerA, &newVerB, &newVerC, &newVerD,
                            versionBumpOrOverride))
            {
                bBackout = TRUE;
            }
        }
        else
        {
            // Guess the next version number.
            int predictedChanMajor;
            int predictedChanMinor;
            int predictedSnapMajor;
            int predictedSnapMinor;
            if(!getControlFileNetworkVersions(&predictedChanMajor,
                                              &predictedChanMinor,
                                              &predictedSnapMajor,
                                              &predictedSnapMinor,
                                              TRUE))
            {
                return FALSE;
            }

            char verStr[TL_MAXSTRSIZE+1]="";
            if (!readConfigOption(gWorkDirectory,
                                  "tlmproj.cfg", "PROJECT_VERSION_PREFIX=",
                                  verStr, sizeof(verStr),
                                  TRUE, FALSE, FALSE))
            {
                DgnStrcpy(verStr, sizeof(verStr), "0.0.");
            }
            fillVersionString(verStr+strlen(verStr),
                              sizeof(verStr)-strlen(verStr),
                              predictedChanMajor,
                              predictedChanMinor);
            parseFunkyVersion(verStr, 3,
                              &newVerA, &newVerB,
                              &newVerC, &newVerD);
        }
    }

    if(!bBackout)
    {
        // Now write versOut.
        char projectName[TL_MAXSTRSIZE+1]="";
        if(!readConfigOption(gWorkDirectory,
                             "tlmproj.cfg", "PROJECT_NAME=",
                             projectName, sizeof(projectName),
                             TRUE, FALSE, FALSE))
        {
            PrintWrapped0("Couldn't read PROJECT_NAME from "
                          "tlmproj.cfg.");
            return FALSE;
        }
        else
        {
            if(projectName[0] == '\0')
            {
                PrintWrapped0("PROJECT_NAME from tlmproj.cfg is empty.");
                return FALSE;
            }
            for(int i=0; projectName[i] != '\0'; i++)
            {
                if(!ISALPHA(projectName[i]) &&
                   !ISDIGIT(projectName[i]) &&
                   projectName[i] != '_')
                {
                    PrintWrapped0(
                        "PROJECT_NAME from tlmproj.cfg contains a "
                        "character which is not a letter, digit, "
                        "or underscore.");
                    return FALSE;
                }
            }
        }

        saferFprintf(fpVersOut, "%s", projectName);
        saferFprintf(fpVersOut, " version ");
        writeVerToFile(fpVersOut, maintainEngStyleVersion,
                       newVerA, newVerB, newVerC, newVerD);
        saferFprintf(fpVersOut, "\n");
        saferFclose(fpVersOut);
    }

    if(bBackout)
    {
        PrintWrapped0("Backing out....");
        updateUnlock(NULL);
        PrintWrapped0("\n");
        PrintWrapped0("Successfully backed out.");
        PrintWrapped0("\n");
        return FALSE;
    }
    
    // Try editing it, but edit may fail if already checked out so just
    // check the lock status
    if (!tlibEdit("changes.txt", TRUE, FALSE) &&
        (checkLock("changes.txt") != 0))
    {
        PrintWrapped0("Error: changes.txt did not get checked out to you.");
        return FALSE;
    }
    if (!tlibEdit("snapshot.txt", TRUE, FALSE) &&
        (checkLock("snapshot.txt") != 0))
    {
        PrintWrapped0(
            "Error: snapshot.txt did not get checked out to you.");
        return FALSE;
    }

    return TRUE;
}

BOOL tlibCkinend()
{
    if(checkLock("changes.txt") != 1 ||
       checkLock("snapshot.txt") != 1)
    {
        PrintWrapped0("Error: changes.txt and/or snapshot.txt "
                      "did not get checked in.");
        return FALSE;
    }

    {
        // Verify that snapshot.txt's predicted versions were correct.
        int actualPostChanMajor;
        int actualPostChanMinor;
        int actualPostSnapMajor;
        int actualPostSnapMinor;
        if(!getControlFileNetworkVersions(&actualPostChanMajor,
                                          &actualPostChanMinor,
                                          &actualPostSnapMajor,
                                          &actualPostSnapMinor,
                                          FALSE))
        {
            return FALSE;
        }

        int snapshotChanMajor;
        int snapshotChanMinor;
        int snapshotSnapMajor;
        int snapshotSnapMinor;
        char revNum[100];
        if(!getVerFromSnap(revNum, sizeof(revNum),
                           "changes.txt", "snapshot.txt") ||
           !reallyParseVersion(revNum,
                               &snapshotChanMajor, &snapshotChanMinor,
                               revNum, "changes.txt version in snapshot.txt"))
        {
            PrintWrapped0("Couldn't find changes.txt's post-checkin "
                          "version in snapshot.txt.");
            return FALSE;
        }
        if(!getVerFromSnap(revNum, sizeof(revNum),
                           "snapshot.txt", "snapshot.txt") ||
           !reallyParseVersion(revNum,
                               &snapshotSnapMajor, &snapshotSnapMinor,
                               revNum, "snapshot.txt version in snapshot.txt"))
        {
            PrintWrapped0("Couldn't find snapshot.txt's post-checkin "
                          "version in snapshot.txt.");
            return FALSE;
        }
        
        if(compareVersions(actualPostChanMajor, actualPostChanMinor,
                           snapshotChanMajor, snapshotChanMinor) != 0)
        {
            PrintWrapped0("changes.txt's post-checkin version in "
                          "snapshot.txt disagrees with actual "
                          "post-checkin version of changes.txt.");
            return FALSE;
        }

        if(compareVersions(actualPostSnapMajor, actualPostSnapMinor,
                           snapshotSnapMajor, snapshotSnapMinor) != 0)
        {
            PrintWrapped0("snapshot.txt's post-checkin version in "
                          "snapshot.txt disagrees with actual "
                          "post-checkin version of snapshot.txt.");
            return FALSE;
        }
    }

    if(saferFindFile("tlchkin.err"))
    {
        saferSystem0(normal, "type tlchkin.err");
    }
    updateUnlock(NULL);
    return TRUE;
}

BOOL tlibCloneproj(const char *oldNetDir, const char *netDir,
                   const char *localDir, const char *rootDir,
                   const char *newProjectName,
                   const char *newProjectVersionBumpOrOverride,
                   BOOL bActuallyForkproj)
{
    PrintWrapped0("Clone a project's configuration to a new project...");
    char oldCurrDir[TL_MAXSTRSIZE+1]="";
    saferGetcwd(oldCurrDir, sizeof(oldCurrDir));
    saferChdir(gWorkDirectory);

    if(!checkNetAndLocalDirsForInstallOrCloneproj(netDir, localDir))
    {
        return FALSE;
    }

    saferEnsureDirectoryTreePlusSlashExists(localDir);
    saferEnsureDirectoryTreePlusSlashExists(netDir);

    if(!bActuallyForkproj && !saferCheckDirectoryEmpty(localDir))
    {
        PrintWrapped1("The local directory %s is not empty.  Please "
                      "cloneproj only into an empty or "
                      "non-existent directory.", localDir);
        return FALSE;
    }
    
    if(!saferCheckDirectoryEmpty(netDir))
    {
        PrintWrapped1("The network directory %s is not empty.  Please "
                      "cloneproj only into an empty or "
                      "non-existent directory.", netDir);
        return FALSE;
    }

    if(!checkNoImportantMissingFiles())
    {
        return FALSE;
    }

    saferChdir(localDir);

    if(!bActuallyForkproj)
    {
        cloneFile("updating.lck", oldNetDir, localDir);
        cloneFile("tlib.cfg", oldNetDir, localDir);
        cloneFile("tlibproj.cfg", oldNetDir, localDir);
        cloneFile("tlmproj.cfg", oldNetDir, localDir);
        cloneFile("tlmuser.cfg", oldNetDir, localDir);
    }

    // tlmproj.cfg
    if(bActuallyForkproj)
    {
        char oldTlmprojName[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(oldTlmprojName, sizeof(oldTlmprojName), oldNetDir);
        DgnStrcat(oldTlmprojName, sizeof(oldTlmprojName), "tlmproj.cfg");
        FILE *fpTlmproj;
        FILE *fpNewTlmproj;
        if (!saferFopen(&fpTlmproj, oldTlmprojName, eFopenRead) ||
            !saferFopen(&fpNewTlmproj, "tlmproj.cfg", eFopenWrite))
        {
            return FALSE;
        }

        char tlmprojBuffer[TL_MAXSTRSIZE+1]="";
        while(fgets(tlmprojBuffer, TL_MAXSTRSIZE, fpTlmproj))
        {
            if(isPrefix("PROJECT_NAME=", tlmprojBuffer))
            {
                // Change project name
                DgnSprintf(tlmprojBuffer, sizeof(tlmprojBuffer),
                           "PROJECT_NAME=%s\n", newProjectName);
            }
            saferFputs(tlmprojBuffer, fpNewTlmproj);
        }
        saferFclose(fpNewTlmproj);
        saferFclose(fpTlmproj);
    }
    
    // tlibuser.cfg
    if(!createTlibuser("tlibuser.cfg", netDir, localDir, E_CRLF, FALSE))
    {
        return FALSE;
    }

    // src.lst
    if(!bActuallyForkproj)
    {
        FILE *fpSrc;
        if (!saferFopen(&fpSrc, "src.lst", eFopenWrite))
        {
            return FALSE;
        }
        saferFclose(fpSrc);
    }

    // snapshot.txt
    {
        FILE *fpSnapshot;
        if (!saferFopen(&fpSnapshot, "snapshot.txt", eFopenWrite))
        {
            return FALSE;
        }
        saferFprintf(fpSnapshot, "\n");  // tlibbs doesn't like empty files.
        saferFclose(fpSnapshot);
    }

    // changes.txt
    char forkedFromVersionString[TL_MAXSTRSIZE+1]="";
    char forkedFromVersionComment[TL_MAXSTRSIZE+1]="";
    {
        char oldChanName[TL_MAXSTRSIZE+1]="";
        DgnStrcpy(oldChanName, sizeof(oldChanName), oldNetDir);
        DgnStrcat(oldChanName, sizeof(oldChanName), "changes.txt");
        FILE *fpChanges;
        FILE *fpNewChanges;
        if (!saferFopen(&fpChanges, oldChanName, eFopenRead) ||
            !saferFopen(&fpNewChanges, "changes.txt", eFopenWrite))
        {
            return FALSE;
        }

        char chanBuffer[TL_MAXSTRSIZE+1]="";
        while(fgets(chanBuffer, TL_MAXSTRSIZE, fpChanges))
        {
            if(isPrefix(gMarkerForComments, chanBuffer))
            {
                // put comment marker back
                saferFputs(chanBuffer, fpNewChanges);
                if(bActuallyForkproj &&
                   fgets(chanBuffer, TL_MAXSTRSIZE, fpChanges) &&
                   !ISSPACE(chanBuffer[0]))
                {
                    // There's another line -- it has to have a valid
                    // version number in it.
                    char *pNextSpace;
                    char *pNextSpace2;
                    if((pNextSpace=strchr(chanBuffer, ' ')) == NULL ||
                       (pNextSpace=strchr(pNextSpace+1, ' ')) == NULL ||
                       (pNextSpace2=strchr(pNextSpace+1, ' ')) == NULL)
                    {
                        PrintWrapped1("Couldn't find version number "
                                      "in line '%s'.",
                                      chanBuffer);
                        return FALSE;
                    }
                    *pNextSpace2 = '\0';
                    DgnStrcpy(forkedFromVersionString,
                              sizeof(forkedFromVersionString),
                              pNextSpace+1);
                    if(configMaintainEngStyleVersion())
                    {
                        int newVerA=0, newVerB=0, newVerC=0, newVerD=0;
                        parseFunkyVersion(
                            forkedFromVersionString, 4,
                            &newVerA, &newVerB, &newVerC, &newVerD);
                        if(!bumpVersion(&newVerA, &newVerB, &newVerC, &newVerD,
                                        newProjectVersionBumpOrOverride))
                        {
                            return FALSE;
                        }
                    }
                    DgnStrcpy(forkedFromVersionComment,
                              sizeof(forkedFromVersionComment),
                              "Forked from ");
                    DgnStrcat(forkedFromVersionComment,
                              sizeof(forkedFromVersionComment), chanBuffer);
                }
                break;
            }
            else
            {
                saferFputs(chanBuffer, fpNewChanges);
            }
        }
        saferFclose(fpNewChanges);
        saferFclose(fpChanges);
    }

    // updtstrc.bat
    if(configUseUpdtstrc())
    {
        FILE *fpTempFile = NULL;
        {
            char oldUpdtstrcName[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(oldUpdtstrcName, sizeof(oldUpdtstrcName), oldNetDir);
            DgnStrcat(oldUpdtstrcName, sizeof(oldUpdtstrcName),
                      "updtstrc.bat");
            fpTempFile=saferFopenOrExit(oldUpdtstrcName, eFopenRead);
        }
        FILE *fpTempFile2=saferFopenOrExit("updtstrc.bat", eFopenWrite);
        char buffer[TL_MAXSTRSIZE+1]="";
        int label=0;
        BOOL foundEcho=FALSE;
        while(!feof(fpTempFile))
        {
            if (fgets(buffer, TL_MAXSTRSIZE, fpTempFile)==NULL)
            {
                break;
            }
            const char *suffix=getSuffixOfInsensitivePrefix(":label",buffer);
            if(suffix!=NULL)
            {
                label=atoi(suffix);
            }
            else
            {
                suffix=getSuffixOfInsensitivePrefix(":lab",buffer);
                if(suffix!=NULL)
                {
                    label=atoi(suffix);
                }
            }
            if(isInsensitivePrefix(":helpecho",buffer))
            {
                saferFprintf(
                    fpTempFile2,
                    ":helpecho\n"
                    "rem WARNING: everything after this point is edible.\n"
                    "echo call updtstrc 2 > updthelp.bat\n\n"
                    ":lab2\n:end\n");
                foundEcho=TRUE;
                break;
            }
            else
            {
                if(label<=1)
                {
                    saferFputs(buffer, fpTempFile2);
                }
            }
        }
        saferFclose(fpTempFile);
        saferFclose(fpTempFile2);
        if ((label==0) || (foundEcho==FALSE))
        {
            PrintWrapped0("Couldn't find label in updtstrc.bat.");
            pauseAndExit();
        }
    }

    // rootdir.mak
    if(configUseRootdirMak())
    {
        if(!createRootdir(rootDir, E_CRLF))
        {
            return FALSE;
        }
    }

    // updthelp.bat
    if(configUseUpdtstrc() && !createUpdthelp())
    {
        return FALSE;
    }

    char origWorkDir[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(origWorkDir, sizeof(origWorkDir), gWorkDirectory);
    
    readLocalConfig(FALSE);

    if(bActuallyForkproj)
    {
        saferRemove(TLIBWORK_TRK, FALSE);
        
        FILE *fpSrcLst=NULL;
        if (!saferFopen(&fpSrcLst, "src.lst", eFopenRead))
        {
            return FALSE;
        }

        // Create all files in src.lst, which already has the correct
        // contents.  But don't create src.lst itself yet, since we have it
        // open.
        int indexForPrevChangesTxt=0;
        FileListReader srcLstReader(fpSrcLst, "src.lst", eSrcLst, TRUE);
        while(!srcLstReader.done())
        {
            srcLstReader.next();
            if(srcLstReader.done())
            {
                break;
            }
            if(!strcmp(srcLstReader.currentFile(), "changes0.txt"))
            {
                assert(indexForPrevChangesTxt==0);
                indexForPrevChangesTxt++;
            }
            else if(!strcmp(srcLstReader.currentFile(), "changes1.txt"))
            {
                assert(indexForPrevChangesTxt==1);
                indexForPrevChangesTxt++;
            }
            else if(!strcmp(srcLstReader.currentFile(), "changes2.txt"))
            {
                assert(indexForPrevChangesTxt==2);
                indexForPrevChangesTxt++;
            }
            else if(!strcmp(srcLstReader.currentFile(), "changes3.txt"))
            {
                assert(indexForPrevChangesTxt==3);
                indexForPrevChangesTxt++;
            }
            else if(!strcmp(srcLstReader.currentFile(), "changes4.txt"))
            {
                assert(indexForPrevChangesTxt==4);
                indexForPrevChangesTxt=-1;
            }
            if(strcmp(srcLstReader.currentFile(), "src.lst") != 0 &&
               !tlibCreate(FALSE, srcLstReader.currentFile(),
                           FALSE, FALSE, FALSE, "1",
                           oldNetDir, NULL,
                           forkedFromVersionComment, 0, NULL))
            {
                PrintWrapped1("File %s could not be created "
                              "in your new project.",
                              srcLstReader.currentFile());
                return FALSE;
            }
        }
        saferFclose(fpSrcLst);
        char prevChangesTxtName[TL_MAXSTRSIZE+1]="";
        if(indexForPrevChangesTxt >= 0)
        {
            DgnSprintf(prevChangesTxtName, sizeof(prevChangesTxtName),
                       "changes%d.txt", indexForPrevChangesTxt);
            char oldChanName[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(oldChanName, sizeof(oldChanName), oldNetDir);
            DgnStrcat(oldChanName, sizeof(oldChanName), "changes.txt");
            saferCopy(oldChanName, prevChangesTxtName, TRUE);
            if(!tlibCreate(FALSE, prevChangesTxtName,
                           TRUE, FALSE, FALSE, "1",
                           NULL, NULL,
                           "Initial revision", 0, NULL))
            {
                PrintWrapped1("File %s could not be created "
                              "in your new project.",
                              prevChangesTxtName);
                return FALSE;
            }
        }
        if(!tlibCreate(FALSE, "src.lst",
                       FALSE, FALSE, FALSE, "1",
                       oldNetDir, NULL,
                       forkedFromVersionComment, 0, NULL))
        {
            PrintWrapped1("File %s could not be created "
                          "in your new project.",
                          "src.lst");
            return FALSE;
        }
        {
            FILE *fpComments = NULL;
            if(!saferFopen(&fpComments, "comments.txt", eFopenWrite))
            {
                return FALSE;
            }
            char buffer[TL_MAXSTRSIZE+1]="";
            DgnSprintf(buffer, sizeof(buffer), "%s\n", gUserName);
            saferFputs(buffer, fpComments);
            DgnSprintf(buffer, sizeof(buffer),
                       "    %s using \"tlm forkproj\".\n",
                       forkedFromVersionComment);
            saferFputs(buffer, fpComments);
            if(indexForPrevChangesTxt >= 0)
            {
                DgnSprintf(buffer, sizeof(buffer),
                           "    Previous project history saved as %s.\n",
                           prevChangesTxtName);
            }
            else
            {
                DgnSprintf(buffer, sizeof(buffer),
                           "    Previous project history not saved, "
                           "as changes[0-4].txt already exist.\n");
            }
            saferFputs(buffer, fpComments);
            saferFclose(fpComments);
        }
        const char *commentsArgv[] = { "@version.txt" };
        if(!tlibCkinbeg(TRUE, forkedFromVersionString,
                        newProjectVersionBumpOrOverride,
                        "version.txt", NULL) ||
           !tlibSnap("snapshot.txt", TRUE) ||
           !tlibAddcomm("comments.txt", "version.txt", TRUE) ||
           !tlibCheckin("snapshot.txt", 1, commentsArgv) ||
           !tlibCheckin("changes.txt", 1, commentsArgv) ||
           !tlibCkinend())
        {
            return FALSE;
        }
        saferRemove("changes.old", TRUE);
        saferRemove("comments.txt", TRUE);
        saferRemove("version.txt", TRUE);
    }
    else
    {
        PrintWrapped1("First versions of important files have been "
                      "created in %s.  "
                      "You should take this opportunity to examine "
                      "and/or modify them appropriately for your new "
                      "project before they're placed under version "
                      "control for the first time.  In particular, "
                      "tlmproj.cfg and tlibproj.cfg "
                      "are the most likely files to need "
                      "project-specific tweaks other than simple "
                      "comment header block changes.",
                      localDir);
        pauseForKey(FALSE);

        readLocalConfig(FALSE);

        if(!tlibCreate(FALSE, "updating.lck", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "tlib.cfg", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "tlibproj.cfg", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "tlibuser.cfg", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "tlmproj.cfg", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "tlmuser.cfg", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "snapshot.txt", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           !tlibCreate(FALSE, "changes.txt", TRUE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL) ||
           (configUseUpdtstrc() &&
            !tlibCreate(FALSE, "updtstrc.bat", TRUE, FALSE, FALSE, "1",
                        NULL, NULL,
                        forkedFromVersionComment, 0, NULL)) ||
           (configUseRootdirMak() &&
            !tlibCreate(FALSE, "rootdir.mak", TRUE, FALSE, FALSE, "1",
                        NULL, NULL,
                        forkedFromVersionComment, 0, NULL)) ||
           !srcLstAdd("src.lst") || // add src.lst to itself before making
                                    // its create the last (and not adding
                                    // it to itself during that create)
           !tlibCreate(FALSE, "src.lst", FALSE, FALSE, FALSE, "1",
                       NULL, NULL,
                       forkedFromVersionComment, 0, NULL))
        {
            PrintWrapped0("One or more important files could not be created "
                          "in your new project.");
            return FALSE;
        }
    }
    
    if(!tlibUpdateProject(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE,
                          NULL, NULL))
    {
        return FALSE;
    }

    // show an xcheck for good measure
    if(!tlibXcheck(TRUE, FALSE, FALSE, NULL, "xcheck.001", TRUE))
    {
        return FALSE;
    }
    saferSort(TRUE, TRUE, FALSE, 0, 0, TRUE, "xcheck.001", "xcheck.res");
    saferRemove("xcheck.001", TRUE);
    saferSystem0(normal, "type xcheck.res");
    if(bActuallyForkproj)
    {
        PrintWrapped0("The only difference that should appear in the above "
                      "xcheck is that you may have locally-modified copies "
                      "of updthelp.bat and xcheck.001/xcheck.res "
                      "files for the xcheck "
                      "itself.  Project forking complete!  "
                      "You should prep and checkin "
                      "in the new fork for the first time to make sure "
                      "checkins work on it.  After doing that, you must "
                      "do a checkin in the project it was forked from and "
                      "bump that project's version number (make sure to "
                      "leave room for all of the fork-derived versions "
                      "you plan to make!)");
    }
    else
    {
        PrintWrapped0("The only differences that should appear in the above "
                      "xcheck are that you may have locally-modified copies "
                      "of tlibuser.cfg, tlmuser.cfg, updthelp.bat, and/or "
                      "rootdir.mak, and xcheck.001/xcheck.res files for "
                      "the xcheck itself.  Project cloning complete!  "
                      "Now just prep and checkin for the first time to "
                      "get your snapshot going, and you're all set!");
    }
    PrintWrapped1("Please email Joev with the location and a brief "
                  "description of the new %s so that he can add it "
                  "to the list of known TLM-controlled projects.",
                  bActuallyForkproj ? "fork" : "project");

    saferChdir(oldCurrDir);

    return TRUE;
}

BOOL tlibForkproj(const char *oldNetDir, const char *netDir,
                  const char *localDir,
                  const char *newProjectName,
                  const char *newProjectVersionBumpOrOverride)
{
    char oldNetDir2[TL_MAXSTRSIZE+1];
    DgnStrcpy(oldNetDir2, sizeof(oldNetDir2), oldNetDir);
    if(oldNetDir2[strlen(oldNetDir2)-1] != '\\')
    {
        oldNetDir2[strlen(oldNetDir2)+1]='\0';
        oldNetDir2[strlen(oldNetDir2)]='\\';
    }
    PrintWrapped0("Create a new project based on an existing project...");
    if(!checkNetAndLocalDirsForInstallOrCloneproj(netDir, localDir))
    {
        return FALSE;
    }
    saferEnsureDirectoryTreePlusSlashExists(netDir);
    if(!saferCheckDirectoryEmpty(netDir))
    {
        PrintWrapped1("The new network directory %s is not empty.  Please "
                      "forkproj only into an empty or "
                      "non-existent directory.", netDir);
        return FALSE;
    }
    if(!tlibInstall(NULL, NULL, oldNetDir, localDir, localDir,
                    E_CRLF, eInstallFull))
    {
        return FALSE;
    }
    saferSpawn1(normal, eCheckRetNoneAndNoCheckValidExe,
                gChmodPath, "+w %s\\**\\*", localDir);
    if(!tlibCloneproj(oldNetDir2, netDir, localDir, localDir,
                      newProjectName, newProjectVersionBumpOrOverride, TRUE))
    {
        return FALSE;
    }
    return TRUE;
}

typedef enum TextResourceType
{
    eTlmTxtResource,
    eTlmCppResource
} TextResourceType;

void PrintTextResource(TextResourceType textRes)
{
    const char *desc="";
    switch(textRes)
    {
     case eTlmTxtResource: desc="tlm.txt documentation"; break;
     case eTlmCppResource: desc="tlm.cpp source"; break;
     default: assert(FALSE);
    }
#ifdef NAKED_CPP_FILE
    PrintWrapped1("This version of " TLM_NAME " was compiled in "
                  "isolation, and thus has no %s resource.", desc);
#else
    int textResId=0;
    switch(textRes)
    {
     case eTlmTxtResource: textResId=IDR_TLM_TXT; break;
     case eTlmCppResource: textResId=IDR_TLM_CPP; break;
     default: assert(FALSE);
    }

    BOOL bSuccess=FALSE;
    HRSRC hRsrc = FindResource(
        NULL, MAKEINTRESOURCE( textResId ),
        MAKEINTRESOURCE( IDT_TEXT_FILE ) );
    if(hRsrc != NULL)
    {
        HGLOBAL hGlb = LoadResource(NULL, hRsrc);
        if(hGlb != NULL)
        {
            const char *pszData = (const char *)LockResource(hGlb);
            if(pszData != NULL)
            {
                while(pszData[0] != '\0')
                {
                    if(pszData[0] != '\r')
                    {   // We have \r\n, we want \n
                        putc(pszData[0], stdout);
                    }
                    pszData++;
                }
                bSuccess=TRUE;
            }
            FreeResource(hGlb);
        }
    }
    if(!bSuccess)
    {
        PrintWrapped1("Error: could not find the %s resource.", desc);
    }
#endif
}

BOOL isHelpSwitch(const char *arg)
{
    return (!_stricmp(arg, "-?") || !_stricmp(arg, "-h") ||
            !_stricmp(arg, "/?") || !_stricmp(arg, "/h"));
}

const char *gHelpStrings[] =
{
    ("Usage: " TLM_NAME " [-v] [-y] [-b] [-q] [-c] keyword [arguments] "
     "where keyword is:"),
    "Meta-information:",
    "  -?,-h      -- Show this help.",
    "  -??        -- Show this help and the detailed help for every command.",
    ("  doc        -- Show the documentation (e.g. '" TLM_NAME " doc "
     "> tlm.txt'.)"),
    "  ver        -- Display version number.",
    "Getting version-controlled files:",
    "  install    -- Install a version-controlled project locally.",
    "  cloneproj  -- Clone a version-controlled project.",
    "  forkproj   -- Fork a version-controlled project.",
    "  whatsnew   -- See what has changed by looking at changes.txt.",
    "  update     -- Get newest version of all files being tracked.",
    "  get        -- Get revision of a file.",
    "Manipulating version-controlled files locally:",
    "  edit, checkout  -- Check out a file.",
    "  uncheck, unedit -- Lose changes and revert to current network version.",
    "  break      -- Break the lock on a file.  Use cautiously!",
    "  reserve    -- Reserve revision of a file.  Use cautiously!",
    "  breakres   -- Break a file's lock and reserve it.  Use cautiously!",
    "  merge      -- Merge two revisions of a file and check it out.",
    "  mergened   -- Merge two revisions of a file and don't check it out.",
    ("  backout    -- Check out a file and locally revert it to a specified "
     "version."),
    "Manipulating project structure locally:",
    "  create     -- Add a file to version control.",
    "  remove     -- Remove a file from version control.",
    "  move       -- Move a version-controlled file.",
    "  unremove   -- Unremove a file previously removed from version control.",
    "  track      -- Force a file to be added to the network tracking file.",
    "Getting file information:",
    "  info       -- Show checked out files or lock info on one file.",
    "  me         -- Show files checked out by you.",
    "  you        -- Show files checked out by someone else.",
    "  xcheck     -- Show local changes from official source.",
    "  xbackup    -- Make a backup of local changes from official source.",
    "  history    -- Show the history for a file.",
    "  infohist   -- Show the lock status and recent history for a file.",
    "  diff       -- Show the diff for a file.",
    "  diffall    -- Show the diffs for several files.",
    "Checking in your changes:",
    ("  prep, prepdiff  -- Generate comments.txt, ckinall.txt, and "
     "ckinall.bat for a checkin, and maybe also do a diffall."),
    ("Checking in your changes -- commands only used directly from "
     "ckinall.txt:"),
    "  ckinbeg    -- Begin checking in files.",
    "  checkin    -- Check in a file.",
    "  snap       -- Make a snapshot.",
    ("  modcomm    -- Modify comments.txt by merging shared filename "
     "components."),
    "  addcomm    -- Add comments to changes.txt.",
    "  ckinend    -- Finish checking in files.",
    "Miscellaneous:",
    "  unsnap     -- Unsnap from an appropriately-formatted text file.",
    "  unsnapv    -- Unsnap from the specified snapshot.txt version.",
    "  installv   -- Install from the specified snapshot.txt version.",
    "  sort       -- Sort a text file.",
    "  hash       -- Hash a text file.",
    "Obsolete commands: assumption, getnamed, mkdir, rmdir, changes, split.",
    "\n",
    (TLM_NAME " keyword {-?, -h} will give more info on that "
    "particular keyword."),
    "\n",
    (TLM_NAME " global options:"),
    ("If " TLM_NAME " -v (verbose) is specified, " TLM_NAME
     " will print commands as it executes them."),
    ("If " TLM_NAME " -y (answer yes) is specified, " TLM_NAME " will "
     "automatically assume the user answers yes to any "
     "questions it asks, which are usually of the 'Are "
     "you sure you want to continue?' variety.  Don't use this option "
     "unless you know exactly what you're doing."),
    ("If " TLM_NAME " -b (batch mode) is specified, " TLM_NAME " will "
     "never pause after errors and warnings, instead immediately exiting "
     "(in the case of an error) or continuing (in the case of a warning).  "
     "Don't use this option unless you know exactly what you're doing."),
    ("If " TLM_NAME " -q (quiet) is specified, " TLM_NAME " will "
     "never beep before errors and warnings, instead printing a <BEEP> "
     "message.  "
     "Don't use this option unless you know exactly what you're doing."),
    ("If " TLM_NAME " -c (crash into debugger) is specified, " TLM_NAME
     " will drop into the debugger on startup."),
    ("Obsolete " TLM_NAME " global options: " TLM_NAME
     " {-s, -m, -r, -o, -a}."),
    NULL
};

#define PTR_NOTE \
"Note that " TLM_NAME " takes special measures " \
"if a given file ends in .ptr; see " TLM_NAME " doc for details."

typedef enum TlmCommand
{
    eCmdAllCommands,
    eCmdVer,
    eCmdInstall,
    eCmdInstallv,
    eCmdCloneproj,
    eCmdForkproj,
    eCmdWhatsnew,
    eCmdUpdate,
    eCmdGet,
    eCmdEdit,
    eCmdUncheck,
    eCmdBreak,
    eCmdReserve,
    eCmdBreakres,
    eCmdMerge,
    eCmdMergened,
    eCmdBackout,
    eCmdCreate,
    eCmdRemove,
    eCmdUnremove,
    eCmdMove,
    eCmdTrack,
    eCmdInfo,
    eCmdMe,
    eCmdYou,
    eCmdXcheck,
    eCmdXbackup,
    eCmdHistory,
    eCmdInfohist,
    eCmdDiff,
    eCmdDiffall,
    eCmdPrep,
    eCmdPrepdiff,
    eCmdModcomm,
    eCmdCheckin,
    eCmdSnap,
    eCmdAddcomm,
    eCmdCkinbeg,
    eCmdCkinend,
    eCmdUnsnap,
    eCmdUnsnapv,
    eCmdSort,
    eCmdHash
} TlmCommand;

void showInstallUsage(BOOL bIsInstallv)
{
    const char *commandSyntax=(bIsInstallv ?
                               "installv [-cr|-lf|-crlf] [-full|-notopdirs] "
                               "<version of snapshot.txt> "
                               "[<alternate snapshot.txt location>]" :
                               "install [-cr|-lf|-crlf] [-full|-notopdirs]");
    const char *commandExample1=(bIsInstallv ? "installv" : "install");
    const char *commandExample2=(bIsInstallv ? " 375" : "");
    const char *helpRider=(bIsInstallv ?
                           ", with files as specified by the "
                           "given version of snapshot.txt," :
                           "");
    const char *altLocDoc=(bIsInstallv ?
                           "  If an <alternate snapshot.txt location> is "
                           "specified, that name will be used instead "
                           "of 'snapshot.txt' for where the snapshot "
                           "information is located." :
                           "");
    const char *ifInstallFails=(bIsInstallv ?
                                "If an installv is interrupted for "
                                "any reason, you should delete "
                                "the tree and start another installv." :
                                "If an install is interrupted for "
                                "any reason, you should either delete "
                                "the tree and start another install, "
                                "or remove every .ptr file in the tree "
                                "and perform an update.");

    PrintWrapped4("Usage: " TLM_NAME " %s <network dir> "
                  "<local dir> [<make dir>] installs a "
                  TLM_NAME "-controlled project%s "
                  "from the specified network directory into "
                  "the specified local directory.  The option of "
                  "specifying a <make dir> "
                  "(ordinarily assumed to be the same as <local dir>) "
                  "is provided for rare environments where the "
                  "directory specification used for version control "
                  "is not the same as that used for building the "
                  "project.  Note that the <make dir> argument is an "
                  "exception to the rule that '/' will be automatically "
                  "replaced by '\\' in "
                  TLM_NAME " command arguments."
                  "%s  %s  To specify the line termination for text "
                  "files use one of -cr (Mac-style), -lf (Unix-style), "
                  "or -crlf (Win32-style).  If none of "
                  "these three is specified, it uses the default "
                  "Win32-style CR/LF sequence.",
                  commandSyntax, helpRider, altLocDoc, ifInstallFails);
    PrintWrapped2("Examples: " TLM_NAME
                  " %s%s j:\\mrec c:\\mrec", commandExample1,
                  commandExample2);
    PrintWrapped2("          " TLM_NAME
                  " %s -lf%s j:\\mrec k:\\mrec /home/joev/mrec",
                  commandExample1, commandExample2);
    if(bIsInstallv)
    {
        PrintWrapped0("          " TLM_NAME
                      " installv 4347 snap97.txt j:\\mrec c:\\mrec4347");
    }
    PrintWrapped2("          " TLM_NAME
                  " %s%s v:\\code\\natspeak d:\\nat",
                  commandExample1, commandExample2);
    PrintWrapped2("          " TLM_NAME
                  " %s -notopdirs%s v:\\code\\natspeak d:\\nat",
                  commandExample1, commandExample2);
}

void showUsage(TlmCommand tlmCommand)
{
    const char *pSharedMergeHelp1=(
        "merges current version of file on your "
        "machine with current revision on network, "
        "using <version> version of filename as the "
        "root for changes.");
    const char *pSharedMergeHelp2=(
        "  If there is an error, "
        "you may be able to find the original version "
        "of your file in tlmerge.000, if the original "
        "file has been corrupted.  If <version> is \"auto\", "
        TLM_NAME " will attempt to determine from your local "
        "track file what version you have, and use that "
        "version as the root for changes.  However, this option "
        "makes it easier to lose changes if the local track "
        "file is incorrect.  Use it with caution!");

#define MAYBE_BREAK() \
    if(tlmCommand != eCmdAllCommands) \
        break; \
    else \
        PrintWrapped0("\n")

    switch(tlmCommand)
    {
     default:
        assert(!"Bad TlmCommand");
        break;

     case eCmdAllCommands:
     case eCmdVer:
        PrintWrapped0("Usage: " TLM_NAME " ver displays the version "
                      "numbers of " TLM_NAME " and of " TLIBBS_NAME ".");
        MAYBE_BREAK();

     case eCmdInstall:
        showInstallUsage(FALSE);
        MAYBE_BREAK();

     case eCmdInstallv:
        showInstallUsage(TRUE);
        MAYBE_BREAK();

     case eCmdCloneproj:
        PrintWrapped0("Usage: " TLM_NAME " cloneproj <new network dir> "
                      "<new local dir> [<new make dir>] creates a new "
                      TLM_NAME "-controlled project in the specified new "
                      "network directory with its first local "
                      "installation in the specified new local "
                      "directory.  It must be run from within "
                      "an existing installation of a " TLM_NAME "-controlled "
                      "project whose settings will be used as the "
                      "template for the new project.  "
                      "The option of specifying a <new make dir> "
                      "(ordinarily assumed to be the same as "
                        "<new local dir>) "
                      "is provided for rare environments where the "
                      "directory specification used for version control "
                      "is not the same as that used for building the "
                      "project.");
        PrintWrapped0("Example: " TLM_NAME
                      " cloneproj g:\\work\\newrec c:\\newrec");
        MAYBE_BREAK();

     case eCmdForkproj:
        PrintWrapped0("Usage: " TLM_NAME " forkproj <old network dir> "
                      "<new network dir> <new local dir> <new project name> "
                      "[<new project version>] creates a "
                      "new " TLM_NAME "-controlled project in the specified "
                      "new network directory with its first local "
                      "installation in the specified new local "
                      "directory, with its contents being taken from the "
                      "current version of the project "
                      "in the specified old network directory, its name "
                      "being changed to the specified new project name, "
                      "and its version optionally being bumped forward "
                      "to the specified new project version.");
        PrintWrapped0("Example: " TLM_NAME
                      " forkproj g:\\work\\proj g:\\work\\newfork "
                      "c:\\newfork");
        MAYBE_BREAK();

     case eCmdWhatsnew:
        PrintWrapped0("Usage: " TLM_NAME " whatsnew [-q] shows changes "
                      "since your last update.  Note that it determines "
                      "this by comparing your version of changes.txt "
                      "to the current version.  If -q (quiet) is specified, "
                      "generate diff.res but don't display the diff.");
        PrintWrapped0("Example: " TLM_NAME " whatsnew");
        MAYBE_BREAK();

     case eCmdUpdate:
        PrintWrapped0("Usage: " TLM_NAME " update [-v] [-q] [-s] [-f] "
                      "[<filename>] updates the whole "
                      "project (or just <filename>, if it's specified).  "
                      "Update behaves differently than get in "
                      "that get always touches a file in "
                      "question, while update only touches "
                      "it if necessary.  If -v (verbose update) is "
                      "specified, copious details will be printed "
                      "about each file that is or is not updated.  "
                      "If -q (quick) is specified, "
                      "update won't check to see if a file exists "
                      "in order to determine if it must be extracted, "
                      "and will only rely on the version-tracking "
                      "information.  This is dangerous, but for some "
                      "environments, conveniently faster than other "
                      "options.  "
                      "If -s (showOnly) is specified, "
                      "update will only show the files it has to update "
                      "(except it must update src.lst). "
                      "If -f (force) is specified, "
                      "update will forcibly extract every file in the "
                      "project (essentially behaving like get).  "
                      "When updating the whole project, the "
                      "convenient feature of adding any necessary "
                      "subdirectories is enabled.  " PTR_NOTE);
        PrintWrapped0("Example: " TLM_NAME " update");
        MAYBE_BREAK();

     case eCmdGet:
        PrintWrapped0("Usage: " TLM_NAME " get [-s] <filename> "
                      "[<version> [<newfilename>]] retrieves the latest "
                      "version of <filename>, or if <version> is "
                      "specified, that version.  "
                      "Also, the version number may be specified as '*' "
                      "to indicate the latest network version, '*-1' to "
                      "indicate the next-latest network version, or '-' to "
                      "indicate the version from your local track file "
                      "(note that this "
                      "is an exception to the rule against '*' characters "
                      "in " TLM_NAME " commands.)  "
                      "If -s (snapshot) is specified, then interpret the "
                      "specified version number as a version of snapshot.txt "
                      "which should be read to find the actual desired "
                      "version of <filename>.  "
                      "If <newfilename> is "
                      "specified, it is used as the destination rather "
                      "than <filename>, the extraction is not tracked, "
                      "and the destination is made read/write.  "
                      PTR_NOTE);
        PrintWrapped0("Examples: " TLM_NAME " get foo.cpp");
        PrintWrapped0("          " TLM_NAME " get foo.cpp 27 foo27.cpp");
        MAYBE_BREAK();

     case eCmdEdit:
        PrintWrapped0("Usage: " TLM_NAME " [ edit | checkout ] [-p] [-c] "
                      "<filename> retrieves the latest version of <filename> "
                      "and locks the file out to you.  If -p is specified, "
                      "it will pause if the command fails -- ordinarily, "
                      "it won't do this (unlike every other tlm command) "
                      "since it can screw up non-interactive invokations "
                      "(e.g., from an editor.)  If -c is specified, it "
                      "won't check to see that you already have the current "
                      "version of the file before allowing you to "
                      "check it out.");
        PrintWrapped0("Example: " TLM_NAME " edit foo.cpp");
        MAYBE_BREAK();

     case eCmdUncheck:
        PrintWrapped0("Usage: " TLM_NAME " [ uncheck | unedit ] <filename> "
                      "releases your lock on <filename>.");
        PrintWrapped0("Example: " TLM_NAME " uncheck foo.cpp");
        MAYBE_BREAK();

     case eCmdBreak:
        PrintWrapped0("Usage: " TLM_NAME " break <filename> breaks "
                      "the lock on filename, whoever has it.  The "
                      "file must be checked out.");
        PrintWrapped0("Example: " TLM_NAME " break foo.cpp");
        MAYBE_BREAK();

     case eCmdReserve:
        PrintWrapped0("Usage: " TLM_NAME " reserve [-s] [-c] [-r] <filename> "
                      "reserves (locks, but doesn't extract) "
                      "<filename>.  This command makes it easy "
                      "to lose other people's changes.  Use with "
                      "caution!  If -s is specified, a strong lock "
                      "on the file is forced, even if the file is "
                      "ordinarily weak-locked.  If -c is specified, it "
                      "won't check to see that you already have the current "
                      "version of the file before allowing you to "
                      "reserve it.  If -r is specified, it will also "
                      "mark the local version of the file "
                      "(along with its pointed-to files, if any) "
                      "read/write.");
        PrintWrapped0("Examples: " TLM_NAME " reserve foo.cpp");
        PrintWrapped0("          " TLM_NAME " reserve -s updating.lck");
        MAYBE_BREAK();

     case eCmdBreakres:
        PrintWrapped0("Usage: " TLM_NAME " breakres <filename> "
                      "breaks the lock on filename, whoever "
                      "has it, and then reserves it to you.  "
                      "As a convenience, if the file is not checked out, "
                      "a warning will be shown, but it will go ahead "
                      "and reserve it to you anyway.  "
                      "This command makes it easy "
                      "to lose other peoples changes.  Use with "
                      "caution!");
        PrintWrapped0("Example: " TLM_NAME " breakres foo.cpp");
        MAYBE_BREAK();

     case eCmdMerge:
        PrintWrapped2("Usage: " TLM_NAME " merge <filename> <version> %s"
                      "  It then checks the file out to you.%s",
                      pSharedMergeHelp1, pSharedMergeHelp2);
        PrintWrapped0("Example: " TLM_NAME " merge foo.cpp 10");
        MAYBE_BREAK();

     case eCmdMergened:
        PrintWrapped2("Usage: " TLM_NAME " mergened <filename> <version> %s%s",
                      pSharedMergeHelp1, pSharedMergeHelp2);
        PrintWrapped0("Example: " TLM_NAME " mergened foo.cpp 10");
        MAYBE_BREAK();

     case eCmdBackout:
        PrintWrapped0("Usage: " TLM_NAME " backout "
                      "<filename> <version> retrieves the specified "
                      "version of <filename> and locks the file out "
                      "to you.  This results in you having the file "
                      "legitimately checked out, but with local "
                      "modifications that make it the same as it was "
                      "in the specified version.");
        PrintWrapped0("Example: " TLM_NAME " backout foo.cpp 10");
        MAYBE_BREAK();
     case eCmdCreate:
        PrintWrapped0("Usage: " TLM_NAME " create [-f <forkedfromdir>] "
                      "<filename> "
                      "[<startversion> [@commentfile | comment]*] "
                      "adds <filename> to the project, checking out src.lst "
                      "if you don't already have it checked out.  Note that "
                      "executing this command only partly creates the file; "
                      "the revised src.lst must be checked in before the "
                      "change is visible to other installations "
                      "(once they're updated).  "
                      "Please don't use a path with '.\\' or '..\\' in it, "
                      "and don't create a new file with the name "
                      "of an old file that has been removed "
                      "or moved away (see '" TLM_NAME
                      " unremove' for such a case).  "
                      "The starting version will be 1 unless <startversion> "
                      "is specified and has a value of other than 1 "
                      "(this should not be done without a good reason.)  "
                      "If comment arguments are specified (meaning that a "
                      "<startversion> argument must have been specified, "
                      "even if it was 1), the file will be created with "
                      "comments taken sequentially from the command line "
                      "and the specified files, in addition to the default "
                      "comment of 'Initial revision'.  "
                      "If -f <forkedfromdir> is specified, then forking "
                      "semantics will be used: 1. The current history in "
                      "the <forkedfromdir> directory will be obtained; 2. "
                      "This history will be added at the end of the "
                      "file's initial comments; 3. The <startversion>, "
                      "if specified, is ignored, and instead the "
                      "starting version will be one greater than the "
                      "existing history's latest version; 4. The file is "
                      "not re-checked-out at the end of the creation "
                      "process.  Note that for a file to be created, it "
                      "(and its pointed files, if it's a .ptr file) "
                      "must exist and be writable.  " PTR_NOTE);
        PrintWrapped0("Example: " TLM_NAME " create foo.cpp");
        MAYBE_BREAK();

     case eCmdRemove:
        PrintWrapped0("Usage: " TLM_NAME " remove <filename> "
                      "removes <filename> from the project, "
                      "checking out src.lst "
                      "if you don't already have it checked out.  Note that "
                      "executing this command only partly removes the file; "
                      "the revised src.lst must be checked in before the "
                      "change is visible to other installations "
                      "(once they're updated).  " TLM_NAME " remove also "
                      "checks out the file to DELETED_BY_<name> and "
                      "removes your local copy.  The file must not "
                      "be checked out.");
        PrintWrapped0("Example: " TLM_NAME " remove foo.cpp");
        MAYBE_BREAK();

     case eCmdUnremove:
        PrintWrapped0("Usage: " TLM_NAME " unremove <filename> "
                      "takes a file that had previously been removed "
                      "or moved, and resurrects it into version "
                      "control with its old contents.  You then "
                      "presumably will want to check it out and put in "
                      "the appropriate new contents.  This command "
                      "is provided solely for the ability to reuse "
                      "parts of the namespace, in situations where "
                      TLM_NAME " create would fail because the old "
                      "library was preserved to keep the snapshot "
                      "valid.  Note that for a file to be unremoved, it "
                      "(and its pointed files, if it's a .ptr file) "
                      "should not exist locally.  " PTR_NOTE);
        PrintWrapped0("Example: " TLM_NAME " unremove foo.cpp");
        MAYBE_BREAK();

     case eCmdMove:
        PrintWrapped0("Usage: " TLM_NAME " move <filename1> "
                      "<filename2> moves <filename1> to <filename2> "
                      "in the project, checking out src.lst "
                      "if you don't already have it checked out.  Note that "
                      "executing this command only partly moves the file; "
                      "the revised src.lst must be checked in before the "
                      "change is visible to other installations "
                      "(once they're updated).  "
                      "Please don't use a path with '.\\' "
                      "or '..\\' in it, and don't move a "
                      "file to the location of an old file that has been "
                      "removed or moved away.  " TLM_NAME " move also "
                      "moves your local copy.  You must have the "
                      "file checked out, or " TLM_NAME " must be able "
                      "to check it out for you.");
        PrintWrapped0("Example: " TLM_NAME " move bar\\foo.cpp "
                      "baz\\foo.cpp");
        MAYBE_BREAK();

     case eCmdTrack:
        PrintWrapped0("Usage: " TLM_NAME " track [-f] <filename> forces "
                      "the given file to be tracked by the tlib "
                      "library's tlibwork.trk.  If -f is specified, the file "
                      "will first be removed from the tracking file before "
                      "it is added back in (among other things, this forces "
                      "the reference copy to be refreshed.)  "
                      "This command should generally "
                      "only be needed during advanced version "
                      "control trickery.");
        PrintWrapped0("Example: " TLM_NAME " track foo.cpp");
        MAYBE_BREAK();

     case eCmdInfo:
        PrintWrapped0("Usage: " TLM_NAME " info [-f] [<filename>] "
                      "displays info about the given file "
                      "(or all files in the project if <filename> "
                      "isn't provided).  If -f is specified, it "
                      "includes info about files that have been "
                      "deleted from the project too.");
        PrintWrapped0("Example: " TLM_NAME " info foo.cpp");
        MAYBE_BREAK();

     case eCmdMe:
        PrintWrapped0("Usage: " TLM_NAME " me displays which files "
                      "are checked out to you.");
        PrintWrapped0("Example: " TLM_NAME " me");
        MAYBE_BREAK();

     case eCmdYou:
        PrintWrapped0("Usage: " TLM_NAME " you <username> displays "
                      "which files are checked out to <username>.");
        PrintWrapped0("Example: " TLM_NAME " you JohnD");
        MAYBE_BREAK();

     case eCmdXcheck:
        PrintWrapped0("Usage: " TLM_NAME " xcheck [-f | -s | -l] [-r] "
                      "displays info as "
                      "to how the local source tree differs from "
                      "the network version.  If -f is specified, full "
                      "information is given.  If -s is specified, only "
                      "information about already version-controlled "
                      "files will be given.  If -l is specified, rather "
                      "than displaying difference information, xcheck "
                      "simply lists all the files in the local "
                      "installation of the project, including those "
                      "referenced by .ptr files, and not including "
                      "those excluded by the local configuration as "
                      "to which files should be updated.  If -r is specified "
                      "then the network reference copy is not checked.");
        PrintWrapped0("Example: " TLM_NAME " xcheck");
        MAYBE_BREAK();

     case eCmdXbackup:
        PrintWrapped0("Usage: " TLM_NAME " xbackup [-f | -s] [-r] <dirname> "
                      "will make a new subdirectory in <dirname> and copy "
                      "all files in the local source tree that differ "
                      "from the network version into that subdirectory, "
                      "with their tree structure intact.  If -f is "
                      "specified, even the files that are ordinarily "
                      "considered irrelevant will be copied.  If -s "
                      "is specified, only already "
                      "version-controlled files will be copied.  "
                      "If -r is specified "
                      "then the network reference copy is not checked.");
        PrintWrapped0("Example: " TLM_NAME " xbackup c:\\backup");
        MAYBE_BREAK();

     case eCmdHistory:
        PrintWrapped0("Usage: " TLM_NAME " history <filename> gives "
                      "the history of a file.");
        PrintWrapped0("Example: " TLM_NAME " history foo.cpp");
        MAYBE_BREAK();

     case eCmdInfohist:
        PrintWrapped0("Usage: " TLM_NAME " infohist <filename> gives "
                      "the lock status and recent history of a file.");
        PrintWrapped0("Example: " TLM_NAME " infohist foo.cpp");
        MAYBE_BREAK();

     case eCmdDiff:
        PrintWrapped0("Usage: " TLM_NAME " diff [-s] [-b | -w | -t | -c] "
                      "[-q] "
                      "<filename> [<versionnumber> [<versionnumber2>]] gives "
                      "the diff of <filename> with the official "
                      "specified version of <filename>. If "
                      "<versionnumber> is not specified, the "
                      "latest version is assumed.  If "
                      "<versionnumber2> is specified, the diff "
                      "is between ver1 and ver2, rather than "
                      "between local and ver1.  "
                      "Also, either version number may be specified as '*' "
                      "to indicate the latest network version, '*-1' to "
                      "indicate the next-latest network version, or '-' to "
                      "indicate the version from your local track file "
                      "(note that this "
                      "is an exception to the rule against '*' characters "
                      "in " TLM_NAME " commands.)  "
                      "If -s (snapshot) is specified, then interpret each "
                      "specified version number as a version of snapshot.txt "
                      "which should be read to find the actual desired "
                      "version of <filename>.  "
                      "The default diff command is \"diff\".  "
                      "If -b is specified, diff is instructed to "
                      "ignore whitespace differences.  "
                      "If -w is specified, then windiff is used to "
                      "generate the diff.  "
                      "If -m is specified, then winmerge is used to "
                      "generate the diff.  "
                      "If -t is specified, then tlibcomp is used to "
                      "generate the diff.  "
                      "If -c is specified, then the custom executable "
                      "specified by your tlmuser.cfg's "
                      "CUSTOM_DIFF_EXECUTABLE and "
                      "CUSTOM_DIFF_EXECUTABLE_IS_INTERACTIVE settings "
                      "is used to generate the diff.  "
                      "The following switch applies only to the "
                      "non-interactive commands (the default command, "
                      "and the custom command if it's not specified as "
                      "interactive): "
                      "if -q (quiet) is specified, then generate diff.res "
                      "but don't display the diff.");
        PrintWrapped0("Example: " TLM_NAME " diff foo.cpp");
        MAYBE_BREAK();

     case eCmdDiffall:
        PrintWrapped0("Usage: " TLM_NAME " diffall [-b | -w | -t | -c] "
                      "[filename [snapver1 [snapver2]]] gives the diff "
                      "of all currently checked out files "
                      "(or the files listed in filename, if given) "
                      "with the official versions in the tlib "
                      "library.  "
                      "The default diff command is \"diff\".  "
                      "If -b is specified, diff is instructed to "
                      "ignore whitespace differences.  "
                      "If -w is specified, then windiff is used to "
                      "generate the diff.  "
                      "If -m is specified, then winmerge is used to "
                      "generate the diff.  "
                      "If -t is specified, then tlibcomp is used to "
                      "generate the diff.  "
                      "If -c is specified, then the custom executable "
                      "specified by your tlmuser.cfg's "
                      "CUSTOM_DIFF_EXECUTABLE and "
                      "CUSTOM_DIFF_EXECUTABLE_IS_INTERACTIVE settings "
                      "is used to generate the diff.  "
                      "If snapver1 is specified, it gives "
                      "the differences between the local files "
                      "and the versions gotten from that version of "
                      "snapshot.txt.  If snapver2 is also specified, it "
                      "gives the differences between the versions "
                      "gotten from those two versions of snapshot.txt "
                      "(but only for the files whose versions actually "
                      "changed.)  "
                      "The differences are stored in diffall.res.");
        PrintWrapped0("Example: " TLM_NAME " diffall tlck.004");
        MAYBE_BREAK();

     case eCmdPrep:
        PrintWrapped0("Usage: " TLM_NAME " prep [filename] creates a "
                      "comment file (comments.txt), a command file "
                      "(ckinall.txt), and a batch file that executes "
                      "the command file's commands (ckinall.bat) "
                      "from the output of " TLM_NAME
                      " me (tlck.004).  If <filename> "
                      "is given, then it is used as the list of "
                      "files to prepare to check in instead of performing "
                      TLM_NAME " me.  In your project root work "
                      "directory, edit comments.txt and ckinall.txt, "
                      "adding full comments to comments.txt, and brief "
                      "comments to 'checkin' lines in ckinall.txt.  "
                      "Then just run ckinall and all "
                      "files will be checked in and changes.txt and "
                      "snapshot.txt will be updated.  "
                      "See " TLM_NAME " checkin -? for details on how "
                      "to document checkin lines in ckinall.txt.");
        PrintWrapped0("Example: " TLM_NAME " prep");
        MAYBE_BREAK();

     case eCmdPrepdiff:
        PrintWrapped0("Usage: " TLM_NAME " prepdiff [-b | -w | -t | -c] "
                      "[filename] creates a "
                      "comment file (comments.txt), a command file "
                      "(ckinall.txt), a batch file that executes "
                      "the command file's commands (ckinall.bat), "
                      "and a diff file (diffall.res) "
                      "from the output of " TLM_NAME " me (tlck.004).  "
                      "The default diff command is \"diff\".  "
                      "If -b is specified, diff is instructed to "
                      "ignore whitespace differences.  "
                      "If -w is specified, then windiff is used to "
                      "generate the diff.  "
                      "If -m is specified, then winmerge is used to "
                      "generate the diff.  "
                      "If -t is specified, then tlibcomp is used to "
                      "generate the diff.  "
                      "If -c is specified, then the custom executable "
                      "specified by your tlmuser.cfg's "
                      "CUSTOM_DIFF_EXECUTABLE and "
                      "CUSTOM_DIFF_EXECUTABLE_IS_INTERACTIVE settings "
                      "is used to generate the diff.  "
                      "If <filename> "
                      "is given, then it is used instead of performing "
                      TLM_NAME " me.  In your project root work "
                      "directory, edit comments.txt and ckinall.txt, "
                      "adding full comments to comments.txt, and brief "
                      "comments to 'checkin' lines in ckinall.txt, "
                      "using diffall.res to help "
                      "indicate the changes you need to remark upon.  "
                      "Then just run ckinall and all "
                      "files will be checked in and changes.txt and "
                      "snapshot.txt will be updated.  "
                      "See " TLM_NAME " checkin -? for details on how "
                      "to document checkin lines in ckinall.txt.");
        PrintWrapped0("Example: " TLM_NAME " prepdiff");
        MAYBE_BREAK();

     case eCmdModcomm:
        PrintWrapped0("Usage: " TLM_NAME " modcomm <filename> [<outfilename>] "
                      "modifies <filename> in order to make it "
                      "easier to read.  If <outfilename> is "
                      "not given, 'tlmodcom.001' is assumed.  "
                      TLM_NAME " modcomm looks in <filename> for "
                      "single lines, each containing optional whitespace, "
                      "followed by the name of a file in the local "
                      "or network src.lst.  When it finds a "
                      "sequence of consecutive lines which differ in "
                      "in exactly one of their path components, it "
                      "merges them all into one line.  E.g., "
                      "'aaa\\bbb\\c.cpp' and 'aaa\\bbb\\d.cpp' would "
                      "be merged into 'aaa\\bbb\\{c.cpp, d.cpp}'; "
                      "'aaa\\bbb\\c.cpp' and 'aaa\\ddd\\c.cpp' "
                      "would be merged into "
                      "'aaa\\{bbb, ddd}\\c.cpp'.  "
                      "If this clause is not met, but the files have the "
                      "same name and differ in the entire directory "
                      "component, they will be merged with respect to "
                      "the differing directory components.  E.g., "
                      "'aaa\\c.cpp' and 'aaa\\bbb\\c.cpp' would "
                      "be merged into '{aaa, aaa\\bbb}\\c.cpp'.  "
                      "A merge is rejected "
                      "if it will cause a line to go over 75 characters.");
        PrintWrapped0("Example: " TLM_NAME " modcomm");
        MAYBE_BREAK();

     case eCmdCheckin:
        PrintWrapped0("Usage: " TLM_NAME " checkin <filename> "
                      "[@commentfile | comment]* checks "
                      "in a (already created) file with the comments "
                      "taken sequentially from the command line and the "
                      "specified files.  "
                      "It should not be called "
                      "interactively, only from the ckinall.bat and "
                      "ckinall.txt files created by " TLM_NAME " prep.  "
                      "Note that if the file has not "
                      "been changed, " TLIBBS_NAME " will check in "
                      "a new version of it into the revision "
                      "history anyway.  "
                      "Note that for a file to be checked in, it "
                      "(and its pointed files, if it's a .ptr file) "
                      "must exist and be writable.  " PTR_NOTE);
        PrintWrapped0("Example: " TLM_NAME " checkin foo.cpp @mycomm.txt");
        MAYBE_BREAK();

     case eCmdSnap:
        PrintWrapped0("Usage: " TLM_NAME " snap [-p] updates "
                      "the project snapshot stored in snapshot.txt.  "
                      "It should not be called "
                      "interactively, only from the ckinall.bat and "
                      "ckinall.txt files created by " TLM_NAME " prep.  "
                      "If -p is specified, the versions on changes.txt "
                      "and snapshot.txt "
                      "will be predictively bumped in the generated "
                      "snapshot, simulating the effect of these files' "
                      "each being subsequently checked in.");
        PrintWrapped0("Example: " TLM_NAME " snap");
        MAYBE_BREAK();

     case eCmdAddcomm:
        PrintWrapped0("Usage: " TLM_NAME " addcomm <filename> "
                      "<version input file> "
                      "adds comments from <filename> "
                      "to the appropriate place in changes.txt.  "
                      "It should not be called "
                      "interactively, only from the ckinall.bat and "
                      "ckinall.txt files created by " TLM_NAME " prep.  "
                      "The <version input file> is used for the project "
                      "version number inserted into the text of "
                      "changes.txt.  Note that changes.txt "
                      "must have already been checked out.  "
                      "Must be run from your project root work "
                      "directory.");
        PrintWrapped0("Example: " TLM_NAME
                      " addcomm comments.txt");
        MAYBE_BREAK();

     case eCmdCkinbeg:
        PrintWrapped0("Usage: " TLM_NAME " ckinbeg "
                      "-c <ckinall.bat syntax version> "
                      "-v <version output file> -k <ckinall.txt filename> "
                      "[-b [nobump | <exact version>]] "
                      "begins the checkin process.  "
                      "It should not be called "
                      "interactively, only from the ckinall.bat and "
                      "ckinall.txt files created by " TLM_NAME " prep.  "
                      "The -c option is used so that TLM "
                      "can avoid executing with a ckinall.bat designed "
                      "for a previous version, where "
                      "non-backwards-compatible changes to relevant TLM "
                      "commands have been made.  "
                      "The -v <version output file> option is used so that "
                      "TLM can enter the predicted project version number "
                      "into this file, so it can be used in subsequent "
                      "checkin and addcomm commands.  "
                      "The -k <ckinall.txt filename> is used to verify that "
                      "all of the files that will be checked in during the "
                      "specified checkin script are in fact writable "
                      "and checked out to the current user.  "
                      "The -b <bump type> option "
                      "must be specified (and may only be specified) in a "
                      "project with MAINTAIN_ENG_STYLE_PROJECT_VERSION=1.  "
                      "When this option is specified, "
                      "the -b option's enumerated "
                      "bump type nobump will cause the fourth "
                      "version component to be bumped; or, if any other "
                      "option is specified to "
                      "-b, it's parsed as a full A.BB.CCC.DDD "
                      "version number "
                      "(e.g., 2.02.500.000), and used as the "
                      "exact new version number; note however that it must "
                      "move the version number forward.");
        MAYBE_BREAK();

     case eCmdCkinend:
        PrintWrapped0("Usage: " TLM_NAME " ckinend finishes the "
                      "checkin process, verifying that everything "
                      "has completed successfully and unchecking "
                      "updating.lck to allow others to update and "
                      "check in again.  "
                      "It should not be called "
                      "interactively, only from the ckinall.bat and "
                      "ckinall.txt files created by " TLM_NAME " prep.");
        MAYBE_BREAK();

     case eCmdUnsnap:
        PrintWrapped0("Usage: " TLM_NAME " unsnap [-i] [-n] [-c] [-v] "
                      "<snapfile> "
                      "retrieves the files specified by <snapfile>.  "
                      "If -i (incremental) is specified, it will "
                      "only retrieve files that have different versions "
                      "in the specified snapshot than the versions that "
                      "are locally present.  "
                      "If -n (newer) and -i are both specified, it will "
                      "only retrieve files that have newer versions "
                      "in the specified snapshot than the versions that "
                      "are locally present (only useful for getting "
                      "some esoteric information out of broken snapshots.)  "
                      "If -c (check libraries) is specified, files listed "
                      "in the specified snapshot that don't have "
                      "corresponding library files on the network will be "
                      "silently ignored (only useful for getting some "
                      "esoteric information out of broken snapshots.)  "
                      "If -v (verbose unsnap) is "
                      "specified, copious details will be printed "
                      "about each file that is or is not unsnapped.");
        PrintWrapped0("Example: " TLM_NAME " unsnap snapshot.txt");
        MAYBE_BREAK();

     case eCmdUnsnapv:
        PrintWrapped0("Usage: " TLM_NAME " unsnapv [-i] [-n] [-c] [-v] "
                      "<version of snapshot.txt> "
                      "[<alternate snapshot.txt location>] "
                      "retrieves the files as "
                      "specified by that version of snapshot.txt.  "
                      "If -i (incremental) is specified, it will "
                      "only retrieve files that have different versions "
                      "in the specified snapshot than the versions that "
                      "are locally present.  "
                      "If -n (newer) and -i are both specified, it will "
                      "only retrieve files that have newer versions "
                      "in the specified snapshot than the versions that "
                      "are locally present (only useful for getting "
                      "some esoteric information out of broken snapshots.)  "
                      "If -c (check libraries) is specified, files listed "
                      "in the specified snapshot that don't have "
                      "corresponding library files on the network will be "
                      "silently ignored (only useful for getting some "
                      "esoteric information out of broken snapshots.)  "
                      "If -v (verbose unsnap) is "
                      "specified, copious details will be printed "
                      "about each file that is or is not unsnapped.  "
                      "If an <alternate snapshot.txt location> is "
                      "specified, that name will be used instead "
                      "of 'snapshot.txt' for where the snapshot "
                      "information is located.");
        PrintWrapped0("Examples: " TLM_NAME " unsnapv -i 375");
        PrintWrapped0("          " TLM_NAME " unsnapv 4347 snap97.txt");
        MAYBE_BREAK();

     case eCmdSort:
        PrintWrapped0("Usage: " TLM_NAME " sort [-i] [-s<n>] <infile> "
                      "<outfile> sorts the text file at <infile> into "
                      "the location specified by <outfile>.  If -i is "
                      "given, the sort is case-insensitive.  If -s<n> "
                      "is given, the sort starts at the zero-based "
                      "column <n>.  It has a hard limit on the number "
                      "of characters per line, and is provided only "
                      "because it is needed internally for other "
                      "purposes and convenient to be surfaced.");
        PrintWrapped0("Example: " TLM_NAME " sort -i -s0 src.lst src.2");
        MAYBE_BREAK();

     case eCmdHash:
        PrintWrapped0("Usage: " TLM_NAME " hash <infile> "
                      "<outfile> hashes the text file at <infile> into "
                      "the location specified by <outfile>.  "
                      "It has a hard limit on the number "
                      "of characters per line, and is provided only "
                      "because it is handy for encoding files so as to "
                      "remove any actual information but leave the "
                      "approximate pattern of line similarity that will "
                      "cause diff algorithms to behave roughly the same "
                      "way.");
        PrintWrapped0("Example: " TLM_NAME " hash changes.txt changes.2");
        MAYBE_BREAK();
        
    }
}

void tlibVer()
{
    char tempConfigFile[TL_MAXSTRSIZE+1]="";
    saferTmpnam(tempConfigFile, sizeof(tempConfigFile));
    FILE *fpConfig=saferFopenOrExit(tempConfigFile, eFopenWrite);
    saferFputs("say %TLIBNAME%.%TLIBPROG% running in %TLIBMODE% mode "
               "(%TLIBWORDSIZE%-bit); SN=%tlibcfg:serialno%.\n", fpConfig);
    saferFclose(fpConfig);

    char envSetting[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(envSetting, sizeof(envSetting), "!");
    DgnStrcat(envSetting, sizeof(envSetting), tempConfigFile);
    saferPutenv("TLIBCFG", envSetting);
    // You can add -ctmp.tmp before q to put TLIB's configuration as
    // it understands it into tmp.tmp.
    saferTlibbs0(normal, "q");
    saferPutenv("TLIBCFG", "");
    saferRemove(tempConfigFile, FALSE);
}

void initEnvironmentVariables()
{
    saferGetenv(gTlibbsPath, sizeof(gTlibbsPath), "TLM_TLIBBS_PATH");
    if(gTlibbsPath[strlen(gTlibbsPath)-1]=='\\')
    {
        PrintWrapped1("Can't get TLM_TLIBBS_PATH environment variable.  "
                      TLM_TLIBBS_PATH_RECOMMENDATION, gTlibMinVerStr);
        pauseAndExit();
    }
    else
    {
        const char *pLastSlash=strrchr(gTlibbsPath, '\\');
        if(pLastSlash == NULL)
        {
            PrintWrapped1("TLM_TLIBBS_PATH environment variable must be "
                          "an absolute path.  "
                          TLM_TLIBBS_PATH_RECOMMENDATION, gTlibMinVerStr);
            pauseAndExit();
        }
        else
        {
            const char *pLastDot=strrchr(gTlibbsPath, '.');
            if(pLastDot == NULL || pLastDot < pLastSlash)
            {
                DgnStrcat(gTlibbsPath, sizeof(gTlibbsPath), ".exe");
            }
            if(!saferFindFileAllowMismatchedCase(gTlibbsPath))
            {
                PrintWrapped1("TLM_TLIBBS_PATH environment variable must "
                              "point to a valid executable.  "
                              TLM_TLIBBS_PATH_RECOMMENDATION, gTlibMinVerStr);
                pauseAndExit();
            }
        }
        DgnStrcpy(gTlibcompPath, sizeof(gTlibcompPath), gTlibbsPath);
        char *lastSlash=strrchr(gTlibcompPath, '\\');
        if(lastSlash!=NULL)
        {
            lastSlash[1]='\0';
        }
        else
        {
            gTlibcompPath[0]='\0';
        }
        DgnStrcpy(gTlmergePath, sizeof(gTlmergePath), gTlibcompPath);
        DgnStrcpy(gTlibSerPath, sizeof(gTlibSerPath), gTlibcompPath);
        DgnStrcat(gTlibcompPath, sizeof(gTlibcompPath), "tlibcomp.exe");
        DgnStrcat(gTlmergePath, sizeof(gTlmergePath), "tlmerge.exe");
        DgnStrcat(gTlibSerPath, sizeof(gTlibSerPath), "tlib.ser");
    }

    saferGetenv(gTempPath, sizeof(gTempPath), "TEMP");
    if(gTempPath[0]=='\0')
    {
        saferGetenv(gTempPath, sizeof(gTempPath), "TMP");
    }
    if(gTempPath[0]=='\0')
    {
        PrintWrapped0("Can't get TEMP or TMP environment variables.");
        pauseAndExit();
    }
    saferGetenv(gUserName, sizeof(gUserName), "TLIBID");
    if(gUserName[0]=='\0')
    {
        PrintWrapped0("Can't get TLIBID environment variable.  This should "
                      "be a case-correct version of your login name, e.g., "
                      "'set TLIBID=JohnD'.");
        pauseAndExit();
    }
    char binDir[TL_MAXSTRSIZE+1]="";
    saferGetenv(binDir, sizeof(binDir), "BIN_DIR");
    if(binDir[0]!='\0' && binDir[strlen(binDir)-1]!='\\')
    {
        PrintWrapped0("BIN_DIR environment variable must end in a "
                      "backslash.");
        pauseAndExit();
    }
    DgnStrcpy(gChmodPath, sizeof(gChmodPath), binDir);
    DgnStrcpy(gTailPath, sizeof(gTailPath), binDir);
    DgnStrcpy(gDiffPath, sizeof(gDiffPath), binDir);
    DgnStrcpy(gWinMergePath, sizeof(gWinMergePath), binDir);
    DgnStrcpy(gMorePath, sizeof(gMorePath), binDir);
    DgnStrcat(gChmodPath, sizeof(gChmodPath), "chmod.exe");
    DgnStrcat(gTailPath, sizeof(gTailPath), "tail.exe");
    DgnStrcat(gDiffPath, sizeof(gDiffPath), "diff.exe");
    DgnStrcat(gWinMergePath, sizeof(gWinMergePath), "winmerge.exe");
    DgnStrcat(gMorePath, sizeof(gMorePath), "more.exe");

    // Avoid any idiosyncratic options the user may have in the environment
    // variable overrides controlling these executables.
    saferPutenv("TAIL", "");
    saferPutenv("DIFF", "");
    saferPutenv("MORE", "");

    // We want to guarantee use of cmd.exe under WinNT and command.com under
    // Win9x.
    {
        const char *desiredCmd=(gbWinNT ? "cmd.exe" : "command.com");
        char comSpec[TL_MAXSTRSIZE+1]="";
        saferGetenv(comSpec, sizeof(comSpec), "TLM_COMSPEC");
        BOOL bFoundOne = FALSE;
        if(comSpec[0]!='\0')
        {
            const char *pLastSlash=strrchr(comSpec, '\\');
            if(pLastSlash!=NULL &&
               !_stricmp(desiredCmd, pLastSlash+1) &&
               saferFindFileAllowMismatchedCase(comSpec))
            {
                DgnStrcpy(gComSpecPath, sizeof(gComSpecPath), comSpec);
                bFoundOne=TRUE;
            }
        }
        saferGetenv(comSpec, sizeof(comSpec), "COMSPEC");
        if(!bFoundOne && comSpec[0]!='\0')
        {
            const char *pLastSlash=strrchr(comSpec, '\\');
            if(pLastSlash!=NULL &&
               !_stricmp(desiredCmd, pLastSlash+1) &&
               saferFindFileAllowMismatchedCase(comSpec))
            {
                DgnStrcpy(gComSpecPath, sizeof(gComSpecPath), comSpec);
                bFoundOne=TRUE;
            }
        }
        if(!bFoundOne)
        {
            PrintWrapped1("Either COMSPEC or TLM_COMSPEC environment "
                          "variable must be a full path pointing to "
                          "the system-default %s binary.", desiredCmd);
            pauseAndExit();
        }
    }
    gbEnvironmentInitialized=TRUE;
}

void checkTlibSer()
{
    BOOL bSerialnoPresent=FALSE;
    if(saferFindFileAllowMismatchedCase(gTlibSerPath))
    {
        FILE *fpTlibSer=saferFopenOrExit(gTlibSerPath, eFopenRead);
        char buffer[TL_MAXSTRSIZE+1]="";
        while(fgets(buffer, TL_MAXSTRSIZE, fpTlibSer))
        {
            if(isInsensitivePrefix("serialno ", buffer))
            {
                bSerialnoPresent=TRUE;
                break;
            }
        }
        saferFclose(fpTlibSer);
    }
    if(!bSerialnoPresent)
    {
        PrintWrapped1("Your tlib installation doesn't appear to have "
                      "a properly configured serial number file at %s.  "
                      "TLM will give tlib a chance to prompt you for this "
                      "information, then bail out.",
                      gTlibSerPath);
        pauseAndWarn();
        saferTlibbs0(normal, "q");
        failAndExit();
    }
}

void verifyTlibGoodEnough()
{
    char tempConfigFile[TL_MAXSTRSIZE+1]="";
    saferTmpnam(tempConfigFile, sizeof(tempConfigFile));
    FILE *fpConfig=saferFopenOrExit(tempConfigFile, eFopenWrite);
    saferFputs("say %TLIBNAME%\n", fpConfig);
    saferFclose(fpConfig);

    char envSetting[TL_MAXSTRSIZE+1]="";
    DgnStrcpy(envSetting, sizeof(envSetting), "!");
    DgnStrcat(envSetting, sizeof(envSetting), tempConfigFile);
    saferPutenv("TLIBCFG", envSetting);

    char tempVerFile[TL_MAXSTRSIZE+1]="";
    saferTmpnam(tempVerFile, sizeof(tempVerFile));
    redirectOutput(tempVerFile, FALSE);
    int ret=saferTlibbs0(normal, "q");
    closeRedirectedOutput();
    saferPutenv("TLIBCFG", "");
    saferRemove(tempConfigFile, FALSE);

    if(ret != 0)
    {
        PrintWrapped3("Couldn't successfully execute your local version "
                      "of TLIB (%s).  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      tempVerFile, gTlibbsPath, gTlibMinVerStr);
        pauseAndExit();
    }

    char ver[TL_MAXSTRSIZE+1]="";
    FILE *fpVer=saferFopenOrExit(tempVerFile, eFopenRead);
    if(!fgets(ver, TL_MAXSTRSIZE, fpVer))
    {
        PrintWrapped3("Couldn't read first line of TLIB "
                      "output file %s from your local version "
                      "of TLIB (%s).  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      tempVerFile, gTlibbsPath, gTlibMinVerStr);
        pauseAndExit();
    }
    // we now have a string like "TLIB 5.50w/WC-beta, 5 user license. Copr.
    // 1985-1998 Burton Systems Software." and can discriminate based on
    // the version number.
    char *pFirstSpace=strchr(ver, ' ');
    char *shortVer=ver;
    if(pFirstSpace != NULL)
    {
        shortVer=pFirstSpace+1;
    }
    char *pNextSpace=strchr(shortVer, ' ');
    if(pNextSpace != NULL)
    {
        pNextSpace[0]='\0';
    }
    char *pFirstComma=strchr(shortVer, ',');
    if(pFirstComma != NULL)
    {
        pFirstComma[0]='\0';
    }
    char *pFirstSlash=strchr(shortVer, '/');
    if(pFirstSlash != NULL)
    {
        pFirstSlash[0]='\0';
    }
    DgnStrcpy(gTlibCurVerStr, sizeof(gTlibCurVerStr), shortVer);
    parseTlibVersion(gTlibCurVerStr, &gTlibCurVerMajor,
                     &gTlibCurVerMinor, &gTlibCurVerCharacter,
                     "your local version of TLIB", gTlibbsPath);

    verifyTlibVersionGoodEnough("this version of TLM");

    if(!fgets(ver, TL_MAXSTRSIZE, fpVer))
    {
        PrintWrapped3("Couldn't read second line of TLIB "
                      "output file %s from "
                      "your local version of TLIB (%s).  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      tempVerFile, gTlibbsPath, gTlibMinVerStr);
        pauseAndExit();
    }
    // tlibx puts out another line like " (DOS-extended version running in
    // DPMI protected mode, mem avail=66318336)" here, so we have to skip
    // it.
    if(ver[0]==' ' &&
       !fgets(ver, TL_MAXSTRSIZE, fpVer))
    {
        PrintWrapped3("Couldn't read third line of TLIB "
                      "output file %s from "
                      "your local version of TLIB (%s).  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      tempVerFile, gTlibbsPath, gTlibMinVerStr);
        pauseAndExit();
    }
    saferFclose(fpVer);
    
    // We now have a string like "TLIB", "TLIBX", "TLIB2", "TLIB32C", or
    // "TLIBDLL" and will proceed to discriminate against the ones that
    // don't work in this environment.
    trimFinalWhiteSpace(ver);

    if(!_stricmp(ver, "TLIB") ||
       !_stricmp(ver, "TLIBDLL") ||
       !_stricmp(ver, "TLIB2") ||
       !_stricmp(ver, "TLIBX"))
    {
        PrintWrapped3("Your version of TLIB (%s) identifies itself "
                      "as build '%s', which is not supported by TLM.  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      gTlibbsPath, ver, gTlibMinVerStr);
        pauseAndExit();
    }
    else if(!_stricmp(ver, "TLIB32C"))
    {
        // No known problems.
    }
    else
    {
        // Could have been a bad line.  Best to reject.
        PrintWrapped3("Your version of TLIB (%s) identifies itself "
                      "as build '%s', which is not a known build.  "
                      TLM_TLIBBS_PATH_RECOMMENDATION,
                      gTlibbsPath, ver, gTlibMinVerStr);
        pauseAndExit();
    }
    saferRemove(tempVerFile, FALSE);
}

typedef enum WorkNeeds
{
    eEnvOnly,
    eEnvAndTlibOnly,
    eEnvAndTlibAndLocalConfigOnly,
    eEverything,
    eEverythingPlusChangeRestrictions,
    eEverythingPlusChangeAndCheckinRestrictions
} WorkNeeds;

void prepareForWork(WorkNeeds wn)
{
    initEnvironmentVariables();
    if(wn == eEnvAndTlibOnly ||
       wn == eEnvAndTlibAndLocalConfigOnly ||
       wn == eEverything ||
       wn == eEverythingPlusChangeRestrictions ||
       wn == eEverythingPlusChangeAndCheckinRestrictions)
    {
        checkTlibSer();
        verifyTlibGoodEnough();
    }
    if(wn == eEnvAndTlibAndLocalConfigOnly ||
       wn == eEverything ||
       wn == eEverythingPlusChangeRestrictions ||
       wn == eEverythingPlusChangeAndCheckinRestrictions)
    {
        readLocalConfig(wn == eEverythingPlusChangeAndCheckinRestrictions);
    }
    if(wn == eEverythingPlusChangeRestrictions ||
       wn == eEverythingPlusChangeAndCheckinRestrictions)
    {
        if(gbPreventChanges)
        {
            PrintWrapped0("PREVENT_CHANGES=1 setting disallows the "
                          "attempted operation.  Perhaps this is a "
                          "backup directory (in which change operations "
                          "should not be attempted), and/or "
                          "you intended to do this from another "
                          "installation.");
            pauseAndExit();
        }
    }
    if(wn == eEverything ||
       wn == eEverythingPlusChangeRestrictions ||
       wn == eEverythingPlusChangeAndCheckinRestrictions)
    {
        checkNetworkDirectoryPresent();
    }
}

void checkForExtraArguments(int nextArgn, int argc)
{
    if(nextArgn < argc)
    {
        if(!pauseForYesOrNo("\nExtra arguments found on " TLM_NAME
                            " command line.  Execute command anyway?"))
        {
            printf("Exiting...\n");
            failAndExit();
        }
        else
        {
            printf("\n");
        }
    }
}

int main(int argc, char *argv[])
{
    BOOL tlRet=TRUE;
    assert(argv[argc] == NULL);
    int initialArgc=argc;
    char **initialArgv=argv;

    argc--;
    argv++;
    while(argc>0 && argv[0][0] == '-')
    {
        if (!_stricmp(argv[0], "-v"))
        {
            gbVerbose=TRUE;
        }
        else if (!_stricmp(argv[0], "-y"))
        {
            gbAnswerYes=TRUE;
        }
        else if (!_stricmp(argv[0], "-b"))
        {
            gbNeverPause=TRUE;
        }
        else if (!_stricmp(argv[0], "-q"))
        {
            gbNeverBeep=TRUE;
        }
        else if (!_stricmp(argv[0], "-c"))
        {
            tlmCrashIntoDebugger();
        }
        else
        {
            break;
        }
        argc--;
        argv++;
    }

    OSVERSIONINFO verInfo;
    verInfo.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
    if(!GetVersionEx(&verInfo))
    {
        PrintWrapped0("Error: GetVersionEx failed.");
        pauseAndExit();
    }
    else
    {
        gbWinNT = (verInfo.dwPlatformId==VER_PLATFORM_WIN32_NT);
    }

    // Set process priority above normal because otherwise, tasks with
    // frequent file access (like "tlm xcheck") will yield way too much of
    // their time to other processes running at the same time.
    SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
   
    if(0 == GetModuleFileName( 0, gFullTlmPath, TL_MAXSTRSIZE ))
    {
        reportLastErrorAndExit("Couldn't get full path to " TLM_NAME
                               " executable.");
    }

    _strlwr_s(gFullTlmPath, sizeof(gFullTlmPath));
    if(!saferFindFileAllowMismatchedCase(gFullTlmPath))
    {
        PrintWrapped1("Couldn't find %s.", gFullTlmPath);
        pauseAndExit();
    }
    
    BOOL alreadyHandled = FALSE;
    {
        // As long as the keyword isn't checkin or create, interpret any '@'
        // signs in arguments as requests for multiple tlm invokations on
        // their contents.  If the keyword is checkin or create, only
        // interpret an '@' sign immediately following the keyword as a
        // request for multiple tlm invokations.
        //
        // Don't allow '*' or '?' except in special cases.
        //
        // Replace '/' with '\\' except in special cases.
        //
        // We'll clean up after the possible exceptions during
        // checkin/get/diff/install/installv handling (i.e., to avoid
        // somebody cheating by saying something like "tlm get *" or "tlm
        // install g:/foo d:/foo", which gets by this level.)
        BOOL bCommandIsInstall = argc > 0 && !_stricmp(argv[0], "install");
        BOOL bCommandIsInstallv = argc > 0 && !_stricmp(argv[0], "installv");
        BOOL bCommandIsGet = argc > 0 && !_stricmp(argv[0], "get");
        BOOL bCommandIsDiff = argc > 0 && !_stricmp(argv[0], "diff");
        BOOL bCommandIsCheckin = argc > 0 && !_stricmp(argv[0], "checkin");
        BOOL bCommandIsCreate = argc > 0 && !_stricmp(argv[0], "create");
        BOOL bCommandIsQuestionQuestion = (
            argc > 0 && !_stricmp(argv[0], "-??"));
        BOOL bFoundValidAtArgument=FALSE;
        int validAtArgumentIndex=-1;
        for(int arg = 0; arg<argc; arg++)
        {
            if(!bCommandIsInstall &&
               !bCommandIsInstallv &&
               !(bCommandIsCheckin && arg > 1))
            {
                replaceForwardSlashesWithBackslashes(argv[arg]);
            }
            if(strchr(argv[arg], '*') &&
               !(bCommandIsCheckin && arg > 1) &&
               ((!bCommandIsGet && !bCommandIsDiff) ||
                (strcmp(argv[arg], "*") != 0 &&
                 strcmp(argv[arg], "*-1") != 0)))
            {
                PrintWrapped0("Wildcard character '*' is "
                              "not allowed in " TLM_NAME " commands "
                              "except for special cases with "
                              "different semantics in " TLM_NAME
                              " get and " TLM_NAME
                              " diff (see " TLM_NAME
                              " get -? and " TLM_NAME
                              " diff -? for details.)");
                tlRet=FALSE;
                alreadyHandled=TRUE;
                break;
            }
            if(strchr(argv[arg], '?') &&
               !isHelpSwitch(argv[arg]) &&
               !(arg == 0 && bCommandIsQuestionQuestion) &&
               !(bCommandIsCheckin && arg > 1))
            {
                PrintWrapped0("Wildcard character '?' is "
                              "not allowed in " TLM_NAME " commands "
                              "unless it's part of a '-?' help switch.");
                tlRet=FALSE;
                alreadyHandled=TRUE;
                break;
            }
            if(strchr(argv[arg]+1, '@'))
            {
                PrintWrapped0("Response file signifier '@' is only ever "
                              "allowed as the first character of a "
                              "command-line argument.");
                tlRet=FALSE;
                alreadyHandled=TRUE;
                break;
            }
            if(argv[arg][0] == '@' &&
               (arg == 1 ||
                (!bCommandIsCheckin &&
                 !bCommandIsCreate)))
            {
                if(bFoundValidAtArgument)
                {
                    PrintWrapped0("At most one '@' response file argument "
                                  "is allowed per " TLM_NAME " command.");
                    tlRet=FALSE;
                    alreadyHandled=TRUE;
                    break;
                }
                bFoundValidAtArgument=TRUE;
                validAtArgumentIndex=arg;
            }
        }
        if(!alreadyHandled && bFoundValidAtArgument)
        {
            FILE *fpInput;
            if(!saferFopen(&fpInput, argv[validAtArgumentIndex]+1,
                           eFopenRead))
            {
                tlRet=FALSE;
                alreadyHandled=TRUE;
            }
            else
            {
                initialArgv[0] = gFullTlmPath;
                char myCmdLine[TL_MAXSTRSIZE+1]="";
                myCmdLine[0]='\0';
                for(int i=0; i<initialArgc; i++)
                {
                    if(i>0)
                    {
                        DgnStrcat(myCmdLine, sizeof(myCmdLine), " ");
                    }
                    DgnStrcat(myCmdLine, sizeof(myCmdLine), initialArgv[i]);
                }
                printf("\n**** Starting batch: %s ****\n", myCmdLine);

                char buffer[TL_MAXSTRSIZE+1]="";
                argv[validAtArgumentIndex] = buffer;
                int nCommandsExecuted=0;
                int nCommandsFailed=0;
                gbAnswerYes=FALSE;
                while(fgets(buffer, TL_MAXSTRSIZE, fpInput))
                {
                    trimFinalWhiteSpace(buffer);
                    if(buffer[0] != '\0' &&
                       !(buffer[0] == '/' && buffer[1] == '/'))
                    {
                        printf("\n");
                        int childRet=saferSpawn(
                            loud, eCheckRetNone,
                            (const char **) initialArgv);
                        if(childRet!=0)
                        {
                            nCommandsFailed++;
                            BOOL bExit=FALSE;
                            if(childRet==2)
                            {
                                printf("\nChild command failed.\n");
                                bExit=TRUE;
                            }
                            else if(!pauseForYesOrNo(
                                "\nChild command failed.  "
                                "Continue with batch?"))
                            {
                                bExit=TRUE;
                            }
                            if(bExit)
                            {
                                printf("Exiting...\n");
                                failAndExit();
                            }
                        }
                        nCommandsExecuted++;
                    }
                }
                saferFclose(fpInput);
                argv[validAtArgumentIndex]=NULL;
                printf("\n**** Finished batch: %s ****\n", myCmdLine);
                printf("\n**** %d child commands were executed",
                       nCommandsExecuted);
                if(nCommandsFailed > 0)
                {
                    printf("; %d failed", nCommandsFailed);
                }
                printf(" ****\n");
                tlRet=TRUE;
                alreadyHandled=TRUE;
            }
        }
    }

    if (alreadyHandled)
    {
    }
    else if(argc==0 || isHelpSwitch(argv[0]) || !_stricmp(argv[0], "help"))
    {
        checkForExtraArguments(1, argc);
        MultiPrintWrapped0(gHelpStrings);
        tlRet=TRUE;
    }
    else if(!_stricmp(argv[0], "-??"))
    {
        checkForExtraArguments(1, argc);
        MultiPrintWrapped0(gHelpStrings);
        PrintWrapped0("\n");
        showUsage(eCmdAllCommands);
        tlRet=TRUE;
    }
    else if(!_stricmp(argv[0], "doc"))
    {
        checkForExtraArguments(1, argc);
        PrintTextResource(eTlmTxtResource);
        tlRet=TRUE;
    }
    else if(!_stricmp(argv[0], "source"))
    {
        checkForExtraArguments(1, argc);
        // Intentionally undocumented; this is handy if I'm at somneone
        // else's machine and want to get a copy of tlm.cpp to debug with,
        // but don't want to have the hassle of finding it on the network.
        // In this case, I just "tlm source > tlm.cpp", then "cl tlm.cpp".
        // But nobody who can't read the source (i.e. this comment) should
        // need to read the source, so we'll keep it low-key.
        PrintTextResource(eTlmCppResource);
        tlRet=TRUE;
    }
    else if(!_stricmp(argv[0], "ver"))
    {
        // Display version number.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdVer);
        }
        else
        {
            checkForExtraArguments(1, argc);
            prepareForWork(eEnvAndTlibOnly);
            PrintWrapped3("TLM version %s (checked into DevTools by %s on %s)",
                          gTlmVersionNumber, gTlmLastModifier,
                          gTlmLastModifiedTimestamp);
            PrintWrapped2("Compiled by %s on %s", gTlmCompilerName,
                          gTlmCompileDate);
            PrintWrapped0("\n");
            PrintWrapped1("Path to tlib executable is %s.", gTlibbsPath);
            PrintWrapped0("\n");
            tlibVer();
        }
    }
    else if(!_stricmp(argv[0], "sort"))
    {
        // Sort a text file.
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdSort);
        }
        else
        {
            prepareForWork(eEnvOnly);
            BOOL insensitive=FALSE;
            int startColumn=0;
            const char *inFile=NULL;
            const char *outFile=NULL;
            int argn=1;
            if(argn<argc && !_stricmp(argv[argn], "-i"))
            {
                insensitive=TRUE;
                argn++;
            }
            const char *suffix=NULL;
            if(argn<argc)
            {
                suffix=getSuffixOfInsensitivePrefix(
                    "-s", argv[argn]);
                if(suffix!=NULL)
                {
                    argn++;
                    startColumn=atoi(suffix);
                }
            }
            if(argn<argc)
            {
                inFile=argv[argn++];
            }
            if(argn<argc)
            {
                outFile=argv[argn++];
            }
            if(inFile==NULL || outFile==NULL)
            {
                PrintWrapped0("Must specify an input file and "
                              "an output file.");
                tlRet=FALSE;
            }
            else
            {
                checkForExtraArguments(argn, argc);
                saferSort(insensitive, FALSE, FALSE, startColumn, 0, FALSE,
                          inFile, outFile);
                tlRet=TRUE;
            }
        }
    }
    else if(!_stricmp(argv[0], "hash"))
    {
        // Hash a text file; useful for creating a version of a text file
        // that has no actual information, but which roughly resembles the
        // old version in terms of how it will appear to a diff algorithm.
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdHash);
        }
        else
        {
            prepareForWork(eEnvOnly);
            const char *inFile=NULL;
            const char *outFile=NULL;
            inFile=argv[1];
            outFile=argv[2];
            if(inFile==NULL || outFile==NULL)
            {
                PrintWrapped0("Must specify an input file and "
                              "an output file.");
                tlRet=FALSE;
            }
            else
            {
                checkForExtraArguments(3, argc);
                saferHash(inFile, outFile);
                tlRet=TRUE;
            }
        }
    }
    else if(!_stricmp(argv[0], "install"))
    {
        // Install a version-controlled project locally
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdInstall);
        }
        else
        {
            // We really want eEnvAndTlibAndLocalConfigOnly, but we don't
            // have a local config yet, so we'll check that separately from
            // within tlibInstall once we do.
            prepareForWork(eEnvAndTlibOnly);
            int argn=1;
            NewLineTypeEnum newLineType=E_CRLF;
            InstallSubsetType installSubsetType=eInstallPrompt;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-cr"))
                {
                    newLineType = E_CR;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-lf"))
                {
                    newLineType = E_LF;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-crlf"))
                {
                    newLineType = E_CRLF;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-full"))
                {
                    installSubsetType=eInstallFull;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-notopdirs"))
                {
                    installSubsetType=eInstallNoTopdirs;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            char *netDir=(argn<argc ? argv[argn++] : NULL);
            char *localDir=(argn<argc ? argv[argn++] : NULL);
            char *makeDir=(argn<argc ? argv[argn++] : localDir);

            if(netDir==NULL || localDir==NULL || makeDir==NULL)
            {
                PrintWrapped0("Must specify a network directory and "
                              "a local directory.");
                tlRet=FALSE;
            }
            if(tlRet)
            {
                // Clean up after "install" exception in global '/'-handling.
                replaceForwardSlashesWithBackslashes(netDir);
                replaceForwardSlashesWithBackslashes(localDir);
                checkForExtraArguments(argn, argc);
                tlRet=tlibInstall(NULL, NULL, netDir, localDir, makeDir,
                                  newLineType, installSubsetType);
            }
        }
    }
    else if(!_stricmp(argv[0], "installv"))
    {
        // Install the specified version of a version-controlled project
        // locally
        if(argc<4 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdInstallv);
        }
        else
        {
            // We really want eEnvAndTlibAndLocalConfigOnly, but we don't
            // have a local config yet, so we'll check that separately from
            // within tlibInstall once we do.
            prepareForWork(eEnvAndTlibOnly);
            int argn=1;
            NewLineTypeEnum newLineType=E_CRLF;
            InstallSubsetType installSubsetType=eInstallPrompt;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-cr"))
                {
                    newLineType = E_CR;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-lf"))
                {
                    newLineType = E_LF;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-crlf"))
                {
                    newLineType = E_CRLF;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-full"))
                {
                    installSubsetType=eInstallFull;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-notopdirs"))
                {
                    installSubsetType=eInstallNoTopdirs;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            const char *snapVer=(argn<argc ? argv[argn++] : NULL);
            const char *snapshotTxtName="snapshot.txt";
            char *netDir=NULL;
            char *localDir=NULL;
            char *makeDir=NULL;
            // This algorithm for determining what the next argument means
            // is evil, but convenient.
            if(argn<argc)
            {
                if(strchr(argv[argn], ':') == NULL &&
                   strchr(argv[argn], '\\') == NULL)
                {
                    // must be a network directory, so it must be an
                    // alternate snapshot.txt name (such as snap97.txt).
                    snapshotTxtName=argv[argn++];
                }
            }
            if(argn<argc)
            {
                netDir=argv[argn++];
            }
            if(argn<argc)
            {
                localDir=argv[argn++];
            }
            makeDir=(argn<argc ? argv[argn++] : localDir);
            if(snapshotTxtName == NULL || snapVer==NULL ||
               netDir==NULL || localDir==NULL || makeDir==NULL)
            {
                PrintWrapped0("Must specify a snapshot version, "
                              "a network directory, and "
                              "a local directory.");
                tlRet=FALSE;
            }
            if(tlRet && !strcmp(snapVer, "-"))
            {
                PrintWrapped1("Illegal version argument '%s'.", snapVer);
                tlRet=FALSE;
            }
            if(tlRet)
            {
                // Clean up after "installv" exception in global '/'-handling.
                replaceForwardSlashesWithBackslashes(netDir);
                replaceForwardSlashesWithBackslashes(localDir);
                checkForExtraArguments(argn, argc);
                tlRet=tlibInstall(snapshotTxtName, snapVer,
                                  netDir, localDir, makeDir,
                                  newLineType, installSubsetType);
            }
        }
    }
    else if(!_stricmp(argv[0], "forkproj"))
    {
        // Make a new version-controlled project, using a specified project
        // as the basis for the new project's configuration and contents.
        if(argc<5 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdForkproj);
        }
        else
        {
            // We really want eEnvAndTlibAndLocalConfigOnly, but we don't
            // have a local config yet, so we'll check that separately from
            // within tlibInstall once we do.
            prepareForWork(eEnvAndTlibOnly);
            int argn=1;
            const char *oldNetDir=argv[argn++];
            const char *netDir=argv[argn++];
            const char *localDir=argv[argn++];
            const char *newProjectName=argv[argn++];
            const char *newProjectVersionBumpOrOverride=(
                argn<argc ? argv[argn++] : "nobump");
            checkForExtraArguments(argn, argc);
            tlRet=tlibForkproj(oldNetDir, netDir, localDir,
                               newProjectName,
                               newProjectVersionBumpOrOverride);
        }
    }
    else if(!_stricmp(argv[0], "cloneproj"))
    {
        // Make a new version-controlled project, using the current project
        // as the basis for the new project's configuration.
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdCloneproj);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            int argn=1;
            const char *netDir=argv[argn++];
            const char *localDir=argv[argn++];
            const char *rootDir=(argn<argc ? argv[argn++] : localDir);
            checkForExtraArguments(argn, argc);
            char oldNetDir[TL_MAXSTRSIZE+1]="";
            DgnStrcpy(oldNetDir, sizeof(oldNetDir), gNetworkDirectory);
            tlRet=tlibCloneproj(oldNetDir, netDir, localDir, rootDir,
                                NULL, NULL, FALSE);
        }
    }
    else if(!_stricmp(argv[0], "whatsnew"))
    {
        // See what has changed by looking at changes.txt
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdWhatsnew);
        }
        else
        {
            prepareForWork(eEverything);
            BOOL bDisplayDiff=TRUE;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-q"))
                {
                    bDisplayDiff=FALSE;
                    argn++;
                }
            }
            checkForExtraArguments(argn, argc);
            tlRet=tlibWhatsnew(bDisplayDiff);
        }
    }
    else if(!_stricmp(argv[0], "update"))
    {
        // Get newest version of all files being tracked. For this to work,
        // the track parameter in tlib.cfg must be set so that it includes
        // every file you want to track.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdUpdate);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            BOOL bCheckFileExists=TRUE;
            BOOL bVerboseUpdate=FALSE;
            BOOL bJustShow = FALSE;
            BOOL bForceExtractEvenIfAlreadyUpdated=FALSE;
            const char *arg="";
            int argn=1;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-q"))
                {
                    bCheckFileExists=FALSE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-v"))
                {
                    bVerboseUpdate=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-s"))
                {
                    bJustShow=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-f"))
                {
                    bForceExtractEvenIfAlreadyUpdated=TRUE;
                    argn++;
                }
                else
                {
                    arg=argv[argn++];
                    break;
                }
            }
            checkForExtraArguments(argn, argc);
            tlRet=tlibUpdate(bCheckFileExists, bVerboseUpdate, bJustShow,
                             bForceExtractEvenIfAlreadyUpdated, arg);
        }
    }
    else if(!_stricmp(argv[0], "get"))
    {
        // Get revision of a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdGet);
        }
        else
        {
            prepareForWork(eEverything);
            int argn=1;
            BOOL interpretVersionsAsSnapshotVersions=FALSE;
            if(argn<argc && !_stricmp(argv[argn], "-s"))
            {
                interpretVersionsAsSnapshotVersions=TRUE;
                argn++;
            }
            if(argn<argc)
            {
                const char *fileName=argv[argn++];
                const char *ver=(argn<argc ? argv[argn++] : "*");
                const char *destName=(argn<argc ? argv[argn++] : NULL);
                // Clean up after "get" exception in global '*'-handling.
                if(strchr(fileName, '*') ||
                   (destName != NULL && strchr(destName, '*')))
                {
                    PrintWrapped0("Wildcard character '*' is "
                                  "not allowed in filename arguments to "
                                  TLM_NAME " get commands.");
                    tlRet=FALSE;
                }
                if(tlRet && strchr(ver, '*') &&
                   (strcmp(ver, "*") != 0) && (strcmp(ver, "*-1") != 0))
                {
                    PrintWrapped1("Illegal version argument '%s'.", ver);
                    tlRet=FALSE;
                }
                if(tlRet)
                {
                    checkForExtraArguments(argn, argc);
                    tlRet=tlibGet(fileName,
                                  interpretVersionsAsSnapshotVersions,
                                  ver, destName);
                }
            }
            else
            {
                showUsage(eCmdGet);
            }
        }
    }
    else if(!_stricmp(argv[0], "edit") || !_stricmp(argv[0], "checkout"))
    {
        // Check out a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdEdit);
        }
        else
        {
            // A special case to our policy of beeping and pausing when a
            // command fails: when tlm edit is called from the command line,
            // we will not pause for any reason (unless -p is specified).
            // This works around a problem with M, where if you use
            // "M_CHECKOUT=tlm edit" in WinM on Win95, it hangs the TLM
            // process rather than allow any keystrokes back from the user.
            // We'd rather not be interactive when dealing with this case,
            // so we make tlm edit non-interactive in general.
            BOOL bPauseOnWarning=FALSE;
            BOOL bCheckForCurrentVersion=TRUE;
            int argn=1;
            while(argn<argc && argv[argn][0] == '-')
            {
                if(!_stricmp(argv[argn], "-p"))
                {
                    bPauseOnWarning=TRUE;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    bCheckForCurrentVersion=FALSE;
                }
                else
                {
                    break;
                }
                argn++;
            }

            if(!bPauseOnWarning)
            {
                gbNeverPause=TRUE;
            }
            prepareForWork(eEverythingPlusChangeRestrictions);
            if(argc<=argn)
            {
                PrintWrapped0("Must specify a filename.");
                tlRet=FALSE;
            }
            else
            {
                const char *fileName=argv[argn++];
                checkForExtraArguments(argn, argc);
                tlRet=tlibEdit(fileName, bPauseOnWarning,
                               bCheckForCurrentVersion);
            }
        }
    }
    else if(!_stricmp(argv[0], "uncheck") || !_stricmp(argv[0], "unedit"))
    {
        // Lose changes and revert to current network version.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdUncheck);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(2, argc);
            tlRet=tlibUncheck(argv[1]);
        }
    }
    else if(!_stricmp(argv[0], "break"))
    {
        // Break the lock on a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdBreak);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(2, argc);
            tlRet=tlibBreak(argv[1], FALSE);
        }
    }
    else if(!_stricmp(argv[0], "reserve"))
    {
        // Reserve revision of a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdReserve);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            BOOL bForceStrong=FALSE;
            BOOL bCheckForCurrentVersion=TRUE;
            BOOL bMarkLocalReadWrite=FALSE;
            int argn=1;
            while(argn<argc && argv[argn][0] == '-')
            {
                if(!_stricmp(argv[argn], "-s"))
                {
                    bForceStrong=TRUE;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    bCheckForCurrentVersion=FALSE;
                }
                else if(!_stricmp(argv[argn], "-r"))
                {
                    bMarkLocalReadWrite=TRUE;
                }
                else
                {
                    break;
                }
                argn++;
            }
            if(argc<=argn)
            {
                PrintWrapped0("Must specify a filename.");
                tlRet=FALSE;
            }
            else
            {
                const char *fileName=argv[argn++];
                checkForExtraArguments(argn, argc);
                tlRet=tlibReserve(fileName, bForceStrong,
                                  bCheckForCurrentVersion,
                                  bMarkLocalReadWrite);
            }
        }
    }
    else if(!_stricmp(argv[0], "breakres"))
    {
        // Break the lock on a file, then reserve it to you.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdBreakres);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(2, argc);
            if(checkLock(argv[1]) == 1)
            {
                PrintWrapped1("Warning: %s was not checked out, "
                              "so no lock was broken.  Reserving anyway.",
                              argv[1]);
            }
            else
            {
                tlRet=tlibBreak(argv[1], FALSE);
            }
            if(tlRet)
            {
                tlRet=tlibReserve(argv[1], FALSE, TRUE, FALSE);
            }
        }
    }
    else if(!_stricmp(argv[0], "merge") ||
            !_stricmp(argv[0], "mergened"))
    {
        // Merge two revisions of a file with (merge) and without (mergened)
        // checking the file out to you.
        if (argc == 2 && !isHelpSwitch(argv[1]))
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            if(!_stricmp(argv[0], "merge"))
            {
                showUsage(eCmdMerge);
            }
            else
            {
                showUsage(eCmdMergened);
            }
            PrintWrapped0("\n");
            PrintWrapped0("You have not provided a version.");
            PrintWrapped0("\n");
            if(!getFileVersionFromTrack(argv[1], TRUE, FALSE, TRUE,
                                        NULL, NULL))
            {
                tlRet=FALSE;
            }
        }
        else if(argc<3 || isHelpSwitch(argv[1]))
        {
            if(!_stricmp(argv[0], "merge"))
            {
                showUsage(eCmdMerge);
            }
            else
            {
                showUsage(eCmdMergened);
            }
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            BOOL edit=FALSE;
            if(!_stricmp(argv[0], "merge"))
            {
                edit=TRUE;
            }
            if(tlRet && !strcmp(argv[2], "-"))
            {
                PrintWrapped1("Illegal version argument '%s'.", argv[2]);
                tlRet=FALSE;
            }
            if(tlRet)
            {
                checkForExtraArguments(3, argc);
                tlRet=tlibMerge(edit, argv[1], argv[2]);
            }
        }
    }
    else if(!_stricmp(argv[0], "backout"))
    {
        // Check out a file.
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdBackout);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            int argn=1;
            const char *fileName=argv[argn++];
            const char *revNum=argv[argn++];
            checkForExtraArguments(argn, argc);
            tlRet=tlibBackout(fileName, revNum);
        }
    }
    else if(!_stricmp(argv[0], "create"))
    {
        // Add a new library file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdCreate);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            const char *pForkedFromDir=NULL;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-f"))
                {
                    argn++;
                    if(argc<=argn)
                    {
                        PrintWrapped0("Must specify a forked-from directory.");
                        tlRet=FALSE;
                    }
                    else
                    {
                        pForkedFromDir=argv[argn++];
                    }
                }
            }
            if(tlRet)
            {
                if(argc<=argn)
                {
                    PrintWrapped0("Must specify a filename.");
                    tlRet=FALSE;
                }
                else
                {
                    const char *fileName=argv[argn++];
                    const char *pVersion = (argn<argc ? argv[argn++] : "1");
                    // don't checkForExtraArguments, since mergeComments
                    // will eat them all.
                    tlRet=tlibCreate(FALSE, fileName, TRUE,
                                     pForkedFromDir == NULL, TRUE,
                                     pVersion, NULL, pForkedFromDir,
                                     "Initial revision",
                                     argc-argn, (char const **) argv+argn);
                }
            }
        }
    }
    else if(!_stricmp(argv[0], "remove"))
    {
        // Remove a file, preserving library information.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdRemove);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(2, argc);
            tlRet=tlibRemove(argv[1]);
        }
    }
    else if(!_stricmp(argv[0], "unremove"))
    {
        // Unremove a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdUnremove);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(2, argc);
            tlRet=tlibCreate(TRUE, argv[1], TRUE, TRUE, TRUE, NULL, NULL, NULL,
                             NULL, 0, NULL);
        }
    }
    else if(!_stricmp(argv[0], "move"))
    {
        // Move a file from one location to another, preserving library
        // information.
        if(argc<3 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdMove);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            checkForExtraArguments(3, argc);
            tlRet=tlibMove(argv[1], argv[2]);
        }
    }
    else if(!_stricmp(argv[0], "track"))
    {
        // Force a file to be tracked on the network.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdTrack);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);
            BOOL bFirstUntrack=FALSE;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-f"))
                {
                    bFirstUntrack=TRUE;
                    argn++;
                }
            }
            if(argc<=argn)
            {
                PrintWrapped0("Must specify a filename.");
                tlRet=FALSE;
            }
            else
            {
                const char *fileName=argv[argn++];
                checkForExtraArguments(argn, argc);
                tlRet=tlibTrack(fileName, bFirstUntrack);
            }
        }
    }
    else if(!_stricmp(argv[0], "info"))
    {
        // Give information as to which files are
        // currently checked out, and who has them checked out.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdInfo);
        }
        else
        {
            prepareForWork(eEverything);
            if(argc>1)
            {
                if(!_stricmp(argv[1], "-f"))
                {
                    if(argc>2)
                    {
                        checkForExtraArguments(3, argc);
                        tlRet=tlibInfo(argv[2]);
                    }
                    else
                    {
                        tlRet=tlibTlinfo(TRUE, NULL, NULL, "info.001");
                        if(tlRet)
                        {
                            saferSort(TRUE, TRUE, FALSE, 19, 45, FALSE,
                                      "info.001", "info.res");
                            saferRemove("info.001", TRUE);
                            saferSystem0(normal, "type info.res");
                            PrintWrapped0("\n");
                            PrintWrapped0("Information about checked-out "
                                          "files is in info.res\n\n");
                        }
                    }
                }
                else
                {
                    checkForExtraArguments(2, argc);
                    tlRet=tlibInfo(argv[1]);
                }
            }
            else
            {
                tlRet=tlibTlinfo(FALSE, NULL, NULL, "info.001");
                if(tlRet)
                {
                    saferSort(TRUE, TRUE, FALSE, 19, 45, FALSE,
                              "info.001", "info.res");
                    saferRemove("info.001", TRUE);
                    saferSystem0(normal, "type info.res");
                    PrintWrapped0("\n");
                    PrintWrapped0("Information about checked-out "
                                  "files is in info.res\n\n");
                }
            }
        }
    }
    else if(!_stricmp(argv[0], "me"))
    {
        // Give information as to which files are currently checked out by
        // you.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdMe);
        }
        else
        {
            prepareForWork(eEverything);
            checkForExtraArguments(1, argc);
            tlRet=tlibMe();
        }
    }
    else if(!_stricmp(argv[0], "you"))
    {
        // Give information as to which files are currently checked out by
        // some specified user.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdYou);
        }
        else
        {
            prepareForWork(eEverything);
            checkForExtraArguments(2, argc);
            tlRet=tlibYou(argv[1]);
        }
    }
    else if(!_stricmp(argv[0], "xcheck"))
    {
        // Give information as to how the local source tree differs from the
        // network version.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdXcheck);
        }
        else
        {
            BOOL bFull=FALSE;
            BOOL bListOnly=FALSE;
            BOOL bShort=FALSE;
            BOOL bCheckReferenceCopy = TRUE;
            int argn=1;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-f"))
                {
                    bFull=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-s"))
                {
                    bShort=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-l"))
                {
                    bListOnly=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-r"))
                {
                    bCheckReferenceCopy = FALSE;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            prepareForWork(bCheckReferenceCopy ?
                           eEverything :
                           eEnvAndTlibAndLocalConfigOnly);
            checkForExtraArguments(argn, argc);
            tlRet=tlibXcheck(bFull, bShort, bListOnly, NULL, "xcheck.001",
                             bCheckReferenceCopy);
            if(tlRet)
            {
                saferSort(TRUE, TRUE, FALSE, 0, 0, TRUE,
                          "xcheck.001", "xcheck.res");
                saferRemove("xcheck.001", TRUE);
                saferSystem0(normal, "type xcheck.res");
                PrintWrapped0("\n");
                if(bListOnly)
                {
                    PrintWrapped0("A list of all tlib and pointer "
                                  "version-controlled files in the local "
                                  "installation is in xcheck.res.");
                }
                else
                {
                    PrintWrapped0("Information about files that are changed "
                                  "from the network version is in "
                                  "xcheck.res.");
                }
            }
        }
    }
    else if(!_stricmp(argv[0], "xbackup"))
    {
        // Give information as to how the local source tree differs from the
        // network version.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdXbackup);
        }
        else
        {
            BOOL bFull=FALSE;
            BOOL bShort=FALSE;
            BOOL bCheckReferenceCopy = TRUE;
            int argn=1;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-f"))
                {
                    bFull=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-s"))
                {
                    bShort=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-r"))
                {
                    bCheckReferenceCopy = FALSE;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            const char *dirName=(argn<argc ? argv[argn++] : NULL);
            if(dirName==NULL)
            {
                PrintWrapped0("Must specify a destination directory.");
                tlRet=FALSE;
            }
            else
            {
                prepareForWork(bCheckReferenceCopy ?
                               eEverything :
                               eEnvAndTlibAndLocalConfigOnly);
                checkForExtraArguments(argn, argc);
                tlRet=tlibXbackup(bFull, bShort, dirName, bCheckReferenceCopy);
            }
        }
    }
    else if(!_stricmp(argv[0], "history"))
    {
        // Give the history for a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdHistory);
        }
        else
        {
            prepareForWork(eEverything);
            checkForExtraArguments(2, argc);
            tlRet=tlibHistory(argv[1]);
        }
    }
    else if(!_stricmp(argv[0], "infohist"))
    {
        // Give the lock status and recent history for a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdInfohist);
        }
        else
        {
            prepareForWork(eEverything);
            checkForExtraArguments(2, argc);
            tlRet=tlibInfohist(argv[1]);
        }
    }
    else if(!_stricmp(argv[0], "diff"))
    {
        // Give the diff for a file.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdDiff);
        }
        else
        {
            prepareForWork(eEverything);
            const char *fileName=NULL;
            const char *optArg1="*";
            const char *optArg2=NULL;
            BOOL interpretVersionsAsSnapshotVersions=FALSE;
            DiffType diffType=eDiffStandard;
            BOOL displayDiff=TRUE;
            int argn=1;
            while(argn<argc && argv[argn][0] == '-')
            {
                if(!_stricmp(argv[argn], "-s"))
                {
                    interpretVersionsAsSnapshotVersions=TRUE;
                }
                else if(!_stricmp(argv[argn], "-b"))
                {
                    diffType=eDiffStandardIgnoringWhitespace;
                }
                else if(!_stricmp(argv[argn], "-w"))
                {
                    diffType=eDiffWinDiff;
                }
                else if(!_stricmp(argv[argn], "-m"))
                {
                    diffType=eDiffWinMerge;
                }
                else if(!_stricmp(argv[argn], "-t"))
                {
                    diffType=eDiffTlibcomp;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    diffType=eDiffCustom;
                }
                else if(!_stricmp(argv[argn], "-q"))
                {
                    displayDiff=FALSE;
                }
                else
                {
                    break;
                }
                argn++;
            }
            if(argn<argc)
            {
                fileName=argv[argn++];
                if(argn<argc)
                {
                    optArg1=argv[argn++];
                    if(argn<argc)
                    {
                        optArg2=argv[argn++];
                    }
                }
                // Clean up after "diff" exception in global '*'-handling.
                if(strchr(fileName, '*'))
                {
                    PrintWrapped0("Wildcard character '*' is "
                                  "not allowed in filename arguments to "
                                  TLM_NAME " diff commands.");
                    tlRet=FALSE;
                }
                if(tlRet && optArg1 != NULL &&
                   strchr(optArg1, '*') &&
                   (strcmp(optArg1, "*") != 0) &&
                   (strcmp(optArg1, "*-1") != 0))
                {
                    PrintWrapped1("Illegal version argument '%s'.", optArg1);
                    tlRet=FALSE;
                }
                if(tlRet && optArg2 != NULL &&
                   strchr(optArg2, '*') &&
                   (strcmp(optArg2, "*") != 0) &&
                   (strcmp(optArg2, "*-1") != 0))
                {
                    PrintWrapped1("Illegal version argument '%s'.", optArg2);
                    tlRet=FALSE;
                }
                if(tlRet)
                {
                    checkForExtraArguments(argn, argc);
                    tlRet=tlibDiff(fileName, optArg1, optArg2,
                                   interpretVersionsAsSnapshotVersions,
                                   diffType, displayDiff, TRUE);
                }
            }
            else
            {
                showUsage(eCmdDiff);
            }
        }
    }
    else if(!_stricmp(argv[0], "diffall"))
    {
        // Give the diffs for all files currently checked out.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdDiffall);
        }
        else
        {
            prepareForWork(eEverything);
            const char *fileName;
            const char *snapver1=NULL;
            const char *snapver2=NULL;
            DiffType diffType=eDiffStandard;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-b"))
                {
                    diffType=eDiffStandardIgnoringWhitespace;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-w"))
                {
                    diffType=eDiffWinDiff;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-m"))
                {
                    diffType=eDiffWinMerge;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-t"))
                {
                    diffType=eDiffTlibcomp;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    diffType=eDiffCustom;
                    argn++;
                }
            }

            if(argn<argc)
            {
                fileName=argv[argn++];
                if(argn<argc)
                {
                    snapver1=argv[argn++];
                    if(argn<argc)
                    {
                        snapver2=argv[argn++];
                    }
                }
                checkForExtraArguments(argn, argc);
                tlRet=tlibDiffall(fileName, snapver1, snapver2, diffType);
            }
            else
            {
                fileName="tlck.004";
                tlRet=tlibMe();
                if(tlRet)
                {
                    checkForExtraArguments(argn, argc);
                    char currDir[TL_MAXSTRSIZE+1]="";
                    saferGetcwd(currDir, sizeof(currDir));
                    saferChdir(gWorkDirectory);
                    tlRet=tlibDiffall(fileName, snapver1, snapver2, diffType);
                    saferChdir(currDir);
                }
            }
        }
    }
    else if(!_stricmp(argv[0], "prep"))
    {
        // Prepare for a checkin.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdPrep);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            int argn=1;
            char *filename = "tlck.004";
            if(argn<argc)
            {
                filename=argv[argn++];
                tlRet=TRUE;
            }
            else
            {
                tlRet=tlibMe();
            }
            if(tlRet)
            {
                checkForExtraArguments(argn, argc);
                tlRet=tlibPrep(filename);
            }
        }
    }
    else if(!_stricmp(argv[0], "prepdiff"))
    {
        // Prepare for a checkin.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdPrepdiff);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            char *filename = "tlck.004";
            DiffType diffType=eDiffStandard;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-b"))
                {
                    diffType=eDiffStandardIgnoringWhitespace;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-w"))
                {
                    diffType=eDiffWinDiff;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-m"))
                {
                    diffType=eDiffWinMerge;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-t"))
                {
                    diffType=eDiffTlibcomp;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    diffType=eDiffCustom;
                    argn++;
                }
            }

            if(argn<argc)
            {
                filename=argv[argn++];
                tlRet=TRUE;
            }
            else
            {
                tlRet=tlibMe();
            }
            if(tlRet)
            {
                checkForExtraArguments(argn, argc);
                tlRet=tlibPrep(filename);
            }
            if(tlRet)
            {
                char currDir[TL_MAXSTRSIZE+1]="";
                saferGetcwd(currDir, sizeof(currDir));
                saferChdir(gWorkDirectory);
                tlRet=tlibDiffall(filename, NULL, NULL, diffType);
                saferChdir(currDir);
            }
        }
    }
    else if(!_stricmp(argv[0], "modcomm"))
    {
        // Prepare for a checkin.
        int argn=1;
        if(argc<=argn || isHelpSwitch(argv[argn]))
        {
            showUsage(eCmdModcomm);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            const char *commFile=argv[argn++];
            const char *outputFile=(argn<argc ? argv[argn++] : "tlmodcom.001");
            checkForExtraArguments(argn, argc);
            tlRet = tlibModcomm(commFile, outputFile);
        }
    }
    else if(!_stricmp(argv[0], "checkin"))
    {
        // Check in a file.  You lose your lock.
        int argn=1;
        if(argc<=argn || isHelpSwitch(argv[argn]))
        {
            showUsage(eCmdCheckin);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            const char *fileName=argv[argn++];
            // don't checkForExtraArguments, since mergeComments
            // will eat them all.
            tlRet=tlibCheckin(fileName, argc-argn, (char const **) argv+argn);
        }
    }
    else if(!_stricmp(argv[0], "snap"))
    {
        // Make a snapshot
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdSnap);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            BOOL bPredictiveIncrementForControlFiles=FALSE;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-p"))
                {
                    bPredictiveIncrementForControlFiles=TRUE;
                    argn++;
                }
            }
            checkForExtraArguments(argn, argc);
            tlRet=tlibSnap("snapshot.txt",
                           bPredictiveIncrementForControlFiles);
        }
    }
    else if(!_stricmp(argv[0], "addcomm"))
    {
        // Add comments to changes.txt.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdAddcomm);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            int argn=1;
            const char *commentFile = argv[argn++];
            const char *verInFile=(argn<argc ? argv[argn++] : NULL);
            if(verInFile==NULL)
            {
                PrintWrapped0("Bad args to addcomm.");
                tlRet=FALSE;
            }
            if(tlRet)
            {
                checkForExtraArguments(argn, argc);
                tlRet = tlibAddcomm(commentFile, verInFile, FALSE);
            }
        }
    }
    else if(!_stricmp(argv[0], "ckinbeg"))
    {
        // Begin checking in a bunch of files.  Not interactive.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdCkinbeg);
        }
        else
        {
            gbFailureShouldStopBatch=TRUE;  // With ckinbeg, the user
                                            // shouldn't be asked if they
                                            // want to continue after it
                                            // fails.
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            char *versionBumpOrOverride=NULL;
            char *versOut=NULL;
            char *ckinallToVerify=NULL;
            BOOL bCkinallUsesGoodSyntax=FALSE;
            int argn=1;
            if(argn<argc)
            {
                if(!_stricmp(argv[argn], "-c"))
                {
                    argn++;
                    if(argn<argc)
                    {
                        char *ckinallSyntaxVersion=argv[argn++];
                        if(CURRENT_CKINALL_SYNTAX_VERSION ==
                           atoi(ckinallSyntaxVersion))
                        {
                            bCkinallUsesGoodSyntax = TRUE;
                        }
                    }
                    else
                    {
                        PrintWrapped0("Bad args to ckinbeg.");
                        tlRet=FALSE;
                    }
                }
            }
            if(tlRet && !bCkinallUsesGoodSyntax)
            {
                PrintWrapped0("Your ckinall.bat is obsolete, using syntax "
                              "no longer supported by " TLM_NAME ".  "
                              "Please re-prep before checking in.  You "
                              "may want to save your comments.txt and "
                              "ckinall.txt somewhere before doing so, "
                              "so you can refer back to your modifications "
                              "to those files after re-prepping.");
                tlRet=FALSE;
            }
            if(tlRet)
            {
                if(argn<argc && !_stricmp(argv[argn], "-v"))
                {
                    argn++;
                    if(argn<argc)
                    {
                        versOut=argv[argn++];
                    }
                }
                if(versOut==NULL)
                {
                    PrintWrapped0("Bad args to ckinbeg.");
                    tlRet=FALSE;
                }
            }
            if(tlRet)
            {
                if(argn<argc && !_stricmp(argv[argn], "-k"))
                {
                    argn++;
                    if(argn<argc)
                    {
                        ckinallToVerify=argv[argn++];
                    }
                }
                if(ckinallToVerify==NULL)
                {
                    PrintWrapped0("Bad args to ckinbeg.");
                    tlRet=FALSE;
                }
            }
            if(tlRet && argn<argc)
            {
                if(!_stricmp(argv[argn], "-b"))
                {
                    argn++;
                    if(argn<argc)
                    {
                        versionBumpOrOverride=argv[argn++];
                    }
                    if(versionBumpOrOverride==NULL)
                    {
                        PrintWrapped0("Bad args to ckinbeg.");
                        tlRet=FALSE;
                    }
                }
            }
            if(tlRet)
            {
                if(configMaintainEngStyleVersion() !=
                   (versionBumpOrOverride!=NULL))
                {
                    PrintWrapped0("Bad args to ckinbeg.");
                    tlRet=FALSE;
                }
            }
            if(tlRet)
            {
                checkForExtraArguments(argn, argc);
                tlRet=tlibCkinbeg(FALSE, NULL, versionBumpOrOverride, versOut,
                                  ckinallToVerify);
            }
        }
    }
    else if(!_stricmp(argv[0], "ckinend"))
    {
        // Finish checking in a bunch of files.  Not interactive.
        if(argc>1 && isHelpSwitch(argv[1]))
        {
            showUsage(eCmdCkinend);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeAndCheckinRestrictions);
            checkForExtraArguments(1, argc);
            tlRet=tlibCkinend();
        }
    }
    else if(!_stricmp(argv[0], "unsnap"))
    {
        // Make an unsnapshot
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdUnsnap);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);

            BOOL bIncremental=FALSE;
            BOOL bNewer=FALSE;
            BOOL bCheckLibraries=FALSE;
            BOOL bVerbose=FALSE;
            int argn=1;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-i"))
                {
                    bIncremental=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-n"))
                {
                    bNewer=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    bCheckLibraries=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-v"))
                {
                    bVerbose=TRUE;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            if(argn<argc)
            {
                const char *fileName=argv[argn++];
                checkForExtraArguments(argn, argc);
                tlRet=tlibUnsnap(fileName, bIncremental, bNewer,
                                 bCheckLibraries, bVerbose);
            }
            else
            {
                showUsage(eCmdUnsnap);
            }
        }
    }
    else if(!_stricmp(argv[0], "unsnapv"))
    {
        // Make an unsnapshot of a particular version.
        if(argc<2 || isHelpSwitch(argv[1]))
        {
            showUsage(eCmdUnsnapv);
        }
        else
        {
            prepareForWork(eEverythingPlusChangeRestrictions);

            BOOL bIncremental=FALSE;
            BOOL bNewer=FALSE;
            BOOL bCheckLibraries=FALSE;
            BOOL bVerbose=FALSE;
            int argn=1;
            while(argn<argc)
            {
                if(!_stricmp(argv[argn], "-i"))
                {
                    bIncremental=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-n"))
                {
                    bNewer=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-c"))
                {
                    bCheckLibraries=TRUE;
                    argn++;
                }
                else if(!_stricmp(argv[argn], "-v"))
                {
                    bVerbose=TRUE;
                    argn++;
                }
                else
                {
                    break;
                }
            }
            if(argn<argc)
            {
                const char *snapVer=argv[argn++];
                const char *snapshotTxtName=(argn<argc ? argv[argn++] :
                                             "snapshot.txt");
                if(tlRet && !strcmp(snapVer, "-"))
                {
                    PrintWrapped1("Illegal version argument '%s'.", snapVer);
                    tlRet=FALSE;
                }
                if(tlRet)
                {
                    checkForExtraArguments(argn, argc);
                    tlRet=tlibUnsnapv(snapshotTxtName, snapVer,
                                      bIncremental, bNewer, bCheckLibraries,
                                      bVerbose);
                }
            }
            else
            {
                showUsage(eCmdUnsnapv);
            }
        }
    }
    else if(!_stricmp(argv[0], "assumption"))
    {
        PrintWrapped0(TLM_NAME " assumption is obsolete; its documentation "
                      "has been absorbed into " TLM_NAME " doc.");
    }
    else if(!_stricmp(argv[0], "getnamed"))
    {
        PrintWrapped0(TLM_NAME " getnamed is obsolete; its functionality "
                      "has been absorbed into " TLM_NAME " get.  See "
                      TLM_NAME " get -? for details.");
    }
    else if(!_stricmp(argv[0], "mkdir"))
    {
        PrintWrapped0(TLM_NAME " mkdir is obsolete; " TLM_NAME " create can "
                      "automatically make directories when creating files "
                      "in them.");
    }
    else if(!_stricmp(argv[0], "rmdir"))
    {
        PrintWrapped0(TLM_NAME " rmdir is obsolete.");
    }
    else if(!_stricmp(argv[0], "changes"))
    {
        PrintWrapped0(TLM_NAME " changes is obsolete.");
    }
    else if(!_stricmp(argv[0], "split"))
    {
        PrintWrapped0(TLM_NAME " split is obsolete.");
    }
    else
    {
        PrintWrapped1("Unknown keyword %s.", argv[0]);
        tlRet=FALSE;
    }
    if(!tlRet)
    {
        PrintWrapped1("ERROR: " TLM_NAME " %s failed.", argv[0]);
        pauseAndExit();
    }
    return 0;
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
