////////////////////////////////////////////////////////////////////////////
//
//  FILE:         showtime.cpp
//  DATE:         9-Nov-01
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Just print the date and time as one nicely formatted line.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <time.h>

static char *sWeekdayNames[] =
{
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" 
};

static char *sMonthNames[] =
{
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" 
};

int main( int argc, char ** /*argv*/ )
{
    if( argc > 1 ) {
        printf("Usage: showtime\n\n");
        printf("Just print the current date and time as one "
               "nicely formatted line.\n");
        return 1;
    }

    {
        tm localTM;
        tm *pTM = &localTM;
        __time64_t t = _time64(NULL);
        int errnum = _localtime64_s(pTM, &t);
        if(errnum != 0)
        {
            printf("Error: localtime failed.\n");
        }
        else
        {
            printf("%s %s %02d, %04d   %02d:%02d:%02d\n",
                   sWeekdayNames[ pTM->tm_wday ],
                   sMonthNames[ pTM->tm_mon ],
                   pTM->tm_mday,
                   pTM->tm_year + 1900,
                   pTM->tm_hour,
                   pTM->tm_min,
                   pTM->tm_sec);
        }
    }
    
    return 0;
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 showtime.cpp 09-Nov-2001,19:17:52,`JOEV2' Initial revision
// 2 showtime.cpp 09-Nov-2001,19:31:06,`JOEV2' DevTools version 0.0.4
//      Created initial versions of tools files, minor cleanup.
// 3 showtime.cpp 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 showtime.cpp 19-Apr-2006,21:04:10,`JOEV' DevTools version 0.0.135
//      Fixed usage of deprecated functions.
// 5 showtime.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 6 showtime.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
