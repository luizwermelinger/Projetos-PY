////////////////////////////////////////////////////////////////////////////
//
//  FILE:         setclip.cpp
//  DATE:         23-Jun-03
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Set the current clipboard in text format.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _MSC_VER
#include <windows.h>
#endif

int main(int argc, char **argv)
{
    if(argc<=1)
    {
        return 0;
    }
    int allocLen=1;
    for(int i=1; i<argc; i++)
    {
        allocLen+=strlen(argv[i]) + 1;
    }
    char *pStr=(char *)malloc(allocLen);
    pStr[0]='\0';
    for(int j=1; j<argc; j++)
    {
        strcat_s(pStr, allocLen, argv[j]);
        if(j != argc-1)
        {
            strcat_s(pStr, allocLen, " ");
        }
    }
#ifndef _MSC_VER
    printf("Don't know how to set the clipboard on this OS.\n");
    return 0;
#else
    if (OpenClipboard(NULL))
    {
        HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, allocLen);
        if (hGlobal != NULL)
        {
            char *pStrCopy=(char *)GlobalLock(hGlobal);
            if(pStrCopy != NULL)
            {
                strcpy_s(pStrCopy, allocLen, pStr);
                GlobalUnlock(hGlobal);
                if(EmptyClipboard())
                {
                    SetClipboardData(CF_TEXT, hGlobal);
                }
            }
        }
        CloseClipboard();
    }
    return 0;
#endif
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 setclip.cpp 23-Jun-2003,17:59:48,`JOEV3' Initial revision
// 2 setclip.cpp 24-Jun-2003,19:09:58,`JOEV3' DevTools version 0.0.51
//      New utilities.
// 3 setclip.cpp 01-Jul-2003,17:48:38,`JOEV4' DevTools version 0.0.53
//      Minor fixes and cleanup.
// 4 setclip.cpp 19-Apr-2006,21:02:22,`JOEV' DevTools version 0.0.135
//      Fixed usage of deprecated functions.
// 5 setclip.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 6 setclip.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
