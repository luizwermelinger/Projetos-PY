////////////////////////////////////////////////////////////////////////////
//
//  FILE:         showver.cpp
//  DATE:         7-Jan-03
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Show the version number of the specified file.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _MSC_VER
#include <windows.h>
#endif

int main(int argc, char **argv)
{
    if(argc != 2)
    {
        printf("Usage: showver <filename>\n\n");
        printf("Show the version number of the specified file.\n");
        return 1;
    }
    char *pFileName=argv[1];

#ifndef _MSC_VER
    printf("Don't know how to show version numbers on this OS.\n");
    return 0;
#else
    DWORD unk; // Unused
    DWORD dwVerSize = GetFileVersionInfoSize(
        pFileName, &unk );

    if( dwVerSize != 0 )
    {
        BYTE * buffer = new BYTE[ dwVerSize ];
        BOOL bRet = GetFileVersionInfo(
            pFileName, 0, dwVerSize, buffer );

        if(bRet)
        {
            VS_FIXEDFILEINFO *pInfo;
            UINT nSize;
            BOOL bRet = VerQueryValue( buffer, "\\",
                                       (void**)&pInfo, &nSize );
            WORD foundVersion[4] = { 0, 0, 0, 0 };
            if( bRet )
            {
                foundVersion[0] = HIWORD(pInfo->dwFileVersionMS);
                foundVersion[1] = LOWORD(pInfo->dwFileVersionMS);
                foundVersion[2] = HIWORD(pInfo->dwFileVersionLS);
                foundVersion[3] = LOWORD(pInfo->dwFileVersionLS);
                printf("%d.%d.%d.%d\n",
                       foundVersion[0], foundVersion[1],
                       foundVersion[2], foundVersion[3]);
            }
        }
    }
    return 0;
#endif
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 showver.cpp 07-Jan-2003,17:04:20,`JOEV4' Initial revision
// 2 showver.cpp 08-Jan-2003,17:32:20,`JOEV4' DevTools version 0.0.30
// 3 showver.cpp 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 showver.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 5 showver.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
