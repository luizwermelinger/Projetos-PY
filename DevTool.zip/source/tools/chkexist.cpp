////////////////////////////////////////////////////////////////////////////
//
//  FILE:         chkexist.cpp
//  DATE:         9-Nov-01
//  AUTHOR:       Joev Dubach (original author Dean Sturtevant)
//  DESCRIPTION:  A simple executable to return an error condition when a
//                file doesn't exist; very handy for verifying that an item
//                has been successfully built from within pmake.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <io.h>

int main( int argc, char **argv )
{
    if( argc != 2 ) {
        fprintf( stderr, "ERROR: usage is 'chkexist filename'\n" );
        return 1;
    }
    if( _access( argv[1], 0 ) != 0 ) {
        fprintf( stderr, "ERROR: '%s' doesn't exist\n", argv[1] );
        return 1;
    }
    return 0;
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 chkexist.cpp 09-Nov-2001,19:16:04,`JOEV2' Initial revision
// 2 chkexist.cpp 09-Nov-2001,19:31:04,`JOEV2' DevTools version 0.0.4
//      Created initial versions of tools files, minor cleanup.
// 3 chkexist.cpp 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 chkexist.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 5 chkexist.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
