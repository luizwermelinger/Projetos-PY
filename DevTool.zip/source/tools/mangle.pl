############################################################################
#
#  FILE:         mangle.pl
#  DATE:         9-Nov-01
#  AUTHOR:       Joev Dubach (original author David Wald)
#  DESCRIPTION:  Shroud C++ source files.
#
# Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
#
# Copyright protection claimed includes all forms and matters of
# copyrightable material and information now allowed by statutory or
# judicial law or hereinafter granted, including without limitation,
# material generated from the software programs which are displayed
# on the screen such as icons, screen display looks, etc.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#     Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#     Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in
#     the documentation and/or other materials provided with the
#     distribution.
#
#     Neither the name of Nuance Communications, Inc. nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# See end of file for revision history.
#
############################################################################

# Usage: "perl5 -w mangle.pl < foo.cpp > foo2.cpp"
#
# Note that #includes won't work quite right (it'll mangle the include
# header name), but they'll still be #includes, so it'll be obvious how to
# fix them.  Ditto for some other preprocessor things like #pragmas.

@keywords = ( "asm", "auto", "break", "case", "catch", "char",
"class", "const", "continue", "default", "delete", "do", "double",
"else", "enum", "extern", "float", "for", "friend", "goto", "if",
"inline", "int", "long", "namespace",
"new", "operator", "private", "protected",
"public", "register", "return", "short", "signed", "sizeof", "static",
"struct", "switch", "template", "this", "throw", "try", "typedef",
"union", "unsigned", "using", "virtual", "void", "volatile", "while",
"include", "ifdef", "ifndef", "endif", "elif",
"define", "undef", "defined", "pragma" );

@libnames = ("memcpy", "printf", "scanf");

@gcc_keywords = ("format", "noreturn");

%map = ();
foreach (@keywords, @libnames, @gcc_keywords) { $map{$_} = $_; }
$extern_C = "A" . ("_"x1000) . "extern_C";
$map{$extern_C} = "extern \"C\"";

@symgen = ("", "A", "Ba", "Cxa", "Dx00", "Ex000");
$symseed = "D";

while(<>)
{
    s/extern\s+\"C\"/$extern_C/;
    foreach (split(/\b/))
    {
        if (/^\d/ || !/^\w+$/ || /^_/)
        {
            print;
        }
        else
        {
            if (!defined($map{$_})) {
                $i = length;
                # The next three lines produce a little friendlier-looking
                # code by not generating really long mangled symbol names.
                # If you have a bug that depends on symbol length, you may
                # want to comment out these three lines.
                if ($i > 5) {
                    $i = 5;
                }
                if ($i > $#symgen) {
                    for ($j = $#symgen+1; $j <= $i; $j++) {
                        $symgen[$j] = substr( ($symseed++) . "x" . ("0"x$j),
                                              0, $j );
                    }
                }
                $map{$_} = $symgen[$i]++;
            }
            print $map{$_};
        }
    }
}

############################################################################
#
#-DT- *tlib-revision-history*
#-DT- 1 mangle.pl 09-Nov-2001,18:41:10,`JOEV2' Initial revision
#-DT- 2 mangle.pl 09-Nov-2001,18:49:40,`JOEV2' DevTools version 0.0.4
#-DT-      Created initial versions of tools files, minor cleanup.
#-DT- 3 mangle.pl 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
#-DT-      Header cleanup.
#-DT- 4 mangle.pl 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
#-DT-      lint changes.
#-DT- 5 mangle.pl 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
#-DT-      Updated current copyright year.
#-DT- *tlib-revision-history*
#
############################################################################
