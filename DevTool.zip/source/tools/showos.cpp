////////////////////////////////////////////////////////////////////////////
//
//  FILE:         showos.cpp
//  DATE:         9-Nov-01
//  AUTHOR:       Joev Dubach
//  DESCRIPTION:  Just print the OS version, as one nicely formatted line.
//
// Copyright (c) 2001-2007 Nuance Communications, Inc.  All rights reserved.
//
// Copyright protection claimed includes all forms and matters of
// copyrightable material and information now allowed by statutory or
// judicial law or hereinafter granted, including without limitation,
// material generated from the software programs which are displayed
// on the screen such as icons, screen display looks, etc.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//     Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//
//     Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//
//     Neither the name of Nuance Communications, Inc. nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// See end of file for revision history.
//
////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#ifdef _MSC_VER
#include <windows.h>
#endif

int main(int argc, char ** /*argv*/)
{
    if(argc > 1)
    {
        printf("Usage: showos\n\n");
        printf("Just print the OS version, as one nicely formatted line.\n");
        return 1;
    }

#ifndef _MSC_VER
    printf("Unknown\n");
    return 0;
#else
    // Figure out OS
    OSVERSIONINFO os;
    os.dwOSVersionInfoSize = sizeof(os);
    BOOL bRet = GetVersionEx(&os);
    if(!bRet)
    {
        printf("Unknown\n");
        return 0;
    }

    if(os.dwPlatformId == VER_PLATFORM_WIN32s)
    {
        printf("Win32s\n");
    }
    else if(os.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
    {
        // Known versions:
        //  4.0:  Windows 95
        //  4.10: Windows 98
        //  4.90: Windows Me
        if(os.dwMajorVersion == 4 && os.dwMinorVersion == 0)
        {
            printf("Windows 95 build %d", os.dwBuildNumber);
        }
        else if(os.dwMajorVersion == 4 && os.dwMinorVersion == 10)
        {
            printf("Windows 98 build %d", os.dwBuildNumber);
        }
        else if(os.dwMajorVersion == 4 && os.dwMinorVersion == 90)
        {
            printf("Windows Me build %d", os.dwBuildNumber);
        }
        else
        {
            printf("Windows %d.%d build %d",
                   os.dwMajorVersion, os.dwMinorVersion, os.dwBuildNumber);
        }
        if(os.szCSDVersion[0] != '\0')
        {
            printf(" (%s)", os.szCSDVersion);
        }
        printf("\n");
    }
    else if(os.dwPlatformId == VER_PLATFORM_WIN32_NT)
    {
        // Known versions:
        //  3.51: Windows NT 3.51
        //  4.0:  Windows NT 4.0
        //  5.0:  Windows 2000
        //  5.1:  Windows XP (and Windows .NET Server, but we'll ignore that.)
        if(os.dwMajorVersion == 3 && os.dwMinorVersion == 51)
        {
            printf("Windows NT 3.51 build %d", os.dwBuildNumber);
        }
        else if(os.dwMajorVersion == 4 && os.dwMinorVersion == 0)
        {
            printf("Windows NT 4.0 build %d", os.dwBuildNumber);
        }
        else if(os.dwMajorVersion == 5 && os.dwMinorVersion == 0)
        {
            printf("Windows 2000 build %d", os.dwBuildNumber);
        }
        else if(os.dwMajorVersion == 5 && os.dwMinorVersion == 1)
        {
            printf("Windows XP build %d", os.dwBuildNumber);
        }
        else
        {
            printf("Windows NT %d.%d build %d",
                   os.dwMajorVersion, os.dwMinorVersion, os.dwBuildNumber);
        }
        if(os.szCSDVersion[0] != '\0')
        {
            printf(" (%s)", os.szCSDVersion);
        }
        printf("\n");
    }
    else
    {
        printf("Unknown\n");
    }
    return 0;
#endif
}

////////////////////////////////////////////////////////////////////////////
//
// *tlib-revision-history*
// 1 showos.cpp 09-Nov-2001,19:17:18,`JOEV2' Initial revision
// 2 showos.cpp 09-Nov-2001,19:31:06,`JOEV2' DevTools version 0.0.4
//      Created initial versions of tools files, minor cleanup.
// 3 showos.cpp 16-Jun-2003,16:49:56,`JOEV3' DevTools version 0.0.42
//      Header cleanup.
// 4 showos.cpp 14-Dec-2006,11:27:32,`JOEV' DevTools version 0.0.181
//      lint changes.
// 5 showos.cpp 02-Jan-2007,04:19:28,`JOEV' DevTools version 0.0.185
//      Updated current copyright year.
// *tlib-revision-history*
//
////////////////////////////////////////////////////////////////////////////
